﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using VemexPortal_v2.Controls;
using VemexPortal_v2.EntityObjects;


namespace VemexPortal_v2.dataimport
{
    public partial class viewdataimport : PageControl
    {
        public List<Contact> ContactList = new List<Contact>();
       

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ContactList = new ContactControl().GetAuctionContactList();
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                if (flupload.HasFile)
                {
                  
                 //   flupload.PostedFile
                    DataImportService.DataImportClient service = new DataImportService.DataImportClient();

                    string fileExtension = Path.GetExtension(flupload.PostedFile.FileName);
                    string filePath = Server.MapPath("~/") + "ExcelImport/" + Convert.ToString(System.DateTime.Now.Ticks) + fileExtension;
                    string virdir = Convert.ToString(ConfigurationManager.AppSettings["VirtualDirectory"]);
                    virdir = virdir.Replace("/", "").Replace(@"\", "");
                    if (virdir.Length > 2)
                        filePath = filePath.Replace(virdir, @"ImportService");
                    filePath = filePath.Replace("/", @"\");
                    flupload.SaveAs(filePath);
                    HelpControl.AddToLog("File Path : " + filePath);
                    string sellerid = LoginControl.LoggedUser().LoginNumber;


                    string LogFile = CreateServiceLogFile();
                    HelpControl.AddToLog("Service Log File Path : " + LogFile);

                    VemexPortal_v2.DataImportService.ImportFile file = new DataImportService.ImportFile()
                    {
                        FilePath = filePath,
                        FileName = flupload.PostedFile.FileName,
                        FileSize = flupload.PostedFile.ContentLength,
                        SellerId = sellerid,
                        IsSellerImport = true,
                        LogFilePath = LogFile
                    };
                    if (chkAuction.Checked && !string.IsNullOrEmpty(hdnAuctionId.Value))
                    {
                        file.IsSellerImport = false;
                        Guid AuctionId;
                        if (Guid.TryParse(hdnAuctionId.Value, out AuctionId))
                        {
                            file.AuctionUserId = AuctionId;
                        }
                        //file.SellerId = string.Empty;
                    }

                    service.PostFile(file);

                    new ErrorControl("Records will be uploaded to CRM");

                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home", false);
                     
                }
            }
            catch (Exception ex)
            {
                new ErrorControl("Error Occured while uploading Data. Please contact administrator");
                HelpControl.AddToLog("Data Import Event btnUpload_Click : " +ex.Message);
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home", false);
            }
        }

        public string CreateServiceLogFile()
        {

            string today = DateTime.Now.ToLocalTime().ToString("dd-MM-yyyy");

            string filePath = Server.MapPath("~/") + "Log/" + today + ".txt";

            string virdir = Convert.ToString(ConfigurationManager.AppSettings["VirtualDirectory"]);
            
            virdir = virdir.Replace("/", "").Replace(@"\", "");
            if (virdir.Length > 2)
                filePath = filePath.Replace(virdir, @"ImportService");
            filePath = filePath.Replace("/", @"\");

             TextWriter w;
            if (!File.Exists(filePath))
            {

                //path = "co_ sdf .txt";
               FileStream fs = File.Create(filePath);

                fs.Close();

                w = File.AppendText(filePath);
                w.WriteLine("File Created");
                w.Close();
            }
            return filePath;
        }
    }
}