﻿var Contract = {

    isBusy: false,

    Create: function (customerType, firstName, lastName, birthdate, ico, dic, email, phone, street, houseNumber, orientationNumber, postalCode, city, postalStreet, postalHouseNumber, postalOrientationNumber,
                      postalPostalCode, postalCity, companyName, companyIco, companyDic, trustJobTitle, trustFirstName, trustLastName, trustJobTitleSecond, trustFirstNameSecond, trustLastNameSecond, contractTime,
                      productName, supplyPointStreet, supplyPointHouseNumber, supplyPointOrientationNumber, supplyPointPostalCode, supplyPointCity, eic, ean, supplyPointContractReason, supplyPointConsumption,
                      supplyPointConsumptionNT, supplyPointConsumptionVT, supplyPointBreakerValue, supplyPointDistributionAmount, supplyPointConnectionType, supplyPointLastProvider, supplyPointNewDistributionGas, supplyPointNewDistributionElectricity, supplyPointDepositAmount, supplyPointDepositTimeType,
                      supplyPointDeliveryType, supplyPointChangesType, supplyPointDepositPaymentType, supplyPointInvoicePaymentType, supplyPointSIPO, supplyPointBankNumberFirst, supplyPointBankNumberSecond, supplyPointBankCode, successCallback, errorCallback) {

        if (this.isBusy)
            return;
        else
            this.isBusy = true;
       
        var domain = "http://www.creativemages.com/vemex/contractjs/createcontract.aspx",
            params = "?customerType=" + customerType + "&firstName=" + firstName + "&lastName=" + lastName +
                    "&birthdate=" + birthdate + "&ico=" + ico + "&dic=" + dic + "&email=" + email + "&phone=" + phone + "&street=" + street + "&houseNumber=" + houseNumber +
                    "&orientationNumber=" + orientationNumber + "&postalCode=" + postalCode + "&city=" + city + "&postalStreet=" + postalStreet + "&postalHouseNumber=" + postalHouseNumber +
                    "&postalOrientationNumber=" + postalOrientationNumber + "&postalPostalCode=" + postalPostalCode + "&postalCity=" + postalCity +
                    "&companyName=" + companyName + "&companyIco=" + companyIco + "&companyDic=" + companyDic + "&trustJobTitle=" + trustJobTitle + "&trustFirstName=" + trustFirstName + "&trustLastName=" + trustLastName +
                    "&trustJobTitleSecond=" + trustJobTitleSecond + "&trustFirstNameSecond=" + trustFirstNameSecond + "&trustLastNameSecond=" + trustLastNameSecond + "&contractTime=" + contractTime + "&productName=" + productName +
                    "&supplyPointStreet=" + supplyPointStreet + "&supplyPointHouseNumber=" + supplyPointHouseNumber + "&supplyPointOrientationNumber=" + supplyPointOrientationNumber + "&supplyPointPostalCode=" + supplyPointPostalCode + "&supplyPointCity=" + supplyPointCity +
                    "&eic=" + eic + "&ean=" + ean + "&supplyPointContractReason=" + supplyPointContractReason + "&supplyPointConsumption=" + supplyPointConsumption +
                    "&supplyPointConsumptionNT=" + supplyPointConsumptionNT + "&supplyPointConsumptionVT=" + supplyPointConsumptionVT + "&supplyPointBreakerValue=" + supplyPointBreakerValue +
                    "&supplyPointDistributionAmount=" + supplyPointDistributionAmount + "&supplyPointConnectionType=" + supplyPointConnectionType + "&supplyPointLastProvider=" + supplyPointLastProvider + "&supplyPointNewDistributionGas=" + supplyPointNewDistributionGas + "&supplyPointNewDistributionElectricity=" + supplyPointNewDistributionElectricity +
                    "&supplyPointDepositAmount=" + supplyPointDepositAmount + "&supplyPointDepositTimeType=" + supplyPointDepositTimeType + "&supplyPointDeliveryType=" + supplyPointDeliveryType +
                    "&supplyPointChangesType=" + supplyPointChangesType + "&supplyPointDepositPaymentType=" + supplyPointDepositPaymentType + "&supplyPointInvoicePaymentType=" + supplyPointInvoicePaymentType +
                    "&supplyPointSIPO=" + supplyPointSIPO + "&supplyPointBankNumberFirst=" + supplyPointBankNumberFirst + "&supplyPointBankNumberSecond=" + supplyPointBankNumberSecond +
                    "&supplyPointBankCode=" + supplyPointBankCode,
        
            url = domain + params;

        $.ajax({
            dataType: "jsonp",
            jsonpCallback: "callback",
            url: url + "&callback=callback",
            timeout: 25000,
            cache: false,
            success: function (result) {
                this.isBusy = false;
                if (typeof (successCallback) == "function")
                    successCallback(result);
            },
            error: function (result) {
                this.isBusy = false;
                if (typeof (errorCallback) == "function")
                    errorCallback(result);
            }
        });

    }

};