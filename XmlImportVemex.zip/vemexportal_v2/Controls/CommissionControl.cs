﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using VemexPortal.Controls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2.Controls
{
    public class CommissionControl
    {

        public List<Commission> GetCommissionList(PortalRights rights, LoginControl user)
        {

            List<Commission> list = new List<Commission>();

            QueryExpression query = GenerateQuery(rights, user);

            // Obtain results from the query expression.
            EntityCollection ec = ServiceControl.GetService().RetrieveMultiple(query);

            foreach (Entity contact in ec.Entities)
            {
                Commission commission = new Commission();
                commission.Name = contact.Attributes.Contains("cre_name") ? Convert.ToString(contact["cre_name"]) : string.Empty;

                if (contact.Attributes.Contains("cre_reward"))
                {
                    commission.Reward = ((Money)contact.Attributes["cre_reward"]).Value.ToString();
                }
                commission.EIC_EAN =  contact.Attributes.Contains("cre_opm") ? Convert.ToString(contact["cre_opm"]) : string.Empty;
                if (contact.Attributes.Contains("account1.name"))
                {
                    var alias = contact.Attributes["account1.name"] as AliasedValue;
                    commission.AccountName = Convert.ToString(alias.Value);
                }
                if (contact.Attributes.Contains("opportunity2.name"))
                {
                    var alias = contact.Attributes["opportunity2.name"] as AliasedValue;
                    commission.OpportunityName = Convert.ToString(alias.Value);
                }

                list.Add(commission);
            }

            return list;

        }

        private QueryExpression GenerateQuery(PortalRights rights, LoginControl user)
        {
            ColumnSet columns = new ColumnSet(true);
            EntityReference reference = user.ParentCustomer;
            QueryExpression query = new QueryExpression();
            EntityReference currentContact = new EntityReference("contact", user.Id);
            switch (rights.AccessLevel)
            {
                case AccessLevel.kontakt:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Commission,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = { new ConditionExpression { AttributeName = Constants.ComminssionOwner, Operator = ConditionOperator.Equal, Values = {user.Id}},
                                    new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                }
                            },
                           LinkEntities ={
                                        new LinkEntity
                                        {                        
                                           LinkToEntityName  = Constants.Account, LinkToAttributeName = Constants.AccountId, 
                                            LinkFromEntityName = Constants.Commission, LinkFromAttributeName = Constants.CommissionAccount,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        },

                                        new LinkEntity
                                        {                        
                                            LinkToEntityName = Constants.Opportunity,LinkToAttributeName  = Constants.OpportunityId, 
                                            LinkFromEntityName = Constants.Commission,LinkFromAttributeName  = Constants.CommissionOpportunity,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        }                                     
                           }

                        };
                    }
                    break;
                case AccessLevel.account:
                    {
                        if (reference != null)
                        {
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Commission,
                                ColumnSet = columns,
                                Criteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                }
                                },
                                LinkEntities = 
                                    {
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName = Constants.Commission, LinkFromAttributeName = Constants.ComminssionOwner, 
                                            LinkToEntityName = Constants.Contact,
                                            LinkToAttributeName = Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName = Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {reference.Id}}}
                                            }
                                        },
                                          new LinkEntity
                                        {                        
                                           LinkToEntityName  = Constants.Account, LinkToAttributeName = Constants.AccountId, 
                                            LinkFromEntityName = Constants.Commission, LinkFromAttributeName = Constants.CommissionAccount,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        },

                                        new LinkEntity
                                        {                        
                                            LinkToEntityName = Constants.Opportunity,LinkToAttributeName  = Constants.OpportunityId, 
                                            LinkFromEntityName = Constants.Commission,LinkFromAttributeName  = Constants.CommissionOpportunity,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        }        

                                    }
                            };
                        }
                    }
                    break;
                case AccessLevel.organizace:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Commission,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                }
                            },
                           LinkEntities ={
                                        new LinkEntity
                                        {                        
                                           LinkToEntityName  = Constants.Account, LinkToAttributeName = Constants.AccountId, 
                                            LinkFromEntityName = Constants.Commission, LinkFromAttributeName = Constants.CommissionAccount,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        },

                                        new LinkEntity
                                        {                        
                                            LinkToEntityName = Constants.Opportunity,LinkToAttributeName  = Constants.OpportunityId, 
                                            LinkFromEntityName = Constants.Commission,LinkFromAttributeName  = Constants.CommissionOpportunity,
                                           Columns = new ColumnSet(new string[]{"name"}),
                                          JoinOperator = JoinOperator.LeftOuter
                                        }                                     
                           }

                        };
                    }
                    break;
                default:
                    break;
            }
            query.Distinct = true;
            return query;
        }

     
    }
}