﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using VemexPortal.Controls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2.Controls
{
    public class PortalRole
    {
        public PortalRole()
        {
            Rights = new List<PortalRights>();
        }
        public List<PortalRights> Rights { get; set; }

        public string Name { get; set; }
        public Guid Id { get; set;}

        public static PortalRole Getrole(EntityReference crmRole, IOrganizationService service)
        {

            PortalRole role = new PortalRole();
            //Create Query Expression.
            QueryExpression query = GetRightsByRoleQuery(crmRole.Id);

            // Obtain results from the query expression.
            EntityCollection ec = service.RetrieveMultiple(query);

            OptionSetMetadata AccesslLevelSet = Utility.GetOptionSet(Constants.PortalRights, Constants.PortalRightAccessLevel, service);
            OptionSetMetadata EntityNameSet = Utility.GetOptionSet(Constants.PortalRights, Constants.PortalRightEntityName, service);

            foreach (Entity entity in ec.Entities)
            {
                PortalRights right = new PortalRights();
                right.CanCreate = Convert.ToBoolean(entity.Attributes["cre_metevytvoit"]);
                right.CanEdit = Convert.ToBoolean(entity.Attributes["cre_mohouupravovat"]);
                right.CanDelete = Convert.ToBoolean(entity.Attributes["cre_mesmazat"]);
                right.LinkPage = Convert.ToString(entity.Attributes["cre_linkpage"]);

                right.Name = Convert.ToString(entity.Attributes[Constants.CreName]);
                right.Id = (Guid)entity.Attributes[Constants.PortalRightId];
                //AccessLevel
                OptionSetValue option = entity.Attributes[Constants.PortalRightAccessLevel] as OptionSetValue;
                var Accesslevel = AccesslLevelSet.Options.Where(lst => lst.Value == option.Value).FirstOrDefault();
                if (Accesslevel != null)
                    right.AccessLevel = (AccessLevel)Enum.Parse(typeof(AccessLevel), Accesslevel.Label.UserLocalizedLabel.Label);

                //entity name
                option = entity.Attributes[Constants.PortalRightEntityName] as OptionSetValue;
                var EntityName = EntityNameSet.Options.Where(lst => lst.Value == option.Value).FirstOrDefault();
                if(EntityName != null)
                    right.Entity = (Entity_Name)Enum.Parse(typeof(Entity_Name), EntityName.Label.UserLocalizedLabel.Label);

                role.Rights.Add(right);
            }

            Entity roleEntity = service.Retrieve(crmRole.LogicalName, crmRole.Id, new ColumnSet(true));

            if (roleEntity != null)
            {
                role.Id = roleEntity.Id;
                role.Name = roleEntity.Attributes.Contains(Constants.CreName) ? Convert.ToString(roleEntity[Constants.CreName]) : string.Empty;
            }
            return role;
        }

        private static QueryExpression GetRightsByRoleQuery(Guid crmRoleId)
        {
            QueryExpression query = new QueryExpression()
            {
                EntityName = Constants.PortalRights,
                ColumnSet = new ColumnSet(true),
                LinkEntities = 
                {
                    new LinkEntity
                    {
                        
                        LinkFromEntityName = Constants.PortalRights,
                        LinkFromAttributeName = Constants.PortalRightId,                                
                        LinkToEntityName = Constants.PortalRoleRightRelation,                                
                        LinkToAttributeName = Constants.PortalRightId,
                        LinkEntities = 
                        {
                            new LinkEntity
                            {
                                LinkFromEntityName = Constants.PortalRoleRightRelation,
                                LinkFromAttributeName = Constants.PortalRoleId,                                
                                LinkToEntityName = Constants.PortalRole,                                
                                LinkToAttributeName = Constants.PortalRoleId,
                                LinkCriteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions = 
                                    {
                                        new ConditionExpression
                                        {
                                            AttributeName = Constants.PortalRoleId,
                                            Operator = ConditionOperator.Equal,
                                            Values = { crmRoleId }
                                        }
                                    }
                                }
                            }
                        }
                                
                    }
                }
            };

            query.Distinct = true;
            return query;
        }

        public static bool CanEdit(string entityname)
        {
            Entity_Name entity = (Entity_Name)Enum.Parse(typeof(Entity_Name), entityname);
            return ApplyRights(entity, "edit");
        }

        public static bool CanCreate(string entityname)
        {            
            Entity_Name entity = (Entity_Name)Enum.Parse(typeof(Entity_Name), entityname);
            return ApplyRights(entity, "create");
        }
        
        public static bool CanDelete(string entityname)
        {
            Entity_Name entity = (Entity_Name)Enum.Parse(typeof(Entity_Name), entityname);
            return ApplyRights(entity, "delete");
        }

        public static bool CanEdit(Guid id, Entity_Name entity)
        {
            bool canedit = false;
            switch (entity)
            {
                case Entity_Name.kontakt:
                    {
                        canedit = new ContactControl().CanEditContact(id);
                    }
                    break;
            }
            return canedit;
        }
        
       private static bool ApplyRights(Entity_Name entity, string right)
        {
            bool allow = false;
            List<PortalRights> list = GetRights(entity);
            PortalRights rights = null;
            if (list != null)
            {
                switch (right)
                {
                    case "view":
                        {
                            rights = list.FirstOrDefault();
                            break;
                        }
                    case "delete":
                        {
                            rights = list.Where(lst => lst.CanDelete == true).FirstOrDefault();
                            break;
                        }
                    case "create":
                        {
                            rights = list.Where(lst => lst.CanCreate == true).FirstOrDefault();
                            break;
                        }

                    case "edit":
                        {
                            rights = list.Where(lst => lst.CanEdit == true).FirstOrDefault();
                            break;
                        }
                    default:
                        break;
                }
            }
            if (rights != null) allow = true;
           

            return allow;
        }

        internal static bool CanView(Entity_Name entity_Name)
        {
            return ApplyRights(entity_Name, "view");
        }

        public static List<PortalRights> GetRights(Entity_Name entiy_name)
        {
            return LoginControl.Role.Rights.Where(lst => lst.Entity == entiy_name).ToList();
        }

        public static List<PortalRole> GetAllRoles()
        {
            List<PortalRole> Roles = new List<PortalRole>();

            FilterExpression filter = new FilterExpression() { 
                FilterOperator = LogicalOperator.And};

            filter.AddCondition(Constants.StateCode, ConditionOperator.Equal, 0);

            IOrganizationService service = ServiceControl.GetService();

            EntityCollection RoleCollection = Service.RetrieveMultiple(Constants.PortalRole, null, new ColumnSet(true), ServiceControl.GetService());

            foreach (Entity roleEntity in RoleCollection.Entities)
            {

                PortalRole role = new PortalRole();
                //Create Query Expression.
                QueryExpression query = GetRightsByRoleQuery(roleEntity.Id);

                // Obtain results from the query expression.
                EntityCollection ec = service.RetrieveMultiple(query);

                foreach (Entity entity in ec.Entities)
                {
                    PortalRights right = new PortalRights();
                    right.CanCreate = Convert.ToBoolean(entity.Attributes["cre_metevytvoit"]);
                    right.CanEdit = Convert.ToBoolean(entity.Attributes["cre_mohouupravovat"]);
                    right.CanDelete = Convert.ToBoolean(entity.Attributes["cre_mesmazat"]);
                    right.LinkPage = Convert.ToString(entity.Attributes["cre_linkpage"]);
                    right.Name = Convert.ToString(entity.Attributes["cre_name"]);
                    OptionSetValue option = entity.Attributes["cre_pstupovrove"] as OptionSetValue;
                    right.AccessLevel = (AccessLevel)option.Value;
                    option = entity.Attributes["cre_nzevsubjektu"] as OptionSetValue;
                    right.Entity = (Entity_Name)option.Value;
                    role.Rights.Add(right);
                }

                role.Id = roleEntity.Id;
                role.Name = roleEntity.Attributes.Contains(Constants.CreName) ? Convert.ToString(roleEntity[Constants.CreName]) : string.Empty;
                Roles.Add(role);
            }

            return Roles;
        }

        public static List<PortalFieldRight> GetFieldsByRightId(Guid RightId)
        {
            List<PortalFieldRight> list = new List<PortalFieldRight>();

            FilterExpression filter = new FilterExpression();
            filter.AddCondition(Constants.PortalField_PortalRight, ConditionOperator.Equal, RightId);
            filter.FilterOperator = LogicalOperator.And;

            EntityCollection FieldRights = Service.RetrieveMultiple(Constants.PortalFieldRight, filter, new ColumnSet(true), ServiceControl.GetService());

            foreach (Entity entity in FieldRights.Entities)
            {
                PortalFieldRight fieldright = new PortalFieldRight();
                fieldright.Id = entity.Id;
                fieldright.Name = entity.Attributes.Contains(Constants.CreName) ? Convert.ToString(entity[Constants.CreName]) : string.Empty;
                fieldright.Show = entity.Attributes.Contains(Constants.PortalFielRightShow) ? Convert.ToBoolean(entity[Constants.PortalFielRightShow]) : true;
                fieldright.OtherField = entity.Attributes.Contains(Constants.PortalFieldOtherField) ? Convert.ToString(entity[Constants.PortalFieldOtherField]) : string.Empty;
                list.Add(fieldright);
            }
            return list;
        }
    }
}