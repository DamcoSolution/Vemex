﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VemexPortal.Controls
{
    public class DuplicateControl
    {
        public string companyName { get; set; }
        public string companyIco { get; set; }
        public string companyDic { get; set; }
        public string registryRecord { get; set; }
        public string titul { get; set; }
        public string titulLast { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string birthday { get; set; }
        public string ico { get; set; }
        public string dic { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string street { get; set; }
        public string houseNumber { get; set; }
        public string orientationNumber { get; set; }
        public string postalCode { get; set; }
        public string postalCodeValue { get; set; }
        public string city { get; set; }
        public string postalStreet { get; set; }
        public string postalHouseNumber { get; set; }
        public string postalOrientationNumber { get; set; }
        public string postalPostalCode { get; set; }
        public string postalPostalCodeValue { get; set; }
        public string postalCity { get; set; }
        public string trustJobTitle { get; set; }
        public string trustFirstName { get; set; }
        public string trustLastName { get; set; }
        public string trustJobTitleSecond { get; set; }
        public string trustFirstNameSecond { get; set; }
        public string trustLastNameSecond { get; set; }
        public bool contractTimeFirstCheck { get; set; }
        public string contractTimeFirstFrom { get; set; }
        public string contractTimeFirstTo { get; set; }
        public bool contractTimeSecondCheck { get; set; }
        public bool contractTimeSecondOneYears { get; set; }
        public bool contractTimeSecondTwoYears { get; set; }
        public bool contractTimeSecondThreeYears { get; set; }
        public bool contractTimeThirdCheck { get; set; }
        public string contractTimeThirdFrom { get; set; }
        public bool invoiceDeliveryEmailCheck { get; set; }
        public bool invoiceDeliveryPostCheck { get; set; }
        public bool changesDeliveryEmailCheck { get; set; }
        public bool changesDeliveryPostCheck { get; set; }
        public bool changesDeliveryWebCheck { get; set; }
        public bool advancesPaymentTransferCheck { get; set; }
        public bool advancesPaymentCollectionCheck { get; set; }
        public bool advancesPaymentSlipCheck { get; set; }
        public bool advancesPaymentSIPOCheck { get; set; }
        public bool advancesInvoicesTransferCheck { get; set; }
        public bool advancesInvoicesCollectionCheck { get; set; }
        public bool advancesInvoicesSlipCheck { get; set; }
        public string bankNumberFirst { get; set; }
        public string bankNumberSecond { get; set; }
        public string bankCode { get; set; }
        public string SIPONumber { get; set; }
        public bool contractClosedCheck { get; set; }
        public string contractSignature { get; set; }
        public bool smallCheck { get; set; }
        public bool homeCheck { get; set; }
    }
}