﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;

namespace VemexPortal.Controls
{
    public class UrlControl
    {
        public static string GetPathUrl()
        {
            Uri uri = new Uri(HttpContext.Current.Request.Url.AbsoluteUri);
            string port = uri.Port != -1 && uri.Port.ToString() != "80" ? ":" + uri.Port.ToString() : "";
            string url = HttpContext.Current.Request.Url.Host + port;

            for (var i = 0; i < (uri.Segments.Count() - 1); i++)
            {
                if (uri.Segments.Count() > 2)
                    url += uri.Segments[i];
            }
            url = uri.Scheme + "://" + url;

            if (uri.Segments.Count() > 2)
                url = url.Substring(0, url.Length - 1);

            return url;
        }

        public static string GetSiteRootUrl()
        {
            string protocol;

            if (HttpContext.Current.Request.IsSecureConnection)
                protocol = "https";
            else
                protocol = "http";

            StringBuilder uri = new StringBuilder(protocol + "://");

            string hostname = HttpContext.Current.Request.Url.Host;

            uri.Append(hostname);

            int port = HttpContext.Current.Request.Url.Port;

            if (port != 80 && port != 443)
            {
                uri.Append(":");
                uri.Append(port.ToString());
            }
            var virtualDirectory = ConfigurationManager.AppSettings["VirtualDirectory"];
            if (!string.IsNullOrEmpty(virtualDirectory))
                uri.Append(virtualDirectory);

            return uri.ToString();
        }
    }
}