﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using VemexPortal.Controls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2.Controls
{
    public class AccountControl
    {
        public List<Account> GetAllAccount()
        {
            List<Account> list = new List<Account>();

            FilterExpression filter = new FilterExpression()
            {
                FilterOperator = LogicalOperator.And,
                Conditions =
                {
                     new ConditionExpression(Constants.StateCode, ConditionOperator.Equal, 0),
                                    new ConditionExpression(Constants.AccountRoleCode, ConditionOperator.Equal, Constants.AccountRoleId)
                }
            };

            EntityCollection AccountCollection = Service.RetrieveMultiple(Constants.Account, filter, new ColumnSet(true), ServiceControl.GetService());
           
            foreach (Entity accountEntity in AccountCollection.Entities)
            {
                Account account = new Account();

                account.Id = accountEntity.Id;
                account.Name = accountEntity.Attributes.Contains(Constants.Name) ? Convert.ToString(accountEntity[Constants.Name]) : string.Empty;
                account.Prefix = accountEntity.Attributes.Contains(Constants.AccountPrefix) ? Convert.ToString(accountEntity[Constants.AccountPrefix]) : string.Empty;
                account.LastUserId = accountEntity.Attributes.Contains(Constants.AccountLastPortalUserId) ? Convert.ToString(accountEntity[Constants.AccountLastPortalUserId]) : string.Empty;

                list.Add(account);
            }
            return list;
        }

        public static string GetNextUserId(Guid AccountId)
        {
            string lastuserid = string.Empty, nextuserid = string.Empty, accountprefix = string.Empty;
           

            //Entity entity = Service.Retrieve(Constants.Account, AccountId, new ColumnSet(true), ServiceControl.GetService());

            Entity entity = ServiceControl.GetService().Retrieve(Constants.Account, AccountId, new ColumnSet(true));

            if (entity != null)
            {
                lastuserid = entity.Attributes.Contains(Constants.AccountLastPortalUserId) ? Convert.ToString(entity[Constants.AccountLastPortalUserId]) : string.Empty;

                accountprefix = entity.Attributes.Contains(Constants.AccountPrefix) ? Convert.ToString(entity[Constants.AccountPrefix]) : string.Empty;
                int indexof = lastuserid.IndexOf(accountprefix) != -1 ? lastuserid.IndexOf(accountprefix) + accountprefix.Length : 0;
                string useridwithoutprefix = lastuserid.Substring(indexof);

                nextuserid = accountprefix + Convert.ToString(Convert.ToInt16(useridwithoutprefix) + 1).PadLeft(useridwithoutprefix.Length,'0');
            }
            return nextuserid;
        }

        public static void UpdateUserId(Guid AccountId)
        {
            string lastuserid = string.Empty, nextuserid = string.Empty, accountprefix = string.Empty;


            //Entity entity = Service.Retrieve(Constants.Account, AccountId, new ColumnSet(true), ServiceControl.GetService());

            Entity entity = ServiceControl.GetService().Retrieve(Constants.Account, AccountId, new ColumnSet(true));

            if (entity != null)
            {
                lastuserid = entity.Attributes.Contains(Constants.AccountLastPortalUserId) ? Convert.ToString(entity[Constants.AccountLastPortalUserId]) : string.Empty;

                
                accountprefix = entity.Attributes.Contains(Constants.AccountPrefix) ? Convert.ToString(entity[Constants.AccountPrefix]) : string.Empty;
                int indexof = lastuserid.IndexOf(accountprefix) != -1 ? lastuserid.IndexOf(accountprefix) + accountprefix.Length : 0;
                string useridwithoutprefix = lastuserid.Substring(indexof);

                nextuserid = accountprefix + Convert.ToString(Convert.ToInt16(useridwithoutprefix) + 1).PadLeft(useridwithoutprefix.Length, '0');
                    entity[Constants.AccountLastPortalUserId] = entity.Attributes.Contains(Constants.AccountLastPortalUserId) ?
                    nextuserid : string.Empty;

                ServiceControl.GetService().Update(entity);
            }
            
        }
    }
}