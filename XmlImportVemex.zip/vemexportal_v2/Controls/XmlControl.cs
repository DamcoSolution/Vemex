﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using VemexPortal.Controls;

namespace Web.Controls
{
    public class XmlControl
    {
        private XmlDocument document;
        private XmlElement root;
        private XmlNodeList nodes;
        private List<PageControl> xmlList;

        public XmlControl(string fileName)
        {
            document = new XmlDocument();
            document.Load(HttpContext.Current.Server.MapPath("~/" + fileName));
            root = document.DocumentElement;
        }

        public List<PageControl> GetXmlList(string selectNode)
        {
            nodes = root.SelectNodes(selectNode);
            xmlList = new List<PageControl>();

            if (nodes != null)
                foreach (XmlNode node in nodes)
                {
                    xmlList.Add(new PageControl
                    { 
                        title = node["title"] != null ? node["title"].InnerText : string.Empty,
                        description = node["description"] != null ? node["description"].InnerText : string.Empty
                    });
                }
            else
                xmlList = null;

            return xmlList;
        }
    }
}