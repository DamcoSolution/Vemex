﻿$(function () {

    // variables
    var filesCount = 0;

    // form types 
    var $smallCheck = $("#smallCheck"),
        $homeCheck = $("#homeCheck");

    // buttons
    var $saveAndEndBtn = $("#saveAndEndBtn"),
        $postalAddressBtn = $("#postalAddressBtn"),
        $addNewFileBtn = $("#addNewFileBtn"),
        $removeFileBtn = $(".removeFile"),
        $popCloseBtn = $(".popholder .poptop .popclose"),
        $popInputBtn = $(".popholder .popmiddle input"),
        $copyAddressBtn = $("#copyAddressBtn"),
        $copySecondAddressBtn = $("#copySecondAddressBtn"),
        $copyAddressGasBtn = $("#copyAddressGasBtn"),
        $copySecondAddressGasBtn = $("#copySecondAddressGasBtn");

    // form parts
    var $postalAddressPart = $("#postalAddressPart"),
        $uploadFilesPart = $("#uploadFilesPart"),
        $homeParts = $("div[data-id=home]"),
        $smallParts = $("div[data-id=small]"),
        $loading = $(".loadingholder"),
        $popHolder = $(".popholder"),
        $pop = $(".popholder .pop");

    // person detail
    var $firstName = $("#firstNameTxt"),
        $lastName = $("#lastNameTxt"),
        $titul = $("#titulTxt"),
        $lastTitul = $("#lastTitulTxt"),
        $ico = $("#icoTxt"),
        $dic = $("#dicTxt");

    // company detail
    var $companyName = $("#companyNameTxt"),
        $companyIco = $("#companyIcoTxt"),
        $companyDic = $("#companyDicTxt");

    // address
    var $street = $("#streetTxt"),
        $houseNumber = $("#houseNumberTxt"),
        $orientationNumber = $("#orientationNumberTxt"),
        $postalCode = $("#postalCodeTxt"),
        $country = $("#countryTxt"),
        $postalStreet = $("#postalStreetTxt"),
        $postalHouseNumber = $("#postalHouseNumberTxt"),
        $postalOrientationNumber = $("#postalOrientationNumberTxt"),
        $postalPostalCode = $("#postalPostalCodeTxt"),
        $postalCountry = $("#postalCountryTxt");

    // supply point
    var $supplyPointStreet = $("#supplyPointStreetTxt"),
        $supplyPointHouseNumber = $("#supplyPointHouseNumberTxt"),
        $supplyPointOrientationNumber = $("#supplyPointOrientationNumberTxt"),
        $supplyPointPostalCode = $("#supplyPointPostalCodeTxt"),
        $supplyPointCountry = $("#supplyPointCountryTxt"),
        $supplyPointStreetGas = $("#supplyPointStreetGasTxt"),
        $supplyPointHouseNumberGas = $("#supplyPointHouseNumberGasTxt"),
        $supplyPointOrientationNumberGas = $("#supplyPointOrientationNumberGasTxt"),
        $supplyPointPostalCodeGas = $("#supplyPointPostalCodeGasTxt"),
        $supplyPointCountryGas = $("#supplyPointCountryGasTxt"),
        $supplyPointInvoicePaymentTransferCheck = $("#supplyPointInvoicePaymentTransferCheck"),
        $supplyPointNewDistributionTxt = $("#supplyPointNewDistributionTxt"),
        $supplyPointYearSubscriptionAmountTxt = $("#supplyPointYearSubscriptionAmountTxt"),
        $supplyPointNewDistributionGasTxt = $("#supplyPointNewDistributionGasTxt"),
        $supplyPointYearSubscriptionAmountGasTxt = $("#supplyPointYearSubscriptionAmountGasTxt"),
        $supplyPointDepositAmountTxt = $("#supplyPointDepositAmountTxt"),
        $supplyPointDepositAmountGasTxt = $("#supplyPointDepositAmountGasTxt"),
        $supplyPointDepositMonthCheck = $("#supplyPointDepositMonthCheck"),
        $supplyPointDepositQuarterCheck = $("#supplyPointDepositQuarterCheck"),
        $contractTimeYearFive = $("#contractTimeYearFive"),
        $contractTimeYearFirst = $("#contractTimeYearFirst"),
        $contractTimeYearSecond = $("#contractTimeYearSecond"),
        $contractTimeYearThird = $("#contractTimeYearThird"),
        $supplyPointEICText = $("#supplyPointEICTxt"),
        $supplyPointEANText = $("#supplyPointEANTxt")
        $supplyPointYearSubscriptionAmountVTTxt = $("#supplyPointYearSubscriptionAmountVTTxt"),
        $supplyPointYearSubscriptionAmountNTTxt = $("#supplyPointYearSubscriptionAmountNTTxt"),
        $supplyPointDistributionAmountTxt = $("#supplyPointDistributionAmountTxt");

    var $inputsFile = $("input[type=file]"),
        $allInputs = $("input[type=text], input[type=checkbox]");

    // checks switch
    ui.switchchecks("#smallCheck, #homeCheck");
    ui.switchchecks("#resignationUnitMonthCheck, #resignationUnitDayCheck");
    ui.switchchecks("#contractTimeFirstCheck, #contractTimeSecondCheck, #contractTimeThirdCheck", function () {
        $contractTimeYearFive.attr("checked", false);
        $contractTimeYearFirst.attr("checked", false);
        $contractTimeYearSecond.attr("checked", false);
        $contractTimeYearThird.attr("checked", false);
    });
    ui.switchchecks("#contractTimeYearFirst, #contractTimeYearSecond, #contractTimeYearThird, #contractTimeYearFive");
    ui.switchchecks("#supplyPointChangeProviderCheck, #supplyPointChangeCustomerCheck, #supplyPointChangeNewSubscriptionCheck, #supplyPointChangeProviderPriceCheck, #supplyPointOverwriteCheck");
    ui.switchchecks("#supplyPointDepositMonthCheck, #supplyPointDepositQuarterCheck");
    ui.switchchecks("#supplyPointDeliverEmailCheck, #supplyPointDeliverPostCheck");
    ui.switchchecks("#supplyPointChangesDeliverEmailCheck, #supplyPointChangesDeliverPostCheck, #supplyPointChangesDeliverWebCheck");
    ui.switchchecks("#supplyPointDepositPaymentTransferCheck, #supplyPointDepositPaymentCollectionCheck, #supplyPointDepositPaymentSlipCheck, #supplyPointDepositPaymentSIPOCheck");
    ui.switchchecks("#supplyPointInvoicePaymentTransferCheck, #supplyPointInvoicePaymentCollectionCheck, #supplyPointInvoicePaymentSlipCheck");

    // replace value
    ui.replacecount("#noticePeriodTxt, #postalCodeTxt, #supplyPointBreakerAmountTxt, #postalPostalCodeTxt, #supplyPointPostalCodeTxt, #supplyPointPostalCodeGasTxt, #postalCode, #postalPostalCode, #supplyPointPostalCode, #contractNumberTxt, #phoneTxt, #houseNumberTxt, #icoTxt, #companyIcoTxt, #postalHouseNumberTxt, #supplyPointHouseNumberTxt, #supplyPointHouseNumberGasTxt, #supplyPointInvoicePaymentSIPOTxt, #supplyPointBankNumberSecondTxt, #supplyPointBankNumberFirstTxt, #supplyPointBankNumberCodeTxt");

    /* commented for now as thorowing exception wiil revisit again
    ui.replacecountwithline("#supplyPointDepositAmountTxt, #supplyPointDepositAmountTxt, #supplyPointYearSubscriptionAmountGasTxt, #supplyPointDepositAmountGasTxt, #supplyPointYearSubscriptionAmountVTTxt, #supplyPointYearSubscriptionAmountNTTxt");
    */
    // autocomplete 
    AutocompleteInput("#titulAutocomplete");
    AutocompleteInput("#titulLastAutocomplete");
    AutocompleteInput("#distributionAutocomplete");
    AutocompleteInput("#distributionGasAutocomplete");
    AutocompleteInput("#distributionAmountAutocomplete");
    AutocompleteInput("#supplierAutocomplete");
    AutocompleteInput("#supplierGasAutocomplete");

    // events
    $saveAndEndBtn.click(SaveAndEndClick);
    $postalAddressBtn.click(PostalAddressBtnClick);
    $copyAddressBtn.click(CopyAddressClick);
    $copySecondAddressBtn.click(CopySecondAddressClick);
    $copyAddressGasBtn.click(CopyAddressGasClick);
    $copySecondAddressGasBtn.click(CopySecondAddressGasClick);
    $addNewFileBtn.click(AddNewFileClick);
    $popCloseBtn.click(PopCloseClick);
    $popInputBtn.click(PopInputClick);
    $allInputs.click(CheckIfClientIsSelected);
    $removeFileBtn.live("click", RemoveUploadFile);
    $inputsFile.live("change", OnFileChange);
    $ico.change(OnIcoChange);
    $companyIco.change(OnCompanyIcoChange);
    $homeCheck.change(OnHomeChange);
    $smallCheck.change(OnSmallChange);
    $supplyPointYearSubscriptionAmountTxt.change(OnGasYearConsumptionChange);
    $supplyPointDepositMonthCheck.change(OnChangeAmount);
    $supplyPointDepositQuarterCheck.change(OnChangeAmount);
    $supplyPointEICText.change(GetDistributorByEIC);
    $supplyPointEANText.change(GetDistributorByEAN);
    $supplyPointEICText.change(IsEICExists);
    $supplyPointEANText.change(IsEANExists);

    $supplyPointDepositAmountGasTxt.change(OnsupplyPointDepositAmountGasTxtChanged);
    $supplyPointDepositAmountTxt.change(OnsupplyPointDepositAmountTxtChanged);

    //VT change

    $supplyPointYearSubscriptionAmountVTTxt.change(OnChangeAmount);
    $supplyPointYearSubscriptionAmountNTTxt.change(OnChangeAmount);

    $supplyPointYearSubscriptionAmountGasTxt.change(OnChangeAmount);
    // on load
    if ($homeCheck.is(":checked")) {
        $homeParts.show();
        $smallParts.hide();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
        AutocompleteInput("#distributionAmountAutocomplete");
    } else if ($smallCheck.is(":checked")) {
        $homeParts.hide();
        $smallParts.show();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
        AutocompleteInput("#distributionAmountAutocomplete", "C");
    }

    function SaveAndEndClick() {
        if (CheckIfClientIsSelected()) {
            var client = $homeCheck.is(":checked") ? "home" : "small";
            var formSuccess = ValidateForm(client);
            if (formSuccess)
                $loading.show();
            return formSuccess;
        }
        else
            return false;
    }

    function PostalAddressBtnClick() {
        $postalAddressPart.toggle();
        return false;
    }

    function CopyAddressClick() {
        $supplyPointStreet.val($street.val());
        $supplyPointHouseNumber.val($houseNumber.val());
        $supplyPointOrientationNumber.val($orientationNumber.val());
        $supplyPointPostalCode.val($postalCode.val());
        $supplyPointCountry.val($country.val());
        return false;
    }

    function CopyAddressGasClick() {
        $supplyPointStreetGas.val($street.val());
        $supplyPointHouseNumberGas.val($houseNumber.val());
        $supplyPointOrientationNumberGas.val($orientationNumber.val());
        $supplyPointPostalCodeGas.val($postalCode.val());
        $supplyPointCountryGas.val($country.val());
        return false;
    }

    function CopySecondAddressClick() {
        $supplyPointStreet.val($postalStreet.val());
        $supplyPointHouseNumber.val($postalHouseNumber.val());
        $supplyPointOrientationNumber.val($postalOrientationNumber.val());
        $supplyPointPostalCode.val($postalPostalCode.val());
        $supplyPointCountry.val($postalCountry.val());
        return false;
    }

    function CopySecondAddressGasClick() {
        $supplyPointStreetGas.val($postalStreet.val());
        $supplyPointHouseNumberGas.val($postalHouseNumber.val());
        $supplyPointOrientationNumberGas.val($postalOrientationNumber.val());
        $supplyPointPostalCodeGas.val($postalPostalCode.val());
        $supplyPointCountryGas.val($postalCountry.val());
        return false;
    }

    function OnIcoChange() {
        var ico = $(this).val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var name = result.name.split(" ");
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        if (name.length > 2)
                            $titul.val(name[name.length - 3]);
                        $firstName.val(name[name.length - 2]);
                        $lastName.val(name[name.length - 1].replace(",", ""));
                        $dic.val(result.dic.substring(2, result.dic.length));
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnCompanyIcoChange() {
        var ico = $(this).val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        $companyName.val(result.name);
                        $companyDic.val(result.dic);
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnHomeChange() {
        if ($(this).is(":checked")) {
            $homeParts.show();
            $smallParts.hide();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
        }
        else
            $(this).attr("checked", true);
    }

    function OnSmallChange() {
        if ($(this).is(":checked")) {
            $homeParts.hide();
            $smallParts.show();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
        }
        else
            $(this).attr("checked", true);
    }

    function AddNewFileClick() {
        if (filesCount < 14) {
            $uploadFilesPart.append("<div class=\"row\">" +
                                        "<div class=\"file\">" +
                                            "<div class=\"bgleft\"></div>" +
                                            "<div class=\"files\">" +
                                                "<input type=\"file\" name=\"file" + filesCount + "\" /><input type=\"image\" src=\"img/cross.png\" class=\"removeFile\" />" +
                                            "</div>" +
                                            "<div class=\"bgright\"></div>" +
                                        "</div>" +
                                    "</div>");
            filesCount++;
        }
        return false;
    }

    function RemoveUploadFile() {
        filesCount--;
        $(this).parent().parent().parent().remove();
        return false;
    }

    function OnFileChange() {
        if (this.files[0].size > 5242880) {
            alert("Soubor nesmí být větší než 5MB.");
            ClearInputFile($(this));
        }
        else if (!CheckFileType($(this).val())) {
            alert("Špatný formát souboru. Vyberte prosím jiný soubor.");
            ClearInputFile($(this));
        }
    }

    function ClearInputFile($input) {
        $input.val("");
        $input.replaceWith($(this).clone(true));
    }

    function CheckFileType(value) {
        switch (value.substring(value.lastIndexOf(".") + 1).toLowerCase()) {
            case 'gif': case 'jpg': case 'jpeg': case 'doc': case 'docx': case 'xls': case 'xlsx': case 'png': case 'pdf': case 'mp3': case 'wmv': case 'mov':
                return true;
                break;
            default:
                return false;
                break;
        }
    }

    function PopCloseClick() {
        $popHolder.hide();
    }

    function PopInputClick() {
        $loading.show();
        $popHolder.hide();
    }

    function CheckIfClientIsSelected() {
        if ($(this).attr("id") != "smallCheck" && $(this).attr("id") != "homeCheck")
            if (!$smallCheck.is(":checked") && !$homeCheck.is(":checked")) {
                alert("Musíte vybrat Domácnost nebo Maloodběr.");
                $homeCheck.focus();
                return false;
            }
            else
                return true;
    }

    function OnGasYearConsumptionChange() {
        var $this = $(this);
        var val = parseInt($this.val());
        if (val > 629) {
            alert("Roční spotřeba nemůže být větší než 629 MWh.");
            $this.val("");
        }
    }

    function AutocompleteInput(containerId, contains) {

        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
                if ($hiddenInput.attr("id") == "hdnSellerId") {
                    SellerIdChange($hiddenInput.attr("value"));
                }
            },
            change: function (event, ui) {
                if ($hiddenInput.attr("id") == "supplyPointNewDistributionValue" || $hiddenInput.attr("id") == "supplyPointDistributionAmountValue")
                {
                    GetDistributorByEAN();
                }
                else if ($hiddenInput.attr("id") == "supplyPointNewDistributionGasValue") {
                    GetDistributorByEIC();
                }
            }
        });

    }

    function OnChangeAmount() {
        CalculateDepositGas($homeCheck, $supplyPointNewDistributionGasTxt, $supplyPointYearSubscriptionAmountGasTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, $supplyPointDepositAmountGasTxt,false);
        CalculateDeposit($supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountNTTxt, $supplyPointYearSubscriptionAmountVTTxt, $supplyPointDistributionAmountTxt, $supplyPointDepositAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, false);
    }

    function OnsupplyPointDepositAmountGasTxtChanged() {
        CalculateDepositGas($homeCheck, $supplyPointNewDistributionGasTxt, $supplyPointYearSubscriptionAmountGasTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, $supplyPointDepositAmountGasTxt, true);
    }

    function OnsupplyPointDepositAmountTxtChanged() {
        CalculateDeposit($supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountNTTxt, $supplyPointYearSubscriptionAmountVTTxt, $supplyPointDistributionAmountTxt, $supplyPointDepositAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, true);
    }

    function CalculateDeposit(NewDistributor, SubscriptionAmountNT, SubscriptionAmountVT, DistributionAmount, DepositAmount, DepositMonthCheck, DepositQuarterCheck, UpdateOnlyIfLess) {
        if (NewDistributor.val() != "" && DistributionAmount.val() != "" && (SubscriptionAmountNT.val() != "" || SubscriptionAmountVT.val() != "") && (DepositMonthCheck.is(":checked") || DepositQuarterCheck.is(":checked"))) {
            var nt = SubscriptionAmountNT.val() == "" ? 0 : parseFloat(SubscriptionAmountNT.val());
            var vt = SubscriptionAmountVT.val() == "" ? 0 : parseFloat(SubscriptionAmountVT.val());
            var total = DepositAmount.val() != "" ? parseInt(DepositAmount.val()) : 0;

            var depositval = total;
            var success = true;
            switch (NewDistributor.val()) {
                case "PRE Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 5052.14); break;
                        case "C02d": total = (vt * 4402.28); break;
                        case "C03d": total = (vt * 3233.97); break;
                        case "C25d": total = (vt * 4361.11) + (nt * 1893.81); break;
                        case "C26d": total = (vt * 3452.90) + (nt * 1893.81); break;
                        case "C35d": total = (vt * 3289.75) + (nt * 2174.81); break;
                        case "C45d": total = (vt * 2684.38) + (nt * 2242.81); break;
                        case "C55d": total = (vt * 2687.38) + (nt * 2262.81); break;
                        case "C56d": total = (vt * 2667.38) + (nt * 2262.81); break;
                        case "C62d": total = (vt * 2184.86); break;
                        case "D01d": total = (vt * 4211.90); break;
                        case "D02d": total = (vt * 3677.58); break;
                        case "D25d": total = (vt * 4071.09) + (nt * 1780.54); break;
                        case "D26d": total = (vt * 3095.97) + (nt * 1780.54); break;
                        case "D35d": total = (vt * 2752.93) + (nt * 2023.54); break;
                        case "D45d": total = (vt * 2665.93) + (nt * 2160.54); break;
                        case "D55d": total = (vt * 2621.93) + (nt * 2181.54); break;
                        case "D56d": total = (vt * 2621.93) + (nt * 2181.54); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                case "ČEZ Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 4995.15); break;
                        case "C02d": total = (vt * 4436.59); break;
                        case "C03d": total = (vt * 3257.64); break;
                        case "C25d": total = (vt * 4321.91) + (nt * 1888.71); break;
                        case "C26d": total = (vt * 3640.21) + (nt * 1888.71); break;
                        case "C35d": total = (vt * 3358.66) + (nt * 2169.71); break;
                        case "C45d": total = (vt * 2712.30) + (nt * 2237.71); break;
                        case "C55d": total = (vt * 2695.30) + (nt * 2257.71); break;
                        case "C56d": total = (vt * 2695.30) + (nt * 2257.71); break;
                        case "C62d": total = (vt * 2219.45); break;
                        case "D01d": total = (vt * 4524.43); break;
                        case "D02d": total = (vt * 3882.31); break;
                        case "D25d": total = (vt * 4413.03) + (nt * 1792.41); break;
                        case "D26d": total = (vt * 3088.69) + (nt * 1792.41); break;
                        case "D35d": total = (vt * 2785.06) + (nt * 2035.41); break;
                        case "D45d": total = (vt * 2698.06) + (nt * 2172.41); break;
                        case "D55d": total = (vt * 2654.06) + (nt * 2193.41); break;
                        case "D56d": total = (vt * 2654.06) + (nt * 2193.41); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                case "E.ON Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 4932.80); break;
                        case "C02d": total = (vt * 4417.74); break;
                        case "C03d": total = (vt * 3287.24); break;
                        case "C25d": total = (vt * 4362.92) + (nt * 1899.08); break;
                        case "C26d": total = (vt * 3466.47) + (nt * 1899.08); break;
                        case "C35d": total = (vt * 3310.71) + (nt * 2180.08); break;
                        case "C45d": total = (vt * 2679.65) + (nt * 2248.08); break;
                        case "C55d": total = (vt * 2662.65) + (nt * 2268.08); break;
                        case "C56d": total = (vt * 2662.65) + (nt * 2268.08); break;
                        case "C62d": total = (vt * 2158.38); break;
                        case "D01d": total = (vt * 4157.15); break;
                        case "D02d": total = (vt * 3711.05); break;
                        case "D25d": total = (vt * 4118.47) + (nt * 1785.13); break;
                        case "D26d": total = (vt * 2987.13) + (nt * 1785.13); break;
                        case "D35d": total = (vt * 2751.01) + (nt * 2028.13); break;
                        case "D45d": total = (vt * 2664.01) + (nt * 2165.13); break;
                        case "D55d": total = (vt * 2620.01) + (nt * 2186.13); break;
                        case "D56d": total = (vt * 2620.01) + (nt * 2186.13); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                default:
                    success = false;
                    break;
            }
            if (success) {
                if (DepositMonthCheck.is(":checked")) {
                    total = parseInt(total / 12);
                }
                else if (DepositQuarterCheck.is(":checked")) {
                    total = parseInt(total / 4);
                }
                total = (Math.round(total / 100) * 100) + 100;

                if (UpdateOnlyIfLess == false) {
                    DepositAmount.val(total);
                }
                else if (UpdateOnlyIfLess == true && depositval < total) {
                    DepositAmount.val(total);
                }
            }
        }
    }

    function CalculateDepositGas(HomeCheck, NewDistributor, SubscriptionAmount, DepositMonthCheck, DepositQuarterCheck, DepositAmount, UpdateOnlyIfLess) {
        if (NewDistributor.val() != "" && SubscriptionAmount.val() != "" && (DepositMonthCheck.is(":checked") || DepositQuarterCheck.is(":checked"))) {
            var amount = parseFloat(SubscriptionAmount.val());
            var total = DepositAmount.val() != "" ? parseInt(DepositAmount.val()) : 0;
            var depositval = total;
            var success = true;
            switch (NewDistributor.val()) {
                case "E.ON Distribuce":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1701.99;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1144.38;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1039.84;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1018.20;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1008.75;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1000.90;
                        if (amount > 30 && amount <= 35)
                            total = amount * 997.44;
                        if (amount > 35 && amount <= 40)
                            total = amount * 996.72;
                        if (amount > 40 && amount <= 45)
                            total = amount * 993.51;
                        if (amount > 45 && amount <= 50)
                            total = amount * 988.75;
                        if (amount > 50 && amount <= 55)
                            total = amount * 985.02;
                        if (amount > 55 && amount <= 63)
                            total = amount * 981.01;
                        if (amount > 63)
                            total = amount * 935.95;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1732.59;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1174.98;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1070.44;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1048.80;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1039.35;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1031.50;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1028.04;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1027.32;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1024.11;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1019.35;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1015.62;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1011.61;
                        if (amount > 63)
                            total = amount * 966.55;
                    }
                    break;
                case "RWE GasNet":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1650.23;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1172.66;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1077.56;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1070.06;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1064.82;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1059.90;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1059.66;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1057.34;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1053.86;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1051.72;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1050.90;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1049.20;
                        if (amount > 63)
                            total = amount * 1004.20;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1680.83;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1203.26;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1108.16;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1100.66;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1095.42;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1090.50;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1090.26;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1087.94;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1084.46;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1082.32;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1081.50;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1079.80;
                        if (amount > 63)
                            total = amount * 1035.15;
                    }
                    break;
                case "Pražská plynárenská Distribuce":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1553.75;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1036.26;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 958.63;
                        if (amount > 15 && amount <= 20)
                            total = amount * 953.97;
                        if (amount > 20 && amount <= 25)
                            total = amount * 951.17;
                        if (amount > 25 && amount <= 30)
                            total = amount * 946.42;
                        if (amount > 30 && amount <= 35)
                            total = amount * 942.83;
                        if (amount > 35 && amount <= 40)
                            total = amount * 940.26;
                        if (amount > 40 && amount <= 45)
                            total = amount * 939.27;
                        if (amount > 45 && amount <= 50)
                            total = amount * 936.98;
                        if (amount > 50 && amount <= 55)
                            total = amount * 935.50;
                        if (amount > 55 && amount <= 63)
                            total = amount * 931.01;
                        if (amount > 63)
                            total = amount * 895.22;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1584.35;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1066.86;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 989.23;
                        if (amount > 15 && amount <= 20)
                            total = amount * 984.57;
                        if (amount > 20 && amount <= 25)
                            total = amount * 981.77;
                        if (amount > 25 && amount <= 30)
                            total = amount * 977.02;
                        if (amount > 30 && amount <= 35)
                            total = amount * 973.43;
                        if (amount > 35 && amount <= 40)
                            total = amount * 970.86;
                        if (amount > 40 && amount <= 45)
                            total = amount * 969.87;
                        if (amount > 45 && amount <= 50)
                            total = amount * 967.58;
                        if (amount > 50 && amount <= 55)
                            total = amount * 966.10;
                        if (amount > 55 && amount <= 63)
                            total = amount * 961.61;
                        if (amount > 63)
                            total = amount * 925.82;
                    }
                    break;

                case "JMP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1595.36;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1126.93;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1046.00;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1040.16;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1037.87;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1033.07;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1031.39;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1029.84;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1029.04;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1027.88;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1025.74;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1024.47;
                        if (amount > 63)
                            total = amount * 983.51;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1625.96;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1157.53;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1076.60;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1070.76;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1068.47;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1063.67;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1061.99;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1060.44;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1059.64;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1058.48;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1056.34;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1055.07;
                        if (amount > 63)
                            total = amount * 1014.11;
                    }
                    break;
                case "VČP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1675.22;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1199.87;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1088.02;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1082.23;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1077.23;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1072.66;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1068.89;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1065.70;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1063.79;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1062.51;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1061.66;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1059.62;
                        if (amount > 63)
                            total = amount * 1010.97;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1705.82;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1230.47;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1118.62;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1112.83;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1107.83;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1103.26;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1099.49;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1096.30;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1094.39;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1093.11;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1092.26;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1090.22;
                        if (amount > 63)
                            total = amount * 1041.57;
                    }
                    break;
                case "SMP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1650.16;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1176.35;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1084.91;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1073.02;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1067.38;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1062.28;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1061.74;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1060.72;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1058.78;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1057.44;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1055.92;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1053.16;
                        if (amount > 63)
                            total = amount * 1011.41;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1680.76;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1206.95;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1115.51;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1103.62;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1097.98;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1092.88;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1092.34;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1091.32;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1089.38;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1088.04;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1086.52;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1083.76;
                        if (amount > 63)
                            total = amount * 1042.01;
                    }
                    break;
                default:
                    success = false;
                    break;
            }
            if (success) {
                if (DepositMonthCheck.is(":checked")) {
                    total = parseInt(total / 12);
                }
                else if (DepositQuarterCheck.is(":checked")) {
                    total = parseInt(total / 4);
                }
                total = (Math.round(total / 100) * 100) + 100;
		
		if (UpdateOnlyIfLess == false) {
                    DepositAmount.val(total);
                }
                else if (UpdateOnlyIfLess == true && depositval < total) {
                    DepositAmount.val(total);
                }
               
            }
        }
    }

    function GetDistributorByEIC() {
        //var eic = $(this).val();
        var eic = $supplyPointEICText.val();
        if (eic.length == 16) {
            var prefix = eic.substring(0, 4),
                code = eic.substring(4, 5),
                distributorName;
            if (prefix == "27ZG") {
                switch (code) {
                    case "1":
                        distributorName = "Pražská plynárenská Distribuce";
                        break;
                    case "2":
                    case "3":
                    case "4":
                        distributorName = "RWE GasNet";
                        break;
                    case "5":
                        distributorName = "VČP Net";
                        break;
                    case "6":
                        distributorName = "JMP Net";
                        break;
                    case "7":
                        distributorName = "SMP Net";
                        break;
                    case "9":
                        distributorName = "E.ON Distribuce";
                        break;
                }
                var $container = $("#distributionGasAutocomplete");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];
                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        OnChangeAmount();
                    }
                });
            }
        }
    }

    function GetDistributorByEAN() {
        //var ean = $(this).val();
        var ean = $supplyPointEANText.val();
        if (ean.length == 18) {
            var prefix = ean.substring(0, 9),
                code = ean.substring(9, 10),
                distributorName;

            if (prefix == "859182400") {
                switch (code) {
                    case "1":
                    case "2":
                        distributorName = "E.ON Distribuce";
                        break;
                    case "3":
                        distributorName = "PRE Distribuce";
                        break;
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                    case "8":
                        distributorName = "ČEZ Distribuce";
                        break;
                }
                var $container = $("#distributionAutocomplete");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];

                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        OnChangeAmount();
                    }
                });
            }
        }
    }


    function SellerIdChange(sellerId) {
        if (sellerId.length > 0) {
            Ajax.CallWebMethod(
                "obekomodity.aspx/GetNameByUserID",
                { SellerId: sellerId },
                function (response) {
                    if (response.length > 0) {
                        $sellerFirstName.val(response[0]);
                        $sellerLastName.val(response[1]);
                    }
                });
        }
    }


    function IsEICExists() {
        var eic = $supplyPointEICText.val();
        if (eic.length == 16) {
            Ajax.CallWebMethod(
                "plyn.aspx/IsEICExists",
                { eic: eic },
                function (response) {
                    if (response)
                        alert("Smlouva se zadaným EIC již existuje.");
                }
                );
        }
    }

    function IsEANExists() {
        var ean = $supplyPointEANText.val();
        if (ean.length == 18) {
            Ajax.CallWebMethod(
                "elektrina.aspx/IsEANExists",
                { ean: ean },
                function (response) {
                    if (response)
                        alert("Smlouva se zadaným EAN již existuje.");
                }
                );
        }
    }

});