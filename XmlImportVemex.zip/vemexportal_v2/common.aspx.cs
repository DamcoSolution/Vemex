﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.Controls;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2
{
    public partial class common : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static bool SetMenuClick(string rightId)
        {
            Utility.CurrentLinkID = new Guid(rightId);
            return true;
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static string GetPageFieldRights(string rightId)
        {


            // Return JSON data
            JavaScriptSerializer js = new JavaScriptSerializer();

             List<PortalFieldRight> list = PortalRole.GetFieldsByRightId(Utility.CurrentLinkID);

             string retJSON = js.Serialize(list);
            return retJSON;
        }
    }
}