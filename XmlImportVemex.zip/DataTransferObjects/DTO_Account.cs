﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
  public  class DTO_Account
    {
      
      public Guid AccountId { get; set; }
      public string LogicalName
      {
          get
          {
              return "account";
          }
      }

      public DTO_Contact PrimaryContact { get; set; }
      public DTO_Contact ResponsiblePerson1 { get; set; }
      public DTO_Contact ResponsiblePerson2 { get; set; }
      public string Email { get; set; }
      

    }
}
