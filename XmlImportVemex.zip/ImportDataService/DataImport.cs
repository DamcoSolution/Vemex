﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using XmlImportVemex;

namespace ImportDataService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class DataImport : IDataImport
    {
      
        public void PostFile(ImportFile file)
        {
            //upload data file
            ProgramPortal.ImportData(file.FilePath, file.FileName, file.SellerId);
          
        }
    }
}
