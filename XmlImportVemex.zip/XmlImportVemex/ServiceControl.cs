﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Web.Security;
using System.Net;

using System.Configuration;

using System.Web;
using System.Web.Caching;



namespace XmlImportVemex
{
    class ServiceControl
    {
        static IOrganizationService service;

        public static IOrganizationService CreateService()
        {
            try
            {
                //service = CreateCrmService("admin@vemexakvizice5.onmicrosoft.com", "Pass@word1", "vemexakvizice5.crm4.dynamics.com");
                //service = CreateCrmService("admin@vemexakvizice6.onmicrosoft.com", "Pass@word1", "vemexakvizice6.crm4.dynamics.com");
                ///////////////////////service = CreateCrmService("admin@vemexakvizice7.onmicrosoft.com", "Pass@word1", "vemexakvizice7.crm4.dynamics.com");
                service = CreateCrmService(ConfigurationManager.AppSettings["crmEmail"], ConfigurationManager.AppSettings["crmPassword"], ConfigurationManager.AppSettings["crmDomain"]);
                
                //service = CreateCrmService("bilek@vemexenergie.onmicrosoft.com", "3*Vemexenergie*3", "vemexenergie.crm4.dynamics.com");
                return service;
            }
            catch (Exception ex)
            {
                Logger.WriteLine("Chyba: " + ex.Message);
                //Console.WriteLine(" - problém s připojením:");
                //Console.WriteLine("Chyba: " + ex.Message);
                EmaiSender.SendError("consoleApp error", ex.Message);
                return service;
            }
        }

        public static IOrganizationService CreateCrmService(string userName, string password, string url)
        {
            try
            {

                //return CRM.Service.Authentication(userName, password, url);



                Uri organizationUri = new Uri("https://" + url + "/XRMServices/2011/Organization.svc");
                ClientCredentials credentials = new ClientCredentials();
                ClientCredentials DeviceCredentials = Microsoft.Crm.Services.Utility.DeviceIdManager.LoadOrRegisterDevice();
                credentials.UserName.UserName = userName;
                credentials.UserName.Password = password;

                OrganizationServiceProxy _serviceProxy;
                _serviceProxy = new OrganizationServiceProxy(organizationUri, null, credentials, DeviceCredentials);

                service = (IOrganizationService)_serviceProxy;

                //Console.WriteLine(response.UserId.ToString());

                return service;
            }
            catch (Exception ex)
            {
                //Console.WriteLine(" - problém s připojením k internetu");
                //Console.WriteLine("Chyba: " + ex.Message);
                Logger.WriteLine("Chyba: " + ex.Message);
                EmaiSender.SendError("consoleApp CreateService", ex.Message);
                return null;
            }
        }

        public static IOrganizationService GetService()
        {
            return service;
        }

        public static Guid Create(Entity entity, IOrganizationService s)
        {
            try
            {
                //Console.WriteLine("vytvareni entity "+entity.LogicalName);
                
                Guid entity1 = s.Create(entity);

                Logger.WriteLine("vytvareni entity " + entity.LogicalName + " id: " + entity1.ToString());

                return entity1;

            }
            catch (Exception ex)
            {
                Logger.WriteLine(entity.LogicalName + "Chyba: " + ex.Message);
                //EmaiSender.SendError("consoleApp CreateEntity " + entity.LogicalName, ex.Message);
                //Console.WriteLine("Chyba: " + ex.Message);
                EmaiSender.SendError("CRMOnline error", "Error: CRM.Service.RetrieveMultiple was unsuccessful.<br /><br />" +
                "Logical name: " + entity.LogicalName + "<br /><br />" +
                "Message:<br />" + entity.LogicalName + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;
            }
        }
        public static bool EanEicIsOk(string ean, string eic)
        {
            try
            {
                if (ean == "") ean = "nesmyslnahodnota";
                if (eic == "") eic = "nesmyslnahodnota";
                FilterExpression filter = new FilterExpression();
                filter.AddCondition("cre_eanopm", ConditionOperator.Equal, ean);
                filter.AddCondition("cre_eic", ConditionOperator.Equal, eic);
                filter.FilterOperator = LogicalOperator.Or;

                EntityCollection verifiform = RetrieveMultiple("cre_verifyform", filter, new ColumnSet(new string[] { "cre_eanopm", "cre_eic" }), ServiceControl.GetService());

                if (verifiform.Entities.Count() >= 1)
                {
                    return false; 
                }
                else
                    return true;

            }
            catch (Exception ex)
            {
                Logger.WriteLine("Chyba: " + ex.Message);
                //Console.WriteLine("Chyba: " + ex.Message);
                EmaiSender.SendError("CRMOnline error", "Error: CRM.Service.RetrieveMultiple was unsuccessful.<br /><br />" +
                "Logical name: " + "<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;
            }
        }
        public static EntityCollection RetrieveMultiple(string entityName, FilterExpression filter, ColumnSet columnSet, IOrganizationService service)
        {

            try
            {
                QueryExpression query = new QueryExpression();
                query.ColumnSet = columnSet;
                query.EntityName = entityName;
                query.Criteria = filter;

                return service.RetrieveMultiple(query);
            }
            catch (Exception ex)
            {
                Logger.WriteLine("Chyba: " + ex.Message);
                //Console.WriteLine("Chyba: " + ex.Message);
                EmaiSender.SendError("CRMOnline error", "Error: CRM.Service.RetrieveMultiple was unsuccessful.<br /><br />" +
                "Logical name: " + entityName + "<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return new EntityCollection();
            }

        }
        public static bool Update(Entity entity, IOrganizationService service)
        {

            try
            {
                service.Update(entity);
                return true;
            }
            catch (Exception ex)
            {
                Logger.WriteLine(entity.LogicalName + "Chyba: " + ex.Message);
                EmaiSender.SendError("CRMOnline error", "Error: CRM.Service.Update was unsuccessful.<br /><br />" +
                "Logical name: " + entity.LogicalName + "<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;
            }

        }

        public static Entity ExistsContact(string firstName, string lastName, string email, IOrganizationService service, 
            int accountrolecode)
        {

            try
            {
                // filter
                FilterExpression contactRequestFilter = new FilterExpression();


                contactRequestFilter.AddCondition("firstname", ConditionOperator.Equal, firstName);
                contactRequestFilter.AddCondition("lastname", ConditionOperator.Equal, lastName);

                //verifyform contact
                //if(accountrolecode > 0)
                //contactRequestFilter.AddCondition("accountrolecode", ConditionOperator.Equal, accountrolecode);

                if (email != "")
                    contactRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                
                contactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = RetrieveMultiple("contact", contactRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (contactResponse.Entities.Count() >= 1)
                    return contactResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static Entity ExistsAccount(string companyname, string ico, string email, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression accountRequestFilter = new FilterExpression();
                //accountRequestFilter.AddCondition("cre_ico", ConditionOperator.Equal, ico);
                accountRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                accountRequestFilter.AddCondition("name", ConditionOperator.Equal, companyname);
                accountRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection accountResponse = RetrieveMultiple("account", accountRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (accountResponse.Entities.Count() >= 1)
                    return accountResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static Entity ExistsTrustContact(string firstName, string lastName, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression trustContactRequestFilter = new FilterExpression();
                trustContactRequestFilter.AddCondition("firstname", ConditionOperator.Equal, firstName);
                trustContactRequestFilter.AddCondition("lastname", ConditionOperator.Equal, lastName);
                trustContactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = RetrieveMultiple("contact", trustContactRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (contactResponse.Entities.Count() >= 1)
                    return contactResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }


    }
}
