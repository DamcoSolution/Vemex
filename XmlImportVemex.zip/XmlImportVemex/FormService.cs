﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
    class FormService
    {

        static Dictionary<string, GuidMap> guid_map = new Dictionary<string, GuidMap>();

        public static string CreateForms(int contractType, int person, Guid seller_Guid)  //171 140 000 - plyn    171 140 001 - ele,domacnost 0 maloodber 1
        {
            
            Variables.ReduceLenght();

            //Variables.sellerid = Variables.seller_id_auction;
            //
            //Guid seller_Guid = Guid.Empty;
            //
            ////Guid AuctionCheckContact(string AuctionName)
            //
            //if ( Variables.auction_portal_name !="")       
            //    seller_Guid = ContactSeller.AuctionCheckContact(Variables.seller_id_auction);
            //
            //if (Variables.sellerid != "")
            //    seller_Guid = ContactSeller.CheckSeller(Variables.sellerid);



            #region controls

            string errorstring = "";

            enums.titulpred n1;
            enums.titulza n2;
            n1= enums.titulpred.NenalezenTitul;
            n2 = enums.titulza.TitulNenalezen;
            if (Variables.title1P1 == n1.GetHashCode() || Variables.title2P1 == n2.GetHashCode() || Variables.title1P2 == n1.GetHashCode() || Variables.title2P2 == n2.GetHashCode() || Variables.title1C == n1.GetHashCode() || Variables.title2C == n2.GetHashCode() || Variables.title1 == n1.GetHashCode() || Variables.title2 == n2.GetHashCode())
            {
                errorstring += "Titul nenalezen \n";
            }


            if (Variables.streetNumber1.Contains('/'))
            {

                Variables.streetNumber2 = Variables.streetNumber1.Substring(Variables.streetNumber1.IndexOf('/') + 1, Variables.streetNumber1.Length - Variables.streetNumber1.IndexOf('/') - 1);
                Variables.streetNumber1 = Variables.streetNumber1.Substring(0, Variables.streetNumber1.IndexOf('/'));

            }

            if (Variables.takestreetNumber1.Contains('/'))
            {

                Variables.takestreetNumber2 = Variables.takestreetNumber1.Substring(Variables.takestreetNumber1.IndexOf('/') + 1, Variables.takestreetNumber1.Length - Variables.takestreetNumber1.IndexOf('/') - 1);
                Variables.takestreetNumber1 = Variables.takestreetNumber1.Substring(0, Variables.takestreetNumber1.IndexOf('/'));

            }

            if (Variables.streetNumber1.Contains('/'))
            {

                Variables.postalstreetNumber2 = Variables.postalstreetNumber1.Substring(Variables.postalstreetNumber1.IndexOf('/') + 1, Variables.postalstreetNumber1.Length - Variables.postalstreetNumber1.IndexOf('/') - 1);
                Variables.postalstreetNumber1 = Variables.postalstreetNumber1.Substring(0, Variables.postalstreetNumber1.IndexOf('/'));

            }
            bool domacnost = false;
            bool maloodber = false;
            bool plyn = false;
            bool elektrina = false;

            DateTime born1 = DateTime.Now;
            DateTime fromfixedtermcontract1 = DateTime.Now; //od 
            DateTime tofixedtermcontract1 = DateTime.Now; //do
            DateTime fromindefiniteperiodcontract1 = DateTime.Now;
            DateTime dateofsignature1 = DateTime.Now;
            DateTime resignation1 = DateTime.Now;
            DateTime auction_date1 = DateTime.Now;

            if (Variables.born == "31.12.1899 0:00:00")
                Variables.born = "";
            if (Variables.fromfixedtermcontract == "31.12.1899 0:00:00")
                Variables.fromfixedtermcontract = "";
            if (Variables.tofixedtermcontract == "31.12.1899 0:00:00")
                Variables.tofixedtermcontract = "";
            if (Variables.fromindefiniteperiodcontract == "31.12.1899 0:00:00")
                Variables.fromindefiniteperiodcontract = "";
            if (Variables.dateofsignature == "31.12.1899 0:00:00")
                Variables.dateofsignature = "";
            if (Variables.resignation == "31.12.1899 0:00:00")
                Variables.resignation = "";




            if (person == 171140000) domacnost = true;
            else if (person == 171140001) maloodber = true;
            else { errorstring += "person error \n"; }
            if (contractType == 171140000) plyn = true;
            else if (contractType == 171140001) elektrina = true;
            else { errorstring += "contractType error \n"; }

            //if (contractId == "") errorstring += "číslo návrhu\n"; //cislo navrhu
            if (contractType < 171140000 || contractType > 171140001) errorstring += "contractType error \n";//plyn,elektrina
            if (person < 171140000 || person > 171140001) errorstring += "person error \n";// domacnost,maloodber

            if (domacnost == true)
            {
                if (Variables.firstName == "") errorstring += "Jméno \n";
                if (Variables.lastName == "") errorstring += "Příjmení \n";

                if (Variables.born != "")
                {
                    try
                    {
                        born1 = DateTime.Parse(Variables.born);
                        int age = DateTime.Now.Year - born1.Year;
                        if (DateTime.Now.Month < born1.Month || (DateTime.Now.Month == born1.Month && DateTime.Now.Day < born1.Day)) age--;
                        if (age < 18) errorstring += "Věk je menší než 18 let \n";
                        if (born1.Year < 1901)
                        {
                            Variables.born = "";
                            errorstring += "Věk - chyba formátu \n";
                        }

                        
                    }
                    catch (Exception)
                    {
                        errorstring += "Věk - chyba formátu \n";
                        Variables.born = "";
                    }
                }
                if (Variables.ico != "" && Variables.ico.Length != 8) errorstring += "IČO \n";
                if (Variables.dic != "" && Helper.IsValidDic(Variables.dic) == false) errorstring += "DIČ \n";

                if (Variables.born == "" && Variables.ico == "") errorstring += "Věk nebo IČO chybí \n";// domacnost,maloodber
                if (Variables.email == "" && Variables.phoneNumber == "") errorstring += "E-mail nebo Telefon chybí \n";
                if (Variables.email != "" && Helper.IsValidEmail(Variables.email) == false) errorstring += "E-mail nemá správný formát \n";
                Variables.companyName = "";  //nektere udaje pro domacnost nepotrebuji
                Variables.p1_firstName = "";
                Variables.p1_lastName = "";
                Variables.p1_function = "";
                Variables.p2_firstName = "";
                Variables.p2_lastName = "";
                Variables.p2_function = "";
                Variables.title1P1 = enums.titulpred.Default.GetHashCode();
                Variables.title2P1 = enums.titulza.Default.GetHashCode();
                Variables.title1P2 = enums.titulpred.Default.GetHashCode();
                Variables.title2P2 = enums.titulza.Default.GetHashCode();
                Variables.sexP1 = enums.sex.Default.GetHashCode();
                Variables.sexP2 = enums.sex.Default.GetHashCode();
                Variables.contact_firstName = "";
                Variables.contact_lastName = "";
                Variables.title1C = enums.titulpred.Default.GetHashCode();
                Variables.title2C = enums.titulza.Default.GetHashCode();
                Variables.sexC = enums.sex.Default.GetHashCode();
                }

            if (maloodber == true)
            {
                if (Variables.ico.Length != 8) errorstring += "IČO \n";
                if (Variables.dic != "" && Helper.IsValidDic(Variables.dic) == false) errorstring += "DIČ \n";
                if (Variables.companyName == "") errorstring += "Název společnosti \n";
                if (Variables.p1_firstName == "") errorstring += "Jméno odpovědné osoby 1 \n";
                if (Variables.p1_lastName == "") errorstring += "Příjmení odpovědné osoby 1 \n";
                if (Variables.email == "" || Variables.phoneNumber == "") errorstring += "E-mail, telefon chybí \n";
                if (Variables.email != "" && Helper.IsValidEmail(Variables.email) == false) errorstring += "E-mail nemá správný formát \n";
                Variables.firstName = ""; //nektere udaje pro maloodber nepotrebuji
                Variables.lastName = "";
                Variables.born = "";
                Variables.sex = enums.sex.Default.GetHashCode(); ;

            }
            if (Variables.street == "") errorstring += "Ulice sídla \n";
            if (Variables.streetNumber1 == "") errorstring += "Číslo popisné sídla \n";
            if (Variables.city == "") errorstring += "Obec sídla \n";
            if (Variables.zipcode == "") errorstring += "PSČ sídla \n";
            else if (!Variables.zipcode.Contains(' '))
                try
                {
                    Variables.zipcode = Variables.zipcode.Insert(Variables.zipcode.Length - 2, " ");
                }
                catch
                {
                }

            if (Variables.postalstreet == "" && Variables.postalstreetNumber1 == "" && Variables.postalstreetNumber2 == "" && Variables.postalzipcode == "" && Variables.postalcity == "")
            {
                Variables.postalstreet = Variables.street;
                Variables.postalstreetNumber1 = Variables.streetNumber1;
                Variables.postalstreetNumber2 = Variables.streetNumber2;
                Variables.postalzipcode = Variables.zipcode;
                Variables.postalcity = Variables.city;
            }
            else
            {
                if (Variables.postalstreet == "") errorstring += "Korespondenční ulice \n";
                if (Variables.postalstreetNumber1 == "") errorstring += "Korespondenční číslo popisné \n";
                if (Variables.postalcity == "") errorstring += "Korespondenční obec \n";
                if (Variables.postalzipcode == "") errorstring += "Korespondenční PSČ \n";
                else if (!Variables.postalzipcode.Contains(' '))
                    try
                    {
                        Variables.postalzipcode = Variables.postalzipcode.Insert(Variables.postalzipcode.Length - 2, " ");
                    }
                    catch
                    {
                    }
            }

            int oneOptions = 0;
            if (Variables.fixedtermcontract == true) oneOptions++;
            if (Variables.fixedtermcontract1 == true) oneOptions++;
            if (Variables.indefiniteperiodcontract == true) oneOptions++;
            if (oneOptions != 1)
            {
                errorstring += "Je potřeba vybrat jednu z možností: Smlouva na dobu určitou, Smlouva na dobu určitou roky, Smlouva na dobu neurčitou \n";
            }
            else
            {
                if (Variables.fixedtermcontract == true)
                {

                    try
                    {
                        fromfixedtermcontract1 = DateTime.Parse(Variables.fromfixedtermcontract);
                        if (fromfixedtermcontract1.Year < 1901)
                        {
                            Variables.fromfixedtermcontract = "";
                            errorstring += "Od doba určitá - chyba formátu \n";
                        }

                    }
                    catch (Exception)
                    {
                        errorstring += "Od doba určitá \n";
                        Variables.fromfixedtermcontract = "";
                    }

                    try
                    {
                        tofixedtermcontract1 = DateTime.Parse(Variables.tofixedtermcontract);
                        if (tofixedtermcontract1.Year < 1901)
                        {
                            Variables.tofixedtermcontract = "";
                            errorstring += "Do - chyba formátu \n";
                        }
                    }
                    catch (Exception)
                    {
                        errorstring += "Do\n";
                        Variables.tofixedtermcontract = "";
                    }
                    Variables.fromindefiniteperiodcontract = "";
                    Variables.fixedtermcontractyears = enums.fixedtermcontractyears.Default.GetHashCode();


                }
                else if (Variables.fixedtermcontract1 == true)
                {
                    if (Variables.fixedtermcontractyears.GetHashCode() < 171140000) errorstring += "Roky \n";
                    Variables.fromindefiniteperiodcontract = "";
                    //fromfixedtermcontract = "";
                    try
                    {
                        fromfixedtermcontract1 = DateTime.Parse(Variables.fromfixedtermcontract);
                        if (fromfixedtermcontract1.Year < 1901)
                        {
                            Variables.fromfixedtermcontract = "";
                            errorstring += "Od doba určitá - chyba formátu \n";
                        }
                    }
                    catch (Exception)
                    {
                        errorstring += "Od doba určitá \n";
                        Variables.fromfixedtermcontract = "";
                    }

                    //tofixedtermcontract = "";
                    try
                    {
                        tofixedtermcontract1 = DateTime.Parse(Variables.tofixedtermcontract);
                        if (tofixedtermcontract1.Year < 1901)
                        {
                            Variables.tofixedtermcontract = "";
                            errorstring += "Do - chyba formátu \n";
                        }
                    }
                    catch (Exception)
                    {
                        //errorstring += "Do \n";
                        Variables.tofixedtermcontract = "";
                    }
                }
                else if (Variables.indefiniteperiodcontract == true)
                {
                    try
                    {
                        fromindefiniteperiodcontract1 = DateTime.Parse(Variables.fromindefiniteperiodcontract);
                        if (fromindefiniteperiodcontract1.Year < 1901)
                        {
                            Variables.fromindefiniteperiodcontract = "";
                            errorstring += "Od doba neurčitá - chyba formátu \n";
                        }

                        //fromfixedtermcontract1 = DateTime.Parse(fromfixedtermcontract);

                    }
                    catch (Exception)
                    {
                        errorstring += "Od doba neurčitá \n";
                        Variables.fromindefiniteperiodcontract = "";

                    }
                    Variables.fromfixedtermcontract = "";
                    Variables.tofixedtermcontract = "";
                    Variables.fixedtermcontractyears = enums.fixedtermcontractyears.Default.GetHashCode();
                }
                else
                {
                    Variables.fromindefiniteperiodcontract = "";
                    Variables.fromfixedtermcontract = "";
                    Variables.tofixedtermcontract = "";
                }

            }
            if (Variables.takestreet == "") errorstring += "Ulice OPM \n";
            if (Variables.takestreetNumber1 == "") errorstring += "Číslo popisné OPM \n";
            if (Variables.takecity == "") errorstring += "Obec OPM \n";


            if (Variables.takezipcode == "") errorstring += "PSČ OPM \n";

            else if (!Variables.takezipcode.Contains(' '))

                try
                {
                    Variables.takezipcode = Variables.takezipcode.Insert(Variables.takezipcode.Length - 2, " ");
                }
                catch
                {
                }

            if (elektrina == true)
            {
                if (Variables.eanopm == "") errorstring += "EAN chybí \n";
                if (Variables.eanopm != "" && Helper.IsValidEanOpm(Variables.eanopm) == false) errorstring += "EAN - chyba formátu \n";
                Variables.eic = "";
            }
            if (plyn == true)
            {
                if (Variables.eic == "") errorstring += "EIC chybí \n";
                if (Variables.eic != "" && Helper.IsValidEic(Variables.eic) == false) errorstring += "EIC - chyba formátu \n";
                Variables.eanopm = "";
            }

            if (Variables.contractreason.GetHashCode() < 171140000) errorstring += "Důvod uzavření smlouvy \n";

            if (Variables.annualconsumptionvt != "")
            {

                Variables.annualconsumptionvt = Variables.annualconsumptionvt.Replace('.', ',');
                if (Variables.annualconsumptionvt.Contains(","))
                {
                    try
                    {
                        Variables.annualconsumptionvt = Variables.annualconsumptionvt.Substring(0, Variables.annualconsumptionvt.IndexOf(',') + 3);
                    }
                    catch (Exception)
                    {

                    }
                }

            }

            if (Variables.annualconsumptionnt != "")
            {

                Variables.annualconsumptionnt = Variables.annualconsumptionnt.Replace('.', ',');
                if (Variables.annualconsumptionnt.Contains(","))
                {
                    try
                    {

                        Variables.annualconsumptionnt = Variables.annualconsumptionnt.Substring(0, Variables.annualconsumptionnt.IndexOf(',') + 3);
                    }
                    catch (Exception)
                    {

                    }
                }

            }

            if (Variables.capacity_for_day != "")
            {

                Variables.capacity_for_day = Variables.capacity_for_day.Replace('.', ',');
                if (Variables.capacity_for_day.Contains(","))
                {
                    try
                    {

                        Variables.capacity_for_day = Variables.capacity_for_day.Substring(0, Variables.capacity_for_day.IndexOf(',') + 3);
                    }
                    catch (Exception)
                    {

                    }
                }

            }
            if (elektrina == true)
            {
                if (Variables.distributorelectricity.GetHashCode() < 171140000) errorstring += "Distributor elektřiny \n";
                if (Variables.originaldistributor.GetHashCode() < 171140000) errorstring += "Původní dodavatel \n";
                if (Variables.annualconsumptionvt == "") errorstring += "Plánovaná roční spotřeba MWh/rok VT \n";//Plánovaná roční spotřeba MWh/rok VT

                if (Variables.distributionrate.GetHashCode() < 171140000) errorstring += "Distribuční sazba \n";

                //if (maloodber == true)
                //{
                //    if (distributionrate.GetHashCode() >= 171140010) errorstring += "Distribuční sazba D není povolena \n";
                //}

                if (Variables.distributionrate.GetHashCode() != 171140000 && Variables.distributionrate.GetHashCode() != 171140001 &&
                    Variables.distributionrate.GetHashCode() != 171140002 && Variables.distributionrate.GetHashCode() != 171140009 &&
                    Variables.distributionrate.GetHashCode() != 171140010 && Variables.distributionrate.GetHashCode() != 171140011)
                {
                    if (Variables.annualconsumptionnt == "") errorstring += "Plánovaná roční spotřeba MWh/rok NT \n";//Plánovaná roční spotřeba MWh/rok NT
                }
                //else
                //{
                //    if (annualconsumptionnt != "") errorstring += "Plánovaná roční spotřeba MWh/rok NT \n";
                //}


                if (Variables.breakervalue == "") errorstring += "Hodnota jističe před elektroměrem \n";
                if (Variables.connectiontype.GetHashCode() < 171140000) errorstring += "Způsob připojení \n";
                Variables.distributorgas = enums.distributorgas.Default.GetHashCode(); //nejaky udaje pro elektrinu nepotrebuju

            }
            if (plyn == true)
            {
                if (Variables.distributorgas.GetHashCode() < 171140000) 
                     errorstring += "Distributor plynu \n";
                if (Variables.originaldistributor.GetHashCode() < 171140000) errorstring += "Původní dodavatel \n";
                if (Variables.annualconsumptionvt == "") errorstring += "Plánovaná roční spotřeba MWh/rok VT \n";//Plánovaná roční spotřeba MWh/rok VT
                Variables.distributorelectricity = enums.distributorelectricity.Default.GetHashCode(); //nejaky udaje pro plyn nepotrebuju
                Variables.annualconsumptionnt = "";
                Variables.distributionrate = enums.distributionrate.Default.GetHashCode();
                Variables.breakervalue = "";
                Variables.connectiontype = enums.connectiontype.Default.GetHashCode();
            }

            if (Variables.advanceperiod.GetHashCode() < 171140000) errorstring += "Zálohové období \n";

            if (Variables.advancepayment == 0) 
                errorstring += "Výše zálohy \n";
            if (Variables.paymentscheduledelivery.GetHashCode() < 171140000)
            {
                errorstring += "Doručení platebního kalendáře, faktury \n";
            }
            else if (Variables.paymentscheduledelivery.GetHashCode() == 171140000)
            {
                if (Variables.email == "") errorstring += "E-mail chybí pro zasílání faktury \n";
            }

            if (Variables.informationdelivery.GetHashCode() < 171140000) errorstring += "Doručení informace o změně ceníku a OP \n";

            if (Variables.paymenttype.GetHashCode() < 171140000) errorstring += "Způsob platby faktur \n";
            else if (Variables.paymenttype.GetHashCode() == 171140001 || Variables.paymenttypeadvances.GetHashCode() == 171140001) //need accountnumber
            {
                if (Variables.accountnumberp2 == "") errorstring += "Číslo účtu pro vracení přeplatku část 2 \n";
                if (Variables.bankcode == "") errorstring += "Kód banky \n";
                
            }

            if (Variables.accountnumberp2.Contains('/'))
            {

                Variables.bankcode = Variables.accountnumberp2.Substring(Variables.accountnumberp2.IndexOf('/') + 1, Variables.accountnumberp2.Length - Variables.accountnumberp2.IndexOf('/') - 1);
                Variables.accountnumberp2 = Variables.accountnumberp2.Substring(0, Variables.accountnumberp2.IndexOf('/'));

            }
            if (Variables.accountnumberp2.Contains('-'))
            {
                Variables.accountnumberp1 = Variables.accountnumberp2.Substring(0, Variables.accountnumberp2.IndexOf('-'));
                Variables.accountnumberp2 = Variables.accountnumberp2.Substring(Variables.accountnumberp2.IndexOf('-') + 1, Variables.accountnumberp2.Length - Variables.accountnumberp2.IndexOf('-') - 1);

            }

            //if (accountnumberp1 == "") errorstring += "accountnumberp1 error\n";


            if (Variables.accountnumberp2 != "" && Variables.bankcode != "" && Helper.IsValidAccesNumber(Variables.accountnumberp1, Variables.accountnumberp2, Variables.bankcode) == false) errorstring += "Číslo účtu má špatný formát(není Mod11) \n";



            if (Variables.paymenttypeadvances.GetHashCode() < 171140000) errorstring += "Způsob platby záloh \n";
            if (Variables.paymenttypeadvances.GetHashCode() == 171140003) //need sipo
            {
                if (Variables.siponumber == "") errorstring += "SIPO \n";
                if (Variables.siponumber != "" && Helper.IsValidSipo(Variables.siponumber) == false) errorstring += "SIPO má špatný formát \n";
            }
            if (Variables.paymenttype.GetHashCode() == 17114002 && Variables.paymenttypeadvances.GetHashCode() == 17114002)
            {
                Variables.accountnumberp1 = "";
                Variables.accountnumberp2 = "";
                Variables.bankcode = "";
                Variables.siponumber = "";
            }

            try
            {
                dateofsignature1 = DateTime.Parse(Variables.dateofsignature);
                if (dateofsignature1.Year < 1901)
                {
                    Variables.dateofsignature = "";
                    errorstring += "Datum podpisu smlouvy - chyba formátu \n";
                }
            }
              catch (Exception)
            {
                //errorstring += "Datum podpisu smlouvy\n";
                Variables.dateofsignature = "";
            }

            
            try
            {
                auction_date1 = DateTime.Parse(Variables.auction_date);
                if (auction_date1.Year < 1901)
                {
                    Variables.auction_date = "";
                    errorstring += "Datum aukce - chyba formátu \n";
                }
            }
              catch (Exception)
            {
                //errorstring += "Datum podpisu smlouvy\n";
                Variables.auction_date = "";
            }



            try
            {
                resignation1 = DateTime.Parse(Variables.resignation);
                if (resignation1.Year < 1901)
                {
                    Variables.resignation = "";
                    errorstring += "Výpověď k datu - chyba formátu \n";
                }

            }
            catch (Exception)
            {
                //errorstring += "Výpověď k datu - vypočteno automaticky \n";
                Variables.resignation = "";
            }
            
            //if (sellerfirstname == "") errorstring += "sellerfirstname error\n";
            //if (sellerlastname == "") errorstring += "sellerlastname error\n";
            //if (sellerid == "") errorstring += "sellerid error\n";

            if (Variables.resignation_length == 0) errorstring += "Výpovědní lhůta \n";

            if (Variables.resignation_length > 998)
            {
                Variables.resignation_length = 0;
                errorstring += "Výpovědní lhůta - chyba formátu \n";
            }

            # endregion

            #region main

            //prozatimni promene



            //if (errorstring != "") return errorstring; //chyba
            try
            {
                
                
                if (person == 171140000)
                {

                    Guid contact;
                    Guid customeraddress;
                    Guid opportunity;
                    string contactLogicalName;
                    string customeraddressLogicalName;
                    string opportunityLogicalName;


                    if (guid_map.ContainsKey(Variables.firstName + " " + Variables.lastName + " " + Variables.born))
                    {

                        contact = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Contact;
                        customeraddress = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Address;
                        opportunity = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Opportunity;
                        contactLogicalName = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].ContactLogicalName;
                        customeraddressLogicalName = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].AddressLogicalName;
                        opportunityLogicalName = guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].OpportunityLogicalName;

                    }
                    else
                    {


                        contact = Contact.CreateContact(Variables.title1.GetHashCode(), Variables.firstName, Variables.lastName, Variables.title2.GetHashCode(), Variables.born, Variables.ico, Variables.dic, Variables.email, Variables.phoneNumber, Variables.street,
                                      Variables.streetNumber1, Variables.streetNumber2, Variables.zipcode, Variables.city, Variables.recordOR, Variables.auctionnumber, Variables.importnumber, Variables.sex.GetHashCode());
                       
                       contactLogicalName = Contact.GetLogicalName();

                       customeraddress = Address.CreateCustomerAddress(Variables.firstName + " " + Variables.lastName, Variables.postalstreet, Variables.postalstreetNumber1, Variables.postalstreetNumber2,
                                      Variables.postalzipcode, Variables.postalcity, Contact.GetLogicalName(), contact);

                       customeraddressLogicalName = Address.GetLogicalName();

                       opportunity = Opportunity.CreateOpportunity(contractType, Variables.contractId, Variables.dateofsignature, Variables.sellerfirstname, Variables.sellerlastname,
                                            Variables.sellerid, Variables.closedinspaces, Variables.fixedtermcontract, Variables.fromfixedtermcontract, Variables.tofixedtermcontract, Variables.fixedtermcontract1,
                                            Variables.fixedtermcontractyears.GetHashCode(), Variables.fromindefiniteperiodcontract, Variables.indefiniteperiodcontract, Variables.productname, contact,
                                            Contact.GetLogicalName(), Variables.auctionnumber, Variables.importnumber, new Money { Value = Variables.individualprice }, new Money { Value = Variables.individualpriceNT }, new Money { Value = Variables.stableprice }
                                            ,seller_Guid);

                       opportunityLogicalName = Opportunity.GetLogicalName();

                       guid_map.Add(Variables.firstName + " " + Variables.lastName + " " + Variables.born, new GuidMap(Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, "", "", "", "", "", "", ""));
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Contact = contact;
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Address = customeraddress;
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].Opportunity = opportunity;
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].ContactLogicalName = contactLogicalName;
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].AddressLogicalName = customeraddressLogicalName;
                       guid_map[Variables.firstName + " " + Variables.lastName + " " + Variables.born].OpportunityLogicalName = opportunityLogicalName;

                    }



                    Guid supplypoint = SupplyPoint.CreateSupplyPoint(Variables.firstName + " " + Variables.lastName, false, contact, contactLogicalName, opportunity, opportunityLogicalName,
                                        Variables.takestreet, Variables.takestreetNumber1, Variables.takestreetNumber2, Variables.takezipcode, Variables.takecity, Variables.eanopm, Variables.eic, Variables.contractreason.GetHashCode(), Variables.distributorelectricity.GetHashCode(),
                                        Variables.distributorgas.GetHashCode(), Variables.originaldistributor.GetHashCode(), Variables.annualconsumptionnt, Variables.annualconsumptionvt, Variables.distributionrate.GetHashCode(),
                                        Variables.breakervalue, new Money { Value = Variables.advancepayment }, Variables.advanceperiod.GetHashCode(), Variables.connectiontype.GetHashCode(), Variables.informationdelivery.GetHashCode(), Variables.paymentscheduledelivery.GetHashCode(), Variables.paymenttype.GetHashCode(),
                                        Variables.siponumber, Variables.paymenttypeadvances.GetHashCode(), Variables.accountnumberp2, Variables.accountnumberp1, Variables.bankcode, Variables.auctionnumber, Variables.importnumber);

                    //dodelat guid a logicalname
                    Guid verifyform = VerifyForm.CreateVerifyForm(false, Variables.title1.GetHashCode(), Variables.firstName, Variables.lastName, Variables.born, Variables.title2.GetHashCode(), Variables.ico, Variables.dic, Variables.companyName, Variables.ico, Variables.dic,
                                        Variables.p1_function, Variables.p1_firstName, Variables.p1_lastName, Variables.p2_function, Variables.p2_firstName, Variables.p2_lastName, Variables.email, Variables.phoneNumber,
                                        Variables.city, Variables.street, Variables.streetNumber1, Variables.streetNumber2, Variables.zipcode, Variables.recordOR, Variables.postalstreet, Variables.postalstreetNumber1, Variables.postalstreetNumber2, Variables.postalcity, Variables.postalzipcode,
                                        Variables.fixedtermcontract, Variables.fromfixedtermcontract, Variables.tofixedtermcontract, Variables.fixedtermcontract1, Variables.fixedtermcontractyears.GetHashCode(), Variables.indefiniteperiodcontract,
                                        Variables.fromindefiniteperiodcontract, Variables.productname, Variables.takestreet, Variables.takestreetNumber1, Variables.takestreetNumber2, Variables.takecity, Variables.takezipcode, Variables.eanopm, Variables.eic,
                                        Variables.originaldistributor.GetHashCode(), Variables.distributorelectricity.GetHashCode(), Variables.distributorgas.GetHashCode(), Variables.annualconsumptionnt, Variables.annualconsumptionvt, Variables.breakervalue, Variables.distributionrate.GetHashCode(),
                                        Variables.connectiontype.GetHashCode(), Variables.advanceperiod.GetHashCode(), new Money { Value = Variables.advancepayment }, Variables.paymentscheduledelivery.GetHashCode(), Variables.informationdelivery.GetHashCode(), Variables.paymenttypeadvances.GetHashCode(), Variables.paymenttype.GetHashCode(), Variables.siponumber,
                                        Variables.accountnumberp1, Variables.accountnumberp2, Variables.bankcode, Variables.customer_resigned, Variables.resignation_length, Variables.resignation_unit, Variables.contractreason.GetHashCode(), errorstring, Variables.resignation, new Money { Value = Variables.individualprice },
                                        Variables.importnumber, Variables.auctionnumber, Variables.seller_id_auction, Variables.payment_of_commission, Variables.reason_of_commission, Variables.supplypoint_number, Variables.capacity_for_day, Variables.billingperiod, Variables.real_consumption,
                                        contact,contactLogicalName, 
                                        opportunity,opportunityLogicalName,supplypoint,SupplyPoint.GetLogicalName(),Guid.Empty,"",Guid.Empty,""
                                        , Guid.Empty, "", -1, -1, -1, -1, -1, -1, -1, -1, -1, "", "", -1, new Money { Value = Variables.individualpriceNT }, new Money { Value = Variables.stableprice }
                                        ,seller_Guid,Variables.dateofsignature,Variables.auction_portal_name,Variables.auction_date);
                }
                else
                {

                    Guid account;
                    Guid customeraddress;
                    Guid opportunity;
                    Guid p1;
                    Guid p2;
                    Guid contactcompany;

                    string accountLogicalName;
                    string customeraddressLogicalName;
                    string opportunityLogicalName;
                    string p1LogicalName;
                    string p2LogicalName;
                    string contactcompanyLgicalName;

                    if (guid_map.ContainsKey(Variables.companyName))
                    {

                        account = guid_map[Variables.companyName].Account;
                        customeraddress = guid_map[Variables.companyName].Address;
                        opportunity = guid_map[Variables.companyName].Opportunity;
                        p1 = guid_map[Variables.companyName].P1;
                        p2 = guid_map[Variables.companyName].P2;
                        contactcompany = guid_map[Variables.companyName].ContactCompany;

                        accountLogicalName = guid_map[Variables.companyName].AccountLogicalName;
                        customeraddressLogicalName = guid_map[Variables.companyName].AddressLogicalName;
                        opportunityLogicalName = guid_map[Variables.companyName].OpportunityLogicalName;
                        p1LogicalName = guid_map[Variables.companyName].P1LogicalName;
                        p2LogicalName = guid_map[Variables.companyName].P2LogicalName;
                        contactcompanyLgicalName = guid_map[Variables.companyName].ContactCompanyLogicalName;

                    }
                    else
                    {

                        account = Account.CreateAccount(Variables.companyName, Variables.ico, Variables.dic, Variables.p1_function, Variables.p1_firstName, Variables.p1_lastName, Variables.p2_function, Variables.p2_firstName,
                                       Variables.p2_lastName, Variables.email, Variables.phoneNumber, Variables.street, Variables.streetNumber1, Variables.streetNumber2, Variables.zipcode, Variables.city, Variables.recordOR, Variables.auctionnumber, Variables.importnumber,
                                       Variables.title1P1.GetHashCode(), Variables.title2P1.GetHashCode(), Variables.title1P2.GetHashCode(), Variables.title2P2.GetHashCode(), Variables.sexP1.GetHashCode(), Variables.sexP2.GetHashCode(), Variables.contact_firstName, Variables.contact_lastName, Variables.title1C.GetHashCode(), Variables.title2C.GetHashCode(), Variables.sexC.GetHashCode());
                        
                        accountLogicalName = Account.GetLogicalName();
                        p1LogicalName = Account.GetLogicalNameP1();
                        p2LogicalName = Account.GetLogicalNameP2();
                        p1 = Account.GetIdP1();
                        p2 = Account.GetIdP2();
                        contactcompany = Account.GetIdC();
                        contactcompanyLgicalName = Account.GetLogicalNameC();

                        customeraddress = Address.CreateCustomerAddress(Variables.companyName, Variables.postalstreet, Variables.postalstreetNumber1, Variables.postalstreetNumber2,
                                       Variables.postalzipcode, Variables.postalcity, Account.GetLogicalName(), account);

                        customeraddressLogicalName = Address.GetLogicalName();

                        opportunity = Opportunity.CreateOpportunity(contractType, Variables.contractId, Variables.dateofsignature, Variables.sellerfirstname, Variables.sellerlastname,
                                            Variables.sellerid, Variables.closedinspaces, Variables.fixedtermcontract, Variables.fromfixedtermcontract, Variables.tofixedtermcontract, Variables.fixedtermcontract1,
                                            Variables.fixedtermcontractyears.GetHashCode(), Variables.fromindefiniteperiodcontract, Variables.indefiniteperiodcontract, Variables.productname, account,
                                            Account.GetLogicalName(), Variables.auctionnumber, Variables.importnumber, new Money { Value = Variables.individualprice }, new Money { Value = Variables.individualpriceNT }, new Money { Value = Variables.stableprice }
                                            , seller_Guid);

                        opportunityLogicalName = Opportunity.GetLogicalName();

                        guid_map.Add(Variables.companyName, new GuidMap(Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, Guid.Empty, "", "", "", "", "", "", ""));
                        guid_map[Variables.companyName].Account = account;
                        guid_map[Variables.companyName].Address = customeraddress;
                        guid_map[Variables.companyName].Opportunity = opportunity;
                        guid_map[Variables.companyName].P1 = Account.GetIdP1();
                        guid_map[Variables.companyName].P2 = Account.GetIdP2();
                        guid_map[Variables.companyName].ContactCompany = Account.GetIdC();

                        guid_map[Variables.companyName].AccountLogicalName = accountLogicalName;
                        guid_map[Variables.companyName].AddressLogicalName = customeraddressLogicalName;
                        guid_map[Variables.companyName].OpportunityLogicalName = opportunityLogicalName;
                        guid_map[Variables.companyName].P1LogicalName = p1LogicalName;
                        guid_map[Variables.companyName].P2LogicalName = p2LogicalName;
                        guid_map[Variables.companyName].ContactCompanyLogicalName = contactcompanyLgicalName;

                    }

                    Guid supplypoint = SupplyPoint.CreateSupplyPoint(Variables.companyName, true, account, accountLogicalName, opportunity, opportunityLogicalName,
                                        Variables.takestreet, Variables.takestreetNumber1, Variables.takestreetNumber2, Variables.takezipcode, Variables.takecity, Variables.eanopm, Variables.eic, Variables.contractreason.GetHashCode(), Variables.distributorelectricity.GetHashCode(),
                                        Variables.distributorgas.GetHashCode(), Variables.originaldistributor.GetHashCode(), Variables.annualconsumptionnt, Variables.annualconsumptionvt, Variables.distributionrate.GetHashCode(),
                                        Variables.breakervalue, new Money { Value = Variables.advancepayment }, Variables.advanceperiod.GetHashCode(), Variables.connectiontype.GetHashCode(), Variables.informationdelivery.GetHashCode(), Variables.paymentscheduledelivery.GetHashCode(), Variables.paymenttype.GetHashCode(),
                                        Variables.siponumber, Variables.paymenttypeadvances.GetHashCode(), Variables.accountnumberp2, Variables.accountnumberp1, Variables.bankcode, Variables.auctionnumber, Variables.importnumber);
                    //predelat guid a logical name
                    Guid verifyform = VerifyForm.CreateVerifyForm(true, Variables.title1.GetHashCode(), Variables.firstName, Variables.lastName, Variables.born, Variables.title2.GetHashCode(), Variables.ico, Variables.dic, Variables.companyName, Variables.ico, Variables.dic,
                                        Variables.p1_function, Variables.p1_firstName, Variables.p1_lastName, Variables.p2_function, Variables.p2_firstName, Variables.p2_lastName, Variables.email, Variables.phoneNumber,
                                        Variables.city, Variables.street, Variables.streetNumber1, Variables.streetNumber2, Variables.zipcode, Variables.recordOR, Variables.postalstreet, Variables.postalstreetNumber1, Variables.postalstreetNumber2, Variables.postalcity, Variables.postalzipcode,
                                        Variables.fixedtermcontract, Variables.fromfixedtermcontract, Variables.tofixedtermcontract, Variables.fixedtermcontract1, Variables.fixedtermcontractyears.GetHashCode(), Variables.indefiniteperiodcontract,
                                        Variables.fromindefiniteperiodcontract, Variables.productname, Variables.takestreet, Variables.takestreetNumber1, Variables.takestreetNumber2, Variables.takecity, Variables.takezipcode, Variables.eanopm, Variables.eic,
                                        Variables.originaldistributor.GetHashCode(), Variables.distributorelectricity.GetHashCode(), Variables.distributorgas.GetHashCode(), Variables.annualconsumptionnt, Variables.annualconsumptionvt, Variables.breakervalue, Variables.distributionrate.GetHashCode(),
                                        Variables.connectiontype.GetHashCode(), Variables.advanceperiod.GetHashCode(), new Money { Value = Variables.advancepayment }, Variables.paymentscheduledelivery.GetHashCode(), Variables.informationdelivery.GetHashCode(), Variables.paymenttypeadvances.GetHashCode(), Variables.paymenttype.GetHashCode(), Variables.siponumber,
                                        Variables.accountnumberp1, Variables.accountnumberp2, Variables.bankcode, Variables.customer_resigned, Variables.resignation_length, Variables.resignation_unit, Variables.contractreason.GetHashCode(), errorstring, Variables.resignation, new Money { Value = Variables.individualprice },
                                        Variables.importnumber, Variables.auctionnumber, Variables.seller_id_auction, Variables.payment_of_commission, Variables.reason_of_commission, Variables.supplypoint_number, Variables.capacity_for_day, Variables.billingperiod, Variables.real_consumption,
                                        account,accountLogicalName,opportunity,opportunityLogicalName,supplypoint,SupplyPoint.GetLogicalName(),p1,p1LogicalName,p2,p2LogicalName
                                        , contactcompany, contactcompanyLgicalName, Variables.title1P1.GetHashCode(), Variables.title2P1.GetHashCode(), Variables.sexP1.GetHashCode(), Variables.title1P2.GetHashCode(), Variables.title2P2.GetHashCode(), Variables.sexP2.GetHashCode(), Variables.sex.GetHashCode(), Variables.title1C.GetHashCode(), Variables.title2C.GetHashCode()
                                        , Variables.contact_firstName, Variables.contact_lastName, Variables.sexC.GetHashCode(), new Money { Value = Variables.individualpriceNT }, new Money { Value = Variables.stableprice }
                                        ,seller_Guid,Variables.dateofsignature,Variables.auction_portal_name,Variables.auction_date);                                      
                                        
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine("Zaslání e-mailu s chybou: " + ex.Message);
                EmaiSender.SendError("consoleApp error", ex.Message);
                errorstring += "system error, please contact administrator";
            }


            return errorstring;
            #endregion
        }

        public class GuidMap
        {
            //doplnit logical name
            public Guid Contact { get; set; }
            public Guid Account { get; set; }
            public Guid Address { get; set; }
            public Guid Opportunity { get; set; }
            public Guid P1 { get; set; }
            public Guid P2 { get; set; }
            public Guid ContactCompany { get; set; }
            public string ContactLogicalName { get; set; }
            public string AccountLogicalName { get; set; }
            public string AddressLogicalName { get; set; }
            public string OpportunityLogicalName { get; set; }
            public string P1LogicalName { get; set; }
            public string P2LogicalName { get; set; }
            public string ContactCompanyLogicalName { get; set; }

            public GuidMap(Guid contact, Guid account, Guid address, Guid opportunity, Guid p1,Guid p2, Guid contactcompany, string contactLogicalName,
                 string accountLogicalName, string addressLogicalName, string opportunityLogicalName, string p1LogicalName, string p2LogicalName
                ,string contactcompanylogicalname)
            
            {

                Contact = contact;
                Account = account;
                Address = address;
                Opportunity = opportunity;
                P1 = p1;
                P2 = p2;
                ContactCompany = contactcompany;

                ContactLogicalName = contactLogicalName;
                AccountLogicalName = accountLogicalName;
                AddressLogicalName = addressLogicalName;
                OpportunityLogicalName = opportunityLogicalName;
                P1LogicalName = p1LogicalName;
                P2LogicalName = p2LogicalName;
                ContactCompanyLogicalName = contactcompanylogicalname;
            }
        }
    }
}
