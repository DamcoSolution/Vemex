﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace XmlImportVemex
{
    class Helper
    {

        public static bool IsValidEmail(string strIn) // Return true if strIn is in valid e-mail format.
        {
            return Regex.IsMatch(strIn,
                   @"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))" +
                   @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$");
        }
        public static bool IsValidEic(string eic)//EIC 27ZG celkem 16znaku 27ZG700Z0032043F
        {
            bool test = eic.StartsWith("27ZG");  
      

            return test;
        }
        public static bool IsValidEanOpm(string eanopm)//EANOPM 859182 18
        {
            bool test = eanopm.StartsWith("859182");        
            return test;
        }
        public static bool IsValidDic(string dic)//EANOPM 859182 18
        {
            bool test = true;
            if (dic.Length < 8 || dic.Length > 12) test = false;
            return test;
        }
        public static bool IsValidAccesNumber(string acces1, string acces2, string acces3)//3ne null 2kontrola modulo11 delka 5 10 4 max
        {


            //if (acces1 =="") return false;
            if (acces2 == "") return false;
            if (acces3 == "") return false;

            if (acces1.Length > 10) return false;
            if (acces2.Length > 10) return false;
            if (acces3.Length > 7) return false;

            try
            {
                int[] controlNumber = { 1, 2, 4, 8, 5, 10, 9, 7, 3, 6 };
                int test1 = 0;
                int test2 = 0;
                if (acces1.Length != 0)
                {
                    for (int i = 0; i < acces1.Length; i++)
                    {
                        test1 += Convert.ToInt32(Convert.ToString(acces1[acces1.Length - 1 - i])) * controlNumber[i];
                    }
                    if (test1 % 11 != 0) return false;
                }
                for (int j = 0; j < acces2.Length; j++)
                {
                    test2 += Convert.ToInt32(Convert.ToString(acces2[acces2.Length - 1 - j])) * controlNumber[j];
                }
                if (test2 % 11 != 0) return false;
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }


        public static bool IsValidSipo(string sipo) //10znaku, mod 10               3 7 3 1 7 3 1 7 3 1 
        //  a b c d e f g h i M
        //  3 0 1 0 0 1 1 2 9 3
        //Je-li poslední číslo z výsledku nula, tak kontrolní číslo je též nula. 
        //Není-li poslední číslo nula provádí se výpočet kontrolního čísla následujícím způsobem:
        //10 – poslední číslo z výsledku = kontrolní číslo 
        {
            int test = 0;
            int[] controlNumber = { 3, 7, 3, 1, 7, 3, 1, 7, 3, 1 };
            try
            {
                if (sipo.Length != 10) return false;
                for (int j = 0; j < sipo.Length - 1; j++)
                {
                    test += Convert.ToInt32(sipo[j]) * controlNumber[j];
                }
                string lastChar = Convert.ToString(sipo[sipo.Length - 1]);
                int lastDigit = Convert.ToInt32(lastChar);
                int lastDigitTest = test % 10;
                if (lastDigitTest == 0 && lastDigit == 0) return true;
                if (lastDigitTest > 0 && lastDigit == 10 - lastDigitTest) return true;
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }
        public static string RandomString(int size)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }

            return builder.ToString();
        }

       




    }
}
