﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel;
using System.Data;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk;

namespace XmlImportVemex
{
    public class ProgramPortal
    {
        //static int numberOfImport = 0;
        //
        //static int lineInExcel = 0;
        //static bool isAuctionOk = true;
        //CreateFormsElePerson   0
        //CreateFormsEleCompany  1
        //CreateFormsGasPerson   2
        //CreateFormsGasCompany  3
      
        static FileStream stream;
        static IExcelDataReader excelReader2007;
        ImportData importData;
        Convertor objConverter;
        public ProgramPortal(ImportData objImport)
        {
            this.importData = objImport;
        }
        public ProgramPortal()
        { 
        }

        public void ImportData()
        {
            this.ImportData(importData.FilePath, importData.FileName, importData.SellerId);
        }

        public void ImportData(string FilePath, string filename, string sellerid)
        {
            DataSet result = new DataSet();
              string path = string.Empty;
            path = FilePath;
            Logger.init(DateTime.Now.ToString() + " ---- Log importu", this.importData.LogFilePath);

            try
            {

                IOrganizationService service_isOk = ServiceControl.CreateService();

                if (service_isOk != null)
                {

                    string randomstring = Helper.RandomString(6);

                    Logger.WriteLine("Načítají se sady možností z CRM");
                    objConverter = new Convertor();
                    if (objConverter.InitiliazationSuccess == false)
                    {
                        Logger.WriteLine("Optionset Inilization failed. Returning code");
                        return;
                    }

                    Logger.WriteLine("Program byl načten");
                    Logger.WriteLine("");
                    Logger.WriteLine("Zadejte název souboru pro import");

                    Logger.WriteLine("Check File Path : " + FilePath);

                    if (FilePath != string.Empty)
                    {
                        Logger.WriteLine("File Path Not Empty");

                        using (stream = new FileStream(path, FileMode.Open))
                        {
                            excelReader2007 = ExcelReaderFactory.CreateOpenXmlReader(stream);
                            result = excelReader2007.AsDataSet();
                        }
                        StartImport(result, sellerid, filename, path);
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }
        }

        private int StartImport(DataSet result, string seller_id_Value, string filename, string path)
        {
            int numberOfImport = 0;
            
          
            bool IsSellerImport = this.importData.IsSellerImport;
            Guid SellerOrAuctionGuid = Guid.Empty;

            if(!IsSellerImport)
                SellerOrAuctionGuid  = this.importData.AuctionUserId;
      

            Logger.WriteLine("Connecting to CRM");

            IOrganizationService service_isOk = ServiceControl.GetService();

            if (service_isOk != null)
            {

                Logger.WriteLine("OK");

              
                Logger.WriteLine("Options sets is loading");
                bool options_isOk = true;
                if (options_isOk) Logger.WriteLine("OK");
                else
                {
                    Logger.WriteLine("Options sets load error");

                }
                if (options_isOk)
                {
                    bool isLoadFile = true;
                    
                    try
                    {
                        if (isLoadFile == true)
                        numberOfImport =    ProcessData(result, seller_id_Value, IsSellerImport,
                            ref SellerOrAuctionGuid, path, true);
                    }
                    catch (Exception ex)
                    {
                        isLoadFile = false;
                        Logger.WriteLine("Soubor nelze načíst, zkontrolujte prosím, jestli není otevřený");
                        Logger.WriteLine("Exception Occurred : " + ex.Message );
                    }
                    Logger.WriteLine("Bylo importováno " + numberOfImport + " záznamů");
                }
            }
            Logger.WriteLine("------------------------");
            Logger.WriteLine("Program ukončíte libovolnou klávesou");

            return numberOfImport;
        }

        public int ProcessData(DataSet result, string seller_id_Value, bool IsSellerImport, ref Guid SellerOrAuctionGuid, string path, bool isPortalImport)
        {

            string randomstring = Helper.RandomString(6);
            int randomnumber = 1, numberOfImport = 0, lineInExcel = 0;
            string sellerIdFromImport = string.Empty, error = string.Empty;

            Logger.WriteLine("File is able to read");

            CreativeMagesAudit.SetContact(ContactSeller.CheckSeller(seller_id_Value));

            CreativeMagesAudit.CreateAudit(path.Substring(path.LastIndexOf(@"\") + 1) + " " + DateTime.Now.ToString(), 1, this.importData.FileName, 1);

            DataTable table;
            int lastLine = 0;
            int index = result.Tables.IndexOf("ImportListGas");
            bool gas = true;
            bool person = true;
            if (index == -1)
            {
                index = result.Tables.IndexOf("ImportListEle");
                gas = false;
            }
            Logger.WriteLine("Is Gas :" + Convert.ToString(gas));

            if (result.Tables.Contains("ImportListGas") || result.Tables.Contains("ImportListEle"))
            {

                table = result.Tables[index];
                int Columns;

                for (int i = 2; i < table.Rows.Count; i++)
                {
                    if (lastLine > 20)
                    {
                        break;
                    }

                    //Reset Variables
                    Columns = 0;
                    person = false;
                    

                    Variables.Reset();

                    #region mapovani plyn
                    if (gas == true)
                    {

                        Columns++;//domacnost,maloodber
                        Variables.sex = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.title1 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.firstName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.lastName = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.title2 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.born = table.Rows[i].ItemArray[Columns++].ToString();


                        Variables.ico = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.dic = table.Rows[i].ItemArray[Columns++].ToString();

                        if (Variables.lastName != "")
                        {
                            person = true;
                            Columns += 14;
                        }
                        else
                        {

                            person = false;
                            Variables.companyName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.recordOR = table.Rows[i].ItemArray[Columns++].ToString();

                            Variables.sexP1 = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                            Variables.p1_function = table.Rows[i].ItemArray[Columns++].ToString();

                            Variables.title1P1 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                            Variables.p1_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.p1_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title2P1 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                            Variables.sexP2 = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                            Variables.p2_function = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title1P2 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                            Variables.p2_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.p2_lastName = table.Rows[i].ItemArray[Columns++].ToString();

                            Variables.title2P2 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        }


                        Variables.email = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.phoneNumber = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.sexC = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.title1C = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.contact_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.contact_lastName = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.title2C = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.street = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.streetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.streetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.city = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.zipcode = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.postalstreet = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalstreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalstreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalcity = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalzipcode = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.eic = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.takestreet = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takestreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takestreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takecity = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takezipcode = table.Rows[i].ItemArray[Columns++].ToString();


                        Variables.annualconsumptionvt = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.supplypoint_number = table.Rows[i].ItemArray[Columns++].ToString();

                        string distributorgas1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.distributorgas = objConverter.Dictionar_distributorgas.GetOptionSetValue(distributorgas1);

                        // oprava --    ------------------------------------------------------------------------------------------------------

                        string originaldistributor_string = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.originaldistributor = objConverter.Dictionar_originaldistributor.GetOptionSetValue(originaldistributor_string);

                        // oprava --    ----------------------------------------------------------------------------------------------------

                        string contract = table.Rows[i].ItemArray[Columns++].ToString();
                        if (contract == "Určitou")
                        {
                            Variables.fixedtermcontract = true;
                            Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                        }
                        else if (contract == "Určitou roky")
                        {
                            Variables.fixedtermcontract1 = true;
                            Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                        }
                        else if (contract == "Neurčitou")
                        {
                            Variables.indefiniteperiodcontract = true;
                            Variables.fromindefiniteperiodcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Columns++;
                        }
                        else
                        {
                            Columns++;
                            Columns++;
                        }
                        Variables.fixedtermcontractyears = objConverter.Dictionar_fixedtermcontractyears.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        if (table.Rows[i].ItemArray[Columns++].ToString() == "Ano") Variables.customer_resigned = true;

                        Variables.resignation = table.Rows[i].ItemArray[Columns++].ToString();

                        string resignation_length1 = table.Rows[i].ItemArray[Columns++].ToString();
                        if (resignation_length1 == "") resignation_length1 = "0";
                        try
                        {
                            if (resignation_length1.Contains("d"))
                            {
                                resignation_length1 = resignation_length1.Replace("d", "");
                                Variables.resignation_unit = true;
                            }
                            Variables.resignation_length = System.Convert.ToInt32(resignation_length1);

                        }
                        catch (Exception)
                        {
                            //System.Console.WriteLine("The conversion from string to int overflowed.");
                        }

                        Variables.productname = table.Rows[i].ItemArray[Columns++].ToString();

                        string individualP = table.Rows[i].ItemArray[Columns++].ToString();
                        //if (individualP == "") individualP = "0";
                        try
                        {
                            Variables.individualprice = System.Convert.ToDecimal(individualP);
                        }
                        catch (Exception)
                        {
                            //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                            Logger.WriteLine("The conversion from string to decimal overflowed.");
                        }
                       
                        string stablePrice1 = table.Rows[i].ItemArray[Columns++].ToString();
                        try
                        {
                            Variables.stableprice = System.Convert.ToDecimal(stablePrice1);
                        }
                        catch (Exception)
                        {
                            //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                        }
                        Variables.contractreason = objConverter.Dictionar_contractreason.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.advanceperiod = objConverter.Dictionar_advanceperiod.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        string advancepayment1 = table.Rows[i].ItemArray[Columns++].ToString();
                        try
                        {
                            Variables.advancepayment = System.Convert.ToDecimal(advancepayment1);
                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to decimal overflowed.");
                        }

                        Variables.paymenttypeadvances = objConverter.Dictionar_paymenttypeadvances.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.paymenttype = objConverter.Dictionar_paymenttype.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.siponumber = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.accountnumberp1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.accountnumberp2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.bankcode = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.paymentscheduledelivery = objConverter.Dictionar_paymentscheduledelivery.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));//  //Doručení platebního kalendáře, faktury

                        Variables.informationdelivery = objConverter.Dictionar_informationdelivery.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));//  //Doručení informace o změně ceníku a OP

                        if (isPortalImport == false)
                        {
                            Variables.auctionnumber = table.Rows[i].ItemArray[Columns++].ToString();
                        }
                        else
                        {
                            Variables.auctionnumber = string.Empty;
                            Columns++;
                        }
                        
                        Variables.importnumber = table.Rows[i].ItemArray[Columns++].ToString();
                        if (isPortalImport == false)
                        {
                            sellerIdFromImport = table.Rows[i].ItemArray[Columns++].ToString();
                        }
                        else
                        {
                            sellerIdFromImport = seller_id_Value;
                            Columns++;
                        }

                        if (sellerIdFromImport.Length > 0) IsSellerImport = true;

                        Variables.auction_date = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.dateofsignature = table.Rows[i].ItemArray[Columns++].ToString();

                    }

                    #endregion

                    #region mapovani elektrina
                    else
                    {

                        Columns++;//domacnost,maloodber
                        Variables.sex = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.title1 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.firstName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.lastName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.title2 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.born = table.Rows[i].ItemArray[Columns++].ToString();


                        Variables.ico = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.dic = table.Rows[i].ItemArray[Columns++].ToString();

                        if (Variables.lastName != "")
                        {
                            person = true;
                            Columns += 14;
                        }
                        else
                        {

                            person = false;
                            Variables.companyName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.recordOR = table.Rows[i].ItemArray[Columns++].ToString();

                            Variables.sexP1 = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                            Variables.p1_function = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title1P1 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                            Variables.p1_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.p1_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title2P1 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                            Variables.sexP2 = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                            Variables.p2_function = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title1P2 = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                            Variables.p2_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.p2_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.title2P2 = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        }

                        Variables.email = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.phoneNumber = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.sexC = objConverter.Dictionar_sex.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.title1C = objConverter.Dictionar_titulpred.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.contact_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.contact_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.title2C = objConverter.Dictionar_titulza.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.street = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.streetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.streetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.city = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.zipcode = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.postalstreet = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalstreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalstreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalcity = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.postalzipcode = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.eanopm = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.takestreet = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takestreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takestreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takecity = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.takezipcode = table.Rows[i].ItemArray[Columns++].ToString();


                        Variables.annualconsumptionvt = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.annualconsumptionnt = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.supplypoint_number = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.breakervalue = table.Rows[i].ItemArray[Columns++].ToString();
                        //
                        string distributionrate1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.distributionrate = objConverter.Dictionar_distributionrate.GetOptionSetValue(distributionrate1);
                        //
                        string connectiontype1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.connectiontype = objConverter.Dictionar_connectiontype.GetOptionSetValue(connectiontype1);
                        //
                        string distributorelectricity1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.distributorelectricity = objConverter.Dictionar_distributorelectricity.GetOptionSetValue(distributorelectricity1);

                        //originaldistributor = Convertor.originaldistributor(table.Rows[i].ItemArray[Columns++].ToString());
                        // oprava --------------------------------------------------------------------------------------------------------

                        string originaldistributor_string = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.originaldistributor = objConverter.Dictionar_originaldistributor.GetOptionSetValue(originaldistributor_string);


                        // oprava ------------------------------------------------------------------------------------------------------

                        string contract = table.Rows[i].ItemArray[Columns++].ToString();
                        if (contract == "Určitou")
                        {
                            Variables.fixedtermcontract = true;
                            Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                        }
                        else if (contract == "Určitou roky")
                        {
                            Variables.fixedtermcontract1 = true;
                            Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                        }
                        else if (contract == "Neurčitou")
                        {
                            Variables.indefiniteperiodcontract = true;
                            Variables.fromindefiniteperiodcontract = table.Rows[i].ItemArray[Columns++].ToString();
                            Columns++;
                        }
                        else
                        {
                            Columns++;
                            Columns++;
                        }
                        Variables.fixedtermcontractyears = objConverter.Dictionar_fixedtermcontractyears.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        if (table.Rows[i].ItemArray[Columns++].ToString() == "Ano") Variables.customer_resigned = true;

                        Variables.resignation = table.Rows[i].ItemArray[Columns++].ToString();

                        string resignation_length1 = table.Rows[i].ItemArray[Columns++].ToString();
                        if (resignation_length1 == "") resignation_length1 = "0";
                        try
                        {
                            if (resignation_length1.Contains("d"))
                            {
                                resignation_length1 = resignation_length1.Replace("d", "");
                                Variables.resignation_unit = true;
                            }
                            Variables.resignation_length = System.Convert.ToInt32(resignation_length1);

                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to int overflowed. Field resignation_length and value : " + resignation_length1);
                        }

                        Variables.productname = table.Rows[i].ItemArray[Columns++].ToString();

                        string individualP = table.Rows[i].ItemArray[Columns++].ToString();
                        //if (individualP == "") individualP = "0";
                        try
                        {
                            Variables.individualprice = System.Convert.ToDecimal(individualP);
                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to decimal overflowed. Field individualprice and value : " + individualP);
                        }
                        //if (productname == "")
                        //    productname = "Individual - " + individualP;

                        string individualPNT = table.Rows[i].ItemArray[Columns++].ToString();
                        try
                        {
                            Variables.individualpriceNT = System.Convert.ToDecimal(individualPNT);
                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to decimal overflowed. Field individualpriceNT and value : " + individualPNT);
                        }

                        string stablePrice1 = table.Rows[i].ItemArray[Columns++].ToString();
                        try
                        {
                            Variables.stableprice = System.Convert.ToDecimal(stablePrice1);
                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to decimal overflowed. Field stableprice and value : " + stablePrice1);
                        }


                        Variables.contractreason = objConverter.Dictionar_contractreason.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));


                        Variables.advanceperiod = objConverter.Dictionar_advanceperiod.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));


                        string advancepayment1 = table.Rows[i].ItemArray[Columns++].ToString();
                        try
                        {
                            Variables.advancepayment = System.Convert.ToDecimal(advancepayment1);
                        }
                        catch (Exception)
                        {
                            Logger.WriteLine("The conversion from string to decimal overflowed. Field advancepayment and value :" + advancepayment1);
                        }

                        Variables.paymenttypeadvances = objConverter.Dictionar_paymenttypeadvances.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));
                        Variables.paymenttype = objConverter.Dictionar_paymenttype.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        Variables.siponumber = table.Rows[i].ItemArray[Columns++].ToString();

                        Variables.accountnumberp1 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.accountnumberp2 = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.bankcode = table.Rows[i].ItemArray[Columns++].ToString();

                        //  //Doručení platebního kalendáře, faktury
                        Variables.paymentscheduledelivery = objConverter.Dictionar_paymentscheduledelivery.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        //  //Doručení informace o změně ceníku a OP
                        Variables.informationdelivery = objConverter.Dictionar_informationdelivery.GetOptionSetValue(Convert.ToString(table.Rows[i].ItemArray[Columns++]));

                        if (isPortalImport == false)
                        {
                            Variables.auctionnumber = table.Rows[i].ItemArray[Columns++].ToString();
                        }
                        else
                        {
                            Variables.auctionnumber = string.Empty;
                            Columns++;
                        }
                        Variables.importnumber = table.Rows[i].ItemArray[Columns++].ToString();
                        if (isPortalImport == false)
                        {
                            sellerIdFromImport = table.Rows[i].ItemArray[Columns++].ToString();                            
                        }
                        else
                        {
                            sellerIdFromImport = seller_id_Value;
                            Columns++;
                        }
                        if (sellerIdFromImport.Length > 0) IsSellerImport = true;

                        Variables.auction_date = table.Rows[i].ItemArray[Columns++].ToString();
                        Variables.dateofsignature = table.Rows[i].ItemArray[Columns++].ToString();

                    }
                    #endregion

                    if (IsSellerImport)
                        SellerOrAuctionGuid = ContactSeller.CheckSeller(sellerIdFromImport);

                        //we dont need to set is its portaal import because portal import passes GUID directly
                    else if(IsSellerImport == false && isPortalImport == false)
                        SellerOrAuctionGuid = ContactSeller.CheckSeller(Variables.auctionnumber);

                    #region Pridani zaznamu
                    error = "";

                    ////Variables.auctionnumber Variables.auction_portal_name Variables.seller_id_auction
                    bool auctionIsOk = false;
                    bool sellerIsOk = false;

                    if (IsSellerImport && SellerOrAuctionGuid != Guid.Empty)
                    {
                        sellerIsOk = true;
                    }

                    if (!IsSellerImport && SellerOrAuctionGuid != Guid.Empty)
                    {
                        auctionIsOk = true;
                    }

                    bool EanEicIsOk = true;
                    EanEicIsOk = ServiceControl.EanEicIsOk(Variables.eanopm, Variables.eic); //true ok
                    bool customerIsOk = false;
                    if (Variables.lastName != "" || Variables.companyName != "")
                    {
                        customerIsOk = true;
                        lastLine = 0;
                    }
                    else
                    {
                        lastLine++;
                    }

                    if (EanEicIsOk && customerIsOk && (auctionIsOk || sellerIsOk))
                    {

                        if (Variables.importnumber == "")
                        {
                            if (randomnumber < 10)
                                Variables.importnumber = randomstring + "-0000" + randomnumber;
                            else if (randomnumber < 100)
                                Variables.importnumber = randomstring + "-000" + randomnumber;
                            else if (randomnumber < 1000)
                                Variables.importnumber = randomstring + "-00" + randomnumber;
                            else if (randomnumber < 10000)
                                Variables.importnumber = randomstring + "-0" + randomnumber;
                            randomnumber++;

                        }

                        numberOfImport++;
                        lineInExcel = i + 1;
                        Logger.WriteLine("---------- Záznam: " + numberOfImport + " řádek v excelu: " + lineInExcel);

                        if (gas == false && person == true)
                            error = FormService.CreateForms(171140001, 171140000, SellerOrAuctionGuid);
                        if (gas == false && person == false)
                            error = FormService.CreateForms(171140001, 171140001, SellerOrAuctionGuid);
                        if (gas == true && person == true)
                            error = FormService.CreateForms(171140000, 171140000, SellerOrAuctionGuid);
                        if (gas == true && person == false)
                            error = FormService.CreateForms(171140000, 171140001, SellerOrAuctionGuid);

                        if (error != "")
                        {

                            CreativeMagesAudit.AddMissingDataToMessage(error);
                            Logger.WriteLine(error);
                            Logger.WriteLine(error);
                            Logger.WriteLine("Záznam importován, chybí údaje");
                            Logger.WriteLine("");

                        }

                        else
                        {

                            Logger.WriteLine("Záznam importován bez chyb");
                            Logger.WriteLine("");
                            Logger.WriteLine("complete");
                            //Console.ReadKey();

                        }
                        int status;
                        //int statecode = 1;
                        if (CreativeMagesAudit.errorMessage != "")
                        {
                            status = 171140001;
                            //statecode=0;
                        }
                        else if (CreativeMagesAudit.dataMissingMessage != "") status = 171140002;
                        else status = 171140000;

                        CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, status, lineInExcel.ToString(), 1);


                    }//importovano
                    else if (customerIsOk)//neimportovano
                    {
                        //numberOfImport++;
                        lineInExcel = i + 1;

                        Logger.WriteLine("---------- řádek v excelu: " + lineInExcel.ToString());

                        //if (EanEicIsOk && customerIsOk && (auctionIsOk || sellerIsOk))
                        if (!EanEicIsOk)
                        {

                            Logger.WriteLine("EAN nebo EIC v systému již existuje, záznam nebyl importován");
                            //CreativeMagesAudit.AddMissingDataToMessage("EAN nebo EIC v systému již existuje, záznam nebyl importován");
                            CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140003, lineInExcel.ToString(), 0);
                        }
                        else if (!IsSellerImport && !auctionIsOk)
                        {

                            Logger.WriteLine("Chybí název aukčního portálu, záznam nebyl importován");
                            CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140005, lineInExcel.ToString(), 0);

                        }
                        else if (IsSellerImport && !sellerIsOk)
                        {

                            Logger.WriteLine("Chybí Id prodejce, záznam nebyl importován");
                            CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140004, lineInExcel.ToString(), 0);
                        }
                    }

                    #endregion

                }

            }
            else
            {
                Logger.WriteLine("Chybi ImportList");
            }
            return numberOfImport;
        }

    }
}
