﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel;
using System.Data;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk;


namespace XmlImportVemex
{
    class Program
    {

        static int numberOfImport = 0;
        
        static int lineInExcel = 0;
        static bool isAuctionOk = true;
        //CreateFormsElePerson   0
        //CreateFormsEleCompany  1
        //CreateFormsGasPerson   2
        //CreateFormsGasCompany  3
       
        static FileStream stream;
        static IExcelDataReader excelReader2007;
        static DataSet result;
     
        static void Main(string[] args)
        {

            ProgramPortal.ImportData(@"H:\CRM\vemex\Vemex\Průvodka_CLP_EAN_17.11.2013_61.xlsx", "Průvodka_CLP_EAN_17.11.2013_61.xlsx", "Obchodnik");

            string seller_id_Value = "";
            Variables.seller_id_auction = seller_id_Value;

            string auction_portal_name_Value = "";

            Variables.auction_portal_name = auction_portal_name_Value;




            bool tt = Helper.IsValidAccesNumber("000000", "1111111113", "1111");
            //Console.WriteLine(tt);
            
            Logger.init(DateTime.Now.ToString() + " ---- Log importu");

            Console.Write("Navazuje se spojení s CRM");

            IOrganizationService service_isOk = ServiceControl.CreateService();

            if (service_isOk != null)
            {

                Console.WriteLine(" - OK");
                 
                string randomstring = Helper.RandomString(6);
                int randomnumber = 1;

                Console.Write("Načítají se sady možností z CRM");
                bool options_isOk = Convertor.UpdateOptionSets();

                if (options_isOk) Console.WriteLine(" - OK");
                else
                {
                    Console.WriteLine(" - chyba, kontaktujte prosím administrátora");
                    
                }
                if (options_isOk)
                {

                    Console.WriteLine("Program byl načten");
                    Console.WriteLine("");
                    bool isLoadFile = true;
                    string error = "";
                    string path;
                    Console.WriteLine("Zadejte název souboru pro import");
                    path = Console.ReadLine();
                    if (path == "") path = "Vzor EAN (CRM Import)testovaci data v2.0_.xlsx";
                    try
                    {

                        stream = new FileStream(path, FileMode.Open);
                        excelReader2007 = ExcelReaderFactory.CreateOpenXmlReader(stream);
                        result = excelReader2007.AsDataSet();

                    }
                    catch (Exception)
                    {
                        isLoadFile = false;
                        Console.WriteLine("Soubor nelze načíst, zkontrolujte prosím, jestli není otevřený");
                        Logger.WriteLine("Soubor nelze načíst");
                    }

                    if (isLoadFile == true)
                    {
                        Console.WriteLine("Soubor byl načten");
                        Logger.WriteLine("Soubor byl načten");

                        CreativeMagesAudit.CreateAudit(path + " " + DateTime.Now.ToString(), 1, path, 1);

                        DataTable table;
                        int lastLine = 0;
                        int index = result.Tables.IndexOf("ImportListGas");
                        bool gas = true;
                        bool person = true;
                        if (index == -1)
                        {
                            index = result.Tables.IndexOf("ImportListEle");
                            gas = false;
                        }
                        if (result.Tables.Contains("ImportListGas") || result.Tables.Contains("ImportListEle"))
                        {

                            table = result.Tables[index];                          
                            int Columns;

                            for (int i = 2; i < table.Rows.Count; i++)
                            {
                                if (lastLine > 20)
                                {
                                    //Console.WriteLine("Import information");
                                    break;
                                }
                                Columns = 0;
                                person = false;

                                isAuctionOk = true;
                                Variables.Reset();

                                #region mapovani plyn
                                if (gas == true)
                                {

                                    Columns++;//domacnost,maloodber
                                    Variables.sex = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.title1 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.title2 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.born = table.Rows[i].ItemArray[Columns++].ToString();


                                    Variables.ico = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.dic = table.Rows[i].ItemArray[Columns++].ToString();

                                    if (Variables.lastName != "")
                                    {
                                        person = true;
                                        Columns += 14;
                                    }
                                    else
                                    {

                                        person = false;
                                        Variables.companyName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.recordOR = table.Rows[i].ItemArray[Columns++].ToString();

                                        Variables.sexP1 = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p1_function = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title1P1 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p1_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.p1_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title2P1 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());

                                        Variables.sexP2 = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p2_function = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title1P2 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p2_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.p2_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title2P2 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());

                                    }


                                    Variables.email = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.phoneNumber = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.sexC = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());

                                    Variables.title1C = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.contact_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.contact_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.title2C = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());



                                    Variables.street = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.streetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.streetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.city = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.zipcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.postalstreet = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalstreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalstreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalcity = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalzipcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.eic = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.takestreet = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takestreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takestreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takecity = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takezipcode = table.Rows[i].ItemArray[Columns++].ToString();


                                    Variables.annualconsumptionvt = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.supplypoint_number = table.Rows[i].ItemArray[Columns++].ToString();

                                    string distributorgas1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.distributorgas = Convertor.distributorgas(distributorgas1);

                                    // oprava --    ------------------------------------------------------------------------------------------------------

                                    string originaldistributor_string = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.originaldistributor = Convertor.originaldistributor(originaldistributor_string).GetHashCode();


                                    // oprava --    ----------------------------------------------------------------------------------------------------

                                    string contract = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (contract == "Určitou")
                                    {
                                        Variables.fixedtermcontract = true;
                                        Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                                    }
                                    else if (contract == "Určitou roky")
                                    {
                                        Variables.fixedtermcontract1 = true;
                                        Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                                    }
                                    else if (contract == "Neurčitou")
                                    {
                                        Variables.indefiniteperiodcontract = true;
                                        Variables.fromindefiniteperiodcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Columns++;
                                    }
                                    else
                                    {
                                        Columns++;
                                        Columns++;
                                    }
                                    Variables.fixedtermcontractyears = Convertor.fixedtermcontractyears(table.Rows[i].ItemArray[Columns++].ToString());


                                    if (table.Rows[i].ItemArray[Columns++].ToString() == "Ano") Variables.customer_resigned = true;

                                    Variables.resignation = table.Rows[i].ItemArray[Columns++].ToString();

                                    string resignation_length1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (resignation_length1 == "") resignation_length1 = "0";
                                    try
                                    {
                                        if (resignation_length1.Contains("d"))
                                        {
                                            resignation_length1 = resignation_length1.Replace("d", "");
                                            Variables.resignation_unit = true;
                                        }
                                        Variables.resignation_length = System.Convert.ToInt32(resignation_length1);

                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to int overflowed.");
                                    }

                                    Variables.productname = table.Rows[i].ItemArray[Columns++].ToString();

                                    string individualP = table.Rows[i].ItemArray[Columns++].ToString();
                                    //if (individualP == "") individualP = "0";
                                    try
                                    {
                                        Variables.individualprice = System.Convert.ToDecimal(individualP);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }
                                    //if (productname == "")
                                    //    productname = "Individual - " + individualP;


                                    string stablePrice1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    try
                                    {
                                        Variables.stableprice = System.Convert.ToDecimal(stablePrice1);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }


                                    Variables.contractreason = Convertor.contractreason(table.Rows[i].ItemArray[Columns++].ToString());


                                    Variables.advanceperiod = Convertor.advanceperiod(table.Rows[i].ItemArray[Columns++].ToString());


                                    string advancepayment1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    try
                                    {
                                        Variables.advancepayment = System.Convert.ToDecimal(advancepayment1);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }

                                    Variables.paymenttypeadvances = Convertor.paymenttypeadvances(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.paymenttype = Convertor.paymenttype(table.Rows[i].ItemArray[Columns++].ToString());


                                    Variables.siponumber = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.accountnumberp1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.accountnumberp2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.bankcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.paymentscheduledelivery = Convertor.paymentscheduledelivery(table.Rows[i].ItemArray[Columns++].ToString());//  //Doručení platebního kalendáře, faktury
                                    Variables.informationdelivery = Convertor.informationdelivery(table.Rows[i].ItemArray[Columns++].ToString());//  //Doručení informace o změně ceníku a OP

                                    Variables.auctionnumber = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.importnumber = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (seller_id_Value == "") Variables.seller_id_auction = table.Rows[i].ItemArray[Columns++].ToString();
                                    else Columns++;

                                    if (auction_portal_name_Value == "") Variables.auction_portal_name = table.Rows[i].ItemArray[Columns++].ToString();
                                    else Columns++;
                                    
                                    Variables.auction_date = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.dateofsignature = table.Rows[i].ItemArray[Columns++].ToString();

                                    

                                }
                                #endregion

                                #region mapovani elektrina
                                else
                                {

                                    Columns++;//domacnost,maloodber
                                    Variables.sex = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.title1 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.title2 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.born = table.Rows[i].ItemArray[Columns++].ToString();


                                    Variables.ico = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.dic = table.Rows[i].ItemArray[Columns++].ToString();

                                    if (Variables.lastName != "")
                                    {
                                        person = true;
                                        Columns += 14;
                                    }
                                    else
                                    {

                                        person = false;
                                        Variables.companyName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.recordOR = table.Rows[i].ItemArray[Columns++].ToString();

                                        Variables.sexP1 = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p1_function = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title1P1 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p1_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.p1_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title2P1 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());

                                        Variables.sexP2 = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p2_function = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title1P2 = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                        Variables.p2_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.p2_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.title2P2 = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());

                                    }


                                    Variables.email = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.phoneNumber = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.sexC = Convertor.sex(table.Rows[i].ItemArray[Columns++].ToString());

                                    Variables.title1C = Convertor.titulpred(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.contact_firstName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.contact_lastName = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.title2C = Convertor.titulza(table.Rows[i].ItemArray[Columns++].ToString());



                                    Variables.street = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.streetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.streetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.city = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.zipcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.postalstreet = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalstreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalstreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalcity = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.postalzipcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.eanopm = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.takestreet = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takestreetNumber1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takestreetNumber2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takecity = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.takezipcode = table.Rows[i].ItemArray[Columns++].ToString();


                                    Variables.annualconsumptionvt = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.annualconsumptionnt = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.supplypoint_number = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.breakervalue = table.Rows[i].ItemArray[Columns++].ToString();
                                    //
                                    string distributionrate1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.distributionrate = Convertor.distributionrate(distributionrate1);
                                    //
                                    string connectiontype1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.connectiontype = Convertor.connectiontype(connectiontype1);
                                    //
                                    string distributorelectricity1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.distributorelectricity = Convertor.distributorelectricity(distributorelectricity1);

                                    //originaldistributor = Convertor.originaldistributor(table.Rows[i].ItemArray[Columns++].ToString());
                                    // oprava --------------------------------------------------------------------------------------------------------

                                    string originaldistributor_string = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.originaldistributor = Convertor.originaldistributor(originaldistributor_string).GetHashCode();


                                    // oprava ------------------------------------------------------------------------------------------------------


                                    string contract = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (contract == "Určitou")
                                    {
                                        Variables.fixedtermcontract = true;
                                        Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                                    }
                                    else if (contract == "Určitou roky")
                                    {
                                        Variables.fixedtermcontract1 = true;
                                        Variables.fromfixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Variables.tofixedtermcontract = table.Rows[i].ItemArray[Columns++].ToString(); //do
                                    }
                                    else if (contract == "Neurčitou")
                                    {
                                        Variables.indefiniteperiodcontract = true;
                                        Variables.fromindefiniteperiodcontract = table.Rows[i].ItemArray[Columns++].ToString();
                                        Columns++;
                                    }
                                    else
                                    {
                                        Columns++;
                                        Columns++;
                                    }
                                    Variables.fixedtermcontractyears = Convertor.fixedtermcontractyears(table.Rows[i].ItemArray[Columns++].ToString());


                                    if (table.Rows[i].ItemArray[Columns++].ToString() == "Ano") Variables.customer_resigned = true;

                                    Variables.resignation = table.Rows[i].ItemArray[Columns++].ToString();

                                    string resignation_length1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (resignation_length1 == "") resignation_length1 = "0";
                                    try
                                    {
                                        if (resignation_length1.Contains("d"))
                                        {
                                            resignation_length1 = resignation_length1.Replace("d", "");
                                            Variables.resignation_unit = true;
                                        }
                                        Variables.resignation_length = System.Convert.ToInt32(resignation_length1);

                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to int overflowed.");
                                    }

                                    Variables.productname = table.Rows[i].ItemArray[Columns++].ToString();

                                    string individualP = table.Rows[i].ItemArray[Columns++].ToString();
                                    //if (individualP == "") individualP = "0";
                                    try
                                    {
                                        Variables.individualprice = System.Convert.ToDecimal(individualP);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }
                                    //if (productname == "")
                                    //    productname = "Individual - " + individualP;

                                    string individualPNT = table.Rows[i].ItemArray[Columns++].ToString();
                                    try
                                    {
                                        Variables.individualpriceNT = System.Convert.ToDecimal(individualPNT);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }

                                    string stablePrice1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    try
                                    {
                                        Variables.stableprice = System.Convert.ToDecimal(stablePrice1);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }


                                    Variables.contractreason = Convertor.contractreason(table.Rows[i].ItemArray[Columns++].ToString());


                                    Variables.advanceperiod = Convertor.advanceperiod(table.Rows[i].ItemArray[Columns++].ToString());


                                    string advancepayment1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    try
                                    {
                                        Variables.advancepayment = System.Convert.ToDecimal(advancepayment1);
                                    }
                                    catch (Exception)
                                    {
                                        //System.Console.WriteLine("The conversion from string to decimal overflowed.");
                                    }

                                    Variables.paymenttypeadvances = Convertor.paymenttypeadvances(table.Rows[i].ItemArray[Columns++].ToString());
                                    Variables.paymenttype = Convertor.paymenttype(table.Rows[i].ItemArray[Columns++].ToString());


                                    Variables.siponumber = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.accountnumberp1 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.accountnumberp2 = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.bankcode = table.Rows[i].ItemArray[Columns++].ToString();

                                    Variables.paymentscheduledelivery = Convertor.paymentscheduledelivery(table.Rows[i].ItemArray[Columns++].ToString());//  //Doručení platebního kalendáře, faktury
                                    Variables.informationdelivery = Convertor.informationdelivery(table.Rows[i].ItemArray[Columns++].ToString());//  //Doručení informace o změně ceníku a OP

                                    Variables.auctionnumber = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.importnumber = table.Rows[i].ItemArray[Columns++].ToString();
                                    if (seller_id_Value == "") Variables.seller_id_auction = table.Rows[i].ItemArray[Columns++].ToString();
                                    else Columns++;

                                    if (auction_portal_name_Value == "") Variables.auction_portal_name = table.Rows[i].ItemArray[Columns++].ToString();
                                    else Columns++;

                                    Variables.auction_date = table.Rows[i].ItemArray[Columns++].ToString();
                                    Variables.dateofsignature = table.Rows[i].ItemArray[Columns++].ToString();

                                }
                                #endregion

                                #region Pridani zaznamu
                                error = "";

                                //Variables.auctionnumber Variables.auction_portal_name Variables.seller_id_auction
                                bool auctionIsOk = false;
                                bool sellerIsOk = false;


                                Variables.sellerid = Variables.seller_id_auction;

                                Guid seller_Guid = Guid.Empty;

                                //Guid AuctionCheckContact(string AuctionName)

                                    


                                if (Variables.auctionnumber != "" && Variables.auction_portal_name !="")
                                {
                                    
                                    seller_Guid = ContactSeller.AuctionCheckContact(Variables.auction_portal_name);
                                    if(seller_Guid != Guid.Empty)
                                        auctionIsOk = true;
                                }
                                else if (Variables.auctionnumber == "" && Variables.sellerid != "")
                                {
                                    seller_Guid = ContactSeller.CheckSeller(Variables.sellerid);
                                    if (seller_Guid != Guid.Empty)
                                        sellerIsOk = true;
                                }

                                bool EanEicIsOk = true;
                                EanEicIsOk = ServiceControl.EanEicIsOk(Variables.eanopm, Variables.eic); //true ok
                                bool customerIsOk = false;
                                if (Variables.lastName != "" || Variables.companyName != "")
                                {
                                    customerIsOk = true;
                                    lastLine = 0;
                                }
                                else
                                {
                                    lastLine++;
                                }

                                if (EanEicIsOk && customerIsOk && ( auctionIsOk || sellerIsOk))
                                {                              

                                    if (Variables.importnumber == "")
                                    {
                                        if (randomnumber < 10)
                                            Variables.importnumber = randomstring + "-0000" + randomnumber;
                                        else if (randomnumber < 100)
                                            Variables.importnumber = randomstring + "-000" + randomnumber;
                                        else if (randomnumber < 1000)
                                            Variables.importnumber = randomstring + "-00" + randomnumber;
                                        else if (randomnumber < 10000)
                                            Variables.importnumber = randomstring + "-0" + randomnumber;
                                        randomnumber++;

                                    }

                                    numberOfImport++;
                                    lineInExcel = i + 1;
                                    Console.WriteLine("---------- Záznam: " + numberOfImport + " řádek v excelu: " + lineInExcel);
                                    Logger.WriteLine("---------- Záznam: " + numberOfImport + " řádek v excelu: " + lineInExcel);

                                    if (gas == false && person == true)
                                        error = FormService.CreateForms(171140001, 171140000, seller_Guid);
                                    if (gas == false && person == false)
                                        error = FormService.CreateForms(171140001, 171140001, seller_Guid);
                                    if (gas == true && person == true)
                                        error = FormService.CreateForms(171140000, 171140000, seller_Guid);
                                    if (gas == true && person == false)
                                        error = FormService.CreateForms(171140000, 171140001, seller_Guid);

                                    if (error != "")
                                    {

                                        CreativeMagesAudit.AddMissingDataToMessage(error);
                                        Console.WriteLine(error);
                                        Logger.WriteLine(error);
                                        Console.WriteLine("Záznam importován, chybí údaje");
                                        Console.WriteLine("");

                                    }

                                    else
                                    {

                                        Console.WriteLine("Záznam importován bez chyb");
                                        Console.WriteLine("");
                                        Logger.WriteLine("complete");
                                        //Console.ReadKey();

                                    }
                                    int status;
                                    //int statecode = 1;
                                    if (CreativeMagesAudit.errorMessage != "")
                                    {
                                        status = 171140001;
                                        //statecode=0;
                                    }
                                    else if (CreativeMagesAudit.dataMissingMessage != "") status = 171140002;
                                    else status = 171140000;

                                    CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, status, lineInExcel.ToString(), 1);


                                }//importovano
                                else if (customerIsOk)//neimportovano
                                {
                                    //numberOfImport++;
                                    lineInExcel = i + 1;
                                    Console.WriteLine("---------- řádek v excelu: " + lineInExcel.ToString());
                                    Logger.WriteLine("---------- řádek v excelu: " + lineInExcel.ToString());

                                    //if (EanEicIsOk && customerIsOk && (auctionIsOk || sellerIsOk))
                                    if (!EanEicIsOk)
                                    {
                                        Console.WriteLine(error + "EAN nebo EIC v systému již existuje, záznam nebyl importován");
                                        Logger.WriteLine("EAN nebo EIC v systému již existuje, záznam nebyl importován");
                                        //CreativeMagesAudit.AddMissingDataToMessage("EAN nebo EIC v systému již existuje, záznam nebyl importován");
                                        CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140003, lineInExcel.ToString(), 0);
                                    }
                                    else if (Variables.auctionnumber != "" && !auctionIsOk)
                                    {
                                        Console.WriteLine(error + "Chybí název aukčního portálu, záznam nebyl importován");
                                        Logger.WriteLine("Chybí název aukčního portálu, záznam nebyl importován");       
                                        CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140005, lineInExcel.ToString(), 0);

                                    }
                                    else if (Variables.auctionnumber == "" && !sellerIsOk)
                                    {
                                        Console.WriteLine(error + "Chybí Id prodejce, nebo Id nebylo nalezeno, záznam nebyl importován");
                                        Logger.WriteLine("Chybí Id prodejce, záznam nebyl importován");
                                        CreativeMagesAudit.CreateMessage(Variables.eanopm + Variables.eic, 171140004, lineInExcel.ToString(), 0);
                                    }                                   
                                   
                                }


                                #endregion

                            }

                        }
                        else
                        {
                            Console.WriteLine("Chybi ImportList");
                            Logger.WriteLine("Chybi ImportList");
                        }

                        excelReader2007.Close();
                    }

                    Console.WriteLine("Bylo importováno " + numberOfImport + " záznamů");
                    Logger.WriteLine("Bylo importováno " + numberOfImport + " záznamů");
                }
            }
            Console.WriteLine("");
            Console.WriteLine("Program ukončíte libovolnou klávesou");
            Console.ReadKey();

        }
    }
}
