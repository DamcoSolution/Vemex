﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class MarketingListMember
    {
        public Guid AddListMember(Guid CustomerId,string ListName, int listtype)        
        {
         //Listtype  account - 1, contact -2
            Guid memeberId = Guid.Empty;

            FilterExpression filter = new FilterExpression();
            filter.AddCondition("cre_uselikesource", ConditionOperator.Equal, true);
            filter.AddCondition("createdfromcode", ConditionOperator.Equal, listtype);
            filter.AddCondition("listname", ConditionOperator.Equal, ListName);

            filter.FilterOperator = LogicalOperator.And;

            QueryExpression query = new QueryExpression()
            {
                EntityName = "list",
                ColumnSet = new ColumnSet(new string[] 
                 {
                     "listid", 
                     "listname"
                 }),
                Criteria = filter
            };

            EntityCollection entityList = ServiceControl.GetService().RetrieveMultiple(query);

            if (entityList.Entities.Count() >= 1)
            {
                Entity entity = entityList.Entities.FirstOrDefault();
                return AddListMemeber(entity.Id, CustomerId);
            }
            return memeberId;
        }

        private Guid AddListMemeber(Guid ListId, Guid CustomerId)
        {
            Guid Responseid = Guid.Empty;
            try
            {                
                // Add a single contact to the copied marketing list.
                var addMemberReq = new AddMemberListRequest
                {
                    EntityId = CustomerId,
                    ListId = ListId
                };


                AddMemberListResponse response = (AddMemberListResponse)ServiceControl.GetService().Execute(addMemberReq);
                if (response != null)
                    Responseid = response.Id;
            }
            catch
            {
            }
            return Responseid;
        }

    }
}
