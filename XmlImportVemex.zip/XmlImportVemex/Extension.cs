﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
   public static class Extension
    {
       public static int GetOptionSetValue(this Dictionary<string,int> dictionary, string key)
       {
           if (dictionary.ContainsKey(key)) return dictionary[key];
           else return -1;
       }
    }
}
