﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class Contact
    {
        static string LogicalName = "";
        static Guid id = Guid.Empty;

        public static Guid CreateContact(int title1, string firstName, string lastName,
                                          int title2, string born, string ico, string dic, string email, string phoneNumber, string street,
                                          string streetNumber1, string streetNumber2, string zipcode, string city, string recordOR, 
                                            string auctionnumber,string importnumber,int sex)
        {
            try
            {
                Entity contact = new Entity("contact");
                contact["cre_ico"] = ico;
                contact["cre_dic"] = dic;
                contact["cre_genders"] = new OptionSetValue(sex);
                if (title1 >= 171140000) contact["cre_titulpred"] = new OptionSetValue(title1);
                if (title2 >= 171140000) contact["cre_titulza"] = new OptionSetValue(title2);
                contact["lastname"] = lastName;
                contact["firstname"] = firstName;
                contact["emailaddress1"] = email;
                contact["telephone2"] = phoneNumber;
                if (born != "") contact["birthdate"] = DateTime.Parse(born);
                contact["cre_commercialregisterrecord"] = recordOR;
                contact["address1_addresstypecode"] = new OptionSetValue(1);
                contact["address1_city"] = city;
                contact["address1_name"] = firstName + " " + lastName;
                contact["address1_line1"] = street;
                contact["cre_housenumber"] = streetNumber1;
                contact["cre_orientationnumber"] = streetNumber2;
                contact["address1_postalcode"] = zipcode;
                contact["cre_auctionnumber"] = auctionnumber;
                contact["cre_importnumber"] = importnumber;
                LogicalName = contact.LogicalName;
                id = ServiceControl.Create(contact, ServiceControl.GetService());
                return id;
            }
            catch (Exception ex)
            {
                EmaiSender.SendError("consoleApp error Cont", ex.Message);
                return Guid.Empty;
            }
        }
        public static string GetLogicalName()
        {
            return LogicalName;
        }
        public static Guid GetId()
        {
            return id;
        }
    }
}
