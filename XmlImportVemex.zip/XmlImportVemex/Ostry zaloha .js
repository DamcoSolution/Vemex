﻿function OnSave(context) {
    OnSaveValidation(context);
}

function OnLoad() {
    OnLoadValidation();
    CheckExistsEANEICCode();
    OnLoadCollapseSections();
}

function CustomerNotReachedClick() {
    var context = Xrm.Page.context;
    var entity = Xrm.Page.data.entity;
    var status = Xrm.Page.getAttribute("cre_status");
    status.setSubmitMode("always");
    switch (status.getValue()) {
        case 171140000:
            status.setValue(171140003);
            entity.save("saveandclose");
            break;
        case 171140003:
            status.setValue(171140004);
            entity.save("saveandclose");
            break;
        default:
            alert("Akci nelze použít.\nVerifikační formulář není ve vhodném stavu.");
            context.getEventArgs().preventDefault();
            break;
    }
}

function ContractFullVerifikation() {
    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();

    if (verificationComplete_value == false) {

        var entity = Xrm.Page.data.entity;
        var contactVer = Xrm.Page.getAttribute("cre_contactver");
        var accountVer = Xrm.Page.getAttribute("cre_accountver");
        var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
        var contactDetailsVer = Xrm.Page.getAttribute("cre_contact_detailsver");
        var permanentAddressVer = Xrm.Page.getAttribute("cre_permanent_addressver");
        var mailingAdressVer = Xrm.Page.getAttribute("cre_mailing_adressver");
        var contractPeriodVer = Xrm.Page.getAttribute("cre_contract_periodver");
        var supplyPointPaymentTermsVer = Xrm.Page.getAttribute("cre_supplypoint_payment_termsver");
        var status = Xrm.Page.getAttribute("cre_status");

        contactVer.setValue(171140000);
        accountVer.setValue(171140000);
        responsibleVer.setValue(171140000);
        contactDetailsVer.setValue(171140000);
        permanentAddressVer.setValue(171140000);
        mailingAdressVer.setValue(171140000);
        contractPeriodVer.setValue(171140000);
        supplyPointPaymentTermsVer.setValue(171140000);
        //alert("Záznam byl zverifikován");
        entity.save("save");
    }
    else {
        alert("Záznam je zverifikovaný");
    }

}

function ContractFullValidation() {

    var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
    var validationComplete_value = validationComplete.getValue();

    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();

    if (verificationComplete_value == false) {
        alert("Záznam není zverifikován");
    }
    else if (validationComplete_value == true) {
        alert("Záznam je zvalidován");
    }
    else {
        var entity = Xrm.Page.data.entity;
        var contactVal = Xrm.Page.getAttribute("cre_contactval");
        var accountVal = Xrm.Page.getAttribute("cre_accountval");
        var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
        var contactDetailVal = Xrm.Page.getAttribute("cre_contact_detailsval");
        var permanentAddressVal = Xrm.Page.getAttribute("cre_permanent_addressval");
        var mailingAdressVal = Xrm.Page.getAttribute("cre_mailing_adressval");
        var contractPeriodVal = Xrm.Page.getAttribute("cre_contract_periodval");
        var supplyPointPaymentTermsVal = Xrm.Page.getAttribute("cre_supplypoint_payment_termsval");

        contactVal.setValue(171140000);
        accountVal.setValue(171140000);
        responsibleVal.setValue(171140000);
        contactDetailVal.setValue(171140000);
        permanentAddressVal.setValue(171140000);
        mailingAdressVal.setValue(171140000);
        contractPeriodVal.setValue(171140000);
        supplyPointPaymentTermsVal.setValue(171140000);

        //alert("Záznam byl zvalidován");
        entity.save("save");
    }
}


function ContractCancelClick() {
    var entity = Xrm.Page.data.entity;
    var status = Xrm.Page.getAttribute("cre_status");
    status.setSubmitMode("always");
    status.setValue(171140006);
    entity.save("saveandclose");
}

function ContractVerifyClick() {
    var status = Xrm.Page.getAttribute("cre_status");
    var status_value = status.getValue();

    if (status_value == 171140000) {
        alert("Záznam čeká na verifikaci");
    }
    else {
        var entity = Xrm.Page.data.entity;
        var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
        var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
        verificationComplete.setSubmitMode("always");
        validationComplete.setSubmitMode("always");
        var reVerification = Xrm.Page.getAttribute("cre_reverification");
        reVerification.setSubmitMode("always");
        reVerification.setValue(true);
        verificationComplete.setValue(false);
        validationComplete.setValue(false);

        entity.save("save");
    }
}

function ContractRejectClick() {
    var status = Xrm.Page.getAttribute("cre_status");
    status.setSubmitMode("always");

    if (Xrm.Page.getAttribute("cre_validationcomplete").getValue() != true) {
        alert("Záznam není zvalidován");
    }
    else {


        $('body').append('<div id="box"><div id="contectid" class="content"><div><div>');
        $("#contectid").append('<h2>Výpověď Původnímu dodavateli</h2><form><div class="firstSelect"><select id="select1" name="ovoce"><option value="171140000"> Odeslána výpověď dodavateli </option><option value="171140001"> Akceptována výpověď </option><option value="171140002"> Zamítnuta výpověď</option></select></div><div class="secondSelect"><select id="select2"> <option value="171140000">Chybná kmenová data  </option><option value="171140001">Chybný EIC/EAN </option><option value="171140002">Doba určitá </option><option value="171140003">Smlouva u naší společnosti již ukončena </option><option value="171140004">Chybná PM </option><option value="171140005">Neevidujeme smlouvu u sdružených službách/nejsme dodavatelem </option><option value="171140006">Změna dodavatele odvolána </option><option value="171140007">Nedoložena výpověď </option><option value="171140008">Nedodržena výpovědní doba </option><option value="171140009">Evidujeme výpověď </option></select></div></form><div id="sendResult"><b>OK</b></div>');
        var box = {
            "position": "absolute",
            "width": "100%",
            "height": "100%",
            "background": "url('https://vemexakvizice6.crm4.dynamics.com//WebResources/cre_white_bg') transparent"
        }
        $("#box").css(box);
        var box_h2 = {
            "margin": "15"
        }
        $("#box h2").css(box_h2);
        var box_content = {
            "width": "440px",
            "height": "170px",
            "background-color": "#fbfbfb",
            "padding": "20px",
            "border": "2px solid #98828e",
            "margin": "0 auto",
            "text-align": "center",
            "top": "10%",
            "position": "relative"
        }
        $("#box .content").css(box_content);
        var box_content_form_div = {
            "margin": "5px 0"
        }
        $("#box .content form div").css(box_content_form_div);
        var box_content_select2 = {
            "display": "none"
        }
        $("#box .content #select2").css(box_content_select2);
        var box_content_sendResult = {

            "padding": "5px",
            "background-color": "#fbfbfb",
            "color": "black",
            "border": "2px solid #98828e",
            "margin": "20px 150px",
            "cursor": "pointer"
        }
        $("#box .content #sendResult").css(box_content_sendResult);

        var box = $("#box");
        $("#select1").change(function () {
            if ($("#select1").val() == "171140002") {
                $("#select2").show();
            } else {
                $("#select2").hide();
            }
        });

        $("#sendResult").click(function () {
            $("#sendResult").unbind("click");
            $("#select1").unbind("change");

            $("#box").hide();
            var resignation_defeat_status = Xrm.Page.getAttribute("cre_resignation_defeat_status");
            resignation_defeat_status.setSubmitMode("always");

            var resignation_status = Xrm.Page.getAttribute("cre_resignation_status");
            resignation_status.setSubmitMode("always");
            resignation_status.setValue($("#select1").val());
            resignation_defeat_status.setValue(-1);
            var entity = Xrm.Page.data.entity;
            var verificationcomplete = Xrm.Page.getAttribute("cre_verificationcomplete");
            var validationcomplete = Xrm.Page.getAttribute("cre_validationcomplete");
            var supplierchangerequest = Xrm.Page.getAttribute("cre_supplierchangerequest");

            if ($("#select1").val() == 171140002) {

                resignation_defeat_status.setValue($("#select2").val());


                verificationcomplete.setSubmitMode("always");
                validationcomplete.setSubmitMode("always");
                status.setValue(171140000);
                verificationcomplete.setValue(false);
                validationcomplete.setValue(false);

            }
            else {

                supplierchangerequest.setSubmitMode("always");
                supplierchangerequest.setValue(true);
            }

            entity.save("save");

        });
    }

}

function ContractIncorrectClick() {
    var dateParts = [];
    var $cre_undefined_date = Xrm.Page.getAttribute("cre_undefined_date");
    do {
        var userInput = prompt("Zadejte správně datum: (format: dd.mm.rrrr)", userInput);
        if (userInput === null) {
            var task = new Object();
            task.Subject = "Kontaktovat zákazníka";
            task.RegardingObjectId = {
                Id: Xrm.Page.data.entity.getId(),
                LogicalName: Xrm.Page.data.entity.getEntityName()
            };
            REST.Create(task, "TaskSet", false);
            $cre_undefined_date.setValue(true);
            alert("Datum nevyplněno. Nyní byla vytvořena aktivita 'Kontaktovat zakazníka'.");
            Xrm.Page.data.entity.save("save");
            return;
        }
        dateParts = userInput.split(".");
    }
    while (!IsValidDate($.trim(userInput).replace(/\./g, "")));

    var date = new Date(dateParts[2], (dateParts[1] - 1), dateParts[0]);
    var $cre_date = Xrm.Page.getAttribute("cre_tofixedtermcontract");
    $cre_date.setValue(date);
    $cre_undefined_date.setValue(false);
    Xrm.Page.data.entity.save("save");
}

function IsValidDate(date) {
    if (date.length == 8) {
        var day = parseInt(date.substring(0, 2), 10);
        var month = parseInt(date.substring(2, 4), 10);
        var year = date.substring(4, 8);
        if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1900)
            return false;
        else
            return true;
    }
    else
        return false;
}

function CheckExistsEANEICCode() {
    var ean = Xrm.Page.getAttribute("cre_eanopm").getValue();
    var eic = Xrm.Page.getAttribute("cre_eic").getValue();
    if (ean)
        REST.RetrieveMultiple("cre_supplypointSet", "?$filter=cre_EANOPM eq '" + ean + "'&$top=2", true, function (result) {
            if (result)
                if (result.length > 1)
                    alert("Poznámka:\nEAN OPM kód odběrného místa již v systému existuje.");
        });
    else if (eic) {
        REST.RetrieveMultiple("cre_supplypointSet", "?$filter=cre_eic eq '" + eic + "'&$top=2", true, function (result) {
            if (result)
                if (result.length > 1)
                    alert("Poznámka:\nEIC kód odběrného místa již v systému existuje.");
        });
    }
}

function OnLoadCollapseSections() {
    var contactVer = Xrm.Page.getAttribute("cre_contactver");
    var contactVal = Xrm.Page.getAttribute("cre_contactval");
    var accountVer = Xrm.Page.getAttribute("cre_accountver");
    var accountVal = Xrm.Page.getAttribute("cre_accountval");
    var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
    var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
    var contact = Xrm.Page.getAttribute("cre_contact"),
        account = Xrm.Page.getAttribute("cre_account"),
        Tabs = Xrm.Page.ui.tabs;
    if (account.getValue() != null) {
        Tabs.get(2).setDisplayState("collapsed");
        contactVer.setValue(171140000);
        contactVal.setValue(171140000);
    }
    else if (contact.getValue() != null) {
        Tabs.get(3).setDisplayState("collapsed");
        Tabs.get(4).setDisplayState("collapsed");
        accountVer.setValue(171140000);
        accountVal.setValue(171140000);
        responsibleVer.setValue(171140000);
        responsibleVal.setValue(171140000);
    }
}

function OnChangeSectionState(index) {
    Xrm.Page.ui.tabs.get(index).setDisplayState("collapsed");
}

function OnLoadValidation() {
    ///////// POLE VALIDACE
    var contactVal = Xrm.Page.getControl("cre_contactval");
    var accountVal = Xrm.Page.getControl("cre_accountval");
    var responsibleVal = Xrm.Page.getControl("cre_responsibleval");
    var contactDetailVal = Xrm.Page.getControl("cre_contact_detailsval");
    var permanentAddressVal = Xrm.Page.getControl("cre_permanent_addressval");
    var mailingAdressVal = Xrm.Page.getControl("cre_mailing_adressval");
    var contractPeriodVal = Xrm.Page.getControl("cre_contract_periodval");
    var supplyPointPaymentTermsVal = Xrm.Page.getControl("cre_supplypoint_payment_termsval");

    var validationComplete = Xrm.Page.getControl("cre_validationcomplete");
    var validationComplete_value = Xrm.Page.getAttribute("cre_validationcomplete").getValue();
    var validationDesc = Xrm.Page.getControl("cre_aftervalidationdesc");
    var validationDate = Xrm.Page.getControl("cre_validationdate");
    var validationPerson = Xrm.Page.getControl("cre_validationperson");

    ///////// POLE VERIFIKACE
    var contactVer = Xrm.Page.getControl("cre_contactver");
    var accountVer = Xrm.Page.getControl("cre_accountver");
    var responsibleVer = Xrm.Page.getControl("cre_responsiblever");
    var contactDetailsVer = Xrm.Page.getControl("cre_contact_detailsver");
    var permanentAddressVer = Xrm.Page.getControl("cre_permanent_addressver");
    var mailingAdressVer = Xrm.Page.getControl("cre_mailing_adressver");
    var contractPeriodVer = Xrm.Page.getControl("cre_contract_periodver");
    var supplyPointPaymentTermsVer = Xrm.Page.getControl("cre_supplypoint_payment_termsver");

    var verificationComplete = Xrm.Page.getControl("cre_verificationcomplete");
    var verificationComplete_value = Xrm.Page.getAttribute("cre_verificationcomplete").getValue();
    var verificationDesc = Xrm.Page.getControl("cre_afterverificationdesc");
    var verificationDate = Xrm.Page.getControl("cre_verificationdate");
    var verificationPerson = Xrm.Page.getControl("cre_verificationperson");

    var status = Xrm.Page.getAttribute("cre_status");

    // rozdeleni plyn, ele--------------------------------------------------------------------------

    // cre_individualpricemwh kdyz plyn -> cre_individualprice_gas
    // cre_annualconsumptionvt kdyz plyn -> cre_annualconsumption_gas


    var individualpricemwh_control = Xrm.Page.getControl("cre_individualpricemwh");
    var individualpricent_control = Xrm.Page.getControl("cre_individualpricent");
    var stableprice_control = Xrm.Page.getControl("cre_stableprice");
    var individualprice_gas_control = Xrm.Page.getControl("cre_individualprice_gas");

    var annualconsumptionvt_control = Xrm.Page.getControl("cre_annualconsumptionvt");
    var annualconsumptionnt_control = Xrm.Page.getControl("cre_annualconsumptionnt");
    var annualconsumption_gas_control = Xrm.Page.getControl("cre_annualconsumption_gas");


    var individualpricemwh = Xrm.Page.getAttribute("cre_individualpricemwh");
    var individualprice_gas = Xrm.Page.getAttribute("cre_individualprice_gas");


    var annualconsumptionvt = Xrm.Page.getAttribute("cre_annualconsumptionvt");
    var annualconsumption_gas = Xrm.Page.getAttribute("cre_annualconsumption_gas");

    var exemption_tax_control = Xrm.Page.getControl("cre_exemption_tax");



    var eanopm_control = Xrm.Page.getControl("cre_eanopm");
    var eic_control = Xrm.Page.getControl("cre_eic");
    var distributorelectricity_control = Xrm.Page.getControl("cre_distributorelectricity");
    var distributorgas_control = Xrm.Page.getControl("cre_distributorgas");
    var annualconsumptionnt_control = Xrm.Page.getControl("cre_annualconsumptionnt");
    var breakervalue_control = Xrm.Page.getControl("cre_breakervalue");
    var distributionrate_control = Xrm.Page.getControl("cre_distributionrate");
    var connectiontype_control = Xrm.Page.getControl("cre_connectiontype");

    var eanopm = Xrm.Page.getAttribute("cre_eanopm");
    var eanopm_value = eanopm.getValue();

    var eic = Xrm.Page.getAttribute("cre_eic");
    var eic_value = eic.getValue();

    if (eanopm_value != null) {
        eanopm_control.setVisible(true);
        eic_control.setVisible(false);
        distributorelectricity_control.setVisible(true);
        distributorgas_control.setVisible(false);
        annualconsumptionnt_control.setVisible(true);
        breakervalue_control.setVisible(true);
        distributionrate_control.setVisible(true);
        connectiontype_control.setVisible(true);

        individualpricemwh_control.setVisible(true);
        individualpricent_control.setVisible(true);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(false);

        annualconsumptionvt_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        annualconsumption_gas_control.setVisible(false);

        exemption_tax_control.setVisible(false);
        if (IsValidEAN(eanopm_value) == false)
            alert("EAN není validní");

    }
    else if (eic_value != null) {
        eanopm_control.setVisible(false);
        eic_control.setVisible(true);
        distributorelectricity_control.setVisible(false);
        distributorgas_control.setVisible(true);
        annualconsumptionnt_control.setVisible(false);
        breakervalue_control.setVisible(false);
        distributionrate_control.setVisible(false);
        connectiontype_control.setVisible(false);

        individualpricemwh_control.setVisible(false);
        individualpricent_control.setVisible(false);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(true);

        annualconsumptionvt_control.setVisible(false);
        annualconsumptionnt_control.setVisible(false);
        annualconsumption_gas_control.setVisible(true);

        exemption_tax_control.setVisible(true);

        if (individualpricemwh.getValue() != null && individualprice_gas.getValue() == null) {
            individualprice_gas.setValue(individualpricemwh.getValue())
        }

        if (annualconsumptionvt.getValue() != null && annualconsumption_gas.getValue() == null) {
            annualconsumption_gas.setValue(annualconsumptionvt.getValue())
        }
        if (IsValidEIC(eic_value) == false)
            alert("EIC není validní");

    }
    else {
        alert("Není vyplněn kód EIC, nebo EAN");
        eanopm_control.setVisible(true);
        eic_control.setVisible(true);
        distributorelectricity_control.setVisible(true);
        distributorgas_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        breakervalue_control.setVisible(true);
        distributionrate_control.setVisible(true);
        connectiontype_control.setVisible(true);

        individualpricemwh_control.setVisible(true);
        individualpricent_control.setVisible(true);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(true);

        annualconsumptionvt_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        annualconsumption_gas_control.setVisible(true);
        exemption_tax_control.setVisible(true);
    }
    // rozdeleni plyn, ele-----------------------------



    if (verificationComplete_value == false) {

        contactVal.setVisible(false);
        accountVal.setVisible(false);
        responsibleVal.setVisible(false);
        contactDetailVal.setVisible(false);
        permanentAddressVal.setVisible(false);
        mailingAdressVal.setVisible(false);
        contractPeriodVal.setVisible(false);
        supplyPointPaymentTermsVal.setVisible(false);
        validationDesc.setVisible(false);
        validationDate.setVisible(false);
        validationPerson.setVisible(false);
        validationComplete.setVisible(false);

    } else if (verificationComplete_value == true && validationComplete_value == false) {

        if (status.getValue() == 171140004)
            verificationPerson.setVisible(false);
        contactVer.setDisabled(true);
        accountVer.setDisabled(true);
        responsibleVer.setDisabled(true);
        contactDetailsVer.setDisabled(true);
        permanentAddressVer.setDisabled(true);
        mailingAdressVer.setDisabled(true);
        contractPeriodVer.setDisabled(true);
        supplyPointPaymentTermsVer.setDisabled(true);
        verificationDesc.setDisabled(true);
        Xrm.Page.getAttribute("cre_aftervalidationdesc").setValue(Xrm.Page.getAttribute("cre_afterverificationdesc").getValue());

    } else if (verificationComplete_value == true && validationComplete_value == true) {

        Xrm.Page.ui.controls.forEach(function (control, index) {

            control.setDisabled(true);

        });

    }

    verificationComplete.setDisabled(true);
    validationComplete.setDisabled(true);
    validationDate.setDisabled(true);
    verificationDate.setDisabled(true);

    if (Xrm.Page.getAttribute("cre_fromfixedtermcontract").getValue() != null && validationComplete_value != true) {

        var startDate = Xrm.Page.getAttribute('cre_fromfixedtermcontract').getValue();
        var expiryDate = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate() - 1);
        var expiryField = Xrm.Page.getAttribute('cre_resignation').setValue(expiryDate);

    }
    else if (Xrm.Page.getAttribute("cre_fromindefiniteperiodcontract").getValue() != null && validationComplete_value != true) {

        var startDate1 = Xrm.Page.getAttribute('cre_fromindefiniteperiodcontract').getValue();
        var expiryDate1 = new Date(startDate1.getFullYear(), startDate1.getMonth(), startDate1.getDate() - 1);
        var expiryField1 = Xrm.Page.getAttribute('cre_resignation').setValue(expiryDate1);

    }

}

function OnSaveValidation(context) {
    var eic = Xrm.Page.getAttribute("cre_eic");
    var eic_value = eic.getValue();

    var individualpricemwh = Xrm.Page.getAttribute("cre_individualpricemwh");
    var individualprice_gas = Xrm.Page.getAttribute("cre_individualprice_gas");
    var annualconsumptionvt = Xrm.Page.getAttribute("cre_annualconsumptionvt");
    var annualconsumption_gas = Xrm.Page.getAttribute("cre_annualconsumption_gas");

    if (eic_value != null) {
        individualpricemwh.setValue(individualprice_gas.getValue())
        annualconsumptionvt.setValue(annualconsumption_gas.getValue())
    }

    ///////// POLE VALIDACE
    var contactVal = Xrm.Page.getAttribute("cre_contactval");
    var accountVal = Xrm.Page.getAttribute("cre_accountval");
    var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
    var contactDetailVal = Xrm.Page.getAttribute("cre_contact_detailsval");
    var permanentAddressVal = Xrm.Page.getAttribute("cre_permanent_addressval");
    var mailingAdressVal = Xrm.Page.getAttribute("cre_mailing_adressval");
    var contractPeriodVal = Xrm.Page.getAttribute("cre_contract_periodval");
    var supplyPointPaymentTermsVal = Xrm.Page.getAttribute("cre_supplypoint_payment_termsval");

    var contactVal_value = contactVal.getValue();
    var accountVal_value = accountVal.getValue();
    var responsibleVal_value = responsibleVal.getValue();
    var contactDetailVal_value = contactDetailVal.getValue();
    var permanentAddressVal_value = permanentAddressVal.getValue();
    var mailingAdressVal_value = mailingAdressVal.getValue();
    var contractPeriodVal_value = contractPeriodVal.getValue();
    var supplyPointPaymentTermsVal_value = supplyPointPaymentTermsVal.getValue();

    var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
    var validationComplete_value = validationComplete.getValue();
    var validationDesc = Xrm.Page.getAttribute("cre_aftervalidationdesc");
    var validationDesc_value = validationDesc.getValue();

    ///////// POLE VERIFIKACE
    var contactVer = Xrm.Page.getAttribute("cre_contactver");
    var accountVer = Xrm.Page.getAttribute("cre_accountver");
    var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
    var contactDetailsVer = Xrm.Page.getAttribute("cre_contact_detailsver");
    var permanentAddressVer = Xrm.Page.getAttribute("cre_permanent_addressver");
    var mailingAdressVer = Xrm.Page.getAttribute("cre_mailing_adressver");
    var contractPeriodVer = Xrm.Page.getAttribute("cre_contract_periodver");
    var supplyPointPaymentTermsVer = Xrm.Page.getAttribute("cre_supplypoint_payment_termsver");
    var status = Xrm.Page.getAttribute("cre_status");
    var status_value = status.getValue();

    var contactVer_value = contactVer.getValue();
    var accountVer_value = accountVer.getValue();
    var responsibleVer_value = responsibleVer.getValue();
    var contactDetailsVer_value = contactDetailsVer.getValue();
    var permanentAddressVer_value = permanentAddressVer.getValue();
    var mailingAdressVer_value = mailingAdressVer.getValue();
    var contractPeriodVer_value = contractPeriodVer.getValue();
    var supplyPointPaymentTermsVer_value = supplyPointPaymentTermsVer.getValue();


    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();
    var verificationDesc = Xrm.Page.getAttribute("cre_afterverificationdesc");
    var verificationDesc_value = verificationDesc.getValue();


    var cre_aceptedon = Xrm.Page.getAttribute("cre_aceptedon"); // smlouva prijata dne OK
    var cre_aceptedon_value = cre_aceptedon.getValue();

    var cre_dateofsignature = Xrm.Page.getAttribute("cre_dateofsignature"); // datum podpisu smlouvz
    var cre_dateofsignature_value = cre_dateofsignature.getValue();

    var cre_eanopm = Xrm.Page.getAttribute("cre_eanopm"); // cre_eanopm
    var cre_eanopm_value = cre_eanopm.getValue();

    var cre_eic = Xrm.Page.getAttribute("cre_eic"); // cre_eic
    var cre_eic_value = cre_eic.getValue();

    var cre_distributorelectricity = Xrm.Page.getAttribute("cre_distributorelectricity"); // cre_distributorelectricity EAN
    var cre_distributorelectricity_value = cre_distributorelectricity.getValue();

    var cre_distributorgas = Xrm.Page.getAttribute("cre_distributorgas"); // cre_distributorgas EIC
    var cre_distributorgas_value = cre_distributorgas.getValue();

    var cre_advancepayment = Xrm.Page.getAttribute("cre_advancepayment"); //výše zálohy, cre_advancepayment OK
    var cre_advancepayment_value = cre_advancepayment.getValue();

    var cre_resignation = Xrm.Page.getAttribute("cre_resignation"); // výpověď k datu cre_resignation OK
    var cre_resignation_value = cre_resignation.getValue();

    var cre_originaldistributor = Xrm.Page.getAttribute("cre_originaldistributor"); //původního dodavatele cre_originaldistributor
    var cre_originaldistributor_value = cre_originaldistributor.getValue();

    var reVerification = Xrm.Page.getAttribute("cre_reverification");


    if (status_value != 171140006 && status_value != 171140002 && reVerification.getValue() != true) {

        if (cre_aceptedon_value == null) {

            alert("Smlouva přijata dne");
            context.getEventArgs().preventDefault();
            return false;

        }
        if (cre_dateofsignature_value == null) {

            alert("Datum podpisu smlouvy");
            context.getEventArgs().preventDefault();
            return false;

        }

        if (cre_advancepayment_value == null) {

            alert("Výše zálohy");
            context.getEventArgs().preventDefault();
            return false;

        }

        if (cre_resignation_value == null) {

            alert("Výpověď k datu");
            context.getEventArgs().preventDefault();
            return false;

        }

        if (cre_originaldistributor_value == null) {

            alert("Původní dodavatel");
            context.getEventArgs().preventDefault();
            return false;

        }


        if (cre_eanopm_value != null && cre_distributorelectricity_value == null) {

            alert("Distributor elektřiny");
            context.getEventArgs().preventDefault();
            return false;

        }
        if (cre_eic_value != null && cre_distributorgas_value == null) {

            alert("Distributor plynu");
            context.getEventArgs().preventDefault();
            return false;

        }

    }

    var unvalidatedOptionValue = 171140001;
    var unverificatedOptionValue = 171140001;

    var firstTimeUnavalibleStatus = 171140003;
    var secondTimeUnavalibleStatus = 171140004;

    if (verificationComplete_value == false && status_value != 171140006 && status_value != 171140002 && reVerification.getValue() != true) {

        if (contactVer_value == unverificatedOptionValue || accountVer_value == unverificatedOptionValue || responsibleVer_value == unverificatedOptionValue || contactDetailsVer_value == unverificatedOptionValue || permanentAddressVer_value == unverificatedOptionValue || mailingAdressVer_value == unverificatedOptionValue || contractPeriodVer_value == unverificatedOptionValue || supplyPointPaymentTermsVer_value == unverificatedOptionValue) {

            if (status.getValue() != 171140005) {

                if (status_value != firstTimeUnavalibleStatus && status_value != secondTimeUnavalibleStatus) {

                    alert("Musíte zverifikovat celý formulář.");
                    context.getEventArgs().preventDefault();
                    return false;

                }

            }

        }

        if (verificationDesc_value == null) {

            alert("Musíte zvolit o jaký případ se jedná.");
            context.getEventArgs().preventDefault();
            return false;

        }

    } else if (validationComplete_value == false && status_value != 171140006 && status_value != 171140002 && reVerification.getValue() != true) {

        if (contactVal_value == unvalidatedOptionValue || accountVal_value == unvalidatedOptionValue || responsibleVal_value == unvalidatedOptionValue || contactDetailVal_value == unvalidatedOptionValue || permanentAddressVal_value == unvalidatedOptionValue || mailingAdressVal_value == unvalidatedOptionValue || contractPeriodVal_value == unvalidatedOptionValue || supplyPointPaymentTermsVal_value == unvalidatedOptionValue) {

            alert("Musíte zvalidovat celý formulář.");
            context.getEventArgs().preventDefault();
            return false;

        }

        if (validationDesc_value == null) {

            alert("Musíte zvolit o jaký případ se jedná.");
            context.getEventArgs().preventDefault();
            return false;

        }

    }
}

function convertor(value) {
    if (value == 0) return 0;
    if (value == 1) return 1;
    if (value == 2) return 2;
    if (value == 3) return 3;
    if (value == 4) return 4;
    if (value == 5) return 5;
    if (value == 6) return 6;
    if (value == 7) return 7;
    if (value == 8) return 8;
    if (value == 9) return 9;
    if (value == "A") return 10;
    if (value == "B") return 11;
    if (value == "C") return 12;
    if (value == "D") return 13;
    if (value == "E") return 14;
    if (value == "F") return 15;
    if (value == "G") return 16;
    if (value == "H") return 17;
    if (value == "I") return 18;
    if (value == "J") return 19;
    if (value == "K") return 20;
    if (value == "L") return 21;
    if (value == "M") return 22;
    if (value == "N") return 23;
    if (value == "O") return 24;
    if (value == "P") return 25;
    if (value == "Q") return 26;
    if (value == "R") return 27;
    if (value == "S") return 28;
    if (value == "T") return 29;
    if (value == "U") return 30;
    if (value == "V") return 31;
    if (value == "W") return 32;
    if (value == "X") return 33;
    if (value == "Y") return 34;
    if (value == "Z") return 35;
    if (value == "-") return 36;
}

function IsValidEIC(EIC) {
    var isValidEIC = true;
    if (EIC.length != 16)
        isValidEIC = false;
    else {
        var v1 = 16 * convertor(EIC[0]);
        var v2 = 15 * convertor(EIC[1]);
        var v3 = 14 * convertor(EIC[2]);
        var v4 = 13 * convertor(EIC[3]);
        var v5 = 12 * convertor(EIC[4]);
        var v6 = 11 * convertor(EIC[5]);
        var v7 = 10 * convertor(EIC[6]);
        var v8 = 9 * convertor(EIC[7]);
        var v9 = 8 * convertor(EIC[8]);
        var v10 = 7 * convertor(EIC[9]);
        var v11 = 6 * convertor(EIC[10]);
        var v12 = 5 * convertor(EIC[11]);
        var v13 = 4 * convertor(EIC[12]);
        var v14 = 3 * convertor(EIC[13]);
        var v15 = 2 * convertor(EIC[14]);
        var v16_control = convertor(EIC[15]);
        var controlAdd = v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9 + v10 + v11 + v12 + v13 + v14 + v15;
        var modulo = 37 - (controlAdd % 37);
        if (modulo == 37) modulo = 0;
        if (v16_control != modulo) isValidEIC = false;
        if (EIC.substring(0, 4) != "27ZG") isValidEIC = false;
    }
    return isValidEIC;
}

function IsValidEAN(EAN) {
    var isValidEAN = true;
    var eanRegex = /^\d+$/;

    if (!eanRegex.test(EAN)) isValidEAN = false;
    if (EAN.length != 18) {
        isValidEAN = false;
    }
    else {
        var ean1 = 3 * EAN[0];
        var ean2 = 1 * EAN[1];
        var ean3 = 3 * EAN[2];
        var ean4 = 1 * EAN[3];
        var ean5 = 3 * EAN[4];
        var ean6 = 1 * EAN[5];
        var ean7 = 3 * EAN[6];
        var ean8 = 1 * EAN[7];
        var ean9 = 3 * EAN[8];
        var ean10 = 1 * EAN[9];
        var ean11 = 3 * EAN[10];
        var ean12 = 1 * EAN[11];
        var ean13 = 3 * EAN[12];
        var ean14 = 1 * EAN[13];
        var ean15 = 3 * EAN[14];
        var ean16 = 1 * EAN[15];
        var ean17 = 3 * EAN[16];
        var ean18_control = EAN[17];

        var eanmod = ean1 + ean2 + ean3 + ean4 + ean5 + ean6 + ean7 + ean8 + ean9 + ean10 + ean11 + ean12 + ean13 + ean14 + ean15 + ean16 + ean17;

        var eanmod1 = 10 - (eanmod % 10);
        if (eanmod1 == 10) eanmod1 = 0;
        if (ean18_control != eanmod1) isValidEAN = false;
        if (EAN.substring(0, 9) != "859182400") isValidEAN = false;
    }
    return isValidEAN;
}