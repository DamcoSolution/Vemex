﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
    class enums
    {
        
        public enum contracttype
        {

            
            Plyn = 171140000,
            
            Elektrina = 171140001

        }

        public enum sex
        {


            muz = 171140000,

            zena = 171140001,
            Default = -1

        }
        
        public enum informationdelivery
        {

            
            emailem = 171140002,
            
            postou = 171140000,
            
            web = 171140001,
            
            Default = -1

        }

        
        public enum distributorelectricity
        {

            
            CEZ_Distribuce = 171140000,
            
            EON_Distribuce = 171140001,
            
            PRE_Distribuce = 171140002,
            
            SV_servisni = 171140003,

            Energy_Usti_nad_Labem = 171140004,
            
            Petr_Hurta = 171140005,
            QUANTUM = 171140006,
            VLCEK_Josef = 171140007,
            Default = -1

        }

        
        public enum paymenttype
        {

            
            Prevodem_z_uctu = 171140000,
            
            Inkasem = 171140001,
            
            Slozenkou = 171140002,
            
            Default = -1

        }

        
        public enum titulpred
        {

            
            ak = 171140022,
            
            akArch = 171140023,
            
            akMal = 171140024,
            
            akSoch = 171140025,
            
            arch = 171140026,
            
            Bc = 171140004,
            
            BcA = 171140005,
            
            Doc = 171140047,
            
            DocMgrEtMgr = 171140051,
            
            DocIng = 171140032,
            
            DocIngDr = 171140002,
            
            DocMUDr = 171140000,
            
            DocPhDr = 171140035,
            
            DocRNDr = 171140033,
            
            Dr = 171140031,
            
            DrDoc = 171140042,
            
            DrIng = 171140034,
            
            DrProf = 171140036,
            
            ICDr = 171140011,
            
            Ing = 171140008,
            
            IngArch = 171140009,
            
            IngBc = 171140053,
            
            IngMgr = 171140038,
            
            IngPhDr = 171140043,
            
            JUDr = 171140010,
            
            JUDrMgr = 171140050,
            
            JUDrIng = 171140039,
            
            Mag = 171140052,
            
            MDDr = 171140012,
            
            MgA = 171140007,
            
            Mgr = 171140006,
            
            MgrBc = 171140049,
            
            MgrEtMgrIng = 171140056,
            
            MSDr = 171140013,
            
            MUC = 171140014,
            
            MUDr = 171140015,
            
            MVDr = 171140016,
            
            NenalezenTitul = 171140057,
            
            PaedDr = 171140017,
            
            PharmDr = 171140018,
            
            PhDr = 171140019,
            
            PhDrMgr = 171140054,
            
            PhMr = 171140027,
            
            pplkIng = 171140041,
            
            Prof = 171140048,
            
            ProfDr = 171140037,
            
            ProfIng = 171140046,
            
            ProfMUDr = 171140044,
            
            ProfMUDrPhMrDr = 171140001,
            
            ProfRNDr = 171140045,
            
            RCDr = 171140030,
            
            RNDr = 171140028,
            
            RSDr = 171140029,
            
            ThD = 171140003,
            
            ThDr = 171140055,
            
            ThLic = 171140020,
            
            ThMgr = 171140021,
            
            MVDrIng = 171140059, 
            
            Default = -1

        }

        
        public enum titulza
        {

            
            CSc = 171140003,
            
            DiplArch = 171140012,
            
            DiplEkon = 171140013,
            
            DiplGeol = 171140017,
            
            DiplIng = 171140014,
            
            DiplTech = 171140011,
            
            DiplTheol = 171140015,
            
            DiS = 171140002,
            
            DrSc = 171140004,
            
            LLM = 171140007,
            
            MA = 171140016,
            
            MD = 171140010,
            
            MS = 171140008,
            
            MBA = 171140006,
            
            MSc = 171140009,
            
            PhD = 171140005,
            
            TitulNenalezen = 171140001,
            
            Default = -1

        }

        
        public enum originaldistributor
        {
            AKCENTA_ENERGIE = 171140033,
            ALPIQ_ENERGY_SE = 171140034,
            Amper_Market = 171140032,
            ArmexEnergy = 171140000,         
            Bicorn = 171140002,         
            BohemiaEnergy = 171140001,         
            Central_Energy = 171140025,
            Centropol = 171140003,   
            COMFORT_ENERGY = 171140035,
            CORASTA = 171140026,
            Czech_Coal = 171140037,
            Ceska_energie = 171140036,
            CeskeEnergetickeCentrum = 171140004, 
            Ceske_Energeticke_Centrum_Jih = 171140038,
            CEZ = 171140005,    
            Dalkia_Commodities_CZ = 171140039,
            Dalkia_Ceska_republika = 171140040,
            EON = 171140006,             
            Elimon = 171140007,  
            Eneka = 171140041,
            Energie_2 = 171140027,
            ENERGO_LaR = 171140042,
            ENRA_SERVICES =171140028,
            EP_Energy_Traiding = 171140031,  
            EuropeEasyEnergy = 171140008,   
            GasInternational = 171140009,            
            GlobalEnergy = 171140010,            
            HALIMEDES =171140029,
            KORLEA_INVEST = 171140043,
            LamaEnergy = 171140011,            
            Lumen = 171140019,    
            Lumius = 171140044,
            NanoEnergies = 171140018,   
            Optim_Trade = 171140045,
            OptimumEnergy = 171140012,  
            Pragoplyn = 171140046,
            PrazskaEnergetika = 171140013,            
            PrazskaPlynarenska = 171140014,            
            Quantum = 171140015,            
            RWE = 171140020,    
            RWE_Key_Account_CZ = 171140047,
            RWEJMP = 171140022,           
            RWESMP = 171140021,            
            RWEVCP = 171140023,    
            Slovenske_elektrarne = 171140048,
            SPPCZ = 171140016,   
            StEnergy = 171140017,
            SVT_Group = 171140049,
            United_Energy_Trading = 171140050,
            V_Elektra = 171140051,
            VEMEX_Energie  =171140030,
            XEnergie = 171140024,
            Zapadomoravska_energeticka = 171140052,
            FONERGY = 171140053,

            Default = -1

        }

        
        public enum paymenttypeadvances
        {

            
            PrevodemZUctu = 171140000,
            
            Inkasem = 171140001,
            
            Slozenkou = 171140002,
            
            SIPO = 171140003,
            
            Default = -1

        }

        
        public enum connectiontype
        {

            
            Jednofazove = 171140000,
            
            Trifazove = 171140001,
            
            Default = -1

        }

        
        public enum paymentscheduledelivery
        {

            
            emailem = 171140000,
            
            postou = 171140001,
            
            Default = -1

        }

        
        public enum advanceperiod
        {

            
            Mesicne = 171140000,
            
            Ctvrtletne = 171140001,
            
            Zadne = 171140002,
            
            Default = -1

        }

        
        public enum afterverificationdesc
        {

            
            ZmenaDodavatele = 171140000,
            
            PrepisSeZD = 171140001,
            
            NovyOdber = 171140002,
            
            ZmenaDodavateleZmenaCeny = 171140003,
            
            PrepisVRamciVEMEXEnergie = 171140004,

            ZmenaProduktu = 171140005,
            
            Default = -1

        }

        
        public enum distributorgas
        {

            
            RWEGasNet = 171140000,
            
            EONDistribuce = 171140001,
            
            JMPNet = 171140002,
            
            SMPNet = 171140003,
            
            VČPNet = 171140004,
            
            PrazskaPlynarenskaDistribuce = 171140005,
                        
            Default = -1
            
        }

        
        public enum aftervalidationdesc
        {

            
            ZmenaDodavatele = 171140000,
            
            PrepisSeZD = 171140001,
            
            NovyOdber = 171140002,
            
            ZmenaDodavateleZmenaCeny = 171140003,
            
            PrepisVramciVEMEXEnergie = 171140004,
            
            Default = -1

        }

        
        public enum fixedtermcontractyears
        {

            
            Rok1 = 171140000,
            
            Roky2 = 171140001,
            
            Roky3 = 171140002,

            Roky5 = 171140003,
            
            Default = -1

        }

        
        public enum distributionrate
        {

            
            C01d = 171140000,
            
            C02d = 171140001,
            
            C03d = 171140002,
            
            C25d = 171140003,
            
            C26d = 171140004,
            
            C35d = 171140005,
            
            C45d = 171140006,
            
            C55d = 171140007,
            
            C56d = 171140008,
            
            C62d = 171140009,
            
            D01d = 171140010,
            
            D02d = 171140011,
            
            D25d = 171140012,
            
            D26d = 171140013,
            
            D35d = 171140014,
            
            D45d = 171140015,
            
            D55d = 171140016,
            
            D56d = 171140017,
            
            Default = -1

        }

        
        public enum contractreason
        {

            
            ZmenaDodavatele = 171140000,
            
            PrepisSeZD = 171140001,
            
            NovyOdber = 171140002,
            
            ZmenaDodavateleZmenaCeny = 171140003,
            
            PrepisVRamciVEMEXEnergie = 171140004,
            
            ZmenaProduktu = 171140005,
            
            Default = -1

        }
        public enum contractoptions
        {

            Urcitou = 1,

            Urcitou_roky = 2,

            Neurcitou = 3,

            Default = -1

        }
    }

}
