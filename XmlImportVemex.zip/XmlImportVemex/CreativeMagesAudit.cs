﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class CreativeMagesAudit
    {
        static string LogicalName = "";
        static Guid id = Guid.Empty;

        public static string errorMessage="";
        public static string dataMissingMessage="";

        public static Guid CreateAudit(string subject, int prioritycode, string filename,int statecode)
        {
            try
            {

                Entity creativemagesaudit = new Entity("cre_creativemagesaudit");
                creativemagesaudit["subject"] = subject; //predmet,string, povinne
                creativemagesaudit["prioritycode"] = new OptionSetValue(prioritycode); //priorita,options sets 0 nizka 1 stredni 2 vysoka
                creativemagesaudit["scheduledstart"] = DateTime.Now; //pocatecni datum, datetime
                creativemagesaudit["cre_file_name"] = filename; //nazev souboru string
                creativemagesaudit["statecode"] = new OptionSetValue(statecode); //status
                //creativemagesaudit["cre_successfully_imported"] = successfully_imported; //pocet uspechu
                //creativemagesaudit["cre_unsuccessful_imported"] = firstName; //pocet neuspechu

                LogicalName = creativemagesaudit.LogicalName;
                id = ServiceControl.Create(creativemagesaudit, ServiceControl.GetService());
                return id;

            }
            catch (Exception ex)
            {

                EmaiSender.SendError("consoleApp error CreativemagesAudit", ex.Message);
                return Guid.Empty;

            }
        }

        public static Guid CreateMessage(string name,int import_status,string line_record,int statecode)
        {
            try
            {

                Entity auditmessage = new Entity("cre_auditmessage");
                auditmessage["cre_name"] = name; //nazev, string
                auditmessage["cre_creativemagesauditid"] = new EntityReference { LogicalName = LogicalName, Id = id };  //CReativeMages audit navazani na vztah
                auditmessage["cre_import_status"] = new OptionSetValue(import_status); // Uzavřeno 171 140 000, Chyba aplikace 171 140 001,Uzavřeno, některá data chybí 171 140 002
                auditmessage["cre_line_record"] = line_record; //radek zaznamu, string
                if (dataMissingMessage.Length > 9000) dataMissingMessage = dataMissingMessage.Substring(0, 8990);
                if (errorMessage.Length > 9000) errorMessage = errorMessage.Substring(0, 8990);
                auditmessage["cre_missing_data"] = dataMissingMessage; //chybejici data
                auditmessage["cre_application_error"] = errorMessage; //chyby aplikace
                auditmessage["statecode"] = new OptionSetValue(statecode);
                dataMissingMessage="";
                errorMessage="";

                ServiceControl.Create(auditmessage, ServiceControl.GetService());
                return id;

            }
            catch (Exception ex)
            {

                EmaiSender.SendError("consoleApp error auditmessage", ex.Message);
                return Guid.Empty;

            }
        }

        public static bool AddErrorToMessage(string errormessage)
        {
            
            errorMessage += errormessage + "\n";
            return true;

        }

        public static bool AddMissingDataToMessage(string missingdata)
        {
          
            dataMissingMessage += missingdata + "\n";
            return true;

        }

    }
}
