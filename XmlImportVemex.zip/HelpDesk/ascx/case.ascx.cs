﻿using HelpDesk.Controls;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.EntityObjects;
using CreativeMages.Xrm;

namespace HelpDesk.ascx
{
    public partial class _case : System.Web.UI.UserControl
    {
        public List<CreativeMages.Xrm.Contact> ContactList;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (LoginControl.IsLogged() && ServiceControl.IsReady())
                {
                    detailsCheckBoxList.DataSource = CustomerControl.GetContractDetail(LoginControl.GetUsersContract().id);
                    detailsCheckBoxList.DataTextField = "title";
                    detailsCheckBoxList.DataValueField = "id";
                    detailsCheckBoxList.RepeatLayout = RepeatLayout.UnorderedList;
                    detailsCheckBoxList.DataBind();

                    using (CreativeMages.Xrm.XrmContext context = new XrmContext(ServiceControl.GetService()))
                    {

                        var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.Case).FirstOrDefault();
                        if (rights.AccessLevel == AccessLevel.kontakt)
                        {
                            ContactList = context.ContactSet.Where(lst => lst.ContactId == LoginControl.GetUser().id).ToList();
                        }
                        else
                        {
                            ContactList = context.ContactSet.Where(lst => lst.AccountId ==
                                new EntityReference(CreativeMages.Xrm.Account.EntityLogicalName, LoginControl.GetUser().CustomerId)).ToList();
                        }
                    }
                }
            }
        }

        protected void logoutBtn_Click(object sender, ImageClickEventArgs e)
        {
            if (LoginControl.Logout())
                ErrorControl.ThrowError("Byl jste odhlášen.");
            Response.Redirect("~/");
        }

        protected void sendCaseBtn_Click(object sender, ImageClickEventArgs e)
        {           
                Guid detailId = new Guid(detailsCheckBoxList.SelectedItem.Value);
                int limit = cannotCheck.Checked ? 171140001 : 0;
                limit = limitedCheck.Checked ? 171140000 : limit;
                limit = canCheck.Checked ? 1 : limit;

                string solution = consultationCheck.Checked ? "Konzultace" : string.Empty;
                solution = technicianCheck.Checked ? "Zásah technika" : solution;

                int addHours = cannotCheck.Checked ? 1 : 0;
                addHours = limitedCheck.Checked ? 3 : addHours;
                addHours = canCheck.Checked ? 6 : addHours;

                string phone = phoneTxt.Text.Trim();
                string description = descriptionTxt.InnerHtml.ToString();

                ProductItem product = CustomerControl.GetProductFromDetail(detailId);
            

                if (product != null)
                {
                    // create case
                    Guid _caseId = CustomerControl.CreateCase(
                        "Servisní případ - " + DateTime.Now.ToString(),
                        2,
                        3,
                        limit,
                        DateTime.Now.AddHours(addHours).ToUniversalTime(),
                        LoginControl.GetUser().id,
                        LoginControl.GetUsersContract().id,
                        detailId,
                        product.id
                        );

                    if (_caseId != Guid.Empty)
                    {
                        // create annotation if description is not empty
                        if (description != string.Empty || fileUploadAttachment.HasFile)
                        {
                            Annotation annotation = new Annotation();
                            if (fileUploadAttachment.HasFile)
                            {
                               
                                
                                    annotation.FileName = fileUploadAttachment.FileName;
                                    annotation.DocumentBody = Convert.ToBase64String(fileUploadAttachment.FileBytes);
                                
                                //  Convert.ToBase64String(
                            }
                            else
                            {

                                annotation.Subject= "Dodatečná poznámka";
                                annotation.NoteText = "Kontaktní telefonní číslo: " + phone + "\n\n" + description;
                                annotation.ObjectId =  new EntityReference(Incident.EntityLogicalName, _caseId);
                                
                            }
                            CustomerControl.AddAnnotation(annotation);
                        }

                        ErrorControl.ThrowError("Servisní případ byl úspěšně odeslán.");
                    }
                    else
                        ErrorControl.ThrowError("Někde se stala chyba. Zkuste to znovu.");
                }
                else
                    ErrorControl.ThrowError("Někde se stala chyba. Zkuste to znovu.");

                // reload page
                Response.Redirect(UrlControl.GetPathUrl() + "/home");
            }
        
    }
}