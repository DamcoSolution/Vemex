﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk
{
    public enum Entity_Name
    {
        plyn = 171140000,
        elektrina = 171140001,
        obekomodity = 171140002,
        kontakt = 171140003,
        cre_commission = 171140004,
        cre_verifyform = 171140005,
        DataImport = 171140006,
        Case = 171140007
    }

    public enum ContractType
    {
        Domácnost = 171140000,
        Maloodběr = 171140001
    }

    public enum CaseStatus
    {
        plyn = 171140000,
        elektrina = 171140001,
        obekomodity = 171140002,
        kontakt = 171140003,
        cre_commission = 171140004,
        cre_verifyform = 171140005,
        DataImport = 171140006,
        Case = 171140007

    }
    public enum CaseType
    {
        plyn = 171140000,
        elektrina = 171140001,
        obekomodity = 171140002,
        kontakt = 171140003,
        cre_commission = 171140004,
        cre_verifyform = 171140005,
        DataImport = 171140006,
        Case = 171140007

    }
}