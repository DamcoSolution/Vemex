﻿(function ($)
{
    $.fn.center = function (options)
    {
        var settings = $.extend({ "location": "center" }, options);
        return this.each(function ()
        {
            var $this = $(this);
            switch (settings.location)
            {
                case "center":
                    $this.css({ "left": (($(window).width() / 2) - ($this.width() / 2)) + "px", "top": (($(window).height() / 2) - ($this.height() / 2)) + "px" });
                    break;
                case "top":
                    $this.css({ "left": (($(window).width() / 2) - ($this.width() / 2)) + "px" });
                    break;
                case "left":
                    $this.css({ "top": (($(window).height() / 2) - ($this.height() / 2)) + "px" });
                    break;
            }
        });
    };
})(jQuery);

var Logout = {

    Preload: function (width, duration, interval, callback) {

        var tick = 0;
        var position = 0;

        $(document).mousemove(function () {
            tick = 0;
        });

        setInterval(function () {
            tick++;
            var position = ((width / (duration * 1000)) * (tick * 1000)) - width;
            if (callback)
                callback(position);
        }, (interval * 1000));

    },

    Redirect: function (location) {

        window.location = location;

    }

};

var hover =
    {
        alpha: function (elements, alpha, time)
        {
            $(elements).hover(function ()
            {
                $(this).stop().fadeTo(time, alpha[0]);
            },
            function ()
            {
                $(this).stop().fadeTo(time, alpha[1]);
            });
        },
        up: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = $(elements).position().top;
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "top": pos - pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "top": pos + "px" }, time);
                });
            }
        },
        left: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = $(elements).position().left;
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "left": pos - pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "left": pos + "px" }, time);
                });
            }
        },
        right: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = $(elements).position().left;
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "left": pos + pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "left": pos + "px" }, time);
                });
            }
        },
        down: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = $(elements).position().top;
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "top": pos + pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "top": pos + "px" }, time);
                });
            }
        },
        margintop: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = parseInt($(elements).css("margin-top").replace("px", ""));
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "margin-top": pos + pixels + "px" }, time);
                }, function ()
                {
                    $(this).stop().animate({ "margin-top": pos + "px" }, time);
                });
            }
        },
        marginright: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = parseInt($(elements).css("margin-right").replace("px", ""));
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "margin-right": pos + pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "margin-right": pos + "px" }, time);
                });
            }
        },
        marginbottom: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = parseInt($(elements).css("margin-bottom").replace("px", ""));
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "margin-bottom": pos + pixels + "px" }, time);
                },
                function ()
                {
                    $(this).stop().animate({ "margin-bottom": pos + "px" }, time);
                });
            }
        },
        marginleft: function (elements, pixels, time)
        {
            if ($(elements).length)
            {
                var pos = parseInt($(elements).css("margin-left").replace("px", ""));
                $(elements).hover(function ()
                {
                    $(this).stop().animate({ "margin-left": pos + pixels + "px" }, time);

                },
                function ()
                {
                    $(this).stop().animate({ "margin-left": pos + "px" }, time);
                });
            }
        },
        tooltip: function (hoverElement, toolElement, offset)
        {
            if ($(hoverElement).length)
            {
                $(hoverElement).hover(function ()
                {
                    var posx = $(this).offset().left - ($(hoverElement).width() / 2) + offset[0];
                    var posy = $(this).offset().top - $(hoverElement).height() + offset[1];
                    var txt = $(this).attr("title");
                    if (txt != "" && txt != "undefined")
                        $(toolElement).find(".text").text(txt).parent().show().css({ "left": posx + "px", "top": posy + "px" });
                },
                function ()
                {
                    $(toolElement).hide();
                });
            }
        }
    };
var click =
    {
        scrolltoid: function (elements, time, difference)
        {
            $(elements).click(function ()
            {
                var id = $(this).attr("href");
                $("html, body").stop().animate({ "scrollTop": $(id).offset().top + difference + "px" }, time);
                pushState(id);
                return false;
            });
        },
        slideswitch: function (elements, pixels, time)
        {
            if ($(elements).find("input[type=checkbox]").is(":checked")) $(elements).find(".slider").css({ "left": pixels + "px" });
            else $(elements).find(".slider").css({ "left": "0" });
            $(elements).click(function ()
            {
                if ($(this).find("input[type=checkbox]").is(":checked")) {
                    $(this).find(".slider").animate({ "left": "0" }, time);
                    $(this).find("input[type=checkbox]").attr("checked", false);
                }
                else
                {
                    $(this).find(".slider").animate({ "left": pixels + "px" }, time);
                    $(this).find("input[type=checkbox]").attr("checked", true);
                }
            });
        },
        toggle: function (openCloseElements, toggleElements)
        {
            $(openCloseElements).live("click", function ()
            {
                $(toggleElements).toggle();
            });
        },
        shownext: function (clickElements, toggleElements)
        {
            $(clickElements).click(function ()
            {
                $(clickElements).removeClass("active");
                $(toggleElements).hide();
                $(this).toggleClass("active");
                $(this).next(toggleElements).toggle();
            });
        },
        customselect:
            function (elementOver, altOptions, selectedInput)
            {
                $(elementOver).hover(function ()
                {
                    $(altOptions).show();
                },
                function ()
                {
                    $(altOptions).hide();
                });

                $(altOptions + " span").click(function ()
                {
                    $(selectedInput).val($(this).text()); $(altOptions).hide();
                });
            },
        customselectwithvalue: function (elementOver, altOptions, selectedInput, hiddenInput)
        {
            $(elementOver).hover(function ()
            {
                $(altOptions).show();
            },
            function ()
            {
                $(altOptions).hide();
            });
            $(altOptions + " .option").click(function ()
            {
                $(selectedInput).val($(this).find(".text").text());
                $(hiddenInput).val($(this).find(".value").text());
                $(altOptions).hide();
            });
        },
        leftrightslider: function (sliderEl, sliderItemElCount, leftControlEl, rightControlEl, pixels, offset, time)
        {
            var currarticle = 0;
            var numofarticles = sliderItemElCount;
            function SlideArticles(i)
            {
                $(sliderEl).animate({ "left": -(currarticle * pixels) + offset + "px" }, time);
            }
            $(leftControlEl).click(function ()
            {
                currarticle -= 1;
                currarticle = currarticle < 0 ? (numofarticles - 1) : currarticle;
                SlideArticles(currarticle);
                return false;
            });
            $(rightControlEl).click(function ()
            {
                currarticle += 1;
                currarticle = currarticle < numofarticles ? currarticle : 0;
                SlideArticles(currarticle);
                return false;
            });
        },
        toblank: function (element)
        {
            $(element).click(function ()
            {
                this.target = "_blank";
            });
        }
    };

var over =
    {
        effect: function (elements, easing, times, time)
        {
            $(elements).mouseover(function ()
            {
                $(this).effect(easing, { times: times }, time);
            });
        }
    };

var ui = {
    switchchecks:
        function (elements, callback)
        {
            $(elements).change(function ()
            {
                $(elements).attr("checked", false); $(this).attr("checked", true); if (callback) callback();
            });
        },

    onclickdialog: function (clickElements, dialogElements, text)
    {
        $(clickElements).click(function ()
        {
            if (!$(dialogElements).is(":visible"))
            {
                $(dialogElements + " .drag").parent().draggable();
                $(dialogElements + " .html").html(text); $(dialogElements).show();
                maths.center(dialogElements, "center");
                $(dialogElements + " #close").show().click(function ()
                {
                    $(dialogElements).hide();
                });
            }
            return false;
        });
    },

    alertdialog: function (dialogElements, text, delay, time)
    {
        $(dialogElements + " .drag").parent().draggable();
        if (text != null)
            $(dialogElements + " .html").html(text);
        $(dialogElements).show(); maths.center(dialogElements, "center");
        $(dialogElements).delay(delay).fadeOut(time);
        return false;
    },

    replacecount: function (elements)
    {
        $(elements).keyup(function ()
        {
            this.value = this.value.replace(" ", "").replace(/\D/g, "");
        });
    },
    replacecountwithline:
        function (elements) {
            $(elements).keyup(function ()
            {
                this.value = this.value.replace(" ", "").replace(/[a-zA-Z]/g, "").replace(".", ",").replace(",,", ",");
            });
        },
    showonscroll: function (elements, pixels)
    {
        $(window).scroll(function () { ToTop(); });

        function ToTop()
        {
            if ($(window).scrollTop() > pixels)
                $(elements).show();
            else
            {
                $(elements).hide();
            }
        } ToTop();
    }
};

var timer =
    {
        decrement: function (daysEl, hoursEl, minutesEl, secondsEl, time)
        {
            if ($(daysEl).length)
            {
                setInterval(function ()
                {
                    var days = $(daysEl).text();
                    var hours = $(hoursEl).text();
                    var minutes = $(minutesEl).text();
                    var seconds = $(secondsEl).text();
                    seconds -= 1;
                    if (seconds < 0)
                    {
                        seconds = 59;
                        minutes -= 1;
                        if (minutes < 0)
                        {
                            minutes = 59;
                            hours -= 1;
                            if (hours < 0)
                            {
                                hours = 23; days -= 1;
                                if (days < 0)
                                    days = 364;
                            }
                        }
                    }
                    $(secondsEl).text(seconds);
                    $(minutesEl).text(minutes);
                    $(hoursEl).text(hours);
                    $(daysEl).text(days);
                }, time);
            }
        }
    };

var form =
{

        regex: /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/,
        canSubmit: false, posX: 0, posY: 0,

        validate: function (formElement, labelsArray, errorLabel, offsetAlert, submitBtn)
        {
            $(formElement + " input, " + formElement + " textarea, " + formElement + " select").bind("blur", function ()
            {
                try
                {
                    var c = $(this).parent().attr("id");
                    if (labelsArray[c][0] == "name")
                    {
                        if ($.trim($(formElement + " #" + c).find("input").val()).length < 3)
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                            form.posX = $(formElement + " #" + c).offset().left;
                            form.posY = $(formElement + " #" + c).offset().top;
                            $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                );
                            form.canSubmit = false;
                        }
                        else
                        {
                            $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                        }
                    }
                    else if (labelsArray[c][0] == "email")
                    {
                        if (!form.regex.test($.trim($(formElement + " #" + c).find("input").val())) || $.trim($(formElement + " #" + c).find("input").val()) == "")
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                            form.posX = $(formElement + " #" + c).offset().left;
                            form.posY = $(formElement + " #" + c).offset().top;
                            $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                );
                            form.canSubmit = false;
                        }
                        else
                        {
                            $(errorLabel).parent().fadeOut(300);
                            form.canSubmit = true;
                        }
                    }
                    else if (labelsArray[c][0] == "textarea")
                    {
                        if (!$.trim($(formElement + " #" + c).find("textarea").val()).length > 0)
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                            form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }); form.canSubmit = false;
                        } else
                        {
                            $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                        }
                    } else if (labelsArray[c][0] == "text") {
                        if ($.trim($(formElement + " #" + c).find("input").val()).length < 1)
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                            form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                );
                            form.canSubmit = false;
                        }
                        else
                        {
                            $(errorLabel).parent().fadeOut(300);
                            form.canSubmit = true;
                        }
                    }
                    else if (labelsArray[c][0] == "phone")
                    {
                        if ($.trim($(formElement + " #" + c).find("input").val()).length < 9)
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                            form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                            $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                            form.canSubmit = false;
                        }
                        else
                        {
                            $(errorLabel).parent().fadeOut(300);
                            form.canSubmit = true;
                        }
                    }
                    else if (labelsArray[c][0] == "select")
                    {
                        if ($(formElement + " #" + c).find("select option:selected").val() == "0")
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                            form.posX = $(formElement + " #" + c).offset().left;
                            form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                );
                            form.canSubmit = false;
                        }
                        else
                        {
                            $(errorLabel).parent().fadeOut(300);
                            form.canSubmit = true;
                        }
                    }
                    else if (labelsArray[c][0] == "checkbox")
                    {
                        if ($(formElement + " #" + c).find("input").is(":checked") == false)
                        {
                            $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                            form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                            $(errorLabel).parent().css(
                                { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                );
                            form.canSubmit = false;
                        } else
                        {
                            $(errorLabel).parent().fadeOut(300);
                            form.canSubmit = true;
                        }
                    }
                }
                catch (ex) { }
            });
            $(submitBtn).click(function ()
            {
                form.showerrors(formElement, labelsArray, errorLabel, offsetAlert, submitBtn);
                return form.canSubmit;
            });
        },

        showerrors: function (formElement, labelsArray, errorLabel, offsetAlert, submitBtn)
        {
            $(formElement + " input, " + formElement + " textarea, " + formElement + " select").each(function ()
            {
                try
                {
                    if ($(this).is(":visible"))
                    {
                        form.canSubmit = true; var c = $(this).parent().attr("id");
                        if (labelsArray[c][0] == "name") {
                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 3)
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top;
                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "email")

                        {
                            if (!form.regex.test($.trim($(formElement + " #" + c).find("input").val())) || $.trim($("#" + c).find("input").val()) == "")
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "textarea") {
                            if (!$.trim($(formElement + " #" + c).find("textarea").val()).length > 0)
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "text") {
                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 1)
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "phone")
                        {
                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 9)
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "select") {
                            if ($(formElement + " #" + c).find("select option:selected").val() == "0")
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                        else if (labelsArray[c][0] == "checkbox")
                        {
                            if ($(formElement + " #" + c).find("input").is(":checked") == false)
                            {
                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                    );
                                return form.canSubmit = false;
                            }
                        }
                    }
                } catch (ex) { }
            });
        },

        customcheck: function (elements)
        {
            if ($(elements).find("input").is(":checked"))
                $(elements).find("label").addClass("checked");
            else
                $(elements).find("label").removeClass("checked");

            $(elements).find("label").click(function ()
            {
                if ($(elements).find("label").hasClass("checked"))
                {
                    $(elements).find("input").attr("checked", false);
                    $(elements).find("label").removeClass("checked");
                }
                else
                {
                    $(elements).find("input").attr("checked", true); $(elements).find("label").addClass("checked");
                }
            });
        },

        customcheckdiv: function (elements)
        {
            $(elements).each(function ()
            {
                if ($(this).find("input[type=checkbox]").is(":checked"))
                    $(this).addClass("selected"); else $(this).removeClass("selected");
            });
            $(elements).click(function ()
            {
                $(elements).find("input[type=checkbox]").attr("checked", false);
                $(elements).removeClass("selected");
                $(this).toggleClass("selected");
                if ($(this).find("input[type=checkbox]").is(":checked"))
                    $(this).find("input[type=checkbox]").attr("checked", false);
                else
                    $(this).find("input[type=checkbox]").attr("checked", true);
                return false;
                var maths =
                    {
                        center: function (element, type)
                        {
                            switch (type)
                            {
                                case "center": $(element).css(
                                    { "left": (($(window).width() / 2) - ($(element).width() / 2)) + "px", "top": (($(window).height() / 2) - ($(element).height() / 2)) + "px" }
                                    );
                                    break;
                                case "left":
                                    $(element).css(
                                        { "left": (($(window).width() / 2) - ($(element).width() / 2)) + "px" }
                                        );
                                    break;
                                case "top": $(element).css(
                                    { "top": (($(window).height() / 2) - ($(element).height() / 2)) + "px" }
                                    );
                                    break;
                            }
                        }
                    };
                var hover =
                    {
                        alpha: function (elements, alpha, time)
                        {
                            $(elements).hover(function ()
                            {
                                $(this).stop().fadeTo(time, alpha[0]);
                            },
                            function ()
                            {
                                $(this).stop().fadeTo(time, alpha[1]);
                            });
                        },
                        up: function (elements, pixels, time)
                        {
                            if ($(elements).length)
                            {
                                var pos = $(elements).position().top;
                                $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "top": pos - pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "top": pos + "px" }, time);
                                });
                            }
                        },
                        left: function (elements, pixels, time)
                        {
                            if ($(elements).length)
                            {
                                var pos = $(elements).position().left;
                                $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "left": pos - pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "left": pos + "px" }, time);
                                });
                            }
                        },
                        right: function (elements, pixels, time)
                        {
                            if ($(elements).length)
                            {
                                var pos = $(elements).position().left; $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "left": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "left": pos + "px" }, time);
                                });
                            }
                        },
                        down: function (elements, pixels, time)
                        {
                            if ($(elements).length) {
                                var pos = $(elements).position().top; $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "top": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "top": pos + "px" }, time);
                                });
                            }
                        },
                        margintop: function (elements, pixels, time)
                        {
                            if ($(elements).length) {
                                var pos = parseInt($(elements).css("margin-top").replace("px", ""));
                                $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "margin-top": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "margin-top": pos + "px" }, time);
                                });
                            }
                        },
                        marginright: function (elements, pixels, time)
                        {
                            if ($(elements).length)
                            {
                                var pos = parseInt($(elements).css("margin-right").replace("px", ""));
                                $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "margin-right": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "margin-right": pos + "px" }, time);
                                });
                            }
                        },
                        marginbottom: function (elements, pixels, time)
                        {
                            if ($(elements).length) {
                                var pos = parseInt($(elements).css("margin-bottom").replace("px", ""));
                                $(elements).hover(function ()
                                {
                                    $(this).stop().animate(
                                        { "margin-bottom": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "margin-bottom": pos + "px" }, time);
                                });
                            }
                        },
                        marginleft: function (elements, pixels, time)
                        {
                            if ($(elements).length) {
                                var pos = parseInt($(elements).css("margin-left").replace("px", "")); $(elements).hover(function ()
                                {
                                    $(this).stop().animate({ "margin-left": pos + pixels + "px" }, time);
                                },
                                function ()
                                {
                                    $(this).stop().animate({ "margin-left": pos + "px" }, time);
                                });
                            }
                        },
                        tooltip: function (hoverElement, toolElement, offset)
                        {
                            if ($(hoverElement).length)
                            {
                                $(hoverElement).hover(function ()
                                {
                                    var posx = $(this).offset().left - ($(hoverElement).width() / 2) + offset[0];
                                    var posy = $(this).offset().top - $(hoverElement).height() + offset[1];
                                    var txt = $(this).attr("title");
                                    if (txt != "" && txt != "undefined")
                                        $(toolElement).find(".text").text(txt).parent().show().css({ "left": posx + "px", "top": posy + "px" });
                                }, function ()
                                {
                                    $(toolElement).hide();
                                });
                            }
                        }
                    };
                var click =
                    {
                        scrolltoid: function (elements, time, difference)
                        {
                            $(elements).click(function ()
                            {
                                var id = $(this).attr("href"); $("html, body").stop().animate(
                                    { "scrollTop": $(id).offset().top + difference + "px" },
                                    time);
                                pushState(id);
                                return false;
                            });
                        },
                        slideswitch: function (elements, pixels, time)
                        {
                            if ($(elements).find("input[type=checkbox]").is(":checked"))
                                $(elements).find(".slider").css({ "left": pixels + "px" });
                            else
                                $(elements).find(".slider").css({ "left": "0" });
                            $(elements).click(function ()
                            {
                                if ($(this).find("input[type=checkbox]").is(":checked"))
                                {
                                    $(this).find(".slider").animate({ "left": "0" }, time);
                                    $(this).find("input[type=checkbox]").attr("checked", false);
                                }
                                else
                                {
                                    $(this).find(".slider").animate({ "left": pixels + "px" }, time);
                                    $(this).find("input[type=checkbox]").attr("checked", true);
                                }
                            });
                        },
                        toggle: function (openCloseElements, toggleElements)
                        {
                            $(openCloseElements).live("click", function ()
                            {
                                $(toggleElements).toggle();
                            });
                        },
                        shownext: function (clickElements, toggleElements)
                        {
                            $(clickElements).click(function ()
                            {
                                $(clickElements).removeClass("active"); $(toggleElements).hide();
                                $(this).toggleClass("active"); $(this).next(toggleElements).toggle();
                            });
                        },
                        customselect: function (elementOver, altOptions, selectedInput)
                        {
                            $(elementOver).hover(function () { $(altOptions).show(); }, function ()
                            {
                                $(altOptions).hide();
                            });
                            $(altOptions + " span").click(function ()
                            {
                                $(selectedInput).val($(this).text()); $(altOptions).hide();
                            });
                        },
                        leftrightslider: function (sliderEl, sliderItemElCount, leftControlEl, rightControlEl, pixels, offset, time)
                        {
                            var currarticle = 0;
                            var numofarticles = sliderItemElCount;
                            function SlideArticles(i)
                            {
                                $(sliderEl).animate({ "left": -(currarticle * pixels) + offset + "px" }, time);
                            }
                            $(leftControlEl).click(function ()
                            {
                                currarticle -= 1; currarticle = currarticle < 0 ? (numofarticles - 1) : currarticle; SlideArticles(currarticle);
                                return false;
                            });
                            $(rightControlEl).click(function ()
                            {
                                currarticle += 1;
                                currarticle = currarticle < numofarticles ? currarticle : 0;
                                SlideArticles(currarticle); return false;
                            });
                        },
                        toblank: function (element)
                        {
                            $(element).click(function ()
                            {
                                this.target = "_blank";
                            });
                        }
                    };
                var over =
                    {
                        effect: function (elements, easing, times, time)
                        {
                            $(elements).mouseover(function ()
                            {
                                $(this).effect(easing, { times: times }, time);
                            });
                        }
                    }; var ui =
                        {
                            onclickdialog: function (clickElements, dialogElements, text)
                            {
                                $(clickElements).click(function ()
                                {
                                    if (!$(dialogElements).is(":visible")) {
                                        $(dialogElements + " .drag").parent().draggable(); $(dialogElements + " .html").html(text);
                                        $(dialogElements).show(); maths.center(dialogElements, "center");
                                        $(dialogElements + " #close").show().click(function ()
                                        {
                                            $(dialogElements).hide();
                                        });
                                    }
                                    return false;
                                });
                            },
                            alertdialog: function (dialogElements, text, delay, time)
                            {
                                $(dialogElements + " .drag").parent().draggable();
                                if (text != null)
                                    $(dialogElements + " .html").html(text);
                                $(dialogElements).show();
                                maths.center(dialogElements, "center");
                                $(dialogElements).delay(delay).fadeOut(time);
                                return false;
                            },
                            replacecount: function (elements)
                            {
                                $(elements).keyup(function ()
                                { this.value = this.value.replace(/\D/g, ""); });
                                $(elements).change(function ()
                                {
                                    if (this.value == "" || this.value == 0)
                                        this.value = 1;
                                    this.value = this.value.replace(/\D/g, "");
                                });
                            },
                            showonscroll: function (elements, pixels)
                            {
                                $(window).scroll(function () { ToTop(); });
                                function ToTop()
                                {
                                    if ($(window).scrollTop() > pixels)
                                        $(elements).show();
                                    else
                                    {
                                        $(elements).hide();
                                    }
                                } ToTop();
                            }
                        };
                    var timer =
                        {
                            decrement: function (daysEl, hoursEl, minutesEl, secondsEl, time)
                            {
                                if ($(daysEl).length) {
                                    setInterval(function ()
                                    {
                                        var days = $(daysEl).text();
                                        var hours = $(hoursEl).text();
                                        var minutes = $(minutesEl).text();
                                        var seconds = $(secondsEl).text();
                                        seconds -= 1;
                                        if (seconds < 0)
                                        {
                                            seconds = 59; minutes -= 1;
                                            if (minutes < 0)
                                            {
                                                minutes = 59; hours -= 1;
                                                if (hours < 0)
                                                {
                                                    hours = 23; days -= 1;
                                                    if (days < 0)
                                                        days = 364;
                                                }
                                            }
                                        }
                                        $(secondsEl).text(seconds);
                                        $(minutesEl).text(minutes);
                                        $(hoursEl).text(hours);
                                        $(daysEl).text(days);
                                    }, time);
                                }
                            }
                        };
                    var form =
                        {
                            regex: /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/,
                            canSubmit: false, posX: 0, posY: 0,
                            validate: function (formElement, labelsArray, errorLabel, offsetAlert, submitBtn)
                            {
                                $(formElement + " input, " + formElement + " textarea, " + formElement + " select").bind("blur", function ()
                                {
                                    try
                                    {
                                        var c = $(this).parent().attr("id");
                                        if (labelsArray[c][0] == "name")
                                        {
                                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 3)
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left;
                                                form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                                    { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                                    );
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300);
                                                form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "email")
                                        {
                                            if (!form.regex.test($.trim($(formElement + " #" + c).find("input").val())) || $.trim($(formElement + " #" + c).find("input").val()) == "")
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                                form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "textarea")
                                        {
                                            if (!$.trim($(formElement + " #" + c).find("textarea").val()).length > 0)
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left;
                                                form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "text")
                                        {
                                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 1)
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "phone")
                                        {
                                            if ($.trim($(formElement + " #" + c).find("input").val()).length < 9)
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "select")
                                        {
                                            if ($(formElement + " #" + c).find("select option:selected").val() == "0")
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                        else if (labelsArray[c][0] == "checkbox")
                                        {
                                            if ($(formElement + " #" + c).find("input").is(":checked") == false)
                                            {
                                                $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                form.canSubmit = false;
                                            }
                                            else
                                            {
                                                $(errorLabel).parent().fadeOut(300); form.canSubmit = true;
                                            }
                                        }
                                    }
                                    catch (ex)
                                    {
                                    }
                                });
                                $(submitBtn).click(function ()
                                {
                                    form.showerrors(formElement, labelsArray, errorLabel, offsetAlert, submitBtn);
                                    return form.canSubmit;
                                });
                            },
                            showerrors: function (formElement, labelsArray, errorLabel, offsetAlert, submitBtn)
                            {
                                $(formElement + " input, " + formElement + " textarea, " + formElement + " select").each(function ()
                                {
                                    try {
                                        if ($(this).is(":visible"))
                                        {
                                            form.canSubmit = true;
                                            var c = $(this).parent().attr("id");
                                            if (labelsArray[c][0] == "name")
                                            {
                                                if ($.trim($(formElement + " #" + c).find("input").val()).length < 3)
                                                {
                                                    $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                    form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                    $(errorLabel).parent().css(
                                                        { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                                        );
                                                    return form.canSubmit = false;
                                                }
                                            } else
                                                if (labelsArray[c][0] == "email")
                                                {
                                                    if (!form.regex.test($.trim($(formElement + " #" + c).find("input").val())) || $.trim($("#" + c).find("input").val()) == "")
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                        form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                        $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                        return form.canSubmit = false;
                                                    }
                                                }
                                                else if (labelsArray[c][0] == "textarea")
                                                {
                                                    if (!$.trim($(formElement + " #" + c).find("textarea").val()).length > 0)
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                                        form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                                            { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                                            );
                                                        return form.canSubmit = false;
                                                    }
                                                }
                                                else if (labelsArray[c][0] == "text")
                                                {
                                                    if ($.trim($(formElement + " #" + c).find("input").val()).length < 1)
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                                        form.posY = $(formElement + " #" + c).offset().top;
                                                        $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                        return form.canSubmit = false;
                                                    }
                                                }
                                                else if (labelsArray[c][0] == "phone") {
                                                    if ($.trim($(formElement + " #" + c).find("input").val()).length < 9)
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                                        form.posY = $(formElement + " #" + c).offset().top;
                                                        $(errorLabel).parent().css({ "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" });
                                                        return form.canSubmit = false;
                                                    }
                                                }
                                                else if (labelsArray[c][0] == "select")
                                                {
                                                    if ($(formElement + " #" + c).find("select option:selected").val() == "0")
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]); form.posX = $(formElement + " #" + c).offset().left;
                                                        form.posY = $(formElement + " #" + c).offset().top; $(errorLabel).parent().css(
                                                            { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                                            );
                                                        return form.canSubmit = false;
                                                    }
                                                }
                                                else if (labelsArray[c][0] == "checkbox")
                                                {
                                                    if ($(formElement + " #" + c).find("input").is(":checked") == false)
                                                    {
                                                        $(errorLabel).parent().fadeIn(300).find(".text").text(labelsArray[c][1]);
                                                        form.posX = $(formElement + " #" + c).offset().left; form.posY = $(formElement + " #" + c).offset().top;
                                                        $(errorLabel).parent().css
                                                            (
                                                            { "left": (form.posX + offsetAlert[0]) + "px", "top": (form.posY + offsetAlert[1]) + "px" }
                                                            );
                                                        return
                                                        form.canSubmit = false;
                                                    }
                                                }
                                        }
                                    }
                                    catch (ex) { }
                                });
                            },
                            customcheck: function (elements)
                            {
                                if ($(elements).find("input").is(":checked"))
                                    $(elements).find("label").addClass("checked");
                                else
                                    $(elements).find("label").removeClass("checked");
                                $(elements).find("label").click(function ()
                                {
                                    if ($(elements).find("label").hasClass("checked"))
                                    {
                                        $(elements).find("input").attr("checked", false);
                                        $(elements).find("label").removeClass("checked");
                                    } else
                                    {
                                        $(elements).find("input").attr("checked", true);
                                        $(elements).find("label").addClass("checked");
                                    }
                                });
                            },
                            customcheckdiv: function (elements)
                            {
                                $(elements).each(function ()
                                {
                                    if ($(this).find("input[type=checkbox]").is(":checked"))
                                        $(this).addClass("selected");
                                    else
                                        $(this).removeClass("selected");
                                });
                                $(elements).click(function ()
                                {
                                    $(elements).find("input[type=checkbox]").attr("checked", false);
                                    $(elements).removeClass("selected"); $(this).toggleClass("selected");
                                    if ($(this).find("input[type=checkbox]").is(":checked"))
                                        $(this).find("input[type=checkbox]").attr("checked", false);
                                    else
                                        $(this).find("input[type=checkbox]").attr("checked", true); return false;
                                });
                            }
                        };
            });
        }};