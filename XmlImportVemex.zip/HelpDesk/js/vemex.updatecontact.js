﻿$(function () {

    // person detail
    var $firstName = $("#titulTxt"),
        $lastName = $("#firstNameTxt"),
        $titul = $("#lastNameTxt"),
        $lastTitul = $("#titulLastTxt"),
        $UserId = $("#UserIdTxt");
        $hdnContactId = $("#hdnContactId");
    //Button
        $saveAndEndBtn = $("#UpdateContactBtn");

    // autocomplete 
    AutocompleteInput("#titulAutocomplete");
    AutocompleteInput("#titulLastAutocomplete");

    //event
    $saveAndEndBtn.click(SaveAndEndClick);
    $UserId.change(IsUserExists);

    //Loading Holder
    var $loading = $(".loadingholder");

    //Save event handle
    function SaveAndEndClick() {
       
        var formSuccess = ValidateForm();
        if (formSuccess) {
            $loading.show();
        }
        return formSuccess;
    }

    function IsUserExists() {

        var user = $UserId.val();
        var contactid = $hdnContactId.val();
        if (user.length > 0) {
            Ajax.CallWebMethod(
                "updatecontact.aspx/IsUserExists",
                { user: user, entityId: contactid },
                function (response) {
                    if (response) {
                        alert("User Name already exists..");
                        $UserId.val("");
                    }

                }
                );
        }
    }

    function AutocompleteInput(containerId, contains) {


        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
            }
        });

    }
});