﻿$(function () {

    // variables
    var $win = $(window);
    var $login = $(".login");
    var $case = $(".case .holder");
    var $body = $("body");
    var $error = $(".error");
    var $message = $(".message");
    var $caseSubmit = $(".case input[type=image]");
    var $boxCheckbox = $(".box input[type=checkbox]");


    var $loadingCircle = $(".loadingcircle"),
        $loading = $(".loadingholder"),
        $loginSubmit = $(".loginmiddle input[type=image]");

    $loadingCircle.center();
 
    var success = false;
    var loginArr = {
        "#loginEmail input": {
            "type": "email",
            "message": "Musíte vyplnit správný email."
        },
        "#loginID input": {
            "type": "supportid",
            "message": "Musíte vyplnit ID společnosti."
        }
    };
    var formArr = {
        "#productBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Problémový produkt."
        },
        "#limitBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Omezení."
        },
        "#solutionBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Návrh řešení."
        },
        "#phone input": {
            "type": "phone",
            "message": "Musíte vyplnit Kontaktní telefon."
        }
    };
    if ($loginSubmit.length)
        $loginSubmit.click(function () {
            success = Form.Validate(loginArr, function (message) {
                $login.append($message);
                $message.text(message);
            });
            if (success) {
                $loading.show();
                DisableSubmit($loginSubmit);
            }
            return success;
           
        });

    if ($message.length)
        $message.center({ location: "top" }).delay(3000).animate({ "top": "0" }, 350).animate({ "top": -$loading.height() + "px" }, 250);


    // functions
    CenterLogin = function () {
        $login.center();
        $error.center();
    };

    ShowLoading = function () {
        $body.append($loading);
        $loading.find("img").center()
    };

    DisableSubmit = function ($submit) {
        $submit.css({ "opacity": ".45" });
    };

    // actions
    $win.resize(function () {
        CenterLogin();
    });
  
    $caseSubmit.click(function () {
        success = Form.Validate(formArr, function (message) {
            $case.append($message);
            $message.text(message);
        });
        if (success) {
            ShowLoading();
            DisableSubmit($caseSubmit);
        }
        return success;
    });

    $boxCheckbox.change(function () {
        Form.CheckboxList($(this), $(this).parent().parent());
    });

    // ready
    CenterLogin();
    $error.center().delay(2500).fadeOut(400);

});