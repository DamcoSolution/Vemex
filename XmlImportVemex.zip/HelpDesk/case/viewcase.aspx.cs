﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;

namespace HelpDesk.ServiceCase
{
	public partial class viewcase : System.Web.UI.Page
	{
        int pageSize = 20;
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!PortalRole.CanView(Entity_Name.Case))
            {
                new ErrorControl("You don't have right to view contact ");
                //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }
            else
            {
                BindGrid(0, pageSize);
            }

		}

        private void BindGrid(int pageNumber, int pageSize)
        {
            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.Case).FirstOrDefault();
            ContactItem user = LoginControl.GetUser();
            CaseControl caseControl = new CaseControl();
            var list = caseControl.GetCases(rights, user, pageNumber, pageSize);
            int TotalRecordCount = caseControl.TotalRecords;
            grdCases.DataSource = list;
            grdCases.VirtualItemCount = TotalRecordCount;
            grdCases.DataBind();
        }
	}
}