﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;

namespace HelpDesk.contact
{
    public partial class viewcontact : PageControl
    {
        int pageSize = 20;
        protected int TotalRecordCount { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!PortalRole.CanView(Entity_Name.kontakt))
                {
                    new ErrorControl("You don't have right to view contact ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                }
                else
                {
                    BindGrid(0, pageSize);
                }
            }
        }

        private void BindGrid(int pageNumber, int pageSize)
        {
            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.kontakt).FirstOrDefault();
            ContactItem user = LoginControl.GetUser();
            ContactControl contactControl = new ContactControl();
            var list = contactControl.ContactList(rights, user, pageNumber, pageSize);
            list = list.OrderByDescending(mylist => mylist.CreatedOn).ToList();

            TotalRecordCount = contactControl.TotalRecords;
            grdContacts.DataSource = list;
            grdContacts.VirtualItemCount = TotalRecordCount;
            grdContacts.DataBind();
        }

        protected void grdContacts_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Guid id = (Guid)grdContacts.DataKeys[e.NewEditIndex].Value;
            Response.Redirect(UrlControl.GetPathUrl() + "/editcontact.aspx?id=" + id);
        }

        protected void grdContacts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Guid id = (Guid)grdContacts.DataKeys[e.RowIndex].Value;
            new ContactControl().DeactivateContact(id);
            BindGrid(0, pageSize);
        }

        protected void grdContacts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdContacts.PageIndex = e.NewPageIndex;
            BindGrid(e.NewPageIndex, pageSize);
        }

        protected void grdContacts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                var row = e.Row;
                //Create one Cell for adding in my current paging strip
                TableCell infocell = new TableCell();
                infocell.Text = "   [ " + ((grdContacts.PageIndex) * pageSize).ToString() + " - " + Convert.ToString((TotalRecordCount > grdContacts.PageIndex * pageSize + pageSize) ? grdContacts.PageIndex * pageSize + pageSize : TotalRecordCount) + " : " + Convert.ToString(TotalRecordCount) + " ]";

                //Getting table which shows PagingStrip
                Table tbl = (Table)row.Cells[0].Controls[0];

                //Will Find  table
                tbl.Rows[0].Cells.Add(infocell);
            }
        }
    }
}