﻿   
    $btnAcceptChanges = $("#btnAcceptChanges"),
    $hdnIssueId = $("#hdnIssueId");

    $box.hide();
    //event
    $btnAcceptChanges.click(btnAcceptChanges_Onclick);

    function showConfirmBox(id) {
        var $box = $(".boxmiddle");
        alert('hi');
        $box.show();
    }
   
    function btnAcceptChanges_Onclick() {
        $.unblockUI();
    }
