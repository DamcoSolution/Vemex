﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk.Controls
{
    public class LoginControl
    {
        public static ContactItem GetUser()
        {
            return (ContactItem)HttpContext.Current.Session["HelpDeskUser"];
        }

        public static ContractItem GetUsersContract()
        {
            return (ContractItem)HttpContext.Current.Session["HelpDeskContract"];
        }

        public static bool IsLogged()
        {
            return (HttpContext.Current.Session["HelpDeskUser"] != null && HttpContext.Current.Session["HelpDeskContract"] != null);
        }

        public static bool Login(string email, string contractNumber)
        {

            ContractItem contract = CustomerControl.ExistsContract(contractNumber);

            if (contract != null)
            {
                if (contract.expiresOn.ToLocalTime() >= DateTime.Now)
                {
                    ContactItem contact = CustomerControl.ExistsContact(email, contract.customerId);

                    if (contact != null)
                    {
                        HttpContext.Current.Session["HelpDeskUser"] = contact;
                        HttpContext.Current.Session["HelpDeskContract"] = contract;
                        ErrorControl.ThrowError("Byl jste přihlášen.");
                        return true;
                    }
                    else
                    {
                        ErrorControl.ThrowError("Uživatel s uvedeným emailem nebyl nalezen.");
                        return false;
                    }
                }
                else
                {
                    ErrorControl.ThrowError("Smlouva již není platná.");
                    return false;
                }
            }
            else
            {
                ErrorControl.ThrowError("Neplatné číslo smlouvy.");
                return false;
            }

        }

        public static bool Logout()
        {
            HttpContext.Current.Session["HelpDeskUser"] = null;
            HttpContext.Current.Session["HelpDeskContract"] = null;
            HttpContext.Current.Session["LinkId"] = null;

            if (HttpContext.Current.Session["HelpDeskUser"] == null && HttpContext.Current.Session["HelpDeskContract"] == null)
                return true;
            else
                return false;
        }
        
        public static PortalRole Role
        {
            get
            {
                var citem = HttpContext.Current.Session["HelpDeskUser"] as ContactItem;
                if (citem != null) return citem.Role;
                else return null;
            }
        }

        public EntityReference ParentCustomer { get; set; }
    }
}