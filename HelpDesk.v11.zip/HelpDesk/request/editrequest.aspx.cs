﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CreativeMages.Xrm;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;
using Microsoft.Xrm.Sdk;

namespace HelpDesk.request
{
    public partial class editrequest : PageControl
    {
        public List<SelectControl> CategoryList = new List<SelectControl>(),
                                  SubCategoryList = new List<SelectControl>();

        protected Guid EntityId
        {
            get
            {
                Guid id = Guid.Empty;
                Guid.TryParse(Request.QueryString["id"], out id);
                return id;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!PortalRole.CanEdit("Request"))
                {
                    new ErrorControl("You don't have right to edit request ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/default");
                }
                else
                {
                    BinControl(EntityId);
                }
            }
        }

        private void BinControl(Guid issueId)
        {
            using (XrmContext context = new XrmContext(ServiceControl.GetService()))
            {
                var helpdesk = context.cre_helpdeskissueSet.Where(lst => lst.Id == issueId).FirstOrDefault();

                CategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_category");
                SubCategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_subcategory");
                drp_primaryoptionset.DataSource = CategoryList;
                drp_primaryoptionset.DataBind();
                drp_primaryoptionset.Items.Insert(0, new ListItem("Select Category", "0"));
                drp_primaryoptionset.SelectedValue = Convert.ToString(helpdesk.cre_category.Value);

                BindSecondaryCategory();
                drp_secondaryoptionset.SelectedValue = Convert.ToString(helpdesk.cre_subcategory.Value);
                BindControls(context);
                txtControl.Text = helpdesk.cre_name;
                drp_primaryoptionset.Enabled = false;
                drp_secondaryoptionset.Enabled = false;
                SetControlValue(helpdesk);

                BindNotes(helpdesk, context);
                
            }
        }

        private void BindNotes(cre_helpdeskissue helpdesk, XrmContext context)
        {
            var notes = context.AnnotationSet.Where(lst => lst.cre_helpdeskissue_Annotations.Id == helpdesk.Id).ToList().OrderByDescending(x => x.CreatedOn);
            rptrNotes.DataSource = notes;
            rptrNotes.DataBind();
        }

        private void SetControlValue(cre_helpdeskissue helpdesk)
        {
            foreach (RepeaterItem item in rptControls.Items)
            {
                cre_helpdeskconfigurationcre_controltype ControlType =
                    (cre_helpdeskconfigurationcre_controltype)Convert.ToInt32(((HiddenField)item.FindControl("hdnControlType")).Value);

                string ControlName = ((HiddenField)item.FindControl("hdnControlName")).Value;
                var attribute = helpdesk.Attributes.Where(lst => lst.Key == ControlName).FirstOrDefault();
                switch (ControlType)
                {
                    case cre_helpdeskconfigurationcre_controltype.CheckBox:
                        {
                            var chkControl = item.FindControl("chkControl") as CheckBox;
                        }
                        break;

                    case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                        {
                            var txtMulControl = item.FindControl("txtMulControl") as TextBox;
                            txtMulControl.Text = (string)attribute.Value;
                        }
                        break;
                    case cre_helpdeskconfigurationcre_controltype.OptionSet:
                        {
                            OptionSetValue option = (OptionSetValue)attribute.Value;

                            var ddlControl = item.FindControl("ddlControl") as DropDownList;

                            if (ddlControl != null)
                            {
                                var ddlitem = ddlControl.Items.FindByValue(Convert.ToString(option.Value));
                                if (ddlitem != null)
                                    ddlControl.SelectedValue = Convert.ToString(option.Value);
                            }
                        }
                        break;
                    case cre_helpdeskconfigurationcre_controltype.RadioButton:
                        break;
                    case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                    case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                        {
                            var myControl = item.FindControl("txtControl") as TextBox;
                            if (myControl != null)
                            {
                                myControl.Text = Convert.ToString(attribute.Value);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        private void BindSecondaryCategory()
        {
            List<OptionConfiguration> _filteredoption = OptionConfiguration.GetSecondaryOptionsetMain(drp_primaryoptionset.SelectedValue.ToString());

            if (_filteredoption != null && _filteredoption.Count > 0)
            {
                string _subcategory = _filteredoption[0].secondaryoptionvalue;
                string[] resultsArray = _subcategory.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                List<SelectControl> _filteredoptionconfig = OptionConfiguration.GetSecondaryOptionsetFiltered(resultsArray);
                if (_filteredoptionconfig != null && _filteredoptionconfig.Count > 0)
                {

                    drp_secondaryoptionset.Enabled = true;
                    drp_secondaryoptionset.DataSource = _filteredoptionconfig;
                    drp_secondaryoptionset.DataBind();
                    drp_secondaryoptionset.Items.Insert(0, new ListItem("Select Sub Category", "0"));
                    div_controls.Style.Add("display", "none");
                }
            }
            else
            {
                drp_secondaryoptionset.Enabled = false;
                drp_secondaryoptionset.Items.Clear();
                div_controls.Style.Add("display", "none");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void BindControls(XrmContext context)
        {
            if (drp_secondaryoptionset.SelectedIndex > 0 && drp_primaryoptionset.SelectedIndex > 0)
            {
                div_controls.Style.Add("display", "block");

                var conf = context.cre_helpdeskconfigurationSet.ToList().Where(
                    lst => lst.cre_category.Value == Convert.ToInt32(drp_primaryoptionset.SelectedValue)
                        && lst.cre_subcategory.Value == Convert.ToInt32(drp_secondaryoptionset.SelectedValue));

                rptControls.DataSource = conf;
                rptControls.DataBind();
            }
            else
                div_controls.Style.Add("display", "none");
        }

        protected void rptControls_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var entity = e.Item.DataItem as cre_helpdeskconfiguration;
                if (entity != null)
                {
                    cre_helpdeskconfigurationcre_controltype ControlType = (cre_helpdeskconfigurationcre_controltype)entity.cre_controltype.Value;
                    var hdnControlType = e.Item.FindControl("hdnControlType") as HiddenField;
                    if (hdnControlType != null)
                        hdnControlType.Value = entity.cre_controltype.Value.ToString();

                    var hdnControlName = e.Item.FindControl("hdnControlName") as HiddenField;
                    if (hdnControlName != null)
                        hdnControlName.Value = entity.cre_controlname;

                    //cre_helpdeskissuecre_priority.
                    switch (ControlType)
                    {
                        case cre_helpdeskconfigurationcre_controltype.CheckBox:
                            var chkControl = e.Item.FindControl("chkControl") as CheckBox;
                            chkControl.Visible = true;
                            chkControl.Text = entity.cre_name;

                            break;
                        case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                        case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                            {
                                var txtControl = e.Item.FindControl("txtControl") as TextBox;
                                if (txtControl != null)
                                {
                                    txtControl.Visible = true;
                                }
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                            var txtMulControl = e.Item.FindControl("txtMulControl") as TextBox;
                            txtMulControl.Visible = true;

                            break;
                        case cre_helpdeskconfigurationcre_controltype.OptionSet:

                            var ddlControl = e.Item.FindControl("ddlControl") as DropDownList;
                            if (ddlControl != null)
                            {
                                ddlControl.Visible = true;

                                Type type = Type.GetType("CreativeMages.Xrm.cre_helpdeskissue" + entity.cre_controlname + ", CreativeMages.Xrm");
                                if (type != null)
                                {
                                    ddlControl.DataSource = GetEnumForBind(type);
                                    ddlControl.DataTextField = "Value";
                                    ddlControl.DataValueField = "Key";
                                    ddlControl.DataBind();
                                    ddlControl.Items.Insert(0, new ListItem("Select", "0"));
                                }
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.RadioButton:
                            break;
                        default:
                            break;

                    }
                }
            }
        }

        public Dictionary<int, string> GetEnumForBind(Type enumeration)
        {

            string[] names = Enum.GetNames(enumeration);
            Array values = Enum.GetValues(enumeration);
            Dictionary<int, string> lstValues = new Dictionary<int, string>();
            for (int i = 0; i < names.Length; i++)
            {
                lstValues.Add(Convert.ToInt32(values.GetValue(i)), names[i]);
            }
            return lstValues;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            new ErrorControl("Record Updated successfully");
            Save();
        }

        private void Save()
        {
            try
            {
                using (XrmContext context = new XrmContext(ServiceControl.GetService()))
                {
                    var cre_helpdeskissue = context.cre_helpdeskissueSet.Where(lst => lst.Id == EntityId).FirstOrDefault();

                    foreach (RepeaterItem item in rptControls.Items)
                    {
                        cre_helpdeskconfigurationcre_controltype ControlType =
                            (cre_helpdeskconfigurationcre_controltype)Convert.ToInt32(((HiddenField)item.FindControl("hdnControlType")).Value);

                        string ControlName = ((HiddenField)item.FindControl("hdnControlName")).Value;

                        var attribute = cre_helpdeskissue.Attributes.Where(lst => lst.Key == ControlName).FirstOrDefault();

                        switch (ControlType)
                        {
                            case cre_helpdeskconfigurationcre_controltype.CheckBox:
                                {
                                    var chkControl = item.FindControl("chkControl") as CheckBox;
                                    if (chkControl != null && chkControl.Checked)
                                    {
                                        cre_helpdeskissue[ControlName] = true;
                                    }
                                }
                                break;

                            case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                                {
                                    var txtMulControl = item.FindControl("txtMulControl") as TextBox;
                                    if (txtMulControl != null && !string.IsNullOrEmpty(txtMulControl.Text))
                                    {
                                        cre_helpdeskissue[ControlName] = txtMulControl.Text.Trim();
                                    }

                                }
                                break;
                            case cre_helpdeskconfigurationcre_controltype.OptionSet:
                                {
                                    var ddlControl = item.FindControl("ddlControl") as DropDownList;
                                    if (ddlControl != null)
                                    {
                                        int optionsetNumber = 0;
                                        if (int.TryParse(ddlControl.SelectedValue, out optionsetNumber))
                                        {
                                            if (optionsetNumber > 0)
                                                cre_helpdeskissue[ControlName] = new OptionSetValue(optionsetNumber);
                                        }
                                    }
                                }
                                break;
                            case cre_helpdeskconfigurationcre_controltype.RadioButton:
                                break;
                            case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                            case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                                {
                                    var myControl = item.FindControl("txtControl") as TextBox;
                                    if (myControl != null)
                                    {
                                        if (ControlType == cre_helpdeskconfigurationcre_controltype.SingleLineofText)
                                            cre_helpdeskissue[ControlName] = myControl.Text.Trim();
                                        else
                                        {
                                            decimal value = 0;
                                            if (decimal.TryParse(myControl.Text.Trim(), out value))
                                            {
                                                cre_helpdeskissue[ControlName] = value;
                                            }
                                            else
                                            {
                                                cre_helpdeskissue[ControlName] = null;
                                            }
                                        }
                                    }
                                }
                                break;
                            default:
                                break;
                        }

                    }
                    cre_helpdeskissue[Constants.CreName] = txtControl.Text;
                    ContactItem user = LoginControl.GetUser();
                    cre_helpdeskissue["cre_owner"] = new EntityReference("contact", user.id);

                    context.UpdateObject(cre_helpdeskissue);
                    context.SaveChanges();

                    // create annotation if description is not empty
                    description = txtNotes.Text;

                    if (description != string.Empty || fupload.HasFile)
                    {
                        Annotation annotation = new Annotation();
                        if (fupload.HasFile)
                        {


                            annotation.FileName = fupload.FileName;
                            annotation.DocumentBody = Convert.ToBase64String(fupload.FileBytes);
                            annotation.Subject = "Attachment Files";
                            annotation.ObjectId = new EntityReference(cre_helpdeskissue.EntityLogicalName, EntityId);
                            //  Convert.ToBase64String(
                        }
                        else
                        {

                            annotation.Subject = "Notes Created";
                            annotation.NoteText = description;
                            annotation.ObjectId = new EntityReference(cre_helpdeskissue.EntityLogicalName, EntityId);

                        }
                        CustomerControl.AddAnnotation(annotation);
                    }
                    //  ServiceControl.GetService().Update(cre_helpdeskissue);
                }
            }
            catch (Exception ex)
            {
                new ErrorControl("Error Occured : Please contact administrator");
            }
        }

        protected void btnSubmitAndClose_Click(object sender, EventArgs e)
        {
            Save();
            new ErrorControl("Record Updated successfully");
            Response.Redirect(UrlControl.GetPathUrl() + "/viewrequest");

        }
        protected void rptrNotes_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var entity = e.Item.DataItem as Annotation;
                var item = e.Item;
                 
                HtmlGenericControl ltrText = item.FindControl("divControl") as HtmlGenericControl;
                HtmlAnchor hrefFile = item.FindControl("hrefFile") as HtmlAnchor;

                if (entity.IsDocument ?? false == true)
                {
                    ltrText.Visible = false;
                    if (hrefFile != null)
                    {
                        byte[] fileContent = Convert.FromBase64String(entity.DocumentBody);

                        string fileExtension = Path.GetExtension(entity.FileName);

                        string filename = Server.MapPath("~/request/") + "Files/" + entity.Id + fileExtension;

                        using (Stream fileStream = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.Write))
                        {
                            fileStream.Write(fileContent, 0, fileContent.Length);
                        }
                        string url = UrlControl.GetPathUrl() + @"/Files/" + entity.Id + fileExtension;
                        hrefFile.InnerText = entity.FileName;
                        hrefFile.HRef = url;
                    }
                }
                else
                {
                    hrefFile.Visible = false;
                    ltrText.InnerText = entity.NoteText;
                }                
            }
        }
    }
}