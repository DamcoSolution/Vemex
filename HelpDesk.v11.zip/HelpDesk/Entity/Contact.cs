﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk;

namespace HelpDesk.EntityObjects
{
    public class Contact
    {
        public string Name { get; set; }
        public Guid Id { get; set; }

        public string Email { get; set; }
        public string Title { get; set; }
        public string TitleLast { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateofBirth { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public KeyValuePair<string, Guid> ParentCustomer { get; set; }
        public EntityReference Parent { get; set; }

        public DateTime CreatedOn { get; set; }
    }
}