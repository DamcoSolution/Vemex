﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;

namespace HelpDesk.ServiceCase
{
	public partial class viewcase : PageControl
	{
        int pageSize = 20;

		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                if (!PortalRole.CanView(Entity_Name.Case))
                {
                    new ErrorControl("You don't have right to view case ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                }
                else
                {
                    BindGrid(0, pageSize);
                }
            }

		}

        private void BindGrid(int pageNumber, int pageSize)
        {
            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.Case).FirstOrDefault();
            ContactItem user = LoginControl.GetUser();
            CaseControl caseControl = new CaseControl();
            var list = caseControl.GetCases(rights, user, pageNumber, pageSize);
            int TotalRecordCount = caseControl.TotalRecords;
            grdCases.DataSource = list;
            grdCases.VirtualItemCount = TotalRecordCount;
            grdCases.DataBind();
        }

        protected void grdCases_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Cases entity = e.Row.DataItem as Cases;
                GridViewRow row = e.Row;
                Label lblProductName = row.FindControl("lblProductName") as Label;
                if (entity.ProductId != null)
                    lblProductName.Text = entity.ProductId.Name;
         
                ImageButton btnAccept = row.FindControl("btnAccept") as ImageButton;
                if (btnAccept != null && (entity.CaseStatus == CaseStatus.Draft || entity.CaseStatus == CaseStatus.None))
                {
                    btnAccept.Enabled = true;
                }
            }
        }    
        
      
        protected void grdCases_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCases.PageIndex = e.NewPageIndex;
            BindGrid(e.NewPageIndex, pageSize);
        }

        protected void grdCases_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;
            Guid id = (Guid)grdCases.DataKeys[RowIndex].Value;
            if (e.CommandName == "Accept")
            {
                new CaseControl().AcceptCase(id);
                BindGrid(0, pageSize);
            }
            else if (e.CommandName.ToLower() == "editcommand")
            {
                Response.Redirect(UrlControl.GetPathUrl() + "/editcase.aspx?id=" + id, false);
            }
            else if (e.CommandName.ToLower() == "deletecommand")
            {
                new CaseControl().DeactivateCase(id);
                BindGrid(0, pageSize);
            }
        }
	}
}