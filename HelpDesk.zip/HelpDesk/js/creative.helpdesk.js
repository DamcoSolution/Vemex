﻿var Form = {

	Validate: function (fields, callback) {

		if (!fields)
			alert("Parameter required: fileds");
	
		var success = true;

		for (var field in fields) {

			var $field = $(field);

			if ($field.length) {

				var $type = fields[field]["type"];
				var $message = fields[field]["message"];
				var $value = $field.val();

				if ($type == "email") {
					if (!Form.IsValidEmail($value))
				        success = false;
				}else if ($type == "supportid") {
					if ($value == "")
					    success = false;
				}else if ($type == "phone") {
					if ($value.length < 9)
					    success = false;
				}else if ($type == "text") {
					if ($value == "")
				        success = false;
				}else if ($type == "checklist") {
					var isChecked = false;
					$field.each(function (index) {
						if ($field.parent().find("input:eq(" + index + ")").is(":checked"))
							isChecked = true;
					});
					if (!isChecked) 
					    success = false;
				}
			}
			else {
                if(callback)
				    callback("Filed doesn't exist: " + field);
				success = false;
			}

			if (!success) {
                if(callback)
			        callback($message);
			    return false;
			}
		}

		callback("Čekejte prosím...");
		return true;

	},

	IsValidEmail: function (email) {

		var emailRegex = /\S+@\S+\.\S+/;
		return (emailRegex.test(email));
	},

	CheckboxList: function ($clickedInput, $parent) {

		$parent.find("input[type=checkbox]").attr("checked", false);
		$clickedInput.attr("checked", true);

	}

};