﻿$(function () {
    $("input[type=text], input[type=password]").each(function ()
    {
        if ($(this).val() != "") $(this).prev("label").hide();
    });
    var error = 0;
    var r = /^[^.]+(\.[^.]+)*@([^.]+[.])+[a-z]{2,4}$/;
    $("input[type=text], input[type=password], textarea").keydown(
        function ()
        {
            $(this).prev("label").hide();
        });
    $("label[data-type=form]").click(
        function ()
        {
            if ($(this).next("input[type=text], input[type=password], textarea").val() == "")
            {
                $(this).hide(); $(this).next("input[type=text], input[type=password], textarea").trigger("focus");
            }
        });
    $("input[type=text], input[type=password], textarea").blur(function ()
    {
        if ($(this).val() == "" || $(this).val() == $(this).prev("label").text())
        {
            $(this).prev("label").show(); $(this).val("");
        }
    });
    $("input[type=text], input[type=password], textarea").focus(function ()
    {
        if ($(this).val() != "" || $(this).val() != $(this).prev("label").text())
        {
            $(this).prev("label").hide();
        }
    });
});