﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk.Controls
{
    public class ContactItem
    {
        public Guid id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string fullName { get; set; }
        public string email { get; set; }
        public string customerName { get; set; }

        public PortalRole Role { get; set; }

        public Guid CustomerId { get; set; }
        public string CustomerLogicalNamge { get; set; }
    }
}