﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HelpDesk.EntityObjects;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using CreativeMages.Xrm;

namespace HelpDesk.Controls
{
    public class CaseControl
    {
        public int TotalRecords;

        public List<Cases> GetCases(PortalRights rights, ContactItem user, int pageNumber, int pageSize)
        {

            List<Cases> list = new List<Cases>();

            QueryExpression query = GenerateQuery(rights, user);
            query.PageInfo = new PagingInfo() { PageNumber = pageNumber + 1, Count = pageSize, ReturnTotalRecordCount = true };

            // Obtain results from the query expression.
            EntityCollection ec = ServiceControl.GetService().RetrieveMultiple(query);
            this.TotalRecords = ec.TotalRecordCount;
            foreach (Entity entity in ec.Entities)
            {
                Cases cases = SetCaseByEntity(entity);
                list.Add(cases);
            }

            return list;
        }

        private static QueryExpression GenerateQuery(PortalRights rights, ContactItem user)
        {
            var contact = LoginControl.GetUsersContract();

            /*new string[] { 
                    Constants.ContactId, 
                    Constants.ContactFirstName,
                    Constants.ContactLastName,                   
                    Constants.ContactEmail,
                    Constants.ContactFullName ,
                    Constants.ContactPortalRole,
                    Constants.ContactParentCustomerId
                }*/

            ColumnSet columns = new ColumnSet(true);

            EntityReference parentCustomer = new EntityReference(user.CustomerLogicalName, user.CustomerId);
            QueryExpression query = new QueryExpression();

            EntityReference currentContact = new EntityReference(Constants.Contact, contact.id);

            switch (rights.AccessLevel)
            {
                case AccessLevel.kontakt:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Case,
                            ColumnSet = columns,
                            Criteria =
                            {
                                Filters = 
                                {                                    
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.And,
                                        Conditions = 
                                        {
                                            new ConditionExpression(Constants.StateCode, ConditionOperator.Equal,0),
                                            new ConditionExpression(Constants.CaseCustomerId,ConditionOperator.Equal,contact.id)
                                        }
                                   }
                                }
                            }
                        };
                    }
                    break;
                case AccessLevel.account:
                    {

                        if (parentCustomer != null)
                        {
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Case,
                                ColumnSet = columns,
                                Criteria =
                                {
                                    Filters =
                                        {
                                            new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = 
                                                {
                                                    new ConditionExpression(Constants.StateCode,ConditionOperator.Equal,0)
                                                }
                                            }
                                        }
                                },
                                LinkEntities = 
                                    { 
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName =Constants.Contact, LinkFromAttributeName = Constants.ContactId, LinkToEntityName = Constants.Case, LinkToAttributeName =Constants.CaseCustomerId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName =Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {parentCustomer.Id}}}
                                            }
                                        }
                                    }
                            };
                        }
                    }
                    /*
                     //Commented for now
                            //if (reference != null)
                            //{
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Contact,
                                ColumnSet = columns,
                                Criteria =
                                {
                                    Filters = 
                                    {
                                        new FilterExpression
                                        {
                                            FilterOperator = LogicalOperator.And,
                                            Conditions = 
                                            {
                                                new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}},
                                                new ConditionExpression {AttributeName= Constants.ContactAccountRole, Operator=  ConditionOperator.Equal, Values={Constants.AccountRoleId}}
                                            }
                                        },
                                        new FilterExpression
                                        {
                                            FilterOperator = LogicalOperator.Or,
                                            Conditions = 
                                            {
                                                new ConditionExpression {AttributeName = Constants.ContactOwner, Operator = ConditionOperator.Equal, Values ={user.Id}},
                                                new ConditionExpression {AttributeName= Constants.ContactParentCustomerId, Operator=  ConditionOperator.Equal, Values={user.Id}}
                                            }
                                        }

                                    }

                                }
                            };
                        } */

                    break;
                case AccessLevel.organizace:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Case,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                   
                                }
                            },
                        };
                    }
                    break;
                default:
                    break;
            }
            query.Distinct = true;
            return query;
        }
        
        private static Cases SetCaseByEntity(Entity entity)
        {
            Cases caseRec = new Cases();
            if (entity != null)
            {

                if (entity.Attributes.Contains(Constants.CaseProductId))
                {
                    caseRec.ProductId = entity[Constants.CaseCustomerId] as EntityReference;
                }
                caseRec.CaseId = entity.Id;
                caseRec.ID = entity.Attributes.Contains(Constants.CaseTicketNumber) ? entity[Constants.CaseTicketNumber].ToString() : string.Empty;
                caseRec.CaseStatus = entity.Attributes.Contains(Constants.CaseNewStatus) ? (CaseStatus)((OptionSetValue)entity[Constants.CaseNewStatus]).Value : (CaseStatus)(-1);
            }
            return caseRec;
        }

        internal void DeactivateCase(Guid id)
        {
            IncidentResolution incresolution = new IncidentResolution()
            {
                Subject = "deactivated",
                IncidentId = new EntityReference("incident", id)
            };

            CloseIncidentRequest request = new CloseIncidentRequest()
            {
                IncidentResolution = incresolution,
                Status = new OptionSetValue((int)incident_statuscode.Problmjevyeen)
            };

            CloseIncidentResponse resp = (CloseIncidentResponse)ServiceControl.GetService().Execute(request);
        }

        internal void AcceptCase(Guid id)
        {
            try
            {
                using (XrmContext context = new XrmContext(ServiceControl.GetService()))
                {
                    Incident entity = context.IncidentSet.Where(lst => lst.IncidentId == id).FirstOrDefault();
                    // entity.
                    entity.cre_newstateofcase = new OptionSetValue((int)Incidentcre_newstateofcase.AcceptedAkceptovno);
                    context.UpdateObject(entity);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                ErrorControl.ThrowError("Error occured while updating case status. Kindly contact Administrator!");
            }
        }

        public Guid CreateCase(Guid helpdeskissue_id)
        {
            Guid CaseId = new Guid();
            using (var context = new XrmContext(ServiceControl.GetService()))
            {
                var helpdesk = context.cre_helpdeskissueSet.Where(lst => lst.Id == helpdeskissue_id).FirstOrDefault();

                Incident inc = new Incident()
                {
                    CustomerId = new EntityReference(helpdesk.cre_owner.LogicalName, helpdesk.cre_owner.Id),
                    Title = helpdesk.cre_name,
                    cre_cre_helpdeskissue_incident_helpdeskissue = helpdesk
                };

                CaseId = ServiceControl.GetService().Create(inc);

                helpdesk.cre_issuestatus = new OptionSetValue((int)cre_issuestatus.AcceptedAkceptovno);
                 context.UpdateObject(helpdesk);
                 context.SaveChanges();
            }

            return CaseId;
        }
    }   
}