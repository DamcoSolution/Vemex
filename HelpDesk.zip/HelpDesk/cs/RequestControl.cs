﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CreativeMages.Xrm;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace HelpDesk.Controls
{
    public class RequestControl
    {

        public int TotalRecords { get; set; }

        public List<cre_helpdeskissue> IssueList(PortalRights right, ContactItem user, int pageNumber, int pageSize)
        {
            List<cre_helpdeskissue> issueList = new List<cre_helpdeskissue>();

            using (var context = new XrmContext(ServiceControl.GetService()))
            {

                switch (right.AccessLevel)
                {

                    case AccessLevel.kontakt:
                        {

                            issueList = (from helpissue in context.cre_helpdeskissueSet
                                         join cont in context.ContactSet
                                         on helpissue.cre_owner.Id equals cont.Id
                                         where cont.Id == user.id
                                         select helpissue
                                               ).ToList();
                        }
                        break;
                    case AccessLevel.account:
                        {
                            issueList = (from helpissue in context.cre_helpdeskissueSet
                                         join cont in context.ContactSet
                                         on helpissue.cre_owner.Id equals cont.Id
                                         join acc in context.AccountSet
                                         on cont.AccountId.Id equals acc.Id
                                         where acc.Id == user.CustomerId
                                         select helpissue
                                          ).ToList();
                        }
                        break;
                    case AccessLevel.organizace:
                        {
                            issueList = context.cre_helpdeskissueSet.ToList();
                        }
                        break;
                }
            }

            this.TotalRecords = issueList.Count;
            return issueList;
          
        }

        private static QueryExpression GenerateQuery(PortalRights rights, ContactItem user)
        {
            ColumnSet columns = new ColumnSet(true);

            //new string[] { 
            //    Constants.ContactId, 
            //    Constants.ContactFirstName,
            //    Constants.ContactLastName ,
            //    Constants.ContactLastLogin, 
            //    Constants.ContactLogin,
            //    Constants.ContactEmail,
            //    Constants.ContactFullName ,
            //    Constants.PortalRole,
            //    Constants.ContactParentCustomerId
            //   });


            EntityReference reference = new EntityReference(user.CustomerLogicalName, user.CustomerId);
            QueryExpression query = new QueryExpression();

            EntityReference currentContact = new EntityReference(Constants.Contact, user.id);
            switch (rights.AccessLevel)
            {
                case AccessLevel.kontakt:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Contact,
                            ColumnSet = columns,
                            Criteria =
                            {
                                Filters = 
                                {                                    
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.And,
                                        Conditions = 
                                        {
                                            new ConditionExpression(Constants.StateCode, ConditionOperator.Equal,0),
                                            new ConditionExpression(Constants.ContactAccountRole,ConditionOperator.Equal,Constants.AccountRoleId)
                                        }
                                   },
                                   new FilterExpression
                                   {
                                        FilterOperator = LogicalOperator.Or,
                                        Conditions = 
                                        {
                                            new ConditionExpression(Constants.ContactOwner,ConditionOperator.Equal,user.id),
                                            new ConditionExpression(Constants.ContactId,ConditionOperator.Equal,user.id)
                                        }
                                   }
                                }
                            }
                        };
                    }
                    break;
                case AccessLevel.account:
                    {

                        if (reference != null)
                        {
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Contact,
                                ColumnSet = columns,
                                Criteria =
                                {
                                    Filters =
                                        {
                                            new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = 
                                                {
                                                    new ConditionExpression(Constants.StateCode,ConditionOperator.Equal,0),
                                                    new ConditionExpression(Constants.ContactAccountRole, ConditionOperator.Equal, Constants.AccountRoleId)
                                                }
                                            }
                                        }
                                }
                                ,
                                LinkEntities = 
                                    {
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName =Constants.Contact, LinkFromAttributeName = Constants.ContactOwner, LinkToEntityName = Constants.Contact, LinkToAttributeName =Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName =Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {reference.Id}}}
                                            }
                                        },
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName =Constants.Contact, LinkFromAttributeName = Constants.ContactId, LinkToEntityName = Constants.Contact, LinkToAttributeName =Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName =Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {reference.Id}}}
                                            }
                                        }
                                    }
                            };
                        }
                    }
                    /*
                     //Commented for now
                            //if (reference != null)
                            //{
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Contact,
                                ColumnSet = columns,
                                Criteria =
                                {
                                    Filters = 
                                    {
                                        new FilterExpression
                                        {
                                            FilterOperator = LogicalOperator.And,
                                            Conditions = 
                                            {
                                                new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}},
                                                new ConditionExpression {AttributeName= Constants.ContactAccountRole, Operator=  ConditionOperator.Equal, Values={Constants.AccountRoleId}}
                                            }
                                        },
                                        new FilterExpression
                                        {
                                            FilterOperator = LogicalOperator.Or,
                                            Conditions = 
                                            {
                                                new ConditionExpression {AttributeName = Constants.ContactOwner, Operator = ConditionOperator.Equal, Values ={user.Id}},
                                                new ConditionExpression {AttributeName= Constants.ContactParentCustomerId, Operator=  ConditionOperator.Equal, Values={user.Id}}
                                            }
                                        }

                                    }

                                }
                            };
                        } */

                    break;
                case AccessLevel.organizace:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Contact,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}},
                                    new ConditionExpression {AttributeName= Constants.ContactAccountRole, Operator=  ConditionOperator.Equal, Values={Constants.AccountRoleId}}
                                }
                            },
                        };
                    }
                    break;
                default:
                    break;
            }
            query.Distinct = true;
            return query;
        }
    }
}