﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk.Controls
{
    public class ContractItem
    {
        public Guid id { get; set; }
        public string contractNumber { get; set; }
        public DateTime expiresOn { get; set; }
        public Guid customerId { get; set; }
        public int stateCode { get; set; }
        public int statusCode { get; set; }
    }
}