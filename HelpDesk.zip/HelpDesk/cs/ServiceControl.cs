﻿using CRM;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace HelpDesk.Controls
{
    public class ServiceControl
    {
        public static bool IsReady()
        {

            return (HttpContext.Current.Session["_service"] != null);

        }

        public static IOrganizationService GetService()
        {

            // get crm credentials
            string email = ConfigurationManager.AppSettings["crmEmail"];
            string password = ConfigurationManager.AppSettings["crmPassword"];
            string domain = ConfigurationManager.AppSettings["crmDomain"];

            // login to crm
            if (HttpContext.Current.Session["_service"] == null)
                HttpContext.Current.Session["_service"] = Service.Authentication(email, password, domain, FormsAuthentication.HashPasswordForStoringInConfigFile("CR3ativ3S3rv1c3***", "MD5").ToLower());

            // return servie from session
            return (IOrganizationService)HttpContext.Current.Session["_service"];

        }
    }
}