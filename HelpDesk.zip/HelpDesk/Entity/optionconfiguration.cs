﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CRM;
using HelpDesk.Controls;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace HelpDesk.EntityObjects
{
    public class OptionConfiguration
    {
        public string primaryoptionname { get; set; }
        public string primaryoptionvalue { get; set; }
        public string secondaryoptionname { get; set; }
        public string secondaryoptionvalue { get; set; }

        public static List<OptionConfiguration> GetSecondaryOptionsetMain(string primaryoption)
        {
            List<OptionConfiguration> list = new List<OptionConfiguration>();

            FilterExpression filter = new FilterExpression();
            filter.AddCondition("cre_primary_optionvalue", ConditionOperator.Equal, primaryoption);
            filter.FilterOperator = LogicalOperator.And;

            EntityCollection _options = Service.RetrieveMultiple("cre_listconfiguration", filter, new ColumnSet(true), ServiceControl.GetService());

            foreach (Entity entity in _options.Entities)
            {
                OptionConfiguration _optionconfiguration = new OptionConfiguration();

                string entityname = entity.Attributes["cre_primary_optionname"].ToString();
                string optionvalue = entity.Attributes["cre_primary_optionvalue"].ToString();

                //EntityCollection _primaryoptions = Service.RetrieveMultiple("cre_listconfiguration", null, new ColumnSet(true), ServiceControl.GetService());

                _optionconfiguration.primaryoptionname = entity.Attributes["cre_primary_optionname"].ToString();
                _optionconfiguration.primaryoptionvalue = entity.Attributes["cre_primary_optionvalue"].ToString();
                _optionconfiguration.secondaryoptionname = entity.Attributes["cre_secondary_optionname"].ToString();
                _optionconfiguration.secondaryoptionvalue = entity.Attributes["cre_secondary_optionvalue"].ToString();

                list.Add(_optionconfiguration);
            }
            return list;
        }

        public static List<SelectControl> GetSecondaryOptionsetFiltered(string[] options)
        {
            List<SelectControl> FilteredList = new List<SelectControl>();
            List<SelectControl> subCategory = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_subcategory");

            foreach (var item in subCategory)
            {
                if (options.Contains(item.value))
                    FilteredList.Add(item);
            }
            return FilteredList;
        }
    }
}