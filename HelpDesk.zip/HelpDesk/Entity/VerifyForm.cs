﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk.EntityObjects
{
    public class VerifyForm
    {
        public DateTime AcceptedOn { get; set; }
        public DateTime? AcceptedOn_CEST { get; set; }
        public string Status { get; set; }
        public string Name { get; set; }
        public string ContactName { get; set; }
        public string EAN { get; set; }
        public string EIC { get; set; }        
    }
}