﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Web;

namespace XmlImportVemex
{
    class Logger
    {

        static FileStream fs;

        static TextWriter w;
        public static string logFile;
        public static bool WriteLine(string log)
        {
            try
            {
                w = File.AppendText(logFile);
                w.WriteLine(log);
                w.Close();
            }
            catch (Exception Ex)
            {
                
                return false;
            }
            return true;
        }

        public static bool init(string log)
        {
            

            try
            {
                string today = DateTime.Now.ToLocalTime().ToString("dd-MM-yyyy");
                //path = "Log " + DateTime.Now.ToString("yyyy MM dd HH_mm_ss") + ".txt";
              //string logFile = HttpContext.Current.Server.MapPath("~/Log/log-" + today + ".txt");
                //string logFile = "C:\\inetpub\\wwwroot\\creativemages\\ImportService\\Log\\" + today + ".txt";

                while (File.Exists(logFile))
                {
                    logFile = "Log " + DateTime.Now.ToString("yyyy MM dd HH_mm_ss") + ".txt";
                }
                //path = "co_ sdf .txt";
                fs = File.Create(logFile);

                fs.Close();

                w = File.AppendText(logFile);
                w.WriteLine(log);
                w.Close();
            }

            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }
            return true;
        }


        public static bool init(string log, string filepath)
        {

            try
            {
             
                logFile = filepath;
                if (!File.Exists(logFile))
                {
                    fs = File.Create(logFile);
                    fs.Close();
                }
                //path = "co_ sdf .txt";

                w = File.AppendText(logFile);
                w.WriteLine(log);
                w.Close();
            }

            catch (Exception Ex)
            {

                return false;
            }
            return true;
        }
            


    }
}
