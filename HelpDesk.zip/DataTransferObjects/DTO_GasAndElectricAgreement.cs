﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
  public  class DTO_GasAndElectricAgreement
    {
      public ContractType ContractType { get; set; }
      public ContractMode ContractMode { get; set; }
      public DTO_Company Company { get; set; }
      public DTO_Person Person { get; set; }

      public List<DTO_SupplyPoint> SupplyPointList { get; set; }

      public List<DTO_VerifyForm> VerifyFormList { get; set; }

      public DTO_Opportunity Opportunity { get; set; }


    }
}
