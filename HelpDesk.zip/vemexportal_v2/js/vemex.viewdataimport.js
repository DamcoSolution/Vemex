﻿$(function () {

    /*
    
   
    */

    //Variable diclaration
    var $sellerId = $("#chkSellerId"),
        $chkAuction = $("#chkAuction"),
        $DivAuctionList = $("#DivAuctionList"),
        $btnUpload = $("#btnUpload");
    
    var $loading = $(".loadingholder"),
        $popHolder = $(".popholder"),
        $pop = $(".popholder .pop");


    if ($chkAuction.is(":checked") == true) {
        $DivAuctionList.show();
    }
    else {
        $DivAuctionList.hide();
    }

        ui.switchchecks("#chkSellerId, #chkAuction", function () {

            if ($chkAuction.is(":checked") == true) {
                $DivAuctionList.show();
            }
            else {
                $DivAuctionList.hide();
            }
        });
  
    //Events
    AutocompleteInput("#DivAutoCompleteAuctionId");

    $btnUpload.click(OnUploadBtnClick);


    function AutocompleteInput(containerId, contains) {
        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
            }
        });

    }

    function OnUploadBtnClick() {
        var formSuccess = ValidateForm();
        if (formSuccess)
            $loading.show();
        return formSuccess;
    }
});