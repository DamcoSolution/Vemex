﻿$(function () {
    debugger;
    var $supplyPointDepositAmountTxt = $("#supplyPointDepositAmountTxt"),
        $supplyPointDepositAmountTxt2 = $("#supplyPointDepositAmountTxt2");

   // $testTxt.change(Onchange);


   // .replace(/[a-zA-Z]/g, "")
    
    ui.replacecountwithline("#TextBox1");
    // events
    $supplyPointDepositAmountTxt.change(OnsupplyPointDepositAmountTextChanged);
    $supplyPointDepositAmountTxt2.change(OnsupplyPointDepositAmountTextChanged2);

    function OnsupplyPointDepositAmountTextChanged() {
        alert("onchange");
    }

    function OnsupplyPointDepositAmountTextChanged2()
    {
        alert("onchange");
    }
    function Onchange()
    {
        alert("onchange triggered");
    }
});