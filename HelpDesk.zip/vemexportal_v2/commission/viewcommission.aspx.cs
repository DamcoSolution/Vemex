﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using VemexPortal_v2.Controls;

namespace VemexPortal_v2.commission
{
    public partial class viewcommission : PageControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!PortalRole.CanView(Entity_Name.cre_commission))
                {
                    new ErrorControl("You don't have right to view commission ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                }
                else
                {
                    BindGrid();
                }
            }
        }

        private void BindGrid()
        {
            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.cre_commission).FirstOrDefault();
            LoginControl user = LoginControl.LoggedUser();
            var list = new CommissionControl().GetCommissionList(rights, user);
            grdCommission.DataSource = list;
            grdCommission.DataBind();
        }

        protected void grdCommission_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Guid id = (Guid)grdCommission.DataKeys[e.NewEditIndex].Value;
            Response.Redirect(UrlControl.GetPathUrl() + "/editcontact.aspx?id=" + id);
        }

        protected void grdCommission_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Guid id = (Guid)grdCommission.DataKeys[e.RowIndex].Value;
            new ContactControl().DeactivateContact(id);
            BindGrid();
        }

        protected void grdCommission_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCommission.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
               server control at run time. */
        }
    
    }
}