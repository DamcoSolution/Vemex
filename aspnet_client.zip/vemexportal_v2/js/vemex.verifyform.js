﻿$(function () {

    var setinterval;
    //Button
    $btnExport = $("#btnExport");

    //Loading Holder
    var $loading = $(".loadingholder");

    $loading.hide();
    //event
    $btnExport.click(ExportClick);

    function ExportClick() {

        var formSuccess = true;
        if (formSuccess) {
            $loading.show();
            Export();
        }
        return formSuccess;
    }

    function Export() {
        setinterval= setInterval(IsExported, 5000);
    }

    function IsExported() {
        
            Ajax.CallWebMethod(
                "viewverifyform.aspx/IsExported",
                { user: "test" },
                function (response) {                  
                    if (response) {                        
                        $loading.hide();
                        clearInterval(setinterval);
                    }
                }
                );
        
    }


});