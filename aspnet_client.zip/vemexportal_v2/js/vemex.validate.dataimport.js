﻿// variables

var errorCount = 0,
    lineCount = 0,
    $bottomError = $("<div class=\"bottomerror\">" +
                        "<div class=\"holder\">" +
                            "<div class=\"bottomerrortop\">" +
                                "<div class=\"bottomerrortopalert\"></div>" +
                                "<div class=\"bottomerrortopcontent\">Formulář nelze odeslat!</div>" +
                                "<div class=\"bottomerrortoparrow\"><span>Zobrazit chyby:</span> <strong>28</strong></div>" +
                            "</div>" +
                            "<div class=\"bottomerrormiddle\"></div>" +
                        "</div>" +
                        "</div>"),
    $bottomErrorTop = $bottomError.find(".bottomerrortop"),
    $bottomErrorTopCount = $bottomErrorTop.find(".bottomerrortoparrow strong"),
    $bottomErrorTopText = $bottomErrorTop.find(".bottomerrortoparrow span"),
    $bottomErrorTopArrow = $bottomErrorTop.find(".bottomerrortoparrow"),
    $bottomErrorMiddle = $bottomError.find(".bottomerrormiddle");

// events
$bottomErrorTop.click(ErrorTopClick);


// functions
function ValidateForm() {

    // person detail
    var $inputs = $("input"),
    $labels = $(".label"),
    $sellerId = $("#chkSellerId"),
     $chkAuction = $("#chkAuction"),
     $DivAuctionList = $("#DivAuctionList"),
     $btnUpload = $("#btnUpload"),
      $txtAcutionId = $("#txtAcutionId"),
       $flupload = $("#flupload"),
         $lblImportType = $("#lblImportType");


    // remove errors and set default values
    $inputs.removeClass("error");
    $labels.removeClass("error");
    $bottomErrorMiddle.empty();
    errorCount = lineCount = 0;

    if ($sellerId.is(":checked") == false && $chkAuction.is(":checked") == false)
        AddErrorLine($lblImportType, "Please select SellerId or Auction Id Check box.");

    if ($chkAuction.is(":checked") == true && $.trim($txtAcutionId.val()) == "")
        AddErrorLine($txtAcutionId, "Please select Auction Contact.");

    if ($.trim($flupload.val()) == "") {
        AddErrorLine($flupload, "Please select file.");
    }
    else if (!(/\.(xls|xlsx)$/i).test($flupload.val())) {
        AddErrorLine($flupload, "Only Excel File is allowed.");
    }
    ShowHideError();
    return (errorCount == 0);
};

function AddErrorLine($field, message) {
    lineCount += 1;
    var elementId = $field.attr("id").split(" ")[0],
    $element = $("<a href=\"#\" class=\"bottomerrormiddleline\" data-id=\"" + elementId + "\">" + "<span>" + lineCount + "</span>" + message + "</a>");
    $element.click(ErrorLineClick);
    $bottomErrorMiddle.append($element);
    $field.addClass("error");
    errorCount = lineCount;
}

function AddErrorClass($field) {
    $field.addClass("error");
}

function ShowHideError() {

    var $body = $("body");
    if (errorCount > 0) {
        $bottomErrorTopCount.text(errorCount);
        $body.append($bottomError);
        $bottomError.show();
    } else
        $bottomError.hide();
}

function ErrorLineClick() {
    var elId = $(this).attr("data-id");
    var $element = $("#" + elId);
    var scrollTop = $element.offset().top - 15;
    $("html, body").stop().animate({ scrollTop: scrollTop }, 400, function () {
        $element.focus();
    });
    return false;
}

function ErrorTopClick() {
    $bottomErrorMiddle.toggle();
    $bottomErrorTopArrow.toggleClass("active");
    return false;
}
