﻿$(function () {

    // variables
    var filesCount = 0;

    // form types 
    var $smallCheck = $("#smallCheck"),
        $homeCheck = $("#homeCheck");

    //Seller Info
    var $sellerFirstName = $("#txtSellerFirstName"),
        $sellerLastName = $("#txtSellerLastName");

    // buttons
    var $saveAndDuplicateBtn = $("#saveAndDuplicateBtn"),
        $saveAndEndBtn = $("#saveAndEndBtn"),
        $postalAddressBtn = $("#postalAddressBtn"),
        $addNewFileBtn = $("#addNewFileBtn"),
        $removeFileBtn = $(".removeFile"),
        $popCloseBtn = $(".popholder .poptop .popclose"),
        $popInputBtn = $(".popholder .popmiddle input"),
        $copyAddressBtn = $("#copyAddressBtn"),
        $copySecondAddressBtn = $("#copySecondAddressBtn"),
        $copyAddressBtn2 = $("#copyAddressBtn2"),
        $copySecondAddressBtn2 = $("#copySecondAddressBtn2");

    // form parts
    var $postalAddressPart = $("#postalAddressPart"),
        $uploadFilesPart = $("#uploadFilesPart"),
        $homeParts = $("div[data-id=home]"),
        $smallParts = $("div[data-id=small]"),
        $loading = $(".loadingholder"),
        $popHolder = $(".popholder"),
        $pop = $(".popholder .pop"),
        $nextSupplyPoint = $("#nextSupplyPoint"),
        $addSupplyPoint = $("#addSupplyPoint");

    // person detail
    var $firstName = $("#firstNameTxt"),
        $lastName = $("#lastNameTxt"),
        $titul = $("#titulTxt"),
        $lastTitul = $("#lastTitulTxt"),
        $ico = $("#icoTxt"),
        $dic = $("#dicTxt");

    // company detail
    var $companyName = $("#companyNameTxt"),
        $companyIco = $("#companyIcoTxt"),
        $companyDic = $("#companyDicTxt");

   
    // address
    var $street = $("#streetTxt"),
        $houseNumber = $("#houseNumberTxt"),
        $orientationNumber = $("#orientationNumberTxt"),
        $postalCode = $("#postalCodeTxt"),
        $country = $("#countryTxt"),
        $postalStreet = $("#postalStreetTxt"),
        $postalHouseNumber = $("#postalHouseNumberTxt"),
        $postalOrientationNumber = $("#postalOrientationNumberTxt"),
        $postalPostalCode = $("#postalPostalCodeTxt"),
        $postalCountry = $("#postalCountryTxt");

    // supply point
    var $supplyPointStreet = $("#supplyPointStreetTxt"),
        $supplyPointHouseNumber = $("#supplyPointHouseNumberTxt"),
        $supplyPointOrientationNumber = $("#supplyPointOrientationNumberTxt"),
        $supplyPointPostalCode = $("#supplyPointPostalCodeTxt"),
        $supplyPointCountry = $("#supplyPointCountryTxt"),
        $supplyPointInvoicePaymentTransferCheck = $("#supplyPointInvoicePaymentTransferCheck"),
        $supplyPointNewDistributionTxt = $("#supplyPointNewDistributionTxt"),
        $supplyPointYearSubscriptionAmountTxt = $("#supplyPointYearSubscriptionAmountTxt"),
        $supplyPointDepositAmountTxt = $("#supplyPointDepositAmountTxt"),
        $supplyPointDepositMonthCheck = $("#supplyPointDepositMonthCheck"),
        $supplyPointDepositQuarterCheck = $("#supplyPointDepositQuarterCheck"),
        $supplyPointStreet2 = $("#supplyPointStreetTxt2"),
        $supplyPointHouseNumber2 = $("#supplyPointHouseNumberTxt2"),
        $supplyPointOrientationNumber2 = $("#supplyPointOrientationNumberTxt2"),
        $supplyPointPostalCode2 = $("#supplyPointPostalCodeTxt2"),
        $supplyPointCountry2 = $("#supplyPointCountryTxt2"),
        $supplyPointInvoicePaymentTransferCheck2 = $("#supplyPointInvoicePaymentTransferCheck2"),
        $supplyPointNewDistributionTxt2 = $("#supplyPointNewDistributionTxt2"),
        $supplyPointYearSubscriptionAmountTxt2 = $("#supplyPointYearSubscriptionAmountTxt2"),
        $supplyPointDepositAmountTxt2 = $("#supplyPointDepositAmountTxt2"),
        $supplyPointDepositMonthCheck2 = $("#supplyPointDepositMonthCheck2"),
        $supplyPointDepositQuarterCheck2 = $("#supplyPointDepositQuarterCheck2"),
        $contractTimeYearFive = $("#contractTimeYearFive"),
        $contractTimeYearFirst = $("#contractTimeYearFirst"),
        $contractTimeYearSecond = $("#contractTimeYearSecond"),
        $contractTimeYearThird = $("#contractTimeYearThird"),
        $supplyPointEICText = $("#supplyPointEICTxt"),
        $supplyPointEICText2 = $("#supplyPointEICTxt2");

    
    var $inputsFile = $("input[type=file]"),
        $allInputs = $("input[type=text], input[type=checkbox]");

    
    // checks switch
    ui.switchchecks("#smallCheck, #homeCheck");
    ui.switchchecks("#resignationUnitMonthCheck, #resignationUnitDayCheck");
    ui.switchchecks("#contractTimeFirstCheck, #contractTimeSecondCheck, #contractTimeThirdCheck", function () {
        $contractTimeYearFive.attr("checked", false);
        $contractTimeYearFirst.attr("checked", false);
        $contractTimeYearSecond.attr("checked", false);
        $contractTimeYearThird.attr("checked", false);
    });
   
    ui.switchchecks("#contractTimeYearFirst, #contractTimeYearSecond, #contractTimeYearThird, #contractTimeYearFive");
    ui.switchchecks("#supplyPointChangeProviderCheck, #supplyPointChangeCustomerCheck, #supplyPointChangeNewSubscriptionCheck, #supplyPointChangeProviderPriceCheck, #supplyPointOverwriteCheck");
    ui.switchchecks("#supplyPointDepositMonthCheck, #supplyPointDepositQuarterCheck");
    ui.switchchecks("#supplyPointDeliverEmailCheck, #supplyPointDeliverPostCheck");
    ui.switchchecks("#supplyPointChangesDeliverEmailCheck, #supplyPointChangesDeliverPostCheck, #supplyPointChangesDeliverWebCheck");
    ui.switchchecks("#supplyPointDepositPaymentTransferCheck, #supplyPointDepositPaymentCollectionCheck, #supplyPointDepositPaymentSlipCheck, #supplyPointDepositPaymentSIPOCheck");
    ui.switchchecks("#supplyPointInvoicePaymentTransferCheck, #supplyPointInvoicePaymentCollectionCheck, #supplyPointInvoicePaymentSlipCheck");

    ui.switchchecks("#supplyPointChangeProviderCheck2, #supplyPointChangeCustomerCheck2, #supplyPointChangeNewSubscriptionCheck2, #supplyPointChangeProviderPriceCheck2, #supplyPointOverwriteCheck2");
    ui.switchchecks("#supplyPointDepositMonthCheck2, #supplyPointDepositQuarterCheck2");
    ui.switchchecks("#supplyPointDeliverEmailCheck2, #supplyPointDeliverPostCheck2");
    ui.switchchecks("#supplyPointChangesDeliverEmailCheck2, #supplyPointChangesDeliverPostCheck2, #supplyPointChangesDeliverWebCheck2");
    ui.switchchecks("#supplyPointDepositPaymentTransferCheck2, #supplyPointDepositPaymentCollectionCheck2, #supplyPointDepositPaymentSlipCheck2, #supplyPointDepositPaymentSIPOCheck2");
    ui.switchchecks("#supplyPointInvoicePaymentTransferCheck2, #supplyPointInvoicePaymentCollectionCheck2, #supplyPointInvoicePaymentSlipCheck2");
   
    $ico.change(OnIcoChange);

    $companyIco.change(OnCompanyIcoChange);
    //replacecountwithline($companyIco);
    replacecountwithline("#supplyPointDepositAmountTxt, #supplyPointYearSubscriptionAmountTxt, #supplyPointDepositAmountTxt2, #supplyPointYearSubscriptionAmountTxt2");
    replacecount("#noticePeriodTxt, #postalCodeTxt, #postalPostalCodeTxt, #supplyPointPostalCodeTxt, #supplyPointPostalCodeTxt2, #contractNumberTxt, #phoneTxt, #houseNumberTxt, #icoTxt, #companyIcoTxt, #postalHouseNumberTxt, #supplyPointHouseNumberTxt, #supplyPointInvoicePaymentSIPOTxt, #supplyPointBankNumberSecondTxt, #supplyPointBankNumberFirstTxt, #supplyPointBankNumberCodeTxt, #supplyPointHouseNumberTxt2, #supplyPointInvoicePaymentSIPOTxt2, #supplyPointBankNumberSecondTxt2, #supplyPointBankNumberFirstTxt2, #supplyPointBankNumberCodeTxt2");

    // replace value
   // ui.replacecount("#noticePeriodTxt, #postalCodeTxt, #postalPostalCodeTxt, #supplyPointPostalCodeTxt, #supplyPointPostalCodeTxt2, #contractNumberTxt, #phoneTxt, #houseNumberTxt, #icoTxt, #companyIcoTxt, #postalHouseNumberTxt, #supplyPointHouseNumberTxt, #supplyPointInvoicePaymentSIPOTxt, #supplyPointBankNumberSecondTxt, #supplyPointBankNumberFirstTxt, #supplyPointBankNumberCodeTxt, #supplyPointHouseNumberTxt2, #supplyPointInvoicePaymentSIPOTxt2, #supplyPointBankNumberSecondTxt2, #supplyPointBankNumberFirstTxt2, #supplyPointBankNumberCodeTxt2");
 /*
   commented for now as its thorowing exception wiil revisit again
    ui.replacecountwithline("#supplyPointDepositAmountTxt, #supplyPointYearSubscriptionAmountTxt, #supplyPointDepositAmountTxt2, #supplyPointYearSubscriptionAmountTxt2");
    */
  
    // autocomplete 
    AutocompleteInput("#titulAutocomplete");
    AutocompleteInput("#titulLastAutocomplete");
    AutocompleteInput("#distributionAutocomplete");
    AutocompleteInput("#supplierAutocomplete");
    AutocompleteInput("#distributionAutocomplete2");
    AutocompleteInput("#supplierAutocomplete2");

    AutocompleteInput("#DivAutoCompleteSellerId");

 
 
    // events
    $supplyPointDepositAmountTxt.change(OnsupplyPointDepositAmountTextChanged);
    $supplyPointDepositAmountTxt2.change(OnsupplyPointDepositAmountTextChanged2);

   
    $saveAndDuplicateBtn.click(SaveAndDuplicateClick);
    $saveAndEndBtn.click(SaveAndEndClick);
    $postalAddressBtn.click(PostalAddressBtnClick);
    $copyAddressBtn.click(CopyAddressClick);
    $copySecondAddressBtn.click(CopySecondAddressClick);
    $copyAddressBtn2.click(CopyAddressClick2);
    $copySecondAddressBtn2.click(CopySecondAddressClick2);
    $addNewFileBtn.click(AddNewFileClick);
    $popCloseBtn.click(PopCloseClick);
    $popInputBtn.click(PopInputClick);
    $allInputs.click(CheckIfClientIsSelected);
    $removeFileBtn.live("click", RemoveUploadFile);
    $inputsFile.live("change", OnFileChange);
   
  
    $homeCheck.change(OnHomeChange);
    $smallCheck.change(OnSmallChange);
    $supplyPointYearSubscriptionAmountTxt.change(OnGasYearConsumptionChange);
    $supplyPointDepositMonthCheck.change(OnChangeAmount);
    $supplyPointDepositQuarterCheck.change(OnChangeAmount);
    $supplyPointDepositMonthCheck2.change(OnChangeAmount2);
    $supplyPointDepositQuarterCheck2.change(OnChangeAmount2);
    $supplyPointEICText.change(GetDistributorByEIC);
    //$supplyPointEICText.change(IsEICExists);
    $supplyPointEICText2.change(GetDistributorByEIC2);

    //$supplyPointEICText2.change(IsEICExists);

    $supplyPointDepositAmountTxt.change(OnsupplyPointDepositAmountTextChanged);
    $supplyPointDepositAmountTxt2.change(OnsupplyPointDepositAmountTextChanged2);

    // $supplyPointNewDistributionTxt.change(OnChangeAmount);
    //$supplyPointNewDistributionTxt2.change(OnChangeAmount2);
    
    $supplyPointYearSubscriptionAmountTxt.change(OnChangeAmount);
    $supplyPointYearSubscriptionAmountTxt2.change(OnChangeAmount2);

    $addSupplyPoint.click(ShowNextSupplyPoint);

    // on load
    if ($homeCheck.is(":checked")) {
        $homeParts.show();
        $smallParts.hide();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
    } else if ($smallCheck.is(":checked")) {
        $homeParts.hide();
        $smallParts.show();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
    }

    // functions
    function SaveAndDuplicateClick() {
        if (CheckIfClientIsSelected()) {
            var client = $homeCheck.is(":checked") ? "home" : "small";
            var formSuccess = ValidateForm(client, "gas");
            if (formSuccess) {
                $popHolder.show();
                $pop.center();
            }
            return false;
        }
        else
            return false;
    }


    function SaveAndEndClick() {
        if (CheckIfClientIsSelected()) {
            var client = $homeCheck.is(":checked") ? "home" : "small";
            var formSuccess = ValidateForm(client, "gas");
            if (formSuccess)
                $loading.show();
            return formSuccess;
        }
        else
            return false;
    }

    function PostalAddressBtnClick() {
        $postalAddressPart.toggle();
        return false;
    }

    function CopyAddressClick() {
        $supplyPointStreet.val($street.val());
        $supplyPointHouseNumber.val($houseNumber.val());
        $supplyPointOrientationNumber.val($orientationNumber.val());
        $supplyPointPostalCode.val($postalCode.val());
        $supplyPointCountry.val($country.val());
        return false;
    }

    function CopyAddressClick2() {
        $supplyPointStreet2.val($street.val());
        $supplyPointHouseNumber2.val($houseNumber.val());
        $supplyPointOrientationNumber2.val($orientationNumber.val());
        $supplyPointPostalCode2.val($postalCode.val());
        $supplyPointCountry2.val($country.val());
        return false;
    }

    function CopySecondAddressClick() {
        $supplyPointStreet.val($postalStreet.val());
        $supplyPointHouseNumber.val($postalHouseNumber.val());
        $supplyPointOrientationNumber.val($postalOrientationNumber.val());
        $supplyPointPostalCode.val($postalPostalCode.val());
        $supplyPointCountry.val($postalCountry.val());
        return false;
    }

    function CopySecondAddressClick2() {
        $supplyPointStreet2.val($postalStreet.val());
        $supplyPointHouseNumber2.val($postalHouseNumber.val());
        $supplyPointOrientationNumber2.val($postalOrientationNumber.val());
        $supplyPointPostalCode2.val($postalPostalCode.val());
        $supplyPointCountry2.val($postalCountry.val());
        return false;
    }

    function ShowNextSupplyPoint() {
        $(this).hide();
        $nextSupplyPoint.slideDown(400);
    }

    function OnIcoChange() {
     
        var ico = $(this).val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var name = result.name.split(" ");
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        if (name.length > 2)
                            $titul.val(name[name.length - 3]);
                        $firstName.val(name[name.length - 2]);
                        $lastName.val(name[name.length - 1].replace(",", ""));
                        $dic.val(result.dic.substring(2, result.dic.length));
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnCompanyIcoChange() {
        var ico = $companyIco.val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        $companyName.val(result.name);
                        $companyDic.val(result.dic);
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnHomeChange() {
        if ($(this).is(":checked")) {
            $homeParts.show();
            $smallParts.hide();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
        }
        else
            $(this).attr("checked", true);
    }

    function OnSmallChange() {
     
        if ($(this).is(":checked")) {
            $homeParts.hide();
            $smallParts.show();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
        }
        else
            $(this).attr("checked", true);
           
    }

    function AddNewFileClick() {
        if (filesCount < 14) {
            $uploadFilesPart.append("<div class=\"row\">" +
                                        "<div class=\"file\">" +
                                            "<div class=\"bgleft\"></div>" +
                                            "<div class=\"files\">" +
                                                "<input type=\"file\" name=\"file" + filesCount + "\" /><input type=\"image\" src=\"img/cross.png\" class=\"removeFile\" />" +
                                            "</div>" +
                                            "<div class=\"bgright\"></div>" +
                                        "</div>" +
                                    "</div>");
            filesCount++;
        }
        return false;
    }

    function RemoveUploadFile() {
        filesCount--;
        $(this).parent().parent().parent().remove();
        return false;
    }

    function OnFileChange() {
        if (this.files[0].size > 5242880) {
            alert("Soubor nesmí být větší než 5MB.");
            ClearInputFile($(this));
        }
        else if (!CheckFileType($(this).val())) {
            alert("Špatný formát souboru. Vyberte prosím jiný soubor.");
            ClearInputFile($(this));
        }
    }

    function ClearInputFile($input) {
        $input.val("");
        $input.replaceWith($(this).clone(true));
    }

    function CheckFileType(value) {
        switch (value.substring(value.lastIndexOf(".") + 1).toLowerCase()) {
            case 'gif': case 'jpg': case 'jpeg': case 'doc': case 'docx': case 'xls': case 'xlsx': case 'png': case 'pdf': case 'mp3': case 'wmv': case 'mov':
                return true;
                break;
            default:
                return false;
                break;
        }
    }

    function PopCloseClick() {
        $popHolder.hide();
    }

    function PopInputClick() {
        $loading.show();
        $popHolder.hide();
    }

    function CheckIfClientIsSelected() {
        if ($(this).attr("id") != "smallCheck" && $(this).attr("id") != "homeCheck")
            if (!$smallCheck.is(":checked") && !$homeCheck.is(":checked")) {
                alert("Musíte vybrat Domácnost nebo Maloodběr.");              
                $homeCheck.focus();
                return false;
            }
            else
                return true;
    }

    function OnGasYearConsumptionChange() {
        var $this = $(this);
        var val = parseInt($this.val());
        if (val > 629) {
            alert("Roční spotřeba nemůže být větší než 629 MWh.");
            $this.val("");
        }
    }

    function IsEICExists() {
        
        var eic = $supplyPointEICText.val();
        if (eic.length == 16) {
            Ajax.CallWebMethod(
                "plyn.aspx/IsEICExists",
                { eic: eic },
                function (response) {
                    if (response)
                        alert("Smlouva se zadaným EIC již existuje..");
                }
                );
        }
    }

    function AutocompleteInput(containerId, contains) {

        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
                if ($hiddenInput.attr("id") == "hdnSellerId") {
                    SellerIdChange($hiddenInput.attr("value"));
                }

            },
            change: function (event, ui) {
                if ($hiddenInput.attr("id") == "supplyPointNewDistributionValue") {
                    GetDistributorByEIC();                    
                }
                else if ($hiddenInput.attr("id") == "supplyPointNewDistributionValue2") {
                    GetDistributorByEIC2();
                }
            }
        });

    }
      
    function SellerIdChange(sellerId) {
        if (sellerId.length > 0) {
            Ajax.CallWebMethod(
                "plyn.aspx/GetNameByUserID",
                { SellerId: sellerId },
                function (response) {
                    if (response.length > 0) {                       
                        $sellerFirstName.val(response[0]);
                        $sellerLastName.val(response[1]);
                    }
                });
        }
    }

 function OnChangeAmount2() {
        CalculateDeposit($homeCheck, $supplyPointNewDistributionTxt2, $supplyPointYearSubscriptionAmountTxt2, $supplyPointDepositMonthCheck2, $supplyPointDepositQuarterCheck2, $supplyPointDepositAmountTxt2, false);
    }
   
   function OnChangeAmount() {
        CalculateDeposit($homeCheck, $supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, $supplyPointDepositAmountTxt,false);
    }

    function OnsupplyPointDepositAmountTextChanged() {
        CalculateDeposit($homeCheck, $supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, $supplyPointDepositAmountTxt, true);
    }

    function OnsupplyPointDepositAmountTextChanged2() {
        CalculateDeposit($homeCheck, $supplyPointNewDistributionTxt2, $supplyPointYearSubscriptionAmountTxt2, $supplyPointDepositMonthCheck2, $supplyPointDepositQuarterCheck2, $supplyPointDepositAmountTxt2, true);
    }

    function CalculateDeposit(HomeCheck, NewDistributor, SubscriptionAmount, DepositMonthCheck, DepositQuarterCheck, DepositAmount, UpdateOnlyIfLess) {
        
        if (NewDistributor.val() != "" && SubscriptionAmount.val() != "" && (DepositMonthCheck.is(":checked") || DepositQuarterCheck.is(":checked"))) {
            var amount = parseFloat(SubscriptionAmount.val());
            var total = DepositAmount.val() != "" ? parseInt(DepositAmount.val()) : 0;
            var depositval = total;
            var success = true;
            switch (NewDistributor.val()) {
                case "E.ON Distribuce":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1701.99;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1144.38;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1039.84;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1018.20;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1008.75;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1000.90;
                        if (amount > 30 && amount <= 35)
                            total = amount * 997.44;
                        if (amount > 35 && amount <= 40)
                            total = amount * 996.72;
                        if (amount > 40 && amount <= 45)
                            total = amount * 993.51;
                        if (amount > 45 && amount <= 50)
                            total = amount * 988.75;
                        if (amount > 50 && amount <= 55)
                            total = amount * 985.02;
                        if (amount > 55 && amount <= 63)
                            total = amount * 981.01;
                        if (amount > 63)
                            total = amount * 935.95;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1732.59;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1174.98;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1070.44;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1048.80;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1039.35;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1031.50;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1028.04;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1027.32;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1024.11;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1019.35;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1015.62;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1011.61;
                        if (amount > 63)
                            total = amount * 966.55;
                    }
                    break;
                case "RWE GasNet":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1650.23;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1172.66;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1077.56;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1070.06;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1064.82;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1059.90;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1059.66;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1057.34;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1053.86;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1051.72;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1050.90;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1049.20;
                        if (amount > 63)
                            total = amount * 1004.20;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1680.83;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1203.26;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1108.16;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1100.66;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1095.42;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1090.50;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1090.26;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1087.94;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1084.46;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1082.32;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1081.50;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1079.80;
                        if (amount > 63)
                            total = amount * 1035.15;
                    }
                    break;
                case "Pražská plynárenská Distribuce":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1553.75;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1036.26;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 958.63;
                        if (amount > 15 && amount <= 20)
                            total = amount * 953.97;
                        if (amount > 20 && amount <= 25)
                            total = amount * 951.17;
                        if (amount > 25 && amount <= 30)
                            total = amount * 946.42;
                        if (amount > 30 && amount <= 35)
                            total = amount * 942.83;
                        if (amount > 35 && amount <= 40)
                            total = amount * 940.26;
                        if (amount > 40 && amount <= 45)
                            total = amount * 939.27;
                        if (amount > 45 && amount <= 50)
                            total = amount * 936.98;
                        if (amount > 50 && amount <= 55)
                            total = amount * 935.50;
                        if (amount > 55 && amount <= 63)
                            total = amount * 931.01;
                        if (amount > 63)
                            total = amount * 895.22;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1584.35;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1066.86;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 989.23;
                        if (amount > 15 && amount <= 20)
                            total = amount * 984.57;
                        if (amount > 20 && amount <= 25)
                            total = amount * 981.77;
                        if (amount > 25 && amount <= 30)
                            total = amount * 977.02;
                        if (amount > 30 && amount <= 35)
                            total = amount * 973.43;
                        if (amount > 35 && amount <= 40)
                            total = amount * 970.86;
                        if (amount > 40 && amount <= 45)
                            total = amount * 969.87;
                        if (amount > 45 && amount <= 50)
                            total = amount * 967.58;
                        if (amount > 50 && amount <= 55)
                            total = amount * 966.10;
                        if (amount > 55 && amount <= 63)
                            total = amount * 961.61;
                        if (amount > 63)
                            total = amount * 925.82;
                    }
                    break;

                case "JMP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1595.36;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1126.93;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1046.00;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1040.16;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1037.87;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1033.07;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1031.39;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1029.84;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1029.04;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1027.88;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1025.74;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1024.47;
                        if (amount > 63)
                            total = amount * 983.51;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1625.96;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1157.53;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1076.60;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1070.76;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1068.47;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1063.67;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1061.99;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1060.44;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1059.64;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1058.48;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1056.34;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1055.07;
                        if (amount > 63)
                            total = amount * 1014.11;
                    }
                    break;
                case "VČP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1675.22;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1199.87;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1088.02;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1082.23;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1077.23;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1072.66;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1068.89;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1065.70;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1063.79;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1062.51;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1061.66;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1059.62;
                        if (amount > 63)
                            total = amount * 1010.97;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1705.82;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1230.47;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1118.62;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1112.83;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1107.83;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1103.26;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1099.49;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1096.30;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1094.39;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1093.11;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1092.26;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1090.22;
                        if (amount > 63)
                            total = amount * 1041.57;
                    }
                    break;
                case "SMP Net":
                    if (HomeCheck.is(":checked")) {
                        if (amount <= 1.89)
                            total = amount * 1650.16;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1176.35;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1084.91;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1073.02;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1067.38;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1062.28;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1061.74;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1060.72;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1058.78;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1057.44;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1055.92;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1053.16;
                        if (amount > 63)
                            total = amount * 1011.41;
                    }
                    else {
                        if (amount <= 1.89)
                            total = amount * 1680.76;
                        if (amount > 1.89 && amount <= 7.56)
                            total = amount * 1206.95;
                        if (amount > 7.56 && amount <= 15)
                            total = amount * 1115.51;
                        if (amount > 15 && amount <= 20)
                            total = amount * 1103.62;
                        if (amount > 20 && amount <= 25)
                            total = amount * 1097.98;
                        if (amount > 25 && amount <= 30)
                            total = amount * 1092.88;
                        if (amount > 30 && amount <= 35)
                            total = amount * 1092.34;
                        if (amount > 35 && amount <= 40)
                            total = amount * 1091.32;
                        if (amount > 40 && amount <= 45)
                            total = amount * 1089.38;
                        if (amount > 45 && amount <= 50)
                            total = amount * 1088.04;
                        if (amount > 50 && amount <= 55)
                            total = amount * 1086.52;
                        if (amount > 55 && amount <= 63)
                            total = amount * 1083.76;
                        if (amount > 63)
                            total = amount * 1042.01;
                    }
                    break;
                default:
                    success = false;
                    break;
            }
            if (success) {
                if (DepositMonthCheck.is(":checked")) {
                    total = parseInt(total / 12);
                }
                else if (DepositQuarterCheck.is(":checked")) {
                    total = parseInt(total / 4);
                }
                total = (Math.round(total / 100) * 100) + 100;
                if (UpdateOnlyIfLess == false) {
                    DepositAmount.val(total);
                }
                else if (UpdateOnlyIfLess == true && depositval < total)
                {
                    DepositAmount.val(total);
                }
            }
        }
    }

    function GetDistributorByEIC() {

        //var eic = $(this).val();
        var eic = $supplyPointEICText.val();
        if (eic.length == 16) {
            var prefix = eic.substring(0, 4),
                code = eic.substring(4, 5);
            
            if (prefix == "27ZG") {
                switch (code) {
                    case "1":
                        distributorName = "Pražská plynárenská Distribuce";
                        break;
                    case "2":
                    case "3":
                    case "4":
                        distributorName = "RWE GasNet";
                        break;
                    case "5":
                        distributorName = "VČP Net";
                        break;
                    case "6":
                        distributorName = "JMP Net";
                        break;
                    case "7":
                        distributorName = "SMP Net";
                        break;
                    case "9":
                        distributorName = "E.ON Distribuce";
                        break;
                    
                }
                var $container = $("#distributionAutocomplete");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];

                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        //On change amount 
                        OnChangeAmount();
                        
                    }
                });
            }
        }
    }

    function GetDistributorByEIC2() {

        //var eic = $(this).val();
        var eic = $supplyPointEICText2.val();

        if (eic.length == 16) {
            var prefix = eic.substring(0, 4),
                code = eic.substring(4, 5);             
            if (prefix == "27ZG") {
                switch (code) {
                    case "1":
                        distributorName = "Pražská plynárenská Distribuce";

                        break;
                    case "2":
                    case "3":
                    case "4":
                        distributorName = "RWE GasNet";
                        break;
                    case "5":
                        distributorName = "VČP Net";
                        break;
                    case "6":
                        distributorName = "JMP Net";
                        break;
                    case "7":
                        distributorName = "SMP Net";
                        break;
                    case "9":
                        distributorName = "E.ON Distribuce";
                        break;

                }
                var $container = $("#distributionAutocomplete2");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];

                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        //on change amount
                        OnChangeAmount2();
                    }
                });
            }
        }
    }
    
    function replacecount(elements)
    {
        $(elements).keyup(function ()
        { 
            this.value = this.value.replace(" ", "").replace(/\D/g, "");
            if (this.id == "companyIcoTxt") $(this).trigger("change");
        });
    }

    function replacecountwithline(elements) {
        $(elements).keyup(function () {
          
              this.value = this.value.replace(" ", "").replace(/[a-zA-Z]/g, "").replace(".", ",").replace(",,", ",");
            if (this.id == "companyIcoTxt") $(this).trigger("change");
    
        });
    }

  
   
});