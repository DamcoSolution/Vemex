﻿$(function () {

    var $bar = $(".bar"),
        $newslinks = $(".newsmiddlelinks a"),
        $slider = $(".slider"),
        $message = $(".message"),
        $loadingCircle = $(".loadingcircle"),
        $loading = $(".loadingholder"),
        $loginSubmit = $(".loginmiddle input[type=image]"),
        $date = $("input.born"),
        sliderStep = 611,
        preloadWidth = 90;

    $loadingCircle.center();

    if ($bar.length) 
        Logout.Preload(preloadWidth, 1800, 1, function (position) {
            if (position != 0)
                $bar.css({ "left": position + "px" });
            else
                Logout.Redirect("/vemex/odhlaseni");
        });

    if ($newslinks.length)
        $newslinks.click(function () {
            var $this = $(this);
            var index = $this.index();
            $newslinks.removeClass("active");
            $this.addClass("active");
            $slider.stop().animate({ "left": -(index * sliderStep) + "px" }, 400);
            return false;
        });

    if ($loginSubmit.length)
        $loginSubmit.click(function () {
            $loading.show();
        });

    if ($message.length)
        $message.center({ location: "top" }).delay(3000).animate({ "top": "0" }, 350).animate({ "top": -$loading.height() + "px" }, 250);

    if ($date.length)
    {
        $.datepicker.regional["cs"] = {
            closeText: "Zavřít",
            prevText: "Předchozí",
            nextText: "Další",
            currentText: "Dnes",
            monthNames: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září­", "Říjen", "Listopad", "Prosinec"],
            monthNamesShort: ["Led", "Úno", "Bře", "Dub", "Kvě", "Červ", "Červnc", "Srp", "Září", "Říj", "Lis", "Pro"],
            dayNames: ["Neděle", "Pondělí­", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"],
            dayNamesShort: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"],
            dayNamesMin: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"],
            weekHeader: "Sm",
            dateFormat: "dd.mm.yy",
            firstDay: 1,
            isRTL: false,
            showMonthAfterYear: false,
            yearSuffix: "",
            yearRange: "-80:+50"
        };

        $.datepicker.setDefaults($.datepicker.regional["cs"]);
        $date.datepicker({ dateFormat: "ddmmyy", changeMonth: true, changeYear: true });
    }

    $(document).bind("keydown", function (e) {
        if (e.keyCode == 13)
            return false;
    });

});

