﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using Web.Controls;

namespace VemexPortal_v2
{
    public partial class prihlaseni : PageControl
    {
        public int count = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (LoginControl.IsLogged() && LoginControl.Role != null)
                   // Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetPathUrl() + "/home");

                List<NewsControl> newsList = NewsControl.GetNews().OrderByDescending(n => n.createdon).Take(3).ToList();
                newsLinksRepeater.DataSource = newsContentRepeater.DataSource = newsList;
                newsLinksRepeater.DataBind();
                newsContentRepeater.DataBind();
            }
        }

        protected void loginSubmitBtn_Click(object sender, ImageClickEventArgs e)
        {
            string loginName = loginEmailTxt.Text.Trim();
            string loginPass = loginPasswordTxt.Text.Trim();

            if (loginName != "" && loginPass != "")
            {

                if (loginName.Length > 2)
                {
                    if (LoginControl.Login(loginName, loginPass))
                    {
                        //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                        Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                    }
                    else
                        new ErrorControl("Nesprávné jméno nebo heslo.");
                }
                else
                    new ErrorControl("Jméno musí mít alespoň 3 znaky.");
            }
            else
                new ErrorControl("Musíte vyplnit jméno a heslo.");

            Response.Redirect(UrlControl.GetSiteRootUrl() + "/prihlaseni");
        }
    }
}