﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VemexPortal_v2.App_Code;

namespace VemexPortal_v2.EntityObjects
{
    public class PortalRights
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Entity_Name Entity { get; set; }
        public string LinkPage { get; set; }
        public bool CanCreate { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
        public AccessLevel AccessLevel { get; set; }
    }
}