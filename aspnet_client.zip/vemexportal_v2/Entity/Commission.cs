﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk;

namespace VemexPortal_v2.EntityObjects
{
    public class Commission
    {
        public string Name { get; set; }
        public Contact Contact { get; set; }
        public ContractType ContractType { get; set; }
        public string EIC_EAN {get; set;}
        public Contact Rentier { get; set; }
        public string AccountName { get; set; }
        public string OpportunityName { get; set; }
        public string Reward { get; set; }
    }
}