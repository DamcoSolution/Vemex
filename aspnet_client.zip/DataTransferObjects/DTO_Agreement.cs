﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
  public  class DTO_Agreement
    {

      public DTO_VerifyForm VerifyForm { get; set; }
      public DTO_SupplyPoint SupplyPoint { get; set; }
    }
}
