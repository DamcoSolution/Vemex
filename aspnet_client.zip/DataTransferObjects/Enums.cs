﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{

    public enum ContractAgreement
    {

        electric = 171140000,
        gas = 171140001,
        both = 171140002
    }

    public enum ContractMode
    {
        person,
        company
    }

    public enum AccountRoleCode
    {
        AccountContact = 171140003,
        VerifyContact = 171140002,
    }

    public enum ContractPeriod
    {
        None = -1,
        OneYear = 171140000,
        TwoYear = 171140001,
        ThreeYear = 171140002,
        FiveYear = 171140003
    }

    public enum ContractType
    {
        Fixed,
        Infinite
    }

    public enum SupplyPointChange
    {
        None = -1,
        Provider = 171140000,
        Customer = 171140001,
        NewSubscription = 171140002,
        ProviderPrice = 171140003,
        Overwrite = 171140004
    }

    public enum SupplyPointDepositPeriod
    {
        None = -1,
        Monthly = 171140000,
        Quarterly = 171140001
    }
   
    public enum SupplyPointInvoiceDelivery
    {
        None = -1,
        Email = 171140000,
        Post = 171140001
    }
  

    /// <summary>
    /// Information Delivery
    /// </summary>
    public enum SupplyPointChangeDelivery
    {
        None = -1,
        Post = 171140000,
        Web = 171140001,
        Email = 171140002
    }

    public enum SupplyPointDepositPayment
    {
        None = -1,
        Transfer = 171140000,
        Collection = 171140001,
        Slip = 171140002,
        SIPO = 171140003,
    }
    
    public enum SupplyPointInvoicePayment
    {
        None = -1,
        Transfer = 171140000,
        Collection = 171140001,
        Slip = 171140002
    }

    public enum SupplyPointPhase
    {
        None = -1,
        One = 171140000,
        Three = 171140001
    }
}
