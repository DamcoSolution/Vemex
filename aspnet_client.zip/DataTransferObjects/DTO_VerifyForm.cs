﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
    public class DTO_VerifyForm
    {
        public Guid VerifyFormId { get; set; }
        public string LogicalName
        {
            get
            {
                return "cre_verifyform";
            }
        }

        public string TrustFirstTitle { get; set; }
        public string TrustFirstFirstName { get; set; }
        public string TrustFirstLastName { get; set; }


        public string TrustSecondTitle { get; set; }
        public string TrustSecondFirstName { get; set; }
        public string TrustSecondLastName { get; set; }


        public string CompanyDic { get; set; } 
        public string CompanyIco { get; set; }
        public string CompanyName { get; set; } 
        public string Dic { get; set; }
        public string Ico { get; set; }
        public string Email { get; set; }      
        public string FirstName { get; set; }
        public string LastName { get; set; }


        
        public DateTime Birthdate { get; set; }
        public string Phone { get; set; }
        public string RecordOR { get; set; }
        
        public string Street { get; set; }
        public string City { get; set; }
        public string Psc { get; set; }
        public string ShipStreet { get; set; }
        public string ShipCity { get; set; }
        public string ShipPsc { get; set; }
        public string ShipHouseNumber { get; set; }
        public string ShipOrientationNumber { get; set; }
       
        
        public string SupplyPointStreet { get; set; }
        public string SupplyPointCity { get; set; }
        public string SupplyPointPsc { get; set; }
        public string SupplyPointHouseNumber { get; set; }
        public string SupplyPointOrientationNumber { get; set; }
        public string HouseNumber { get; set; }
        public string OrientationNumber { get; set; }
        public string Name { get; set; }
        public string Ean { get; set; }
        public string Eic { get; set; }       
        public string DateTimeFromFirst { get; set; }
        public string DateTimeFromThird { get; set; }
        public string DateTimeToFirst { get; set; }
        public string ProductName { get; set; }
        public string BreakerValue { get; set; }
        public string BankNumberFirstPart { get; set; }
        public string BankNumberSecondPart { get; set; }
        public string BankCode { get; set; }
        public string SipoNumber { get; set; }
        public string AnnualConsumptionVT { get; set; }
        public string AnnualConsumptionNT { get; set; } 
        public string CustomerLogicalName { get; set; }
        public string ContractNumber { get; set; }
        public string SignatureDate { get; set; }
        
        public int TitulLast { get; set; }
        public int ContractTimeYears { get; set; } 
        public int Titul { get; set; }
      
        public SupplyPointChange ContractReason { get; set; }

        public int OriginalProvider { get; set; }
        public int DistributorGas { get; set; }
        public int DistributorElectricity { get; set; }
        public int AdvancePeriod { get; set; }
        public int AdvancePayment { get; set; }
        public int PaymentScheduleDelivery { get; set; }
        public int InformationDelivery { get; set; }
        public int PaymentTypeAdvances { get; set; }
        public int PaymentType { get; set; }
        public int ConnectionType { get; set; }
        public int DistributionRate { get; set; }       
        public int ResignationLength { get; set; }
        public int ContractTypeCode { get; set; }
        public bool ResignationUnit { get; set; } 
        public bool ContractTimeFirstCheck { get; set; }
        public bool ContractTimeSecondCheck { get; set; }
        public bool ContractTimeThirdCheck { get; set; }
        public bool CustomerResigned { get; set; }
        public bool SameTrustPerson { get; set; }
        
        public Guid CustomerId { get; set; }
        public Guid OpportunityId { get; set; }
        public Guid SupplyPointId { get; set; }
        public Guid TrustFirstId { get; set; }
        public Guid TrustSecondId { get; set; }
        public Guid LastTrustFirstId { get; set; }
        public Guid LastTrustSecondId { get; set; }
        public Guid SellerId { get; set; }
       
        
    }
}
