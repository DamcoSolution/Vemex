﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTransferObjects
{
   public static class Extension
    {
       public static int GetOptionSetValue(this Dictionary<string,int> dictionary, string key)
       {
           if (dictionary.ContainsKey(key)) return dictionary[key];
           else return -1;
       }

       public static DateTime Tommddyyyy(this string datetime)
       {
           try
           {
               DateTime date = new DateTime(Convert.ToInt32(datetime.Substring(4,4)), Convert.ToInt32(datetime.Substring(2,2)), Convert.ToInt32(datetime.Substring(0,2)));
               return date;
           }
           catch {
               throw;
           }
       }
    }
}
