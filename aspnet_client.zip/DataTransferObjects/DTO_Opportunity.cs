﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
    public class DTO_Opportunity
    {

        public Guid OpportunityId { get; set; }
        public String LogicalName {
            get
            {
                return "opportunity";
            }
        }

        /// <summary>
        /// ContractNumber
        /// </summary>
        public int OpportunityNumber { get; set; }

        public int ContractTypeCode { get; set; }
        public int ContractTimeYears { get; set; }
        public string ContractNumber { get; set; }
        public string SellerNumberID { get; set; }
        public string SellerFirstName { get; set; }
        public string SellerLastName { get; set; }
        public string SignatureDate { get; set; }
        public string DateTimeFromFirst { get; set; }
        public string DateTimeToFirst { get; set; }
        public string ProductName { get; set; }
        public string DateTimeFromThird { get; set; }
        public string CustomerLogicalName { get; set; }
        public bool Closedinspaces { get; set; }
        public bool ContractTimeFirstCheck { get; set; }
        public bool ContractTimeSecondCheck { get; set; }
        public bool ContractTimeThirdCheck { get; set; }
        public bool CustomerResigned { get; set; }
        public bool GenerateId { get; set; }
        public Guid SellerId { get; set; }
        public Guid CustomerId { get; set; }

    }
}
