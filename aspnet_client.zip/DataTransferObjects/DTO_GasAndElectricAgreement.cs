﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
    public class DTO_GasAndElectricAgreement
    {
        //Enums
        public ContractAgreement ContractAgreement { get; set; }
        public ContractMode ContractMode { get; set; }

        public ContractType ContractType { get; set; }

        //Proposed Number
        public string OpportunityNumber { get; set; }


        public bool GenerateId { get; set; }
        public KeyValuePair<int, string> TitleFirst { get; set; }
        public KeyValuePair<int, string> TitleLast { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        
        public string ICO { get; set; }
        public string DIC { get; set; }
        public string CompanyName { get; set; }
        public string CompanyIco { get; set; }
        public string CompanyDic { get; set; }
        public string Email { get; set; }
        public string Telephone { get; set; }


        // silo trvale bydliste
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string OrientationNumber { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string WrittingOR { get; set; }
        
        // korespondencni adresa
        public string PostalStreet { get; set; }
        public string PostalHouseNumber { get; set; }
        public string PostalOrientationNumber { get; set; }
        public string PostalPostalCode { get; set; }
        public string PostalCountry { get; set; }

        //SupplyPointName
        public string SupplyPointName { get; set; }


        



        public DateTime SignatureDate { get; set; }
        public DTO_Contact Seller { get; set; }

        public string ProductName { get; set; }
        public DateTime ContractTimeFrom { get; set; }
        public DateTime ContractTimeTo { get; set; }
        public DateTime InfiniteContractStartTime { get; set; }
        public ContractPeriod ContractPeriod { get; set; }

        public bool Closedinspaces { get; set; }
        public bool CustomerResigned { get; set; }
        public int NoticePeriod { get; set; }
        public bool ResignationUnit { get; set; }


        public string Trust1_Title { get; set; }
        public string Trust1_FirstName { get; set; }
        public string Trust1_LastName { get; set; }

        public string Trust2_Title { get; set; }
        public string Trust2_FirstName { get; set; }
        public string Trust2_LastName { get; set; }

        //Lists
        public List<DTO_Agreement> Agreement { get; set; }
        


        //DTO 
        public DTO_Company Company { get; set; }
        public DTO_Person Person { get; set; }

        public DTO_Opportunity Opportunity { get; set; }
        
        public DTO_CustomerAddress CustomerAddress { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public DTO_GasAndElectricAgreement()
        {

        }

        public void FinalIniliazation() { 
        }
    }
}
