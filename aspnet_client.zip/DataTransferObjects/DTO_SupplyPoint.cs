﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
    public class DTO_SupplyPoint
    {
        
        public Guid SupplyPointId { get; set; }

        public String LogicalName
        {
            get
            {
                return "cre_supplypoint";
            }
        }
        
        public string Name { get; set; }
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string OrientationNumber { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string Ean { get; set; }
        public string Eic { get; set; }

        public string AnnualConsumptionVT { get; set; }
        public string AnnualConsumptionNT { get; set; }
        public string SupplyPointYearSubscriptionAmount { get; set; }

        public string PointBankNumber_First { get; set; }
        public string BankNumber_Second { get; set; }
        public string BankNumberCode { get; set; }
        public string SIPONumber { get; set; }
        public int SupplyPointBrokerAmount { get; set; }
        public SupplyPointChange SupplyPointChange { get; set; }
        public int SupplyPointLastProvider { get; set; }
        public int SupplyPointNewDistribution { get; set; }
        public int DistributionAmount { get; set; }
        public SupplyPointDepositPeriod SupplyPointDepositPeriod { get; set; }
        public int DepositAmount { get; set; }
        public SupplyPointInvoiceDelivery SupplyPointInvoiceDelivery { get; set; }
        public SupplyPointChangeDelivery SupplyPointChangeDelivery { get; set; }
        public SupplyPointDepositPayment SupplyPointDepositPaymentType { get; set; }
        public SupplyPointInvoicePayment SupplyPointInvoicePaymentType { get; set; }
        public SupplyPointPhase SupplyPointConnectionType { get; set; }
        
        public ContractAgreement ConnectionType { get; set; }

        //To be commented
        public Guid CustomerId { get; set; }
        public Guid OpportunityId { get; set; }

    }
}
