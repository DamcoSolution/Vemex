﻿$(function () {

    // variables
    var $win = $(window);
    var $login = $(".login");
    var $case = $(".case .holder");
    var $body = $("body");
    var $error = $(".error");
    var $message = $(".message");
    var $loginSubmit = $(".login input[type=image]");
    var $caseSubmit = $(".case input[type=image]");
    var $boxCheckbox = $(".box input[type=checkbox]");
    var $loading = $("<div class=\"loading\"><img src=\"img/loading.gif\" height=\"30\" width=\"30\" /></div>");
    var success = false;
    var loginArr = {
        "#loginEmail input": {
            "type": "email",
            "message": "Musíte vyplnit správný email."
        },
        "#loginID input": {
            "type": "supportid",
            "message": "Musíte vyplnit ID společnosti."
        }
    };
    var formArr = {
        "#productBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Problémový produkt."
        },
        "#limitBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Omezení."
        },
        "#solutionBox input": {
            "type": "checklist",
            "message": "Musíte vybrat Návrh řešení."
        },
        "#phone input": {
            "type": "phone",
            "message": "Musíte vyplnit Kontaktní telefon."
        }
    };

    // functions
    CenterLogin = function () {
        $login.center();
        $error.center();
    };

    ShowLoading = function () {
        $body.append($loading);
        $loading.find("img").center()
    };

    DisableSubmit = function ($submit) {
        $submit.css({ "opacity": ".45" });
    };

    // actions
    $win.resize(function () {
        CenterLogin();
    });

    $loginSubmit.click(function () {
        success = Form.Validate(loginArr, function (message) {
            $login.append($message);
            $message.text(message);
        });
        if (success) {
            ShowLoading();
            DisableSubmit($loginSubmit);
        }
        return success;
    });

    $caseSubmit.click(function () {
        success = Form.Validate(formArr, function (message) {
            $case.append($message);
            $message.text(message);
        });
        if (success) {
            ShowLoading();
            DisableSubmit($caseSubmit);
        }
        return success;
    });

    $boxCheckbox.change(function () {
        Form.CheckboxList($(this), $(this).parent().parent());
    });

    // ready
    CenterLogin();
    $error.center().delay(2500).fadeOut(400);

});