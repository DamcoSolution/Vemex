﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelpDesk
{
    public class Constants
    {
        
        //Commission Entity
        public const string ComminssionOwner = "cre_rentier";
        public const string CommissionAccount = "cre_account";
        public const string CommissionOpportunity = "cre_opportunity";
        

        
        public const string StateCode = "statecode";
        public const string AccountId = "accountid";
        
        public const string OpportunityId = "opportunityid";
        
        
        public const string CreName = "cre_name";
        public const string Name = "name";
        public const string Partner = "partner";

        //Entity
        public const string VerifyForm = "cre_verifyform";
        public const string Contact = "contact";
        public const string Account = "account";
        public const string Commission = "cre_commission";
        public const string Opportunity = "opportunity";
        public const string PortalRole = "cre_portlrole";
        public const string PortalRights = "cre_portlprva";
        public const string PortalFieldRight = "cre_portalfieldright";

        //VerifyForm Fields
        public const string VerifyFormOwner = "cre_contact";
        public const string VerifyFormEIC = "cre_eic";
        public const string VerifyFormEAN = "cre_eanopm";
        public const string VerifyFormStatus = "cre_status";
        public const string VerifyFormAcceptedOn = "cre_aceptedon";

        //Contact Entity Fields
        public const string ContactId = "contactid";
        public const string ContactTitle = "cre_titulpred";
        public const string ContactTitleLast = "cre_titulza";
        public const string ContactPassword = "cre_password";
        public const string ContactLogin = "cre_login";
        public const string ContactLastLogin = "cre_lastlogin";
        public const string ContactMobile = "mobilephone";
        public const string ContactLastName = "lastname";
        public const string ContactFirstName = "firstname";
        public const string ContactEmail = "emailaddress1";
        public const string ContactFullName = "fullname";
        public const string ContactBirthDate = "birthdate";
        public const string ContactAccountRole = "accountrolecode";
        public const string ContactParentCustomerId = "parentcustomerid";
        public const string ContactOwner = "cre_owner";
        

        public const int AccountRoleId  = 171140000;
        public const int AuctionRoleId = 171140001;

        //PortalRight Entity Fields
        public const string PortalRightId = "cre_portlprvaid";
        public const string PortalRightAccessLevel = "cre_pstupovrove";
        public const string PortalRightEntityName = "cre_nzevsubjektu";
        

        //PortalRole Entity Fields
        public const string PortalRoleId = "cre_portlroleid";
        public const string PortalRoleRightRelation = "cre_cre_portlprva_cre_portlrole";

        //Account Entity Fields
        public const string AccountRoleCode = "cre_accountrolecode";
        public const string AccountPrefix = "cre_prefix";
        public const string AccountLastPortalUserId = "cre_last_id_contact";

        //PortalFieldRight
       public const string PortalFielRightShow = "cre_show";
       public const string PortalField_PortalRight = "cre_portalright";
       public const string PortalFieldOtherField = "cre_otherfield";

    }
}