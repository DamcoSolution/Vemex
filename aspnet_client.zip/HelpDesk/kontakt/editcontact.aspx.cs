﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;

namespace HelpDesk.contact
{
    public partial class editcontact : PageControl
    {
      List<Account> AccountList;
      protected  Guid EntityId
        {
            get
            {
                Guid id = Guid.Empty;
                Guid.TryParse(Request.QueryString["id"], out id);
                return id;
            }            
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ApplyRights();
               FillData();
            }

        }

        private void FillData()
        {
            //TODO: to set value of fields
            Contact entity = new ContactControl().GetContactById(EntityId);
            firstNameTxt.Text = entity.FirstName;
            lastNameTxt.Text = entity.LastName;
            txtEmail.Text = entity.Email;
            txtPhone.Text = entity.Phone;
            UserIdTxt.Text = entity.UserId;
            passwordTxt.Text = entity.Password;
          
            hdnContactId.Value = EntityId.ToString();
            if (ddlAccount.Items != null)
            {
                ListItem item = ddlAccount.Items.FindByValue(Convert.ToString(entity.ParentCustomer.Value));
                if (item != null) item.Selected = true;
            }

            //Date of Birth
            if (entity.DateofBirth != DateTime.Today)
            {
                string birthdate = Convert.ToString(entity.DateofBirth.Day) + Convert.ToString(entity.DateofBirth.Month) + Convert.ToString(entity.DateofBirth.Year);
                birthdateTxt.Text = birthdate;
            }
        }

        private void ApplyRights()
        {
            bool canEdit = false;
            //LoginControl currentuser = LoginControl.LoggedUser();
            

            if (EntityId != Guid.Empty)
            {
                canEdit = HelpDesk.Controls.PortalRole.CanEdit(EntityId, Entity_Name.kontakt);
            }

            if (!canEdit)
            {
                new ErrorControl("You don't have right to view contact ");
                //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }


            PortalRights rights = PortalRole.GetRights(Entity_Name.kontakt).FirstOrDefault();


            List<PortalRole> Roles = PortalRole.GetAllRoles();

            //AccountList = new AccountControl().GetAllAccount();
            //ddlAccount.DataSource = AccountList;
            //ddlAccount.DataBind();


         //   if (item != null) item.Selected = true;

            Roles = Roles.Where(lst => lst.Rights.Where(ls => (int)ls.AccessLevel <= (int)rights.AccessLevel).FirstOrDefault() != null).ToList();

            ddlRole.DataSource = Roles;
            ddlRole.DataBind();
            ddlAccount.Enabled = false;
        }
        
        protected void UpdateContactBtn_Click(object sender, EventArgs e)
        {
            DateTime? date = null;
            if (birthdateTxt.Text.Trim() != "" && birthdateTxt.Text.Trim().Length == 8)
            {
                int day = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(0, 2));
                int month = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(2, 2));
                int year = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(4, 4));
                date = new DateTime(year, month, day);
            }

            Guid contactid = CustomerControl.CreateUpdateContact(firstNameTxt.Text.Trim(), lastNameTxt.Text.Trim(), txtEmail.Text.Trim(),
                txtPhone.Text.Trim(), date, UserIdTxt.Text.Trim(), passwordTxt.Text.Trim(), EntityId, new Guid(), new Guid(), Constants.AccountRoleId);

            Response.Redirect(UrlControl.GetPathUrl() + "/viewcontact", false);
            // add message to log file
            // HelpControl.AddToLog("Kontakt \"" + firstNameTxt.Text + " " + lastNameTxt.Text + "\" nenalezen. Vytvořen nový: " + contactid);
        }

        [WebMethod]
        public static bool IsUserExists(string user, string entityId)
        {
            Guid entity = new Guid(entityId);
            return ContactControl.IsUserExists(user, ServiceControl.GetService(), entity);
        }
    }
}