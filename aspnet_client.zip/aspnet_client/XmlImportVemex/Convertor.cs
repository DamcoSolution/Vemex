﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
   public  class Convertor
    {

       public  Dictionary<string, int> Dictionar_titulpred;
       public Dictionary<string, int> Dictionar_titulza;
       public Dictionary<string, int> Dictionar_informationdelivery;
       public Dictionary<string, int> Dictionar_sex;
       public Dictionary<string, int> Dictionar_distributorelectricity;
       public Dictionary<string, int> Dictionar_originaldistributor;
       public Dictionary<string, int> Dictionar_paymenttype;
       public Dictionary<string, int> Dictionar_paymenttypeadvances;
       public Dictionary<string, int> Dictionar_connectiontype;
       public Dictionary<string, int> Dictionar_paymentscheduledelivery;
       public Dictionary<string, int> Dictionar_advanceperiod;
       public Dictionary<string, int> Dictionar_distributorgas;
       public Dictionary<string, int> Dictionar_fixedtermcontractyears;
       public Dictionary<string, int> Dictionar_distributionrate;
       public Dictionary<string, int> Dictionar_contractreason;

       public bool InitiliazationSuccess;

       bool UpdateOptionSets()
        {

           this.Dictionar_titulpred = OptionSets.GetSelectOptions("cre_verifyform", "cre_titulpred");

           this.Dictionar_titulza = OptionSets.GetSelectOptions("cre_verifyform", "cre_titulza");
           this.Dictionar_informationdelivery = OptionSets.GetSelectOptions("cre_supplypoint", "cre_informationdelivery");
           this.Dictionar_sex = OptionSets.GetSelectOptions("cre_verifyform", "cre_gendersperson");
           this.Dictionar_distributorelectricity = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributorelectricity");
           this.Dictionar_originaldistributor = OptionSets.GetSelectOptions("cre_supplypoint", "cre_originaldistributor");
           this.Dictionar_paymenttype = OptionSets.GetSelectOptions("cre_supplypoint", "cre_paymenttype");
           this.Dictionar_paymenttypeadvances = OptionSets.GetSelectOptions("cre_supplypoint", "cre_paymenttypeadvances");
           this.Dictionar_connectiontype = OptionSets.GetSelectOptions("cre_supplypoint", "cre_connectiontype");
           this.Dictionar_paymentscheduledelivery = OptionSets.GetSelectOptions("cre_verifyform", "cre_paymentscheduledelivery");
           this.Dictionar_advanceperiod = OptionSets.GetSelectOptions("cre_supplypoint", "cre_advanceperiod");
           this.Dictionar_distributorgas = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributorgas");
           this.Dictionar_fixedtermcontractyears = OptionSets.GetSelectOptions("opportunity", "cre_fixedtermcontractyears");
           this.Dictionar_distributionrate = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributionrate");
           this.Dictionar_contractreason = OptionSets.GetSelectOptions("cre_supplypoint", "cre_contractreason");

           if (null == this.Dictionar_titulpred) return false;
           if (null == this.Dictionar_titulza) return false;
           if (null == this.Dictionar_informationdelivery) return false;
           if (null == this.Dictionar_sex) return false;
           if (null == this.Dictionar_distributorelectricity) return false;
           if (null == this.Dictionar_originaldistributor) return false;
           if (null == this.Dictionar_paymenttype) return false;
           if (null == this.Dictionar_paymenttypeadvances) return false;
           if (null == this.Dictionar_connectiontype) return false;
           if (null == this.Dictionar_paymentscheduledelivery) return false;
           if (null == this.Dictionar_advanceperiod) return false;
           if (null == this.Dictionar_distributorgas) return false;
           if (null == this.Dictionar_fixedtermcontractyears) return false;
           if (null == this.Dictionar_distributionrate) return false;
           if (null == this.Dictionar_contractreason) return false;
            
            return true;
        }

        public Convertor()
        {
           this.InitiliazationSuccess = UpdateOptionSets();
        }

        public static int contractoptions(string value)
        {

                 if (value == "Určitou") return enums.contractoptions.Urcitou.GetHashCode();
            else if (value == "Určitou roky") return enums.contractoptions.Urcitou_roky.GetHashCode();
            else if (value == "Neurčitou") return enums.contractoptions.Neurcitou.GetHashCode();
            else return enums.contractoptions.Default.GetHashCode();
        }

    }
}




