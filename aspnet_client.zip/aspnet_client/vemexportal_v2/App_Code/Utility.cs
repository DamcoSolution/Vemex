﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace VemexPortal_v2.App_Code
{
   
    public enum AccessLevel
    {
        kontakt=171140000,
        account = 171140001,
        organizace=171140002
    }

    public static class Utility
    {
        public static string getOptionSetText(string entityName, string attributeName, int optionsetValue, IOrganizationService OrganizationService)
        {
            string optionsetText = string.Empty;
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest();
            retrieveAttributeRequest.EntityLogicalName = entityName;
            retrieveAttributeRequest.LogicalName = attributeName;
            retrieveAttributeRequest.RetrieveAsIfPublished = true;

            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)OrganizationService.Execute(retrieveAttributeRequest);
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata picklistAttributeMetadata =
              (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;

            OptionSetMetadata optionsetMetadata = picklistAttributeMetadata.OptionSet;

            foreach (OptionMetadata optionMetadata in optionsetMetadata.Options)
            {
                if (optionMetadata.Value == optionsetValue)
                {
                    optionsetText = optionMetadata.Label.UserLocalizedLabel.Label;
                    return optionsetText;
                }

            }
            return optionsetText;
        }

        public static OptionSetMetadata GetOptionSet(string entityName, string attributeName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest();
            retrieveAttributeRequest.EntityLogicalName = entityName;
            retrieveAttributeRequest.LogicalName = attributeName;
            retrieveAttributeRequest.RetrieveAsIfPublished = true;

            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata picklistAttributeMetadata =
              (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;

            OptionSetMetadata optionsetMetadata = picklistAttributeMetadata.OptionSet;
            return optionsetMetadata;
        }


        public static Guid CurrentLinkID
        {
            get
            {
                Guid linkid = Guid.Empty;
                if (HttpContext.Current.Session["LinkId"] != null)
                {   
                    Guid.TryParse(Convert.ToString(HttpContext.Current.Session["LinkId"]), out linkid);
                }
                return linkid;
            }
            set
            {
                HttpContext.Current.Session["LinkId"] = value;
            }
        }
    }
}