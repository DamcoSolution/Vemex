﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.Controls;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2
{
    public partial class LogedIn : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {


                //TODO : Bind Menu from CRM
            if(LoginControl.IsLogged())
            {
                PortalRole role = LoginControl.Role;
                
                if (role != null)
                {
                    rptrMenu.DataSource = role.Rights;
                    rptrMenu.DataBind();
                }

            }

        }

        protected void logoutSubmitBtn_Click(object sender, ImageClickEventArgs e)
        {
            LoginControl.Logout();
            Response.Redirect(UrlControl.GetSiteRootUrl());
        }

        protected void rptrMenu_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PortalRights dataitem =  e.Item.DataItem as PortalRights;
                if (dataitem != null)
                {
                    StringBuilder html = new StringBuilder();
                    html.Append("<input type='hidden' id='hdnId' value= '" + dataitem.Id + "' />");

                    html.Append("<input type='hidden' id='hdnurl' value= '" + VemexPortal.Controls.UrlControl.GetSiteRootUrl() + dataitem.LinkPage + "' />");
                    
                    html.Append("<a href='#' title = '" + dataitem.Name + "'>");
                    
                    if (dataitem.Id == Utility.CurrentLinkID)
                    {
                        html.Append("<span class='menulinkleft'></span>");
                        html.Append("<span class='menulinkmiddle'>" + dataitem.Name + "</span>");
                        html.Append("<span class='menulinkright'></span>");
                    }

                    else
                    {
                        html.Append("<span class='menulinkleftwithoutbg'></span>");
                        html.Append("<span class='menulinkmiddlewithoutbg'>" + dataitem.Name + "</span>");
                        html.Append("<span class='menulinkrightwithoutbg'></span>  </a>");
                    }
                    HtmlGenericControl div = e.Item.FindControl("divItem") as HtmlGenericControl;
                    if (div != null)
                    {
                        div.InnerHtml = html.ToString();
                    }
                }
            }

            
        }
    }
}