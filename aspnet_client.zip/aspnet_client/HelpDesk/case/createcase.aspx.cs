﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;

namespace HelpDesk.ServiceCase
{
	public partial class createcase : PageControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                ApplyRights();
            }

		}


        /// <summary>
        /// Authorization check
        /// </summary>
        private void ApplyRights()
        {
            var currentuser = LoginControl.GetUser();

            bool canCreate = HelpDesk.Controls.PortalRole.CanCreate(Entity_Name.Case.ToString());
            if (!canCreate)
            {
                //new ErrorControl("You don't have right to create contact ");
                //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }
        }
	}
}