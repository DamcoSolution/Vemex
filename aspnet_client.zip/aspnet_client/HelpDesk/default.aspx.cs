﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;
using CreativeMages.Xrm;

namespace HelpDesk
{
    public partial class _default : PageControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var xrm = new XrmContext(ServiceControl.GetService());

                //grab all contacts where the email address ends in @example.com
                var exampleContacts = xrm.BusinessUnitSet.ToList();

                if (LoginControl.IsLogged() && LoginControl.Role != null)
                {
                    Response.Redirect(UrlControl.GetPathUrl() + "/home");


                }
            }
        }
    }
}