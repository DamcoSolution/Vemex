﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web.Controls
{
    public class PriceLevelControl
    {
        public Guid id { get; set; }
        public string name { get; set; }
    }
}