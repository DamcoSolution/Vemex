﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Web.Controls;

namespace CreateProductsToPriceList
{
    public partial class uploadexcel : System.Web.UI.Page
    {
        public OleDbConnection oledbConn;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<PriceLevelControl> priceLevelList = new List<PriceLevelControl>();
                EntityCollection priceLists = Service.RetrieveMultiple("pricelevel", null, new ColumnSet(true), ServiceControl.GetService());

                foreach (Entity priceList in priceLists.Entities)
                    priceLevelList.Add(new PriceLevelControl { id = priceList.Id, name = priceList["name"].ToString() });

                checkListPriceLevel.DataSource = priceLevelList;
                checkListPriceLevel.DataTextField = "name";
                checkListPriceLevel.DataValueField = "id";
                checkListPriceLevel.DataBind();
            }
        }

        protected void createBtn_Click(object sender, EventArgs e)
        {
            if (fileUpload.HasFile && checkListPriceLevel.SelectedIndex > -1)
            {
                try
                {
                    DateTime start = DateTime.Now;

                    string fileExtension = Path.GetExtension(fileUpload.PostedFile.FileName);
                    fileUpload.SaveAs(Server.MapPath("~/") + "Excel" + fileExtension);
                    string path = System.IO.Path.GetFullPath(Server.MapPath("Excel" + fileExtension));

                  oledbConn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");

                //  oledbConn = new OleDbConnection(@"Provider=ADsDSOObject;Data Source=" + path+";");
                   //   oledbConn = new OleDbConnection(@"ProviderMicrosoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;';");
                    

                   // Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\MyExcel.xls;Extended Properties="Excel 8.0;HDR=Yes;IMEX=1";
                    oledbConn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    OleDbDataAdapter oleda = new OleDbDataAdapter();
                    DataSet ds = new DataSet();

                    cmd.Connection = oledbConn;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM [Sheet1$]";
                    oleda = new OleDbDataAdapter(cmd);
                    oleda.Fill(ds);

                    Entity subject = Service.RetrieveMultiple("subject", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();
                    Entity uomschedule = Service.RetrieveMultiple("uomschedule", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();
                    Entity uom = Service.RetrieveMultiple("uom", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();
                    Guid priceLevelId = new Guid(checkListPriceLevel.SelectedValue);

                    //  Create query using querybyattribute
                    QueryByAttribute productPricelist = new QueryByAttribute()
                    {
                        EntityName = "productpricelevel",
                        ColumnSet = new ColumnSet("productid", "pricelevelid", "uomid", "amount"),
                        Attributes = {"pricelevelid", "uomid" },
                        Values = { priceLevelId, uom.Id }
                    };
                    EntityCollection ProductPrice = ServiceControl.GetService().RetrieveMultiple(productPricelist);
                    int number = 0;

                    FilterExpression filter = new FilterExpression();
                    filter.AddCondition("cre_name", ConditionOperator.Equal, "Prod_Num");
                    filter.FilterOperator = LogicalOperator.And;


                    ColumnSet prodColSet = new ColumnSet("productid", "defaultuomid", "name");

                    FilterExpression Productfilter = new FilterExpression();
                    Productfilter.AddCondition("statecode", ConditionOperator.Equal, 0);
                    EntityCollection ProductEntityCol = Service.RetrieveMultiple("product", Productfilter, prodColSet, ServiceControl.GetService());


                    EntityCollection entitylist = Service.RetrieveMultiple("cre_configuration", filter, new ColumnSet(true), ServiceControl.GetService());

                    foreach (Entity entity in entitylist.Entities)
                    {
                        if(entity.Attributes.Contains("cre_lastcontractid"))
                            int.TryParse(Convert.ToString(entity["cre_lastcontractid"]), out number);
                    }
                    bool isproductAdded = false;    
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        if (row["Amount"] != DBNull.Value)
                        {
                            isproductAdded = false; 
                            number += 1;
                            try
                            {
                                decimal price = Convert.ToDecimal(row["Amount"].ToString());
                                //number = Convert.ToInt32(row["ProductNumber"].ToString());

                                string contractType = row["ContractType"].ToString();
                                string customerType = row["CustomerType"].ToString();
                                string distributionAmount = row["DistributionAmount"].ToString();
                                string distribution = row["Distribution"].ToString();
                                string tarifs = row["Tarif"].ToString();
                                string breakerNumber = row["BreakerNumber"].ToString();
                                string breakerF = row["BreakerFrom"].ToString() != string.Empty ? "_" + row["BreakerFrom"].ToString() : string.Empty;
                                string breakerT = row["BreakerTo"].ToString() != string.Empty ? "_" + row["BreakerTo"].ToString() : string.Empty;
                                string name = string.Empty;

                                if (customerType == string.Empty)
                                    name = contractType + "_" + distributionAmount + "_" + distribution + "_" + tarifs;
                                else if (tarifs != string.Empty)
                                    name = contractType + "_" + customerType + "_" + distributionAmount + "_" + distribution + "_" + tarifs;
                                else if (breakerNumber != string.Empty)
                                    name = contractType + "_" + customerType + "_" + distributionAmount + "_" + distribution + "_J_" + breakerNumber + breakerF + breakerT;
                                else
                                    name = contractType + "_" + customerType + "_" + distributionAmount + "_" + distribution;


                                //To Get if product already exists
                                Guid productId = Guid.Empty;
                                Entity product;

                                /*
                                //  Create query using querybyattribute
                                QueryByAttribute querybyexpression = new QueryByAttribute()
                                {
                                    EntityName = "product",
                                    ColumnSet = new ColumnSet(true),
                                    Attributes = { "name" },
                                    Values = { name }
                                };


                                EntityCollection EntityCol = ServiceControl.GetService().RetrieveMultiple(querybyexpression);
                                 */

                                product = ProductEntityCol.Entities.Where(lst => Convert.ToString(lst["name"]) == name).FirstOrDefault();

                                if (product != null)
                                {                                    
                                    productId = product.Id;
                                }
                                else
                                {
                                    product = new Entity("product");
                                    product["productnumber"] = number.ToString();
                                    product["name"] = name;
                                    product["subjectid"] = new EntityReference { Id = subject.Id, LogicalName = subject.LogicalName };
                                    product["defaultuomscheduleid"] = new EntityReference { Id = uomschedule.Id, LogicalName = uomschedule.LogicalName };
                                    product["defaultuomid"] = new EntityReference { Id = uom.Id, LogicalName = uom.LogicalName };
                                    product["quantityonhand"] = Convert.ToDecimal("0");
                                    product["quantitydecimal"] = 0;
                                    product["producttypecode"] = new OptionSetValue(5);
                                    productId = Service.Create(product, ServiceControl.GetService());

                                    isproductAdded = true;
                                    //ProductEntityCol = Service.RetrieveMultiple("product", Productfilter, prodColSet, ServiceControl.GetService());
                                }


                                Entity productPriceLevel = null;

                                if (ProductPrice != null && ProductPrice.Entities.Count() > 0)
                                {
                                    productPriceLevel = ProductPrice.Entities.Where(lst => lst.GetAttributeValue<EntityReference>("productid").Id == productId).FirstOrDefault();
                                }
                                if (productPriceLevel != null)
                                {

                                    if (((Money)productPriceLevel["amount"]).Value != price)
                                    {
                                        productPriceLevel["amount"] = new Money(price);
                                        Service.Update(productPriceLevel, ServiceControl.GetService());
                                        
                                        number -= 1;
                                        isproductAdded = true;
                                    }
                                }
                                else
                                {
                                    productPriceLevel = new Entity("productpricelevel");
                                    productPriceLevel["productid"] = new EntityReference { Id = productId, LogicalName = "product" };
                                    productPriceLevel["pricelevelid"] = new EntityReference { Id = priceLevelId, LogicalName = "pricelevel" };
                                    productPriceLevel["uomid"] = new EntityReference { Id = ((EntityReference)product["defaultuomid"]).Id, LogicalName = "uom" };
                                    productPriceLevel["amount"] = new Money(price);
                                    Service.Create(productPriceLevel, ServiceControl.GetService());
                                }                                
                                if(!isproductAdded)
                                {
                                    number -= 1;
                                    isproductAdded = true;
                                }
                            }
                            catch (Exception ex)
                            {
                                //update portal number;
                                 entitylist = Service.RetrieveMultiple("cre_configuration", filter, new ColumnSet(true), ServiceControl.GetService());

                                if(entitylist.Entities.Count ==1)
                                {
                                    Entity entity = entitylist.Entities[0];
                                    if (isproductAdded == true)
                                    {
                                        entity["cre_lastcontractid"] = Convert.ToString(number - 1);
                                    }
                                    else
                                    {
                                        entity["cre_lastcontractid"] = Convert.ToString(number);
                                    }
                                    ServiceControl.GetService().Update(entity);
                                }
                            }

                        }

                        TimeSpan end = DateTime.Now.Subtract(start);

                        new ErrorControl("Ze souboru <strong>" + fileUpload.PostedFile.FileName + "</strong> bylo vytvořeno <strong>" + ds.Tables[0].Rows.Count + " produktů</strong> a přidáno do ceníku <strong>" + checkListPriceLevel.SelectedItem.Text + "</strong> za " + end.TotalSeconds + " sekund.");
                    }

                    entitylist = Service.RetrieveMultiple("cre_configuration", filter, new ColumnSet(true), ServiceControl.GetService());

                    if (entitylist.Entities.Count == 1)
                    {
                        Entity entity = entitylist.Entities[0];
                        
                        if (isproductAdded == true)
                        {
                            if (Convert.ToString(entity["cre_lastcontractid"]) != Convert.ToString(number))
                            {
                                
                                entity["cre_lastcontractid"] = Convert.ToString(number);
                                ServiceControl.GetService().Update(entity);
                            }
                        }
                        else
                        {
                            if (Convert.ToString(entity["cre_lastcontractid"]) != Convert.ToString(number - 1))
                            {
                                entity["cre_lastcontractid"] = Convert.ToString(number - 1);
                                ServiceControl.GetService().Update(entity);
                            }
                            
                        }
                        
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Chyba: " + ex.Message);
                }
                finally
                {
                    oledbConn.Close();
                }
            }
            else
                new ErrorControl("Musíte vybrat soubor a ceník.");
        }
    }
}