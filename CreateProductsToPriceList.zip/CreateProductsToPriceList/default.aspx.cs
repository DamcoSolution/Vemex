﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using Web.Controls;

namespace CreateProductsToPriceList
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {

                List<PriceLevelControl> priceLevelList = new List<PriceLevelControl>();
                EntityCollection priceLists = Service.RetrieveMultiple("pricelevel", null, new ColumnSet(true), ServiceControl.GetService());

                foreach (Entity priceList in priceLists.Entities)
                    priceLevelList.Add(new PriceLevelControl { id = priceList.Id, name = priceList["name"].ToString() });

                checkListPriceLevel.DataSource = priceLevelList;
                checkListPriceLevel.DataTextField = "name";
                checkListPriceLevel.DataValueField = "id";
                checkListPriceLevel.DataBind();

            }
        }

        protected void createBtn_Click(object sender, EventArgs e)
        {
            try
            {
                decimal price = Convert.ToDecimal(priceTxt.Text.Trim().Replace(",", "."));
                int number = Service.RetrieveMultiple("product", null, new ColumnSet(false), ServiceControl.GetService()).Entities.Count() + 1;

                string contractType = checkContractType.SelectedValue;
                string customerType = checkCustomerType.SelectedValue;
                string distributionAmount = checkDistributionAmount.SelectedValue;
                string distribution = checkDistribution.SelectedValue;
                string tarifs = checkTarifs.SelectedValue;
                string breakerNum = breakerNumber.SelectedValue;
                string breakerF = breakerFrom.SelectedValue != string.Empty ? "_" + breakerFrom.SelectedValue : string.Empty;
                string breakerT = breakerTo.SelectedValue != string.Empty ? "_" + breakerTo.SelectedValue : string.Empty;
                string name = string.Empty;

                if(checkTarif.Checked)
                    name = contractType + "_" + customerType + "_" + distributionAmount + "_" + distribution + "_" + tarifs;
                else if(checkBreaker.Checked)
                    name = contractType + "_" + customerType + "_" + distributionAmount + "_" + distribution + "_J_" + breakerNum + breakerF + breakerT;

                Entity subject = Service.RetrieveMultiple("subject", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();
                Entity uomschedule = Service.RetrieveMultiple("uomschedule", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();
                Entity uom = Service.RetrieveMultiple("uom", null, new ColumnSet(true), ServiceControl.GetService()).Entities.FirstOrDefault();

                Entity product = new Entity("product");
                product["productnumber"] = number.ToString();
                product["name"] = name;
                product["subjectid"] = new EntityReference { Id = subject.Id, LogicalName = subject.LogicalName };
                product["defaultuomscheduleid"] = new EntityReference { Id = uomschedule.Id, LogicalName = uomschedule.LogicalName };
                product["defaultuomid"] = new EntityReference { Id = uom.Id, LogicalName = uom.LogicalName };
                product["quantityonhand"] = Convert.ToDecimal("0");
                product["quantitydecimal"] = 0;
                product["producttypecode"] = new OptionSetValue(5);
                Guid productId = Service.Create(product, ServiceControl.GetService());

                Guid priceLevelId = new Guid(checkListPriceLevel.SelectedValue);

                Entity productPriceLevel = new Entity("productpricelevel");
                productPriceLevel["productid"] = new EntityReference { Id = productId, LogicalName = "product" };
                productPriceLevel["pricelevelid"] = new EntityReference { Id = priceLevelId, LogicalName = "pricelevel" };
                productPriceLevel["uomid"] = new EntityReference { Id = ((EntityReference)product["defaultuomid"]).Id, LogicalName = "uom" };
                productPriceLevel["amount"] = new Money(price);
                Service.Create(productPriceLevel, ServiceControl.GetService());

                new ErrorControl("Produkt vytvořen a přidán do ceníku.");
            }
            catch (Exception ex)
            {
                new ErrorControl("Chyba: " + ex.Message);
            }
        }
    }

    public class Product {

        public Guid id { get; set; }
        public string name { get; set; }
    
    }
}