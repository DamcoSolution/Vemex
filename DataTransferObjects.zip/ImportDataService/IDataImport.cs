﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ImportDataService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IDataImport
    {
        
        [OperationContract]
       void PostFile(ImportFile file);

        // TODO: Add your service operations here
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types defined there, with the namespace "ImportDataService.ContractType".
    [DataContract]
    public class ImportFile
    {
        string fileName = string.Empty;
        long fileSize = 0;
        string filePath;
        bool isSellerImport;
        string sellerId;
        Guid auctionUserId;
        string logFilePath;

        [DataMember]
        public string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }
            
        [DataMember]
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }

        [DataMember]
        public long FileSize
        {
            get { return fileSize; }
            set { fileSize = value; }
        }


        [DataMember]
        public string SellerId
        {
            get { return sellerId; }
            set { sellerId = value; }
        }

        [DataMember]
        public bool IsSellerImport {
            get {
                return isSellerImport;
            }
            set {
                isSellerImport = value;
            }
        }

    
        [DataMember]
        public Guid AuctionUserId {
            get
            {
                return auctionUserId;
            }
            set
            {
                auctionUserId = value;
            }
        }

        [DataMember]
        public string LogFilePath
        {
            get { return logFilePath;  }
            set { logFilePath = value;   }
        }
    }
}
