﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel;
using System.Data;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk;


namespace XmlImportVemex
{
    class Program
    {
  
        //static bool isAuctionOk = true;
        //CreateFormsElePerson   0
        //CreateFormsEleCompany  1
        //CreateFormsGasPerson   2
        //CreateFormsGasCompany  3

        static FileStream stream;
        static IExcelDataReader excelReader2007;
        static DataSet result;

        static void Main(string[] args)
        {
            
            #region init

            Console.Write("Navazuje se spojení s CRM");
            IOrganizationService service_isOk = ServiceControl.CreateService();
            Logger.init(DateTime.Now.ToString() + " ---- Log importu");
            int numberOfImport = 0;
            string path = "";
            string fileName = "";
            //DataSet result;            
            
            #endregion

            // cre_mefakborn(string)

            #region settings

            string whoImportData = "100020";
            bool IsSellerImport = false;
            Guid AuctionGuid = ContactSeller.AuctionCheckContact("111");

            path = @"C:\CreativeMages c# .NET\Hotove programy\XmlImportVemex 3.0b úprava na import do mefaku, poté porovnat\bin\Debug\";
            fileName = "Vzor EAN (CRM Import) - verze 2 – testovací data.xlsx";

            #endregion
         
            if (service_isOk != null)
            {

                Console.WriteLine(" - OK");
                Console.WriteLine("");

                bool isLoadFile = true;             

                if (path == "")
                {
                    Console.WriteLine("Zadejte název souboru pro import");
                    Console.WriteLine("");
                    fileName = Console.ReadLine();

                }
                path += fileName;
                try
                {

                    stream = new FileStream(path, FileMode.Open);
                    excelReader2007 = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    result = excelReader2007.AsDataSet();
                    excelReader2007.Close();
                }
                catch (Exception)
                {
                    isLoadFile = false;
                    Console.WriteLine("Soubor nelze načíst, zkontrolujte prosím, jestli není otevřený");
                    Logger.WriteLine("Soubor nelze načíst");
                }

                if (isLoadFile == true)
                {
                    Console.WriteLine("Probíhá import");
                    Console.WriteLine("");

                    //numberOfImport = ProcessData(result, string.Empty, false, seller_auction, path, false);
                    ProgramPortal p = new ProgramPortal();

                    p.objConverter = new Convertor();
                    if (p.objConverter.InitiliazationSuccess == false)
                    {
                        Logger.WriteLine("Optionset Inilization failed. Returning code");
                        return;
                    }

                    try
                    {
                        p.ProcessData(result, whoImportData, IsSellerImport, AuctionGuid, path, fileName);
                    }
                    catch (Exception ex) 
                    {

                        Console.WriteLine(ex.Message);
                        Console.ReadLine();
                    }
                }

                //Console.WriteLine("Bylo importováno " + numberOfImport + " záznamů");
                Logger.WriteLine("Bylo importováno " + numberOfImport + " záznamů");
                Console.WriteLine("Import skončil");
            }
            Console.WriteLine("");
            Console.WriteLine("Program ukončíte libovolnou klávesou");
            Console.ReadKey();

        }

    }
}
