﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CreativeMages.Xrm;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;
using Microsoft.Xrm.Sdk;

namespace HelpDesk.request
{
    public partial class createrequest : System.Web.UI.Page
    {
        public List<SelectControl> CategoryList = new List<SelectControl>(),
                                   SubCategoryList = new List<SelectControl>();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ApplyRights();
                BindControls();
            }

        }

        /// <summary>
        /// Authorization check
        /// </summary>
        private void ApplyRights()
        {
            var currentuser = LoginControl.GetUser();

            bool canCreate = HelpDesk.Controls.PortalRole.CanCreate(Entity_Name.Case.ToString());
            if (!canCreate)
            {
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void BindControls()
        {
            CategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_category");
            SubCategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_subcategory");
            drp_primaryoptionset.DataSource = CategoryList;
            drp_primaryoptionset.DataBind();
            drp_primaryoptionset.Items.Insert(0, new ListItem("Select Category", "0"));
            div_controls.Style.Add("display", "none");
        }

        protected void rptControls_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var entity = e.Item.DataItem as cre_helpdeskconfiguration;
                if (entity != null)
                {
                    cre_helpdeskconfigurationcre_controltype ControlType = (cre_helpdeskconfigurationcre_controltype)entity.cre_controltype.Value;
                    var hdnControlType = e.Item.FindControl("hdnControlType") as HiddenField;
                    if (hdnControlType != null)
                        hdnControlType.Value = entity.cre_controltype.Value.ToString();

                    var hdnControlName = e.Item.FindControl("hdnControlName") as HiddenField;
                    if (hdnControlName != null)
                        hdnControlName.Value = entity.cre_controlname;

                    //cre_helpdeskissuecre_priority.
                    switch (ControlType)
                    {
                        case cre_helpdeskconfigurationcre_controltype.CheckBox:
                            var chkControl = e.Item.FindControl("chkControl") as CheckBox;
                            chkControl.Visible = true;
                            chkControl.Text = entity.cre_name;

                            break;
                        case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                        case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                            {
                                var txtControl = e.Item.FindControl("txtControl") as TextBox;
                                if (txtControl != null)
                                {
                                    txtControl.Visible = true;
                                }
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                            var txtMulControl = e.Item.FindControl("txtMulControl") as TextBox;
                            txtMulControl.Visible = true;

                            break;
                        case cre_helpdeskconfigurationcre_controltype.OptionSet:

                            var ddlControl = e.Item.FindControl("ddlControl") as DropDownList;
                            if (ddlControl != null)
                            {
                                ddlControl.Visible = true;

                                Type type = Type.GetType("CreativeMages.Xrm.cre_helpdeskissue" + entity.cre_controlname + ", CreativeMages.Xrm");
                                if (type != null)
                                {
                                    ddlControl.DataSource = GetEnumForBind(type);
                                    ddlControl.DataTextField = "Value";
                                    ddlControl.DataValueField = "Key";
                                    ddlControl.DataBind();
                                    ddlControl.Items.Insert(0, new ListItem("Select", "0"));
                                }
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.RadioButton:
                            break;
                        default:
                            break;

                    }
                }
            }
        }

        public Dictionary<int, string> GetEnumForBind(Type enumeration)
        {

            string[] names = Enum.GetNames(enumeration);
            Array values = Enum.GetValues(enumeration);
            Dictionary<int, string> lstValues = new Dictionary<int, string>();
            for (int i = 0; i < names.Length; i++)
            {
                lstValues.Add(Convert.ToInt32(values.GetValue(i)), names[i]);
            }
            return lstValues;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            try
            {
                cre_helpdeskissue obj = new cre_helpdeskissue();

                Entity cre_helpdeskissue = new Entity("cre_helpdeskissue");

                foreach (RepeaterItem item in rptControls.Items)
                {
                    cre_helpdeskconfigurationcre_controltype ControlType =
                        (cre_helpdeskconfigurationcre_controltype)Convert.ToInt32(((HiddenField)item.FindControl("hdnControlType")).Value);

                    string ControlName = ((HiddenField)item.FindControl("hdnControlName")).Value;

                    switch (ControlType)
                    {
                        case cre_helpdeskconfigurationcre_controltype.CheckBox:
                            {
                                var chkControl = item.FindControl("chkControl") as CheckBox;
                                if (chkControl != null && chkControl.Checked)
                                {
                                    cre_helpdeskissue[ControlName] = true;
                                }
                            }
                            break;

                        case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                            {
                                var txtMulControl = item.FindControl("txtMulControl") as TextBox;
                                if (txtMulControl != null && !string.IsNullOrEmpty(txtMulControl.Text))
                                {
                                    cre_helpdeskissue[ControlName] = txtMulControl.Text.Trim();
                                }

                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.OptionSet:
                            {
                                var ddlControl = item.FindControl("ddlControl") as DropDownList;
                                if (ddlControl != null)
                                {
                                    int optionsetNumber = 0;
                                    if (int.TryParse(ddlControl.SelectedValue, out optionsetNumber))
                                    {
                                        if (optionsetNumber > 0)
                                            cre_helpdeskissue[ControlName] = new OptionSetValue(optionsetNumber);
                                    }
                                }
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.RadioButton:
                            break;
                        case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                        case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                            {
                                var myControl = item.FindControl("txtControl") as TextBox;
                                if (myControl != null && !string.IsNullOrEmpty(myControl.Text))
                                {
                                    if (ControlType == cre_helpdeskconfigurationcre_controltype.SingleLineofText)
                                        cre_helpdeskissue[ControlName] = myControl.Text.Trim();
                                    else
                                        cre_helpdeskissue[ControlName] = Convert.ToDecimal(myControl.Text.Trim());
                                }
                            }
                            break;
                        default:
                            break;
                    }


                }

                cre_helpdeskissue[Constants.CreName] = txtControl.Text;

                ServiceControl.GetService().Create(cre_helpdeskissue);
            }
            catch (Exception ex)
            {

            }
        }

        protected void Page_Preinit(Object sender, EventArgs e)
        {

            //plcControls.Controls.Add(

        }

        protected void drp_primaryoptionset_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<OptionConfiguration> _filteredoption = OptionConfiguration.GetSecondaryOptionsetMain(drp_primaryoptionset.SelectedValue.ToString());

            if (_filteredoption != null && _filteredoption.Count > 0)
            {
                string _subcategory = _filteredoption[0].secondaryoptionvalue;
                string[] resultsArray = _subcategory.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);


                List<SelectControl> _filteredoptionconfig = OptionConfiguration.GetSecondaryOptionsetFiltered(resultsArray);
                if (_filteredoptionconfig != null && _filteredoptionconfig.Count > 0)
                {
                    ////fill secondaryoptions

                    drp_secondaryoptionset.Enabled = true;
                    drp_secondaryoptionset.DataSource = _filteredoptionconfig;
                    drp_secondaryoptionset.DataBind();
                    drp_secondaryoptionset.Items.Insert(0, new ListItem("Select Sub Category", "0"));
                    div_controls.Style.Add("display", "none");
                }
            }
            else
            {
                drp_secondaryoptionset.Enabled = false;
                drp_secondaryoptionset.Items.Clear();
                div_controls.Style.Add("display", "none");
            }
        }

        protected void drp_secondaryoptionset_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drp_secondaryoptionset.SelectedIndex > 0 && drp_primaryoptionset.SelectedIndex > 0)
            {
                div_controls.Style.Add("display", "block");
                using (XrmContext context = new XrmContext(ServiceControl.GetService()))
                {

                    var conf = context.cre_helpdeskconfigurationSet.ToList().Where(
                        lst => lst.cre_category.Value == Convert.ToInt32(drp_primaryoptionset.SelectedValue)
                            && lst.cre_subcategory.Value == Convert.ToInt32(drp_secondaryoptionset.SelectedValue));

                    rptControls.DataSource = conf;
                    rptControls.DataBind();
                }
            }
            else
                div_controls.Style.Add("display", "none");
        }

    }
}