﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;
using CreativeMages.Xrm;

namespace HelpDesk.request
{
    public partial class viewrequest : System.Web.UI.Page
    {
        List<SelectControl> CategoryList = new List<SelectControl>(),
                                   SubCategoryList = new List<SelectControl>(),
                                   IssueStatus = new List<SelectControl>();
        int pageSize = 20;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!PortalRole.CanView(Entity_Name.Case))
                {
                    new ErrorControl("You don't have right to view case ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                }
                else
                {
                    BindGrid(0, pageSize);
                }
            }

        }

        private void BindGrid(int pageNumber, int pageSize)
        {
             
             CategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_category");
            SubCategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_subcategory");
            IssueStatus = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_issuestatus");

            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.Case).FirstOrDefault();
            ContactItem user = LoginControl.GetUser();
            RequestControl requestControl = new RequestControl();

            var list = requestControl.IssueList(rights, user, pageNumber, pageSize);
            int TotalRecordCount = requestControl.TotalRecords;
            grdIssueRequest.DataSource = list;
            grdIssueRequest.VirtualItemCount = TotalRecordCount;
            grdIssueRequest.DataBind();
        }

        protected void grdIssueRequest_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                cre_helpdeskissue entity = e.Row.DataItem as cre_helpdeskissue;
                GridViewRow row = e.Row;

                ImageButton btnAccept = row.FindControl("btnAccept") as ImageButton;
                if (btnAccept != null && entity.cre_issuestatus.Value == (int)cre_issuestatus.Draftneschvleno)
                {
                    btnAccept.Enabled = true;
                }
                Label lblCategory = row.FindControl("lblCategory") as Label;
                if (lblCategory != null)
                    lblCategory.Text = CategoryList.Where(lst => lst.value == entity.cre_category.Value.ToString()).FirstOrDefault().text;


                Label lblSubCategory = row.FindControl("lblSubCategory") as Label;
                if (lblSubCategory != null)
                    lblSubCategory.Text = SubCategoryList.Where(lst => lst.value == entity.cre_subcategory.Value.ToString()).FirstOrDefault().text;
                Label lblStatus = row.FindControl("lblStatus") as Label;
                if (lblStatus != null)
                    lblStatus.Text = IssueStatus.Where(lst => lst.value == entity.cre_issuestatus.Value.ToString()).FirstOrDefault().text;
            }
        }
        
        protected void grdIssueRequest_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdIssueRequest.PageIndex = e.NewPageIndex;
            BindGrid(e.NewPageIndex, pageSize);
        }

        protected void grdIssueRequest_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
            int RowIndex = gvr.RowIndex;
            Guid id = (Guid)grdIssueRequest.DataKeys[RowIndex].Value;
            if (e.CommandName == "Accept")
            {
                new CaseControl().AcceptCase(id);
                BindGrid(0, pageSize);
            }
            else if (e.CommandName.ToLower() == "editcommand")
            {
                Response.Redirect(UrlControl.GetPathUrl() + "/editcase.aspx?id=" + id, false);
            }
            else if (e.CommandName.ToLower() == "deletecommand")
            {
                new CaseControl().DeactivateCase(id);
                BindGrid(0, pageSize);
            }
        }
    }
}