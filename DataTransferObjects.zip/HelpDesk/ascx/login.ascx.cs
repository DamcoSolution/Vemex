﻿using HelpDesk.Controls;
using HelpDesk.Help;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HelpDesk.ascx
{
    public partial class login : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginBtn_Click(object sender, ImageClickEventArgs e)
        {
            string email = loginEmailTxt.Text.Trim();
            string contractNumber = loginIDTxt.Text.Trim();
            bool LoginSuccess = false;
            // validate fields
            if (email != string.Empty && contractNumber != string.Empty)
            {
                if (HelpControl.IsValidEmail(email))
                {
                    // call login
                    LoginSuccess = LoginControl.Login(email, contractNumber);
                    if (LoginSuccess)
                    {
                        //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                        Response.Redirect(UrlControl.GetSiteRootUrl() + "/home", false);
                    }
                    else
                    {
                        ErrorControl.ThrowError("Login Failed.");
                    }
                }
                else
                    ErrorControl.ThrowError("Musíte zadat správný email.");
            }
            else
                ErrorControl.ThrowError("Musíte zadat přihlášovací údaje.");

            // reload page
            if (!LoginSuccess)
                Response.Redirect("~/");
        }
    }
}