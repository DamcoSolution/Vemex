﻿$(function () {   

    // person detail
    var $lastName = $("#firstNameTxt"),
        $titul = $("#lastNameTxt"),
        $UserId = $("#UserIdTxt"),
        $ddlAccount = $("#ddlAccount"),
    $ddlContactType = $("#ddlContactType"),
    $divAcountRole = $("#divAcountRole");


    //Button
    $saveAndEndBtn = $("#saveAndEndBtn");

    //event
    $saveAndEndBtn.click(SaveAndEndClick);
    $UserId.change(IsUserExists);

    //dropdown on change 
    $ddlAccount.change(ddlAccountOnChange);

    $ddlContactType.change(ddlContactTypeOnChange)

    //Loading Holder
    var $loading = $(".loadingholder");

    //Save event handle
    function SaveAndEndClick()
    {        
        var formSuccess = ValidateForm();
        if (formSuccess) {
            
            $loading.show();
        }
        return formSuccess;
    }

    function IsUserExists() {
    
        var user = $UserId.val();
        if (user.length >0 ) {
            Ajax.CallWebMethod(
                "createcontact.aspx/IsUserExists",
                { user: user },
                function (response) {
                    if (response) {
                        alert("User Name already exists..");
                        $UserId.val("");
                    }

                }
                );
        }
    }

    function AutocompleteInput(containerId, contains) {
        

        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
            }
        });

    }

    function ddlAccountOnChange() {
        var accountId = "";
        accountId = $ddlAccount.find('option:selected').val();
        if (accountId.length > 0) {
            Ajax.CallWebMethod(
                "createcontact.aspx/GetNextUserIdByAccountId",
                { AccountId: accountId },
                function (response) {
                    if (response.length>0) {
                        $UserId.val(response);
                    }
                });
        }
    }

    function ddlContactTypeOnChange() {
        var accountroleId = $ddlContactType.find('option:selected').val();
        //171140000 = Partner ,171140001 = Auction user
       if (accountroleId == "171140000")
       {
           $divAcountRole.show();
       }
       else if (accountroleId == "171140001")
       {
           $divAcountRole.hide();
       }
    }
    
});