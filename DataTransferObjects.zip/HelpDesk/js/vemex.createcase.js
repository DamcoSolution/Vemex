﻿$(function () {
    
    // autocomplete 
    AutocompleteInput("#DivAutoCompleteContactId");
    //Button
    $saveBtn = $("#sendCaseBtn");

    //Loading Holder
    var $loading = $(".loadingholder");

    //event
    $saveBtn.click(saveBtn_Onclick);

    function AutocompleteInput(containerId, contains) {
        
        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
            }
        });

    }


    function saveBtn_Onclick() {

        var formSuccess = ValidateForm();
        if (formSuccess) {
            $loading.show();
        }
        return formSuccess;

    }

});