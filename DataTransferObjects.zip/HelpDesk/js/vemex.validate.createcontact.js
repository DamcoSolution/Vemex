﻿// variables

var errorCount = 0,
    lineCount = 0,
    $bottomError = $("<div class=\"bottomerror\">" +
                        "<div class=\"holder\">" +
                            "<div class=\"bottomerrortop\">" +
                                "<div class=\"bottomerrortopalert\"></div>" +
                                "<div class=\"bottomerrortopcontent\">Formulář nelze odeslat!</div>" +
                                "<div class=\"bottomerrortoparrow\"><span>Zobrazit chyby:</span> <strong>28</strong></div>" +
                            "</div>" +
                            "<div class=\"bottomerrormiddle\"></div>" +
                        "</div>" +
                        "</div>"),
    $bottomErrorTop = $bottomError.find(".bottomerrortop"),
    $bottomErrorTopCount = $bottomErrorTop.find(".bottomerrortoparrow strong"),
    $bottomErrorTopText = $bottomErrorTop.find(".bottomerrortoparrow span"),
    $bottomErrorTopArrow = $bottomErrorTop.find(".bottomerrortoparrow"),
    $bottomErrorMiddle = $bottomError.find(".bottomerrormiddle");

    // events
    $bottomErrorTop.click(ErrorTopClick);


// functions
function ValidateForm() {

        // person detail
        var $inputs = $("input"),
        $labels = $(".label"),
        $firstName = $("#firstNameTxt"),
        $titul = $("#lastNameTxt"),
        $UserId = $("#UserIdTxt"),
        $birthdateTxt = $("#birthdateTxt"),
        $txtEmail  = $("#txtEmail"),
        $txtPhone = $("#txtPhone"),
        $ddlContactType = $("#ddlContactType"),
        $password = $("#passwordTxt");
        
    //171140000 = Partner ,171140001 = Auction user
        var accountroleId = $ddlContactType.find('option:selected').val();

        // remove errors and set default values
        $inputs.removeClass("error");
        $labels.removeClass("error");
        $bottomErrorMiddle.empty();
        errorCount = lineCount = 0;

        if ($.trim($UserId.val()) == "" && accountroleId == "171140000")
            AddErrorLine($UserId, "User ID can not be left blank.");

        if ($.trim($password.val()) == "" && accountroleId == "171140000")
            AddErrorLine($password, "Password can not be left blank.");

        if ($.trim($firstName.val()) == "")
            AddErrorLine($firstName, "First name can not be left blank.");

        if ($.trim($txtEmail.val()) == "") {
            AddErrorLine($txtEmail, "Email Address can not be left blank.");
        }
        else if (!IsValidEmail($.trim($txtEmail.val())))
        {
            AddErrorLine($txtEmail, "Invalid Email Address.");
        }
        
        if ($.trim($birthdateTxt.val()) != "" && !IsValidDate($.trim($birthdateTxt.val()))) {
            AddErrorLine($birthdateTxt, "Invalid Birth Date.");
        }
        ShowHideError();
        return (errorCount == 0);

};

function AddErrorLine($field, message)
{   
    lineCount += 1;
    var elementId = $field.attr("id").split(" ")[0],
    $element = $("<a href=\"#\" class=\"bottomerrormiddleline\" data-id=\"" + elementId + "\">" + "<span>" + lineCount + "</span>" + message + "</a>");
    $element.click(ErrorLineClick);
    $bottomErrorMiddle.append($element);
    $field.addClass("error");
    errorCount = lineCount;
}

function AddErrorClass($field) {
    $field.addClass("error");
}

function ShowHideError() {

    var $body = $("body");
    if (errorCount > 0) {
        $bottomErrorTopCount.text(errorCount);
        $body.append($bottomError);
        $bottomError.show();
    } else
        $bottomError.hide();
}

function ErrorLineClick() {
    var elId = $(this).attr("data-id");
    var $element = $("#" + elId);
    var scrollTop = $element.offset().top - 15;
    $("html, body").stop().animate({ scrollTop: scrollTop }, 400, function () {
        $element.focus();
    });
    return false;
}

function ErrorTopClick() {
    $bottomErrorMiddle.toggle();
    $bottomErrorTopArrow.toggleClass("active");  
    return false;
}

function IsValidEmail(email) {
    
    var emailRegex = /\S+@\S+\.\S+/;
    return (emailRegex.test(email));
}

function IsValidDate(date) {
    if (date.length == 8) {
        var day = parseInt(date.substring(0, 2), 10);
        var month = parseInt(date.substring(2, 4), 10);
        var year = date.substring(4, 8);
        if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1900)
            return false;
        else
            return true;
    }
    else
        return false;
}