﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using CreativeMages.Xrm;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace ARTAPOC.Plugins
{

    public class IncidentPlugin 
    {

        public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));


            if (context.PrimaryEntityName == "incident" && context.MessageName == "Close" && context.Depth < 2)
            {

                Entity input = new Entity();

                if (context.InputParameters.Contains("IncidentResolution") && context.InputParameters["IncidentResolution"] is Entity)
                {

                    input = (Entity)context.InputParameters["IncidentResolution"];

                    if (input.Attributes.Contains("incidentid"))
                    {

                        if (input.Attributes["incidentid"] is EntityReference)
                        {

                            CloseChildCases(((Microsoft.Xrm.Sdk.EntityReference)(input.Attributes["incidentid"])).Id.ToString(), serviceProvider, context);

                        }

                        else
                        {

                            CloseChildCases(input.Attributes["incidentid"].ToString(), serviceProvider, context);

                        }



                    }

                }

            }

        }



        private void CloseChildCases(string parentIncidentID, IServiceProvider serviceProvider, IPluginExecutionContext context)
        {

            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            QueryByAttribute querybyattribute = new QueryByAttribute("incident");
            querybyattribute.ColumnSet = new ColumnSet("incidentid");
            querybyattribute.Attributes.AddRange("new_maincaseid");
            querybyattribute.Values.AddRange(parentIncidentID.ToString());
            EntityCollection retrieved = service.RetrieveMultiple(querybyattribute);
            int retrievedEntityCount = retrieved.Entities.Count;
            if (retrievedEntityCount > 0)
            {

                for (int entityCount = 0; entityCount < retrievedEntityCount; entityCount++)
                {
                    Entity caseResolution = new Entity("incidentresolution");
                    caseResolution.Attributes.Add("incidentid", retrieved[entityCount].Id.ToString());
                    caseResolution.Attributes.Add("subject", "Parent Case has been resolved");
                    //service.Create(caseResolution);
                    CloseIncidentRequest closedemand = new CloseIncidentRequest();
                    closedemand.IncidentResolution = caseResolution;
                    closedemand.RequestName = "CloseIncident";
                    OptionSetValue o = new OptionSetValue();
                    o.Value = 5;
                    closedemand.Status = o;
                    CloseIncidentResponse resp = (CloseIncidentResponse)service.Execute(closedemand);
                }
            }
        }

    }

}

