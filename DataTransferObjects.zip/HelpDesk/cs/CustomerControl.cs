﻿using CRM;
using CRM.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using CreativeMages.Xrm;

namespace HelpDesk.Controls
{
    public class CustomerControl
    {
        public static ContactItem ExistsContact(string email, Guid parentCustomerId)
        {

            try
            {
                // filter
                FilterExpression contactRequestFilter = new FilterExpression();
                contactRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                contactRequestFilter.AddCondition("parentcustomerid", ConditionOperator.Equal, parentCustomerId);
                contactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = Service.RetrieveMultiple("contact", contactRequestFilter, 
                    new ColumnSet(new string[] { "firstname", "lastname", "emailaddress1", "parentcustomerid", "fullname", "cre_role" }), ServiceControl.GetService());

                // if count is 1 return true
                if (contactResponse.Entities.Count() == 1)
                {
                    Entity contact = contactResponse.Entities.FirstOrDefault();

                    ContactItem item = new ContactItem();
                    item.id = contact.Id;

                    if (contact.Attributes.Contains("firstname"))
                        item.firstName = contact["firstname"].ToString();

                    if (contact.Attributes.Contains("lastname"))
                        item.lastName = contact["lastname"].ToString();

                    if (contact.Attributes.Contains("emailaddress1"))
                        item.email = contact["emailaddress1"].ToString();

                    if (contact.Attributes.Contains("fullname"))
                        item.fullName = contact["fullname"].ToString();

                    if (contact.Attributes.Contains("parentcustomerid"))
                    {
                        item.customerName = ((EntityReference)contact["parentcustomerid"]).Name;
                        item.CustomerId = ((EntityReference)contact["parentcustomerid"]).Id;
                        item.CustomerLogicalNamge = ((EntityReference)contact["parentcustomerid"]).LogicalName;
                    }

                    if (contact.Attributes.Contains("cre_role"))
                    {
                        EntityReference role = contact["cre_role"] as EntityReference;
                        if (role != null)
                        {
                            item.Role = PortalRole.Getrole(role, ServiceControl.GetService());
                        }
                    }

                    return item;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Email.SendError("HelpDesk error", "Error: ExistsContact in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return null;
            }
        }
        
        public static ContractItem ExistsContract(string contractNumber)
        {

            try
            {
                // filter
                FilterExpression contractRequestFilter = new FilterExpression();
                contractRequestFilter.AddCondition("contractnumber", ConditionOperator.Equal, contractNumber);
                contractRequestFilter.AddCondition("statecode", ConditionOperator.Equal, 2);
                contractRequestFilter.AddCondition("statuscode", ConditionOperator.Equal, 3);
                contractRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contracts by filter
                EntityCollection contractResponse = Service.RetrieveMultiple("contract", contractRequestFilter, new ColumnSet(new string[] { "contractnumber", "expireson", "customerid", "statecode", "statuscode" }), ServiceControl.GetService());

                // if count is 1 return true
                if (contractResponse.Entities.Count() == 1)
                {
                    Entity contract = contractResponse.Entities.FirstOrDefault();
                    
                    ContractItem item = new ContractItem();
                    item.id = contract.Id;

                    if (contract.Attributes.Contains("contractnumber"))
                        item.contractNumber = contract["contractnumber"].ToString();

                    if (contract.Attributes.Contains("expireson"))
                        item.expiresOn = DateTime.Parse(contract["expireson"].ToString());

                    if (contract.Attributes.Contains("customerid"))
                        item.customerId = ((EntityReference)contract["customerid"]).Id;

                    item.stateCode = ((OptionSetValue)contract["statecode"]).Value;
                    item.statusCode = ((OptionSetValue)contract["statuscode"]).Value;

                    return item;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Email.SendError("HelpDesk error", "Error: ExistsContract in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return null;
            }

        }

        public static ProductItem GetProductFromDetail(Guid detailId)
        {

            try
            {
                // get detail
                Entity detail = Service.Retrieve("contractdetail", detailId, new ColumnSet(new string[]{ "productid" }), ServiceControl.GetService());

                if (detail.Attributes.Contains("productid"))
                {
                    Entity product = Service.Retrieve("product", ((EntityReference)detail["productid"]).Id, new ColumnSet(false), ServiceControl.GetService());
                    ProductItem item = new ProductItem();
                    item.id = product.Id;

                    return item;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Email.SendError("HelpDesk error", "Error: GetProductFromDetail in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return null;
            }

        }

        public static List<ContractDetailItem> GetContractDetail(Guid contractId)
        {

            try
            {
                // create list
                List<ContractDetailItem> contractDetailsList = new List<ContractDetailItem>();

                // filter
                FilterExpression contractDetailRequestFilter = new FilterExpression();
                contractDetailRequestFilter.AddCondition("contractid", ConditionOperator.Equal, contractId);

                // retrieve all contractdetails by filter
                EntityCollection contractDetailResponse = Service.RetrieveMultiple("contractdetail", contractDetailRequestFilter, new ColumnSet(new string[] { "title" }), ServiceControl.GetService());

                foreach (Entity detail in contractDetailResponse.Entities)
                {
                    contractDetailsList.Add(new ContractDetailItem { 
                        id = detail.Id,
                        title = detail.Attributes.Contains("title") ? detail["title"].ToString() : string.Empty
                    });
                }

                return contractDetailsList;
            }
            catch (Exception ex)
            {
                Email.SendError("HelpDesk error", "Error: GetContractDetail in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return null;
            }

        }

        public static bool AddAnnotation(string content, string objectLogicalName, Guid objectId)
        {

            try
            {

                Entity annotation = new Entity("annotation");
                annotation["subject"] = "Dodatečná poznámka";
                //annotation["filename"] = "dodatecna-poznamka.txt";
                //annotation["documentbody"] = Convert.ToBase64String(new UnicodeEncoding().GetBytes(content));
                //annotation["isdocument"] = true;
                //annotation["mimetype"] = "text/plain";
                annotation["notetext"] = content;
                annotation["objectid"] = new EntityReference(objectLogicalName, objectId);
                Service.Create(annotation, ServiceControl.GetService());
                return true;

            }
            catch (Exception ex)
            {

                Email.SendError("HelpDesk error", "Error: AddAnnotation in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;

            }

        }

        public static Guid CreateCase(string title, int caseTypeCode, int caseOriginCode, int limit, DateTime followUpBy, Guid customerId, Guid contractId, Guid contractDetailId, Guid productId)
        {

            try
            {

                Entity newCase = new Entity("incident");
                newCase["title"] = title;
                newCase["customerid"] = new EntityReference("contact", customerId);
                newCase["contractid"] = new EntityReference("contract", contractId);
                newCase["contractdetailid"] = new EntityReference("contractdetail", contractDetailId);

                if(productId != Guid.Empty)
                    newCase["productid"] = new EntityReference("product", productId);

                newCase["casetypecode"] = new OptionSetValue(caseTypeCode);
                newCase["caseorigincode"] = new OptionSetValue(caseOriginCode);
                newCase["followupby"] = followUpBy;
                newCase["severitycode"] = new OptionSetValue(limit);

                newCase[Constants.CaseNewStatus] = new OptionSetValue((int)CaseStatus.Draft);
                return Service.Create(newCase, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("HelpDesk error", "Error: CreateCase in HelpDesk.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateUpdateContact(string firstName, string lastName, string email, string phone, DateTime? date,
          string userid, string password, Guid? entityid, Guid ParentAccountid, Guid RoleId, int accountRoleid)
        {

            try
            {
                Entity contact = null;
                if (entityid != null)
                {
                    contact = ServiceControl.GetService().Retrieve(Constants.Contact, entityid.Value, new ColumnSet(true));
                }
                else
                {
                    contact = new Entity(Constants.Contact);
                }

                contact[Constants.ContactFirstName] = firstName;
                contact[Constants.ContactLastName] = lastName;
                contact[Constants.ContactBirthDate] = date;
                contact[Constants.ContactEmail] = email;
                contact[Constants.ContactMobile] = phone;
                contact[Constants.ContactAccountRole] = new OptionSetValue(accountRoleid);
                var currentuser = LoginControl.GetUser();
                
                if (accountRoleid == Constants.AccountRoleId)
                {

                    contact[Constants.ContactLogin] = userid;
                    contact[Constants.ContactPassword] = password;

                    if (RoleId != Guid.Empty)
                    {
                        contact[Constants.PortalRole] = new EntityReference(Constants.PortalRole, RoleId);
                    }
                    if (ParentAccountid != Guid.Empty)
                    {
                        contact["parentcustomerid"] = new EntityReference(Constants.Account, ParentAccountid);
                    }
                }
                else
                {
                    //Adding vemex Account
                   // contact["parentcustomerid"] = new EntityReference(Constants.Account, AccountControl.GetOrAddAccountByName("Vemex"));
                }

                if (entityid == null)
                {
                    Guid contactid = Service.Create(contact, ServiceControl.GetService());
                    //if (contactid != Guid.Empty && ParentAccountid != null)
                    //{
                    //    AccountControl.UpdateUserId(ParentAccountid);
                    //}
                    return contactid;
                }
                else
                {
                    //     Service.Update(contact, ServiceControl.GetService());
                    ServiceControl.GetService().Update(contact);
                    return entityid.Value;
                }
            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateContact in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        internal static void AddAnnotation(Annotation annotation)
        {
            using (XrmContext context = new XrmContext(ServiceControl.GetService()))
            {
                context.AddObject(annotation);
                context.SaveChanges();
            }
        }
    }
}