﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CRM;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using HelpDesk.EntityObjects;

namespace HelpDesk.Controls
{
    public class ContactControl
    {
        public int TotalRecords { get; set; }

        public List<Contact> ContactList(PortalRights rights, ContactItem user, int pageNumber, int pageSize)
        {

            List<Contact> list = new List<Contact>();

            QueryExpression query = GenerateQuery(rights, user);
            query.PageInfo = new PagingInfo() { PageNumber = pageNumber + 1, Count = pageSize, ReturnTotalRecordCount = true };

            // Obtain results from the query expression.
            EntityCollection ec = ServiceControl.GetService().RetrieveMultiple(query);
            this.TotalRecords = ec.TotalRecordCount;
            foreach (Entity contact in ec.Entities)
            {
                Contact ContactRec = SetAccountByEntity(contact);
                list.Add(ContactRec);
            }

            return list;

        }

        private static Contact SetAccountByEntity(Entity contact)
        {
            Contact ContactRec = new Contact();
            ContactRec.Name = contact.Attributes.Contains(Constants.ContactFullName) ? contact[Constants.ContactFullName].ToString() : string.Empty;
            ContactRec.Email = contact.Attributes.Contains(Constants.ContactEmail) ? contact[Constants.ContactEmail].ToString() : string.Empty;

            ContactRec.FirstName = contact.Attributes.Contains(Constants.ContactFirstName) ? contact[Constants.ContactFirstName].ToString() : string.Empty;
            ContactRec.LastName = contact.Attributes.Contains(Constants.ContactLastName) ? contact[Constants.ContactLastName].ToString() : string.Empty;
            ContactRec.UserId = contact.Attributes.Contains(Constants.ContactLogin) ? contact[Constants.ContactLogin].ToString() : string.Empty;

            ContactRec.Id = contact.Id;
            return ContactRec;
        }

        private static QueryExpression GenerateQuery(PortalRights rights, ContactItem user)
        {
            var contact = LoginControl.GetUsersContract();
            ColumnSet columns = new ColumnSet(
                new string[] { 
                    Constants.ContactId, 
                    Constants.ContactFirstName,
                    Constants.ContactLastName,                   
                    Constants.ContactEmail,
                    Constants.ContactFullName ,
                    Constants.ContactPortalRole,
                    Constants.ContactParentCustomerId
                });

           EntityReference reference = new EntityReference(user.CustomerLogicalName, user.CustomerId);
            QueryExpression query = new QueryExpression();

            EntityReference currentContact = new EntityReference(Constants.Contact, contact.id);
            
            switch (rights.AccessLevel)
            {
                case AccessLevel.kontakt:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Contact,
                            ColumnSet = columns,
                            Criteria =
                            {
                                Filters = 
                                {                                    
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.And,
                                        Conditions = 
                                        {
                                            new ConditionExpression(Constants.StateCode, ConditionOperator.Equal,0),
                                            new ConditionExpression(Constants.ContactAccountRole,ConditionOperator.Equal,Constants.AccountRoleId)
                                        }
                                   },
                                   new FilterExpression
                                   {
                                        FilterOperator = LogicalOperator.Or,
                                        Conditions = 
                                        {
                                            new ConditionExpression(Constants.ContactOwner,ConditionOperator.Equal,contact.id),
                                            new ConditionExpression(Constants.ContactId,ConditionOperator.Equal,contact.id)
                                        }
                                   }
                                }
                            }
                        };
                    }
                    break;
                case AccessLevel.account:
                    {   
                        
                        if (reference != null)
                        {
                            query = new QueryExpression()
                            {
                                EntityName = Constants.Contact,
                                ColumnSet = columns,
                                Criteria =
                                    {
                                        Filters =
                                        {
                                            new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = 
                                                {
                                                    new ConditionExpression(Constants.StateCode,ConditionOperator.Equal,0),
                                                    new ConditionExpression(Constants.ContactAccountRole, ConditionOperator.Equal, Constants.AccountRoleId)
                                                }
                                            }
                                        }
                                }
                                ,
                                LinkEntities = 
                                    {
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName =Constants.Contact, LinkFromAttributeName = Constants.ContactOwner, LinkToEntityName = Constants.Contact, LinkToAttributeName =Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName =Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {reference.Id}}}
                                            }
                                        },
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName =Constants.Contact, LinkFromAttributeName = Constants.ContactId, LinkToEntityName = Constants.Contact, LinkToAttributeName =Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName =Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal,Values = {reference.Id}}}
                                            }
                                        }
                                    }
                            };
                        }
                   
                    }
#region Commented for now
                    /*
               
                        //if (reference != null)
                        //{
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Contact,
                            ColumnSet = columns,
                            Criteria =
                            {
                                Filters = 
                                {
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.And,
                                        Conditions = 
                                        {
                                            new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}},
                                            new ConditionExpression {AttributeName= Constants.ContactAccountRole, Operator=  ConditionOperator.Equal, Values={Constants.AccountRoleId}}
                                        }
                                    },
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.Or,
                                        Conditions = 
                                        {
                                            new ConditionExpression {AttributeName = Constants.ContactOwner, Operator = ConditionOperator.Equal, Values ={user.Id}},
                                            new ConditionExpression {AttributeName= Constants.ContactParentCustomerId, Operator=  ConditionOperator.Equal, Values={user.Id}}
                                        }
                                    }

                                }

                            }
                        };
                    } */
                    #endregion Commented for now
                    break;
                case AccessLevel.organizace:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.Contact,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}},
                                    new ConditionExpression {AttributeName= Constants.ContactAccountRole, Operator=  ConditionOperator.Equal, Values={Constants.AccountRoleId}}
                                }
                            },
                        };
                    }
                    break;
                default:
                    break;
            }
            query.Distinct = true;
            return query;
        }

        public bool DeactivateContact(Guid contactid)
        {
            SetStateRequest request = new SetStateRequest();

            // In Entity refrence first paramter is Entity name and second paramter is ENtity Id                   
            request.EntityMoniker = new EntityReference(Constants.Contact, contactid);

            request.State = new OptionSetValue(1);
            request.Status = new OptionSetValue(2);
            // Pass request to CRM Service execute method
            ServiceControl.GetService().Execute(request);
            return true;
        }

        public bool CanEditContact(Guid id)
        {
            bool CanEdit = false;
            PortalRights role = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.kontakt && lst.CanEdit == true).FirstOrDefault();
            if(role != null)
            {
            QueryExpression query = GenerateQuery(role, LoginControl.GetUser());
            query.Criteria.Conditions.Add(new ConditionExpression() { AttributeName = Constants.ContactId, Operator = ConditionOperator.Equal, Values = { id} });

            // Obtain results from the query expression.
            EntityCollection ec = ServiceControl.GetService().RetrieveMultiple(query);
                if(ec.Entities.Count() <= 1)
                CanEdit = true;
            }
            return CanEdit;
        }

        public static EntityReference GetPartnerRole()
        {
            EntityReference entity = new EntityReference();

             FilterExpression filter = new FilterExpression();
            filter.AddCondition(Constants.CreName, ConditionOperator.Equal, "Partner");
            filter.FilterOperator = LogicalOperator.And;

            EntityCollection roles = Service.RetrieveMultiple(Constants.PortalRole, filter, new ColumnSet(true), ServiceControl.GetService());

            if (roles.Entities.Count() == 1)
            {
                entity = new EntityReference(Constants.PortalRole, roles.Entities[0].Id);
            }
            return entity;
        }

        internal static bool IsUserExists(string user, IOrganizationService organizationService, Guid? Entityid)
        {
            try
            {
                FilterExpression filter = new FilterExpression();
                filter.AddCondition(Constants.ContactLogin, ConditionOperator.Equal, user);
                filter.FilterOperator = LogicalOperator.And;

                EntityCollection contacts = Service.RetrieveMultiple(Constants.Contact, filter, new ColumnSet(new string[] { Constants.ContactFirstName, Constants.ContactLastName}), ServiceControl.GetService());

                if (contacts.Entities.Count() > 0)
                {
                    if (Entityid != null)
                    {
                        if (contacts.Entities.Count() == 1 && contacts.Entities[0].Id == Entityid)
                        {
                            return false;
                        }
                        else
                            return true;

                    }
                    else
                        return true;
                }
                else
                    return false;
            }
            catch
            {
                return false;
            }
              
        }

        public Contact GetContactById(Guid contactid)
        {
            Contact ContactRec = new Contact();

            Entity entity = Service.Retrieve(Constants.Contact, contactid, new ColumnSet(true), ServiceControl.GetService());

            ContactRec = SetContactByEntity(entity);
            return ContactRec;
        }

        public Contact GetContactUserId(string userid)
        {
            Contact ContactRec = new Contact();


            FilterExpression filter = new FilterExpression();
            filter.AddCondition(Constants.ContactLogin, ConditionOperator.Equal, userid);
            filter.AddCondition(Constants.ContactAccountRole, ConditionOperator.Equal, Constants.AccountRoleId);

            ColumnSet col = new ColumnSet(

               new string[] 
                 {
                     Constants.ContactFirstName, 
                     Constants.ContactLastName, 
                    Constants.ContactLastLogin, 
                    Constants.ContactLogin, 
                    Constants.PortalRole, 
                     Constants.ContactParentCustomerId, 
                     Constants.ContactAccountRole 
                 }
          );
            EntityCollection contacts = Service.RetrieveMultiple(Constants.Contact, filter, col, ServiceControl.GetService());
            if (contacts.Entities.Count() == 1)
            {

                ContactRec = SetContactByEntity(contacts.Entities[0]);
            }
            return ContactRec;
        }

        private static Contact SetContactByEntity(Entity entity)
        {
            Contact ContactRec = new Contact();
            if (entity != null)
            {

                ContactRec.Name = entity.Attributes.Contains(Constants.ContactFullName) ? entity[Constants.ContactFullName].ToString() : string.Empty;
                ContactRec.Email = entity.Attributes.Contains(Constants.ContactEmail) ? entity[Constants.ContactEmail].ToString() : string.Empty;
                ContactRec.Id = entity.Id;
                ContactRec.FirstName = entity.Attributes.Contains(Constants.ContactFirstName) ? entity[Constants.ContactFirstName].ToString() : string.Empty;
                ContactRec.LastName = entity.Attributes.Contains(Constants.ContactLastName) ? entity[Constants.ContactLastName].ToString() : string.Empty;
                ContactRec.Phone = entity.Attributes.Contains(Constants.ContactMobile) ? entity[Constants.ContactMobile].ToString() : string.Empty;
                ContactRec.UserId = entity.Attributes.Contains(Constants.ContactLogin) ? entity[Constants.ContactLogin].ToString() : string.Empty;
                ContactRec.Password = entity.Attributes.Contains(Constants.ContactPassword) ? entity[Constants.ContactPassword].ToString() : string.Empty;
                ContactRec.DateofBirth = entity.Attributes.Contains(Constants.ContactBirthDate) ? (DateTime) entity[Constants.ContactBirthDate] : DateTime.Today;
                if (entity.Attributes.Contains(Constants.ContactTitle))
                {
                    var option = entity[Constants.ContactTitle] as OptionSetValue;
                    if (option != null)
                        ContactRec.Title = option.Value.ToString();
                }

                if (entity.Attributes.Contains(Constants.ContactTitleLast))
                {
                    var option = entity[Constants.ContactTitleLast] as OptionSetValue;
                    if (option != null)
                        ContactRec.TitleLast = option.Value.ToString();
                }
                if(entity.Attributes.Contains(Constants.ContactParentCustomerId))
                {
                    EntityReference Customer = entity[Constants.ContactParentCustomerId] as EntityReference;
                    ContactRec.ParentCustomer = new KeyValuePair<string, Guid>(Customer.LogicalName, Customer.Id);
                }
            }
            return ContactRec;
        }

        public List<Contact> GetAuctionContactList()
        {
            List<Contact> list = new List<Contact>();

            //OptionSetValue option = new OptionSetValue(Constants.AuctionRoleId);
            FilterExpression filter = new FilterExpression();
            filter.AddCondition(Constants.ContactAccountRole, ConditionOperator.Equal, Constants.AuctionRoleId);
            filter.FilterOperator = LogicalOperator.And;
            ColumnSet columns = new ColumnSet(
              new string[] { 
                    Constants.ContactId, 
                    Constants.ContactFirstName,
                    Constants.ContactLastName ,
                    Constants.ContactLastLogin, 
                    Constants.ContactLogin,
                    Constants.ContactEmail,
                    Constants.ContactFullName ,
                    Constants.PortalRole,
                    Constants.ContactParentCustomerId
                });


            EntityCollection contactList = Service.RetrieveMultiple(Constants.Contact, filter, columns, ServiceControl.GetService());
            foreach (Entity contact in contactList.Entities)
            {
                Contact ContactRec = SetAccountByEntity(contact);
                list.Add(ContactRec);
            }
            return list;
        }

    }
}