﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace HelpDesk.Help
{
    public class HelpControl
    {
        public static bool IsValidEmail(string email)
        {
            Regex regex = new Regex(@"^[-!#$%&'*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+/0-9=?A-Z^_a-z{|}~])*@[a-zA-Z](-?[a-zA-Z0-9])*(\.[a-zA-Z](-?[a-zA-Z0-9])*)+$");
            return regex.IsMatch(email);
        }

        public static void AddToLog(string value)
        {
            StreamWriter log;
            string today = DateTime.Now.ToLocalTime().ToString("dd-MM-yyyy");
            string logFile = HttpContext.Current.Server.MapPath("~/Log/log-" + today + ".txt");

            if (!File.Exists(logFile))
                log = new StreamWriter(logFile);
            else
                log = File.AppendText(logFile);

            log.WriteLine(DateTime.Now.ToLocalTime());
            log.WriteLine(value);
            log.WriteLine();
            log.Close();
        }

    }
}