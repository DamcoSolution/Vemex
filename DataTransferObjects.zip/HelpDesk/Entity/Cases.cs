﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk;

namespace HelpDesk.EntityObjects
{
    public class Cases
    {
        public Guid CaseId { get; set; }
        public string ID { get; set; }

        public CaseStatus CaseStatus { get; set; }
        public string Title { get; set; }
        public EntityReference CustomerId { get; set; }
        public EntityReference ContractId { get; set; }
        public EntityReference ContractDetailId { get; set; }
        public EntityReference ProductId { get; set; }
        public CaseType CaseType { get; set; }
        public int CaseOriginCode { get; set; }
        public DateTime FollowupBy { get; set; }
        public int Severitycode { get; set; }

    }
}