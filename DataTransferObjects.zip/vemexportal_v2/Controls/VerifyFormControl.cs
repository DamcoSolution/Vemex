﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using VemexPortal.Controls;
using VemexPortal_v2.App_Code;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2.Controls
{
    public class VerifyFormControl
    {
        public int TotalRecords { get; set; }
        public List<VerifyForm> GetVerifyFormList(PortalRights rights, LoginControl user, int pageNumber, int pageSize)
        {
            List<VerifyForm> list = new List<VerifyForm>();

            QueryExpression query = GenerateQuery(rights, user);
            query.PageInfo = new PagingInfo() { PageNumber = pageNumber + 1, Count = pageSize, ReturnTotalRecordCount=true };

            
            // Obtain results from the query expression.
            IOrganizationService service =  ServiceControl.GetService();
           
            EntityCollection ec = service.RetrieveMultiple(query);

            OptionSetMetadata optionset = Utility.GetOptionSet(Constants.VerifyForm, Constants.VerifyFormStatus, service);
            this.TotalRecords = ec.TotalRecordCount;
            foreach (Entity verifyformEntity in ec.Entities)
            {
                VerifyForm verifyform = new VerifyForm();
                if (verifyformEntity.Attributes.Contains(Constants.VerifyFormAcceptedOn))
                {
                    verifyform.AcceptedOn = Convert.ToDateTime(verifyformEntity[Constants.VerifyFormAcceptedOn]);

                    verifyform.AcceptedOn_CEST = TimeZoneInfo.ConvertTimeFromUtc(verifyform.AcceptedOn.ToUniversalTime(), TimeZoneInfo.FindSystemTimeZoneById("E. Europe Standard Time"));
                }
                verifyform.Name = verifyformEntity.Attributes.Contains(Constants.CreName) ? verifyformEntity[Constants.CreName].ToString() : string.Empty;

                verifyform.EAN =verifyformEntity.Attributes.Contains(Constants.VerifyFormEAN) ? verifyformEntity[Constants.VerifyFormEAN].ToString() : string.Empty;
                verifyform.EIC = verifyformEntity.Attributes.Contains(Constants.VerifyFormEIC) ? verifyformEntity[Constants.VerifyFormEIC].ToString() : string.Empty;
                if (verifyformEntity.Attributes.Contains(Constants.VerifyFormStatus))
                {
                    var option = verifyformEntity[Constants.VerifyFormStatus] as OptionSetValue;

                    var optionMetadata = optionset.Options.Where(lst => lst.Value == option.Value).FirstOrDefault();
                    if (optionMetadata != null)
                    {
                        verifyform.Status = optionMetadata.Label.UserLocalizedLabel.Label;
                    }
                }
                list.Add(verifyform);
            }
            pageNumber = 250;
            while (ec.MoreRecords == true)
            {
                
                query.PageInfo = new PagingInfo() { PageNumber = pageNumber + 1, Count = 20, ReturnTotalRecordCount = true, PagingCookie = ec.PagingCookie };
                ec = service.RetrieveMultiple(query);
                this.TotalRecords = ec.TotalRecordCount;
                pageNumber += 250;
            }

            return list;

        }

        private QueryExpression GenerateQuery(PortalRights rights, LoginControl user)
        {
            ColumnSet columns = new ColumnSet(true);
            EntityReference reference = user.ParentCustomer;
            QueryExpression query = new QueryExpression();
            EntityReference currentContact = new EntityReference(Constants.Contact, user.Id);
            switch (rights.AccessLevel)
            {
                case AccessLevel.kontakt:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.VerifyForm,
                            ColumnSet = columns,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = { new ConditionExpression { AttributeName = Constants.VerifyFormOwner, Operator = ConditionOperator.Equal, Values = {user.Id}},
                                    new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                },
                            }

                        };
                    }
                    break;
                case AccessLevel.account:
                    {
                        if (reference != null)
                        {
                            query = new QueryExpression()
                            {
                                EntityName = Constants.VerifyForm,
                                ColumnSet = columns,
                                Criteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                }
                                },
                                LinkEntities = 
                                    {
                                        new LinkEntity
                                        {                        
                                            LinkFromEntityName = Constants.VerifyForm, LinkFromAttributeName = Constants.VerifyFormOwner, 
                                            LinkToEntityName = Constants.Contact,
                                            LinkToAttributeName = Constants.ContactId,
                                            LinkCriteria = new FilterExpression
                                            {
                                                FilterOperator = LogicalOperator.And,
                                                Conditions = {new ConditionExpression { AttributeName = Constants.ContactParentCustomerId, Operator = ConditionOperator.Equal, 
                                                    Values = {reference.Id}}}
                                            }
                                        }
                                    }
                            };
                        }
                    }
                    break;
                case AccessLevel.organizace:
                    {
                        query = new QueryExpression()
                        {
                            EntityName = Constants.VerifyForm,
                            ColumnSet = columns
                            ,
                            Criteria = new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                Conditions = {new ConditionExpression {AttributeName = Constants.StateCode, Operator = ConditionOperator.Equal, Values ={0}}
                                }
                            }
                        };
                    }
                    break;
                default:
                    break;
            }
             query.AddOrder("createdon", OrderType.Descending);
            query.Distinct = true;
            return query;
        }

        private static void WriteAttachment(string FileName, string FileType, string content)
        {
            HttpResponse Response = System.Web.HttpContext.Current.Response;
            Response.ClearHeaders();
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + FileName);
            Response.ContentType = FileType;
            Response.Write(content);
            Response.End();
        }

    
      
    }
}