﻿$(function () {
    
    // variables
    var filesCount = 0;

    // form types 
    var $smallCheck = $("#smallCheck"),
        $homeCheck = $("#homeCheck");


    //Seller Info
    var $sellerFirstName = $("#txtSellerFirstName"),
        $sellerLastName = $("#txtSellerLastName");



    // buttons
    var $saveAndDuplicateBtn = $("#saveAndDuplicateBtn"),
        $saveAndEndBtn = $("#saveAndEndBtn"),
        $postalAddressBtn = $("#postalAddressBtn"),
        $addNewFileBtn = $("#addNewFileBtn"),
        $removeFileBtn = $(".removeFile"),
        $popCloseBtn = $(".popholder .poptop .popclose"),
        $popInputBtn = $(".popholder .popmiddle input"),
        $copyAddressBtn = $("#copyAddressBtn"),
        $copySecondAddressBtn = $("#copySecondAddressBtn"),
        $copyAddressBtn2 = $("#copyAddressBtn2"),
        $copySecondAddressBtn2 = $("#copySecondAddressBtn2");

    // form parts
    var $postalAddressPart = $("#postalAddressPart"),
        $uploadFilesPart = $("#uploadFilesPart"),
        $homeParts = $("div[data-id=home]"),
        $smallParts = $("div[data-id=small]"),
        $loading = $(".loadingholder"),
        $popHolder = $(".popholder"),
        $pop = $(".popholder .pop"),
        $nextSupplyPoint = $("#nextSupplyPoint"),
        $addSupplyPoint = $("#addSupplyPoint");

    // person detail
    var $firstName = $("#firstNameTxt"),
        $lastName = $("#lastNameTxt"),
        $titul = $("#titulTxt"),
        $lastTitul = $("#lastTitulTxt"),
        $ico = $("#icoTxt"),
        $dic = $("#dicTxt");

    // company detail
    var $companyName = $("#companyNameTxt"),
        $companyIco = $("#companyIcoTxt"),
        $companyDic = $("#companyDicTxt");

    // address
    var $street = $("#streetTxt"),
        $houseNumber = $("#houseNumberTxt"),
        $orientationNumber = $("#orientationNumberTxt"),
        $postalCode = $("#postalCodeTxt"),
        $country = $("#countryTxt"),
        $postalStreet = $("#postalStreetTxt"),
        $postalHouseNumber = $("#postalHouseNumberTxt"),
        $postalOrientationNumber = $("#postalOrientationNumberTxt"),
        $postalPostalCode = $("#postalPostalCodeTxt"),
        $postalCountry = $("#postalCountryTxt");

    // supply point
    var $supplyPointStreet = $("#supplyPointStreetTxt"),
        $supplyPointHouseNumber = $("#supplyPointHouseNumberTxt"),
        $supplyPointOrientationNumber = $("#supplyPointOrientationNumberTxt"),
        $supplyPointPostalCode = $("#supplyPointPostalCodeTxt"),
        $supplyPointCountry = $("#supplyPointCountryTxt"),
        $supplyPointInvoicePaymentTransferCheck = $("#supplyPointInvoicePaymentTransferCheck"),
        $supplyPointNewDistributionTxt = $("#supplyPointNewDistributionTxt"),
        $supplyPointYearSubscriptionAmountVTTxt = $("#supplyPointYearSubscriptionAmountVTTxt"),
        $supplyPointYearSubscriptionAmountNTTxt = $("#supplyPointYearSubscriptionAmountNTTxt"),
        $supplyPointDistributionAmountTxt = $("#supplyPointDistributionAmountTxt"),
        $supplyPointDepositAmountTxt = $("#supplyPointDepositAmountTxt"),
        $supplyPointDepositMonthCheck = $("#supplyPointDepositMonthCheck"),
        $supplyPointDepositQuarterCheck = $("#supplyPointDepositQuarterCheck"),
        $supplyPointStreet2 = $("#supplyPointStreetTxt2"),
        $supplyPointHouseNumber2 = $("#supplyPointHouseNumberTxt2"),
        $supplyPointOrientationNumber2 = $("#supplyPointOrientationNumberTxt2"),
        $supplyPointPostalCode2 = $("#supplyPointPostalCodeTxt2"),
        $supplyPointCountry2 = $("#supplyPointCountryTxt2"),
        $supplyPointInvoicePaymentTransferCheck2 = $("#supplyPointInvoicePaymentTransferCheck2"),
        $supplyPointNewDistributionTxt2 = $("#supplyPointNewDistributionTxt2"),
        $supplyPointYearSubscriptionAmountVTTxt2 = $("#supplyPointYearSubscriptionAmountVTTxt2"),
        $supplyPointYearSubscriptionAmountNTTxt2 = $("#supplyPointYearSubscriptionAmountNTTxt2"),
        $supplyPointDistributionAmountTxt2 = $("#supplyPointDistributionAmountTxt2"),
        $supplyPointDepositAmountTxt2 = $("#supplyPointDepositAmountTxt2"),
        $supplyPointDepositMonthCheck2 = $("#supplyPointDepositMonthCheck2"),
        $supplyPointDepositQuarterCheck2 = $("#supplyPointDepositQuarterCheck2"),
        $contractTimeYearFive = $("#contractTimeYearFive"),
        $contractTimeYearFirst = $("#contractTimeYearFirst"),
        $contractTimeYearSecond = $("#contractTimeYearSecond"),
        $contractTimeYearThird = $("#contractTimeYearThird"),
        $supplyPointEANTxt = $("#supplyPointEANTxt"),
        $supplyPointEANTxt2 = $("#supplyPointEANTxt2");

    var $inputsFile = $("input[type=file]"),
        $allInputs = $("input[type=text], input[type=checkbox]");

    // checks switch 
    ui.switchchecks("#smallCheck, #homeCheck");
    ui.switchchecks("#resignationUnitMonthCheck, #resignationUnitDayCheck");
    ui.switchchecks("#contractTimeFirstCheck, #contractTimeSecondCheck, #contractTimeThirdCheck", function () {
        $contractTimeYearFive.attr("checked", false);
        $contractTimeYearFirst.attr("checked", false);
        $contractTimeYearSecond.attr("checked", false);
        $contractTimeYearThird.attr("checked", false);
    });
    ui.switchchecks("#contractTimeYearFirst, #contractTimeYearSecond, #contractTimeYearThird, #contractTimeYearFive");
    ui.switchchecks("#supplyPointChangeProviderCheck, #supplyPointChangeCustomerCheck, #supplyPointChangeNewSubscriptionCheck, #supplyPointChangeProviderPriceCheck, #supplyPointOverwriteCheck");
    ui.switchchecks("#supplyPointDepositMonthCheck, #supplyPointDepositQuarterCheck");
    ui.switchchecks("#supplyPointDeliverEmailCheck, #supplyPointDeliverPostCheck");
    ui.switchchecks("#supplyPointPhaseOneCheck, #supplyPointPhaseThreeCheck");
    ui.switchchecks("#supplyPointChangesDeliverEmailCheck, #supplyPointChangesDeliverPostCheck, #supplyPointChangesDeliverWebCheck");
    ui.switchchecks("#supplyPointDepositPaymentTransferCheck, #supplyPointDepositPaymentCollectionCheck, #supplyPointDepositPaymentSlipCheck, #supplyPointDepositPaymentSIPOCheck");
    ui.switchchecks("#supplyPointInvoicePaymentTransferCheck, #supplyPointInvoicePaymentCollectionCheck, #supplyPointInvoicePaymentSlipCheck");

    ui.switchchecks("#supplyPointChangeProviderCheck2, #supplyPointChangeCustomerCheck2, #supplyPointChangeNewSubscriptionCheck2, #supplyPointChangeProviderPriceCheck2, #supplyPointOverwriteCheck2");
    ui.switchchecks("#supplyPointDepositMonthCheck2, #supplyPointDepositQuarterCheck2");
    ui.switchchecks("#supplyPointDeliverEmailCheck2, #supplyPointDeliverPostCheck2");
    ui.switchchecks("#supplyPointPhaseOneCheck2, #supplyPointPhaseThreeCheck2");
    ui.switchchecks("#supplyPointChangesDeliverEmailCheck2, #supplyPointChangesDeliverPostCheck2, #supplyPointChangesDeliverWebCheck2");
    ui.switchchecks("#supplyPointDepositPaymentTransferCheck2, #supplyPointDepositPaymentCollectionCheck2, #supplyPointDepositPaymentSlipCheck2, #supplyPointDepositPaymentSIPOCheck2");
    ui.switchchecks("#supplyPointInvoicePaymentTransferCheck2, #supplyPointInvoicePaymentCollectionCheck2, #supplyPointInvoicePaymentSlipCheck2");

    // replace values
    replacecount("#noticePeriodTxt, #postalCodeTxt, #postalPostalCodeTxt, #supplyPointPostalCodeTxt, #supplyPointPostalCodeTxt2, #contractNumberTxt, #phoneTxt, #houseNumberTxt, #icoTxt, #companyIcoTxt, #postalHouseNumberTxt, #supplyPointHouseNumberTxt, #supplyPointHouseNumberTxt2, #supplyPointBreakerAmountTxt, #supplyPointBreakerAmountTxt2, #supplyPointInvoicePaymentSIPOTxt, #supplyPointInvoicePaymentSIPOTxt2, #supplyPointBankNumberSecondTxt, #supplyPointBankNumberSecondTxt2, #supplyPointBankNumberFirstTxt, #supplyPointBankNumberFirstTxt2, #supplyPointBankNumberCodeTxt, #supplyPointBankNumberCodeTxt2");
    replacecountwithline("#supplyPointYearSubscriptionAmountNTTxt, #supplyPointYearSubscriptionAmountNTTxt2, #supplyPointYearSubscriptionAmountVTTxt, #supplyPointYearSubscriptionAmountVTTxt2, #supplyPointDepositAmountTxt, #supplyPointDepositAmountTxt2");
   

    // autocomplete 
    AutocompleteInput("#titulAutocomplete");
    AutocompleteInput("#titulLastAutocomplete");
    AutocompleteInput("#distributionAutocomplete");
    AutocompleteInput("#distributionAmountAutocomplete");
    AutocompleteInput("#supplierAutocomplete");
    AutocompleteInput("#distributionAutocomplete2");
    AutocompleteInput("#distributionAmountAutocomplete2");
    AutocompleteInput("#supplierAutocomplete2");

    AutocompleteInput("#DivAutoCompleteSellerId");

    // events
    $saveAndDuplicateBtn.click(SaveAndDuplicateClick);
    $saveAndEndBtn.click(SaveAndEndClick);
    $postalAddressBtn.click(PostalAddressBtnClick);
    $copyAddressBtn.click(CopyAddressClick);
    $copySecondAddressBtn.click(CopySecondAddressClick);
    $copyAddressBtn2.click(CopyAddressClick2);
    $copySecondAddressBtn2.click(CopySecondAddressClick2);
    $addNewFileBtn.click(AddNewFileClick);
    $popCloseBtn.click(PopCloseClick);
    $popInputBtn.click(PopInputClick);
    $allInputs.click(CheckIfClientIsSelected);
    $removeFileBtn.live("click", RemoveUploadFile);
    $inputsFile.live("change", OnFileChange);
    $ico.change(OnIcoChange);
    $companyIco.change(OnCompanyIcoChange);
    $homeCheck.change(OnHomeChange);
    $smallCheck.change(OnSmallChange);
    $supplyPointDepositMonthCheck.change(OnChangeAmount);
    $supplyPointDepositQuarterCheck.change(OnChangeAmount);
    $supplyPointDepositMonthCheck2.change(OnChangeAmount2);
    $supplyPointDepositQuarterCheck2.change(OnChangeAmount2);
    $supplyPointEANTxt.change(GetDistributorByEAN);
    $supplyPointEANTxt.change(IsEANExists);
    $supplyPointEANTxt2.change(GetDistributorByEAN2);
    $supplyPointEANTxt2.change(IsEANExists);
    $addSupplyPoint.click(ShowNextSupplyPoint);

    //amount change only if less
    $supplyPointDepositAmountTxt.change(OnsupplyPointDepositAmountTextChanged);
    $supplyPointDepositAmountTxt2.change(OnsupplyPointDepositAmountTextChanged2);

    //distributor change
    $supplyPointNewDistributionTxt.change(OnChangeAmount);
    $supplyPointNewDistributionTxt2.change(OnChangeAmount2);

    //VT change
    $supplyPointYearSubscriptionAmountVTTxt2.change(OnChangeAmount2);
    $supplyPointYearSubscriptionAmountVTTxt.change(OnChangeAmount);

    //NT change
    $supplyPointYearSubscriptionAmountNTTxt.change(OnChangeAmount);
    $supplyPointYearSubscriptionAmountNTTxt2.change(OnChangeAmount2);

    //distribution change 
    $supplyPointDistributionAmountTxt.change(OnChangeAmount);
    $supplyPointDistributionAmountTxt2.change(OnChangeAmount2);

    $("input#txtMarketingList").focus(function () {
        $("input#txtMarketingList").autocomplete("search", "");
    });


    // on load
    if ($homeCheck.is(":checked")) {
        $homeParts.show();
        $smallParts.hide();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
        AutocompleteInput("#distributionAmountAutocomplete");

        GetListMemberData("#divMarketingList", 2);

    } else if ($smallCheck.is(":checked")) {
        $homeParts.hide();
        $smallParts.show();
        $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
        AutocompleteInput("#distributionAmountAutocomplete", "C");

        GetListMemberData("#divMarketingList", 1);
    }


    // functions
    function SaveAndDuplicateClick() {
        if (CheckIfClientIsSelected()) {
            var client = $homeCheck.is(":checked") ? "home" : "small";
            var formSuccess = ValidateForm(client, "electricity");
            if (formSuccess) {
                $popHolder.show();
                $pop.center();
            }
            return false;
        }
        else
            return false;
    }

    function SaveAndEndClick() {
        if (CheckIfClientIsSelected()) {
            var client = $homeCheck.is(":checked") ? "home" : "small";
            var formSuccess = ValidateForm(client, "electricity");
            if (formSuccess)
                $loading.show();
            return formSuccess;
        }
        else
            return false;
    }

    function PostalAddressBtnClick() {
        $postalAddressPart.toggle();
        return false;
    }

    function CopyAddressClick() {
        $supplyPointStreet.val($street.val());
        $supplyPointHouseNumber.val($houseNumber.val());
        $supplyPointOrientationNumber.val($orientationNumber.val());
        $supplyPointPostalCode.val($postalCode.val());
        $supplyPointCountry.val($country.val());
        return false;
    }

    function CopyAddressClick2() {
        $supplyPointStreet2.val($street.val());
        $supplyPointHouseNumber2.val($houseNumber.val());
        $supplyPointOrientationNumber2.val($orientationNumber.val());
        $supplyPointPostalCode2.val($postalCode.val());
        $supplyPointCountry2.val($country.val());
        return false;
    }

    function CopySecondAddressClick() {
        $supplyPointStreet.val($postalStreet.val());
        $supplyPointHouseNumber.val($postalHouseNumber.val());
        $supplyPointOrientationNumber.val($postalOrientationNumber.val());
        $supplyPointPostalCode.val($postalPostalCode.val());
        $supplyPointCountry.val($postalCountry.val());
        return false;
    }

    function CopySecondAddressClick2() {
        $supplyPointStreet2.val($postalStreet.val());
        $supplyPointHouseNumber2.val($postalHouseNumber.val());
        $supplyPointOrientationNumber2.val($postalOrientationNumber.val());
        $supplyPointPostalCode2.val($postalPostalCode.val());
        $supplyPointCountry2.val($postalCountry.val());
        return false;
    }

    function ShowNextSupplyPoint()
    {
        $(this).hide();
        $nextSupplyPoint.slideDown(400);
    }

    function OnIcoChange() {
        var ico = $(this).val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var name = result.name.split(" ");
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        if (name.length > 2)
                            $titul.val(name[name.length - 3]);
                        $firstName.val(name[name.length - 2]);
                        $lastName.val(name[name.length - 1].replace(",", ""));
                        $dic.val(result.dic.substring(2, result.dic.length));
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnCompanyIcoChange() {
        var ico = $(this).val();
        if (ico.length == 8) {
            $loading.show();
            ARES.Retrieve(
                ico,
                function (result) {
                    $loading.hide();
                    if (result.code == 200) {
                        var lastIndexStreet = result.street.lastIndexOf(" ");
                        var street = result.street.substring(0, lastIndexStreet);
                        var houseNumber = result.street.split(" ");
                        houseNumber = houseNumber[houseNumber.length - 1];
                        $companyName.val(result.name);
                        $companyDic.val(result.dic);
                        $street.val(street);
                        $country.val(result.city);
                        $postalCode.val(result.postalCode);
                        $houseNumber.val(houseNumber);
                    }
                    else if (result.code == 404)
                        alert("Záznam nenalezen.");
                    else
                        alert("Někde se stala chyba. Zkuste to znovu.");
                }, function () {
                    $loading.hide();
                    alert("Server ARES není dostupný.");
                }
            );
        }
    }

    function OnHomeChange() {
        if ($(this).is(":checked")) {
            $homeParts.show();
            $smallParts.hide();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", false);
            AutocompleteInput("#distributionAmountAutocomplete");

            //List memberbinding
            GetListMemberData("#divMarketingList", 2);

        }
        else
            $(this).attr("checked", true);
    }

    function OnSmallChange() {
        if ($(this).is(":checked")) {
            $homeParts.hide();
            $smallParts.show();
            $supplyPointInvoicePaymentTransferCheck.attr("checked", true);
            AutocompleteInput("#distributionAmountAutocomplete", "C");

            //List memberbinding
            GetListMemberData("#divMarketingList", 1);

        }
        else
            $(this).attr("checked", true);
    }

    function AddNewFileClick() {
        if (filesCount < 14) {
            $uploadFilesPart.append("<div class=\"row\">" +
                                        "<div class=\"file\">" +
                                            "<div class=\"bgleft\"></div>" +
                                            "<div class=\"files\">" +
                                                "<input type=\"file\" name=\"file" + filesCount + "\" /><input type=\"image\" src=\"img/cross.png\" class=\"removeFile\" />" +
                                            "</div>" +
                                            "<div class=\"bgright\"></div>" +
                                        "</div>" +
                                    "</div>");
            filesCount++;
        }
        return false;
    }

    function RemoveUploadFile() {
        filesCount--;
        $(this).parent().parent().parent().remove();
        return false;
    }

    function OnFileChange() {
        if (this.files[0].size > 5242880) {
            alert("Soubor nesmí být větší než 5MB.");
            ClearInputFile($(this));
        }
        else if (!CheckFileType($(this).val())) {
            alert("Špatný formát souboru. Vyberte prosím jiný soubor.");
            ClearInputFile($(this));
        }
    }

    function ClearInputFile($input) {
        $input.val("");
        $input.replaceWith($(this).clone(true));
    }

    function CheckFileType(value) {
        switch (value.substring(value.lastIndexOf(".") + 1).toLowerCase()) {
            case 'gif': case 'jpg': case 'jpeg': case 'doc': case 'docx': case 'xls': case 'xlsx': case 'png': case 'pdf': case 'mp3': case 'wmv': case 'mov':
                return true;
                break;
            default:
                return false;
                break;
        }
    }

    function PopCloseClick() {
        $popHolder.hide();
    }

    function PopInputClick() {
        $loading.show();
        $popHolder.hide();
    }

    function CheckIfClientIsSelected() {
        if ($(this).attr("id") != "smallCheck" && $(this).attr("id") != "homeCheck")
            if (!$smallCheck.is(":checked") && !$homeCheck.is(":checked")) {
                alert("Musíte vybrat Domácnost nebo Maloodběr.");
                $homeCheck.focus();
                return false;
            }
            else
                return true;
    }

    function AutocompleteInput(containerId, contains) {

        var $container = $(containerId);
        var $input = $container.find("input[type=text]");
        var $hiddenInput = $container.find("input[type=hidden]");
        var $options = $container.find(".options .option");
        var object,
            tags = [];

        $options.each(function () {
            var label = $(this).find(".text").text();
            var value = $(this).find(".value").text();
            object = new Object();
            if (contains) {
                if (label.indexOf(contains) != -1) {
                    object.label = label;
                    object.index = value;
                    tags.push(object);
                }
            }
            else {
                object.label = label;
                object.index = value;
                tags.push(object);
            }

        });

        $input.autocomplete({
            source: tags,
            select: function (event, ui) {
                $hiddenInput.val(ui.item.index);
                if ($hiddenInput.attr("id") == "hdnSellerId") {
                    SellerIdChange($hiddenInput.attr("value"));
                }
            },
            change: function (event, ui) {
                if ($hiddenInput.attr("id") == "supplyPointNewDistributionValue" || $hiddenInput.attr("id") == "supplyPointDistributionAmountValue") {
                    GetDistributorByEAN();
                }
                else if ($hiddenInput.attr("id") == "supplyPointNewDistributionValue2" || $hiddenInput.attr("id") == "supplyPointDistributionAmountValue2") {
                    GetDistributorByEAN2();
                }
            }
        });
    }

    openAutoCompleteOnFocus("#txtMarketingList");
     
    function openAutoCompleteOnFocus(elements) {
        $(elements).focus(function () {
            $(elements).autocomplete("search", "");
        });
    }


    function IsEANExists()
    {
        var ean = $(this).val();
        if (ean.length == 18) {
            Ajax.CallWebMethod(
                "elektrina.aspx/IsEANExists",
                { ean: ean },
                function (response) {
                    if (response)
                        alert("Smlouva se zadaným EAN již existuje.");
                }
                );
        }
    }

    function SellerIdChange(sellerId) {
        if (sellerId.length > 0) {
            Ajax.CallWebMethod(
                "elektrina.aspx/GetNameByUserID",
                { SellerId: sellerId },
                function (response) {
                    if (response.length > 0) {
                        $sellerFirstName.val(response[0]);
                        $sellerLastName.val(response[1]);
                    }
                });
        }
    }

  function OnChangeAmount() {
        CalculateDeposit($supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountNTTxt, $supplyPointYearSubscriptionAmountVTTxt, $supplyPointDistributionAmountTxt, $supplyPointDepositAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, false);
    }

    function OnChangeAmount2() {
        CalculateDeposit($supplyPointNewDistributionTxt2, $supplyPointYearSubscriptionAmountNTTxt2, $supplyPointYearSubscriptionAmountVTTxt2, $supplyPointDistributionAmountTxt2, $supplyPointDepositAmountTxt2, $supplyPointDepositMonthCheck2, $supplyPointDepositQuarterCheck2,false);
    }

  function OnsupplyPointDepositAmountTextChanged() {
        CalculateDeposit($supplyPointNewDistributionTxt, $supplyPointYearSubscriptionAmountNTTxt, $supplyPointYearSubscriptionAmountVTTxt, $supplyPointDistributionAmountTxt, $supplyPointDepositAmountTxt, $supplyPointDepositMonthCheck, $supplyPointDepositQuarterCheck, true);
    }

    function OnsupplyPointDepositAmountTextChanged2() {
        CalculateDeposit($supplyPointNewDistributionTxt2, $supplyPointYearSubscriptionAmountNTTxt2, $supplyPointYearSubscriptionAmountVTTxt2, $supplyPointDistributionAmountTxt2, $supplyPointDepositAmountTxt2, $supplyPointDepositMonthCheck2, $supplyPointDepositQuarterCheck2, true);
    }
    
    function CalculateDeposit(NewDistributor, SubscriptionAmountNT, SubscriptionAmountVT, DistributionAmount, DepositAmount, DepositMonthCheck, DepositQuarterCheck, UpdateOnlyIfLess) {

        if (NewDistributor.val() != "" && DistributionAmount.val() != "" && (SubscriptionAmountNT.val() != "" || SubscriptionAmountVT.val() != "") && (DepositMonthCheck.is(":checked") || DepositQuarterCheck.is(":checked"))) {
            var nt = SubscriptionAmountNT.val() == "" ? 0 : parseFloat(SubscriptionAmountNT.val());
            var vt = SubscriptionAmountVT.val() == "" ? 0 : parseFloat(SubscriptionAmountVT.val());
            var total = DepositAmount.val() != "" ? parseInt(DepositAmount.val()) : 0;
            var depositval = total;
            var success = true;
            switch (NewDistributor.val()) {
                case "PRE Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 5052.14); break;
                        case "C02d": total = (vt * 4402.28); break;
                        case "C03d": total = (vt * 3233.97); break;
                        case "C25d": total = (vt * 4361.11) + (nt * 1893.81); break;
                        case "C26d": total = (vt * 3452.90) + (nt * 1893.81); break;
                        case "C35d": total = (vt * 3289.75) + (nt * 2174.81); break;
                        case "C45d": total = (vt * 2684.38) + (nt * 2242.81); break;
                        case "C55d": total = (vt * 2687.38) + (nt * 2262.81); break;
                        case "C56d": total = (vt * 2667.38) + (nt * 2262.81); break;
                        case "C62d": total = (vt * 2184.86); break;
                        case "D01d": total = (vt * 4211.90); break;
                        case "D02d": total = (vt * 3677.58); break;
                        case "D25d": total = (vt * 4071.09) + (nt * 1780.54); break;
                        case "D26d": total = (vt * 3095.97) + (nt * 1780.54); break;
                        case "D35d": total = (vt * 2752.93) + (nt * 2023.54); break;
                        case "D45d": total = (vt * 2665.93) + (nt * 2160.54); break;
                        case "D55d": total = (vt * 2621.93) + (nt * 2181.54); break;
                        case "D56d": total = (vt * 2621.93) + (nt * 2181.54); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                case "ČEZ Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 4995.15); break;
                        case "C02d": total = (vt * 4436.59); break;
                        case "C03d": total = (vt * 3257.64); break;
                        case "C25d": total = (vt * 4321.91) + (nt * 1888.71); break;
                        case "C26d": total = (vt * 3640.21) + (nt * 1888.71); break;
                        case "C35d": total = (vt * 3358.66) + (nt * 2169.71); break;
                        case "C45d": total = (vt * 2712.30) + (nt * 2237.71); break;
                        case "C55d": total = (vt * 2695.30) + (nt * 2257.71); break;
                        case "C56d": total = (vt * 2695.30) + (nt * 2257.71); break;
                        case "C62d": total = (vt * 2219.45); break;
                        case "D01d": total = (vt * 4524.43); break;
                        case "D02d": total = (vt * 3882.31); break;
                        case "D25d": total = (vt * 4413.03) + (nt * 1792.41); break;
                        case "D26d": total = (vt * 3088.69) + (nt * 1792.41); break;
                        case "D35d": total = (vt * 2785.06) + (nt * 2035.41); break;
                        case "D45d": total = (vt * 2698.06) + (nt * 2172.41); break;
                        case "D55d": total = (vt * 2654.06) + (nt * 2193.41); break;
                        case "D56d": total = (vt * 2654.06) + (nt * 2193.41); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                case "E.ON Distribuce":
                    switch (DistributionAmount.val()) {
                        case "C01d": total = (vt * 4932.80); break;
                        case "C02d": total = (vt * 4417.74); break;
                        case "C03d": total = (vt * 3287.24); break;
                        case "C25d": total = (vt * 4362.92) + (nt * 1899.08); break;
                        case "C26d": total = (vt * 3466.47) + (nt * 1899.08); break;
                        case "C35d": total = (vt * 3310.71) + (nt * 2180.08); break;
                        case "C45d": total = (vt * 2679.65) + (nt * 2248.08); break;
                        case "C55d": total = (vt * 2662.65) + (nt * 2268.08); break;
                        case "C56d": total = (vt * 2662.65) + (nt * 2268.08); break;
                        case "C62d": total = (vt * 2158.38); break;
                        case "D01d": total = (vt * 4157.15); break;
                        case "D02d": total = (vt * 3711.05); break;
                        case "D25d": total = (vt * 4118.47) + (nt * 1785.13); break;
                        case "D26d": total = (vt * 2987.13) + (nt * 1785.13); break;
                        case "D35d": total = (vt * 2751.01) + (nt * 2028.13); break;
                        case "D45d": total = (vt * 2664.01) + (nt * 2165.13); break;
                        case "D55d": total = (vt * 2620.01) + (nt * 2186.13); break;
                        case "D56d": total = (vt * 2620.01) + (nt * 2186.13); break;
                        default:
                            success = false;
                            break;
                    }
                    break;
                default:
                    success = false;
                    break;
            }
            if (success) {
                if (DepositMonthCheck.is(":checked")) {
                    total = parseInt(total / 12);
                }
                else if (DepositQuarterCheck.is(":checked")) {
                    total = parseInt(total / 4);
                }

                total = (Math.round(total / 100) * 100) + 100;
                if (UpdateOnlyIfLess == false) {
                    DepositAmount.val(total);
                }
                else if (UpdateOnlyIfLess == true && depositval < total) {
                    DepositAmount.val(total);
                }
            }
        }
    }

    function GetDistributorByEAN() {
        //var ean = $(this).val();
        
        var ean = $supplyPointEANTxt.val();
        if (ean.length == 18) {
            var prefix = ean.substring(0, 9),
                code = ean.substring(9, 10),
                distributorName;

            if (prefix == "859182400") {
                switch (code) {
                    case "1":
                    case "2":
                        distributorName = "E.ON Distribuce";
                        break;
                    case "3":
                        distributorName = "PRE Distribuce";
                        break;
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                    case "8":
                        distributorName = "ČEZ Distribuce";
                        break;
                }
                var $container = $("#distributionAutocomplete");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];

                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        OnChangeAmount();
                    }
                });
            }
        }
    }

    function GetDistributorByEAN2() {
        //var ean = $(this).val();
        
        var ean = $supplyPointEANTxt2.val();
        if (ean.length == 18) {
            var prefix = ean.substring(0, 9),
                code = ean.substring(9, 10),
                distributorName;

            if (prefix == "859182400") {
                switch (code) {
                    case "1":
                    case "2":
                        distributorName = "E.ON Distribuce";
                        break;
                    case "3":
                        distributorName = "PRE Distribuce";
                        break;
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                    case "8":
                        distributorName = "ČEZ Distribuce";
                        break;
                }
                var $container = $("#distributionAutocomplete2");
                var $input = $container.find("input[type=text]");
                var $hiddenInput = $container.find("input[type=hidden]");
                var $options = $container.find(".options .option");
                var object,
                    tags = [];

                $options.each(function () {
                    var label = $(this).find(".text").text();
                    var value = $(this).find(".value").text();
                    if (label == distributorName) {
                        $hiddenInput.val(value);
                        $input.val(label);
                        OnChangeAmount2();
                    }
                });
            }
        }
    }
    function replacecount(elements) {
        $(elements).keyup(function () {
            this.value = this.value.replace(" ", "").replace(/\D/g, "");
            if (this.id == "companyIcoTxt") $(this).trigger("change");
        });
    }

    function replacecountwithline(elements) {
        $(elements).keyup(function () {

            this.value = this.value.replace(" ", "").replace(/[a-zA-Z]/g, "").replace(".", ",").replace(",,", ",");
            if (this.id == "companyIcoTxt") $(this).trigger("change");

        });
    }
});