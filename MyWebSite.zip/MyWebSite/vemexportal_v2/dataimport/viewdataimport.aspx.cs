﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;


namespace VemexPortal_v2.dataimport
{
    public partial class viewdataimport : PageControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (flupload.HasFile)
            {
                //flupload.PostedFile
                DataImportService.DataImportClient service = new DataImportService.DataImportClient();

                string fileExtension = Path.GetExtension(flupload.PostedFile.FileName);
                string filePath = Server.MapPath("~/") + "ExcelImport/" +Convert.ToString(System.DateTime.Now.Ticks) + fileExtension;
                flupload.SaveAs(filePath);
                HelpControl.AddToLog("File Path : "+filePath);
                string sellerid = LoginControl.LoggedUser().LoginNumber;

                VemexPortal_v2.DataImportService.ImportFile file = new DataImportService.ImportFile()
                {
                    FilePath = filePath,
                    FileName = flupload.PostedFile.FileName,
                    FileSize = flupload.PostedFile.ContentLength,
                    SellerId = sellerid
                };
                service.PostFileAsync(file);
            }
        }
    }
}