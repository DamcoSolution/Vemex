﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace VemexPortal.Controls
{
    public class HelpControl
    {
        public static void AddToLog(string value)
        {
            StreamWriter log;
            string today = DateTime.Now.ToLocalTime().ToString("dd-MM-yyyy");
            string logFile = HttpContext.Current.Server.MapPath("~/Log/log-" + today + ".txt");

            if (!File.Exists(logFile))
                log = new StreamWriter(logFile);
            else
                log = File.AppendText(logFile);

            log.WriteLine(DateTime.Now.ToLocalTime());
            log.WriteLine(value);
            log.WriteLine();
            log.Close();
        }
    }
}