﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VemexPortal.Controls
{
    public class ErrorControl
    {
        public ErrorControl(string error)
        {
            HttpContext.Current.Session["error"] = error;
        }

        public static string GetError(string leftSide, string rightSide)
        {
            string error = string.Empty;
            if (HttpContext.Current.Session["error"] != null)
            {
                error = leftSide + HttpContext.Current.Session["error"].ToString() + rightSide;
                HttpContext.Current.Session["error"] = null;
            }
            return error;
        }
    }
}