﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VemexPortal_v2.Controls;
using VemexPortal_v2.App_Code;

namespace VemexPortal.Controls
{
   

    public class LoginControl
    { 

        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LoginNumber { get; set; }
        public EntityReference ParentCustomer { get; set; }

        public int AccountRoleId { get; set; }

        public static PortalRole Role
        {
            get
            {
                return HttpContext.Current.Session["UserRole"] as PortalRole;
            }
        }

        public static LoginControl LoggedUser()
        {
            LoginControl user = new LoginControl();

            if (HttpContext.Current.Session["userID"] != null)
            {
                Entity contact = ((Entity)HttpContext.Current.Session["userID"]);
                user.Id = contact.Id;
                user.FirstName = contact.Attributes.Contains(Constants.ContactFirstName) ? contact[Constants.ContactFirstName].ToString() : string.Empty;
                user.LastName = contact.Attributes.Contains(Constants.ContactLastName) ? contact[Constants.ContactLastName].ToString() : string.Empty;
                user.LoginNumber = contact.Attributes.Contains(Constants.ContactLogin) ? contact[Constants.ContactLogin].ToString() : string.Empty;
                user.ParentCustomer = contact.Attributes.Contains(Constants.ContactParentCustomerId) ? contact[Constants.ContactParentCustomerId] as EntityReference : null;
                user.AccountRoleId = contact.Attributes.Contains(Constants.ContactAccountRole) ? ((OptionSetValue)contact[Constants.ContactAccountRole]).Value : 0;
                
            }

            return user;
        }

        public static bool IsLogged()
        {
            return (HttpContext.Current.Session["userID"] != null);
        }

        public static bool Login(string loginName, string loginPassword)
        {

            FilterExpression filter = new FilterExpression();
            filter.AddCondition(Constants.ContactLogin, ConditionOperator.Equal, loginName);
            filter.AddCondition(Constants.ContactPassword, ConditionOperator.Equal, loginPassword);

           filter.AddCondition(Constants.ContactAccountRole, ConditionOperator.Equal, Constants.AccountRoleId);

            filter.FilterOperator = LogicalOperator.And;
            ColumnSet col = new ColumnSet(
            
                 new string[] 
                 {
                     Constants.ContactFirstName, 
                     Constants.ContactLastName, 
                    Constants.ContactLastLogin, 
                    Constants.ContactLogin, 
                    Constants.PortalRole, 
                     Constants.ContactParentCustomerId, 
                     Constants.ContactAccountRole 
                 }
            );
           EntityCollection contacts = Service.RetrieveMultiple(Constants.Contact, filter, col, ServiceControl.GetService());
           
            IOrganizationService service = ServiceControl.GetService();
            
            if (contacts.Entities.Count() == 1)
            {
                Entity contact = contacts.Entities.FirstOrDefault();
                contact[Constants.ContactLastLogin] = DateTime.Now;

                
                Service.Update(contact, service);
                HttpContext.Current.Session["userID"] = contact;

                if (contact.Attributes.Contains("cre_portlrole"))
                {
                    EntityReference role = contact["cre_portlrole"] as EntityReference;
                    if (role != null)
                    {
                        HttpContext.Current.Session["UserRole"] = PortalRole.Getrole(role, service);
                    }
                }

                return true;
            }
            else
                return false;

        }

        public static void Logout()
        {

            HttpContext.Current.Session["userID"] = null;

        }

     
    }
}