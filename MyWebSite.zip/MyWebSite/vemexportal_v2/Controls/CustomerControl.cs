﻿using CRM;
using CRM.Helper;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using VemexPortal_v2.Controls;
using VemexPortal_v2.App_Code;

namespace VemexPortal.Controls
{
    public class CustomerControl
    {
        public static Entity ExistsContact(string ico, string street, string houseNumber, string orientationNumber, string psc, string city, string firstName, string lastName, string birthday, string email, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression contactRequestFilter = new FilterExpression();


                
                if (ico != string.Empty)
                    contactRequestFilter.AddCondition("cre_ico", ConditionOperator.Equal, ico);

                contactRequestFilter.AddCondition("firstname", ConditionOperator.Equal, firstName);
                contactRequestFilter.AddCondition("lastname", ConditionOperator.Equal, lastName);
                contactRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                contactRequestFilter.AddCondition("address1_line1", ConditionOperator.Equal, street);
                contactRequestFilter.AddCondition("cre_housenumber", ConditionOperator.Equal, houseNumber);

                if(orientationNumber != string.Empty)
                    contactRequestFilter.AddCondition("cre_orientationnumber", ConditionOperator.Equal, orientationNumber);

                contactRequestFilter.AddCondition("address1_postalcode", ConditionOperator.Equal, psc);
                contactRequestFilter.AddCondition("address1_city", ConditionOperator.Equal, city);
                contactRequestFilter.AddCondition("birthdate", ConditionOperator.Equal, DateTime.Parse(birthday));
                contactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = Service.RetrieveMultiple("contact", contactRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (contactResponse.Entities.Count() == 1)
                    return contactResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }



        public static Entity ExistsContact(string birthday, string email, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression contactRequestFilter = new FilterExpression();

                contactRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                contactRequestFilter.AddCondition("birthdate", ConditionOperator.Equal, DateTime.Parse(birthday));

                contactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = Service.RetrieveMultiple("contact", contactRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (contactResponse.Entities.Count() == 1)
                    return contactResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static Entity ExistsTrustContact(string firstName, string lastName, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression trustContactRequestFilter = new FilterExpression();
                trustContactRequestFilter.AddCondition("firstname", ConditionOperator.Equal, firstName);
                trustContactRequestFilter.AddCondition("lastname", ConditionOperator.Equal, lastName);
                trustContactRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection contactResponse = Service.RetrieveMultiple("contact", trustContactRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (contactResponse.Entities.Count() == 1)
                    return contactResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static Entity ExistsAccount(string ico, string email, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression accountRequestFilter = new FilterExpression();
                accountRequestFilter.AddCondition("cre_ico", ConditionOperator.Equal, ico);
                accountRequestFilter.AddCondition("emailaddress1", ConditionOperator.Equal, email);
                accountRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all contacts by filter
                EntityCollection accountResponse = Service.RetrieveMultiple("account", accountRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (accountResponse.Entities.Count() == 1)
                    return accountResponse.Entities.FirstOrDefault();
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static EntityCollection ExistsOpportunities(int formType, Guid customerId, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression oppRequestFilter = new FilterExpression();
                oppRequestFilter.AddCondition("cre_contracttypecode", ConditionOperator.Equal, formType);
                oppRequestFilter.AddCondition("customerid", ConditionOperator.Equal, customerId);
                oppRequestFilter.AddCondition("statecode", ConditionOperator.Equal, 0);
                oppRequestFilter.FilterOperator = LogicalOperator.And;

                // retrieve all opportunities by filter
                EntityCollection opportunitiesResponse = Service.RetrieveMultiple("opportunity", oppRequestFilter, new ColumnSet(true), service);

                // if count is greater than 1 return collection
                if (opportunitiesResponse.Entities.Count() > 0)
                    return opportunitiesResponse;
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static EntityCollection GetOrdersByOpportunityId(Guid opportunityId, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression quotesRequestFilter = new FilterExpression();
                quotesRequestFilter.AddCondition("opportunityid", ConditionOperator.Equal, opportunityId);

                // retrieve all quotes by filter
                EntityCollection quotesResponse = Service.RetrieveMultiple("quote", quotesRequestFilter, new ColumnSet(true), service);

                // if count is greater than 1 return collection
                if (quotesResponse.Entities.Count() > 0)
                    return quotesResponse;
                else
                    return null;
            }
            catch
            {
                return null;
            }

        }

        public static bool IsExistsEIC(string eic, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression eicRequestFilter = new FilterExpression();
                eicRequestFilter.AddCondition("cre_eic", ConditionOperator.Equal, eic);

                // retrieve all contacts by filter
                EntityCollection eicResponse = Service.RetrieveMultiple("cre_supplypoint", eicRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (eicResponse.Entities.Count() > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }

        public static bool IsExistsEAN(string ean, IOrganizationService service)
        {

            try
            {
                // filter
                FilterExpression eicRequestFilter = new FilterExpression();
                eicRequestFilter.AddCondition("cre_eanopm", ConditionOperator.Equal, ean);

                // retrieve all contacts by filter
                EntityCollection eanResponse = Service.RetrieveMultiple("cre_supplypoint", eicRequestFilter, new ColumnSet(true), service);

                // if count is 1 return true
                if (eanResponse.Entities.Count() > 0)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }

        public static Guid CreateContact(int titul, int titulLast, string firstName, string lastName, string email, string phone, string street, string houseNumber, string orientationNumber, string psc, string city, string birthday, string ico, string dic)
        {

            try
            {

                Entity contact = new Entity("contact");

                if(titul > -1)
                    contact["cre_titulpred"] = new OptionSetValue(titul);

                if(titulLast > -1)
                    contact["cre_titulza"] = new OptionSetValue(titulLast);

                contact["firstname"] = firstName;
                contact["lastname"] = lastName;
                contact["birthdate"] = DateTime.Parse(birthday);
                contact["cre_ico"] = ico;
                contact["cre_dic"] = dic;
                contact["address1_line1"] = street;
                contact["cre_housenumber"] = houseNumber;
                contact["cre_orientationnumber"] = orientationNumber;
                contact["address1_postalcode"] = psc;
                contact["address1_city"] = city;
                contact["address1_addresstypecode"] = new OptionSetValue(1);
                contact["emailaddress1"] = email;
                contact["mobilephone"] = phone;
                contact["address1_addresstypecode"] = new OptionSetValue(3);
                return Service.Create(contact, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateContact in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateLead(string firstName, string lastName, string email, string phone, string street, 
                                        string country, string postalCode, string description,string consumptionGas,string VT,string NT,
                                        string contactTime)
        {
            try
            {
                
                Entity lead = new Entity("lead");
                lead["firstname"] = firstName;
                lead["lastname"] = lastName;
                lead["mobilephone"] = phone;
                lead["emailaddress1"] = email;
                lead["address1_city"] = country;
                lead["address1_line1"] = street;
                lead["address1_postalcode"] = postalCode;
                lead["description"] = description;
                //lead["cre_nt"] = NT;
                //lead["cre_vt"] = VT;
                //lead["cre_mwhannualconsumption"] = consumptionGas;
                // spotreby jsou v double
                DateTime contactTime1;
                try
                {
                    if (contactTime.Contains(" [neurčeno]"))
                    {
                        contactTime = contactTime.Replace(" [neurčeno]", "");
                    }
                    if (contactTime.Contains("[neurčeno] "))
                    {
                        contactTime = contactTime.Replace("[neurčeno] ", "");
                    }
                    contactTime1 = DateTime.Parse(contactTime);
                    if (contactTime1.Year < 1901)
                    {
                        contactTime = "";
                    }
                    
                }
                catch (Exception)
                {
                    contactTime = "";
                }
                if (contactTime != "") lead["cre_contact_time"] = DateTime.Parse(contactTime); 
                return Service.Create(lead, ServiceControl.GetServiceSecond());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateLead in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateAccount(string companyName, string companyIco, string companyDic, string email, string phone, string street, string houseNumber, string orientationNumber, string psc, string city, string registryRecord, Guid trustContactFirstId, Guid trustContactSecondId)
        {

            try
            {

                Entity account = new Entity("account");
                account["name"] = companyName;
                account["cre_ico"] = companyIco;
                account["cre_dic"] = "CZ" + companyDic;
                account["address1_line1"] = street;
                account["cre_housenumber"] = houseNumber;
                account["cre_orientationnumber"] = orientationNumber;
                account["address1_postalcode"] = psc;
                account["address1_city"] = city;
                account["emailaddress1"] = email;
                account["address1_addresstypecode"] = new OptionSetValue(1);
                account["telephone1"] = phone;
                account["cre_commercialregisterrecord"] = registryRecord;

                if (trustContactFirstId != Guid.Empty)
                    account["cre_responsibleperson"] = new EntityReference { LogicalName = "contact", Id = trustContactFirstId };

                if (trustContactSecondId != Guid.Empty)
                    account["cre_responsibleperson2"] = new EntityReference { LogicalName = "contact", Id = trustContactSecondId };
                
                return Service.Create(account, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateAccount in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateTrustContact(string jobtitle, string firstName, string lastName)
        {

            try
            {

                Entity trustContact = new Entity("contact");
                trustContact["jobtitle"] = jobtitle;
                trustContact["firstname"] = firstName;
                trustContact["lastname"] = lastName;
                return Service.Create(trustContact, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateTrustContact in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static bool AssignToAccountTrustContacts(Guid trustContactId, Guid trustContactSecondId, Guid accountId)
        {

            try
            {
                bool ret = false;
                // prvni osoba
                if (trustContactId != Guid.Empty)
                {
                    Entity trustContact = new Entity("contact");
                    trustContact.Id = trustContactId;
                    trustContact["parentcustomerid"] = new EntityReference { LogicalName = "account", Id = accountId };
                    ret = Service.Update(trustContact, ServiceControl.GetService());
                }


                // druha osoba
                if (trustContactSecondId != Guid.Empty)
                {
                    Entity trustContactSecond = new Entity("contact");
                    trustContactSecond.Id = trustContactSecondId;
                    trustContactSecond["parentcustomerid"] = new EntityReference { LogicalName = "account", Id = accountId };
                    ret = ret ? Service.Update(trustContactSecond, ServiceControl.GetService()) : ret;
                }

                return ret;

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: AssignToAccountTrustContact in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;

            }

        }

        public static bool UpdateAccountTrustContacts(Entity account, Guid trustContactFirstId, Guid trustContactSecondId)
        {

            try
            {

                if (trustContactFirstId != Guid.Empty)
                    account["cre_responsibleperson"] = new EntityReference { LogicalName = "contact", Id = trustContactFirstId };
                if (trustContactSecondId != Guid.Empty)
                    account["cre_responsibleperson2"] = new EntityReference { LogicalName = "contact", Id = trustContactSecondId };

                return Service.Update(account, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: UpdateAccountTrustContacts in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;

            }

        }

        public static bool ActivateOpportunity(Guid opportunityId)
        {
            WinOpportunityRequest request = new WinOpportunityRequest();
            Entity opportunityClose = new Entity("opportunityclose");
            opportunityClose.Attributes.Add("opportunityid", new EntityReference("opportunity", opportunityId));
            request.OpportunityClose = opportunityClose;
            request.RequestName = "WinOpportunity";
            OptionSetValue option = new OptionSetValue();
            option.Value = 3;
            request.Status = option;
            

            try
            {
                ServiceControl.GetService().Execute(request);
                return true;
            }
            catch (Exception ex)
            {
                Email.SendError("VemexPortal error", "Error: ActivateOpportunity in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;
            }
        }

        public static bool ActivateQuotesByOpportunity(Guid opportunityId)
        {
            try
            {
                EntityCollection quotes = GetOrdersByOpportunityId(opportunityId, ServiceControl.GetService());

                if (quotes != null)
                    foreach (Entity quote in quotes.Entities)
                    {
                        CloseQuoteRequest request = new CloseQuoteRequest();
                        Entity quoteClose = new Entity("quoteclose");
                        quoteClose.Attributes.Add("quoteid", new EntityReference("quote", quote.Id));
                        request.QuoteClose = quoteClose;
                        request.RequestName = "CloseQuote";
                        OptionSetValue option = new OptionSetValue();
                        option.Value = 5;
                        request.Status = option;

                        try
                        {
                            ServiceControl.GetService().Execute(request);
                            return true;
                        }
                        catch
                        {
                            return false;
                        }
                    }

                return true;
            }
            catch (Exception ex)
            {
                Email.SendError("VemexPortal error", "Error: ActivateQuotesByOpportunity in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;
            }
        }

        public static Guid CreateContract(int contractTypeCode, string contractNumber, string sellerNumberID, string sellerFirstName, string sellerLastName, string signatureDate, bool contractTimeFirstCheck, bool contractTimeSecondCheck, bool contractTimeThirdCheck, string dateTimeFromFirst, string dateTimeToFirst, string productName, int contractTimeYears, bool closedinspaces, string dateTimeFromThird, bool customerResigned, bool generateId, Guid sellerId, string customerLogicalName, Guid customerId)
        {

            try
            {

                Entity opportunity = new Entity("opportunity");
                opportunity["cre_contracttypecode"] = new OptionSetValue(contractTypeCode);
                opportunity["name"] = "Smlouva č." + contractNumber;
                opportunity["cre_contractid"] = contractNumber;

                if (customerId != Guid.Empty)
                {
                    if (customerLogicalName == "account")
                        opportunity["customerid"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };
                    else if (customerLogicalName == "contact")
                        opportunity["customerid"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };
                }

                if (sellerId != Guid.Empty)
                    opportunity["cre_seller"] = new EntityReference { LogicalName = "contact", Id = sellerId };

                opportunity["cre_sellerid"] = sellerNumberID;
                opportunity["cre_sellerfirstname"] = sellerFirstName;
                opportunity["cre_sellerlastname"] = sellerLastName;
                opportunity["cre_dateofsignature"] = DateTime.Parse(signatureDate);
                opportunity["cre_closedinspaces"] = closedinspaces;
                opportunity["cre_customer_resigned"] = customerResigned;
                opportunity["cre_productname"] = productName;
                opportunity["cre_generateid"] = generateId;

                if (dateTimeFromFirst != string.Empty)
                    opportunity["cre_fromfixedtermcontract"] = DateTime.Parse(dateTimeFromFirst);

                if (dateTimeToFirst != string.Empty)
                    opportunity["cre_tofixedtermcontract"] = DateTime.Parse(dateTimeToFirst);

                if (contractTimeFirstCheck)
                {
                    opportunity["cre_fixedtermcontract"] = true;
                }
                else if (contractTimeSecondCheck)
                {
                    opportunity["cre_fixedtermcontract1"] = true;
                    opportunity["cre_fixedtermcontractyears"] = new OptionSetValue(contractTimeYears);
                }
                else if (contractTimeThirdCheck)
                {
                    opportunity["cre_indefiniteperiodcontract"] = true;
                    opportunity["cre_fromindefiniteperiodcontract"] = DateTime.Parse(dateTimeFromThird);
                }

                return Service.Create(opportunity, ServiceControl.GetService());
            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateContract in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateSupplyPoint(string name, string street, string city, string psc, string houseNumber, string orientationNumber, 
            string ean, string eic, int contractReason, int originalProvider, int distributorGas, int distributorElectricity, string annualConsumptionVT, 
            string annualConsumptionNT, int advancePeriod, int advancePayment, int paymentScheduleDelivery, int informationDelivery, int paymentTypeAdvances, 
            int paymentType, int connectionType, int distributionRate, string breakerValue, string bankNumberFirstPart, string bankNumberSecondPart, string bankCode, 
            string sipoNumber, string customerLogicalName, Guid customerId, Guid opportunityId, int contractTypeCode)
        {

            try
            {              
                Entity supplyPoint = new Entity("cre_supplypoint");
                supplyPoint["cre_name"] = name;
                supplyPoint["cre_street"] = street;
                supplyPoint["cre_city"] = city;
                supplyPoint["cre_postalcode"] = psc;
                supplyPoint["cre_housenumber"] = houseNumber;
                supplyPoint["cre_orientationnumber"] = orientationNumber;
                supplyPoint["cre_eanopm"] = ean;
                supplyPoint["cre_eic"] = eic;

                if (contractReason > -1)
                    supplyPoint["cre_contractreason"] = new OptionSetValue(contractReason);

                if (originalProvider > -1)
                    supplyPoint["cre_originaldistributor"] = new OptionSetValue(originalProvider);

                if (distributorGas > -1)
                    supplyPoint["cre_distributorgas"] = new OptionSetValue(distributorGas);

                if (distributorElectricity > -1)
                    supplyPoint["cre_distributorelectricity"] = new OptionSetValue(distributorElectricity);


                if (contractTypeCode == 171140001)
                {
                    supplyPoint["cre_annualconsumption_gas"] = annualConsumptionVT;
                    
                }
                else
                    supplyPoint["cre_annualconsumptionvt"] = annualConsumptionVT;

                supplyPoint["cre_annualconsumptionnt"] = annualConsumptionNT;

                if (advancePeriod > -1)
                    supplyPoint["cre_advanceperiod"] = new OptionSetValue(advancePeriod);

                supplyPoint["cre_advancepayment"] = new Money(advancePayment);

                if (paymentScheduleDelivery > -1)
                    supplyPoint["cre_paymentscheduledelivery"] = new OptionSetValue(paymentScheduleDelivery);
                if (informationDelivery > -1)
                    supplyPoint["cre_informationdelivery"] = new OptionSetValue(informationDelivery);

                if (paymentTypeAdvances > -1)
                    supplyPoint["cre_paymenttypeadvances"] = new OptionSetValue(paymentTypeAdvances);
                if (paymentType > -1)
                    supplyPoint["cre_paymenttype"] = new OptionSetValue(paymentType);
                if (connectionType > -1)
                    supplyPoint["cre_connectiontype"] = new OptionSetValue(connectionType);
                if (distributionRate > -1)
                    supplyPoint["cre_distributionrate"] = new OptionSetValue(distributionRate);
            
                supplyPoint["cre_breakervalue"] = breakerValue;
                supplyPoint["cre_accountnumberp1"] = bankNumberFirstPart;
                supplyPoint["cre_accountnumberp2"] = bankNumberSecondPart;
                supplyPoint["cre_bankcode"] = bankCode;
                supplyPoint["cre_siponumber"] = sipoNumber;

                if (customerLogicalName == "account")
                    supplyPoint["cre_account"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };
                else if (customerLogicalName == "contact")
                    supplyPoint["cre_contact"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };

                supplyPoint["cre_opportunity"] = new EntityReference { LogicalName = "opportunity", Id = opportunityId };

                return Service.Create(supplyPoint, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateSupplyPoint in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static Guid CreateVerifyForm(string trustFirstTitle, string trustFirstFirstName, string trustFirstLastName, string trustSecondTitle, string trustSecondFirstName, string trustSecondLastName, string companyDic, string companyIco, string companyName, string dic, 
            string ico, string email, int titul, string firstName, string lastName, int titulLast, string birthdate, string phone, 
            string recordOR, string street, string city, string psc, string shipStreet, string shipCity, string shipPsc, 
            string shipHouseNumber, string shipOrientationNumber, string supplyPointStreet, string supplyPointCity, string supplyPointPsc,
            string supplyPointHouseNumber, string supplyPointOrientationNumber, string houseNumber, string orientationNumber, string name,
            string ean, string eic, bool contractTimeFirstCheck, bool contractTimeSecondCheck, bool contractTimeThirdCheck, 
            string dateTimeFromFirst, string dateTimeFromThird, string dateTimeToFirst, string productName, int contractTimeYears,
            int contractReason, int originalProvider, int distributorGas, int distributorElectricity, string annualConsumptionVT, 
            string annualConsumptionNT, int advancePeriod, int advancePayment, int paymentScheduleDelivery, int informationDelivery, 
            int paymentTypeAdvances, int paymentType, int connectionType, int distributionRate, string breakerValue,
            string bankNumberFirstPart, string bankNumberSecondPart, string bankCode, string sipoNumber, int resignationLength, 
            bool resignationUnit, bool customerResigned, bool sameTrustPerson, string customerLogicalName, string contractNumber, 
            Guid customerId, Guid opportunityId, Guid supplyPointId, Guid trustFirstId, Guid trustSecondId, Guid lastTrustFirstId, 
            Guid lastTrustSecondId, Guid sellerId, int contractTypeCode,string signatureDate)
        {

            try
            {

                Entity verifyForm = new Entity("cre_verifyform");
                verifyForm["cre_accountnumberp1"] = bankNumberFirstPart;
                verifyForm["cre_accountnumberp2"] = bankNumberSecondPart;
                verifyForm["cre_bankcode"] = bankCode;
                verifyForm["cre_advancepayment"] = new Money(advancePayment);

                if (sellerId != Guid.Empty)
                    verifyForm["cre_seller"] = new EntityReference { LogicalName = "contact", Id = sellerId };

                if (advancePeriod > -1)
                    verifyForm["cre_advanceperiod"] = new OptionSetValue(advancePeriod);

                if (contractTypeCode == 171140001)
                {
                    verifyForm["cre_annualconsumption_gas"] = annualConsumptionVT;
                    if (!string.IsNullOrEmpty(lastName))
                    {
                        verifyForm["cre_exemption_tax"] = true;
                    }
                }
                else
                    verifyForm["cre_annualconsumptionvt"] = annualConsumptionVT;

                verifyForm["cre_annualconsumptionnt"] = annualConsumptionNT;

                if (birthdate != string.Empty)
                {
                    DateTime Birthday;
                    if (DateTime.TryParse(birthdate, out Birthday))
                        verifyForm["cre_birthdate"] = Birthday;
                }
                verifyForm["cre_breakervalue"] = breakerValue;
                verifyForm["cre_city"] = city;
                verifyForm["cre_commercialregisterrecord"] = recordOR;
                verifyForm["cre_company_dic"] = companyDic;
                verifyForm["cre_company_ico"] = companyIco;
                verifyForm["cre_company_name"] = companyName;
                verifyForm["cre_connectiontype"] = new OptionSetValue(connectionType);
                verifyForm["cre_afterverificationdesc"] = new OptionSetValue(contractReason);
                verifyForm["cre_dic"] = dic;
                verifyForm["cre_ico"] = ico;
                verifyForm["cre_distributionrate"] = new OptionSetValue(distributionRate);

                if (distributorElectricity > -1)
                    verifyForm["cre_distributorelectricity"] = new OptionSetValue(distributorElectricity);

                if (distributorGas > -1)
                    verifyForm["cre_distributorgas"] = new OptionSetValue(distributorGas);

                verifyForm["cre_eanopm"] = ean;
                verifyForm["cre_eic"] = eic;
                verifyForm["cre_email"] = email;
                if (titul > -1)
                    verifyForm["cre_titulpred"] = new OptionSetValue(titul);
                verifyForm["cre_firstname"] = firstName;
                verifyForm["cre_lastname"] = lastName;
                if (titulLast > -1)
                    verifyForm["cre_titulza"] = new OptionSetValue(titulLast);
                verifyForm["cre_name"] = name;
                verifyForm["cre_phone"] = phone;
                verifyForm["cre_street"] = street;
                verifyForm["cre_city"] = city;
                verifyForm["cre_psc"] = psc;
                verifyForm["cre_housenumber"] = houseNumber;
                verifyForm["cre_orientationnumber"] = orientationNumber;
                verifyForm["cre_ship_street"] = shipStreet;
                verifyForm["cre_ship_city"] = shipCity;
                verifyForm["cre_ship_psc"] = shipPsc;
                verifyForm["cre_ship_housenumber"] = shipHouseNumber;
                verifyForm["cre_ship_orientationnumber"] = shipOrientationNumber;
                verifyForm["cre_supplypoint_street"] = supplyPointStreet;
                verifyForm["cre_supplypoint_city"] = supplyPointCity;
                verifyForm["cre_supplypoint_psc"] = supplyPointPsc;
                verifyForm["cre_supplypoint_housenumber"] = supplyPointHouseNumber;
                verifyForm["cre_supplypoint_orientationnumber"] = supplyPointOrientationNumber;

                if(originalProvider > -1)
                    verifyForm["cre_originaldistributor"] = new OptionSetValue(originalProvider);

                verifyForm["cre_jobtitle"] = trustFirstTitle;
                verifyForm["cre_responsibleperson_firstname"] = trustFirstFirstName;
                verifyForm["cre_responsibleperson_lastname"] = trustFirstLastName;
                verifyForm["cre_jobtitle2"] = trustSecondTitle;
                verifyForm["cre_responsibleperson_firstname2"] = trustSecondFirstName;
                verifyForm["cre_responsibleperson_lastname2"] = trustSecondLastName;
                verifyForm["cre_customer_resigned"] = customerResigned;
                verifyForm["cre_trustedpersonchanged"] = sameTrustPerson;
                verifyForm["cre_resignation_length"] = resignationLength;
                verifyForm["cre_resignation_unit"] = resignationUnit;
                verifyForm["cre_productname"] = productName;
                verifyForm["cre_contractid"] = contractNumber;

                if (dateTimeFromFirst != string.Empty)
                {
                    DateTime TimeFromFirstdate;
                    if (DateTime.TryParse(dateTimeFromFirst, out TimeFromFirstdate))
                        verifyForm["cre_fromfixedtermcontract"] = TimeFromFirstdate;
                }

                if (dateTimeToFirst != string.Empty)
                {
                    DateTime dateTimeToFirstdate;
                    if (DateTime.TryParse(dateTimeToFirst, out dateTimeToFirstdate))
                        verifyForm["cre_tofixedtermcontract"] = dateTimeToFirstdate;
                }
                
                if (contractTimeFirstCheck)
                {
                    verifyForm["cre_fixedtermcontract"] = true;
                }
                else if (contractTimeSecondCheck)
                {
                    verifyForm["cre_fixedtermcontract1"] = true;
                    verifyForm["cre_fixedtermcontractyears"] = new OptionSetValue(contractTimeYears);
                }
                else if (contractTimeThirdCheck)
                {
                    verifyForm["cre_indefiniteperiodcontract"] = true;

                    if (!string.IsNullOrEmpty(dateTimeFromThird))
                    {
                        DateTime dateTimeFromThirddate;
                        if (DateTime.TryParse(dateTimeFromThird, out dateTimeFromThirddate))
                            verifyForm["cre_fromindefiniteperiodcontract"] = dateTimeFromThirddate;
                    }
                }

                if (paymentScheduleDelivery > -1)
                    verifyForm["cre_paymentscheduledelivery"] = new OptionSetValue(paymentScheduleDelivery);
                if (informationDelivery > -1)
                    verifyForm["cre_informationdelivery"] = new OptionSetValue(informationDelivery);

                if (paymentTypeAdvances > -1)
                    verifyForm["cre_paymenttypeadvances"] = new OptionSetValue(paymentTypeAdvances);
                if (paymentType > -1)
                    verifyForm["cre_paymenttype"] = new OptionSetValue(paymentType);
                if (connectionType > -1)
                    verifyForm["cre_connectiontype"] = new OptionSetValue(connectionType);
                if (distributionRate > -1)
                    verifyForm["cre_distributionrate"] = new OptionSetValue(distributionRate);
               
                verifyForm["cre_breakervalue"] = breakerValue;
                verifyForm["cre_accountnumberp1"] = bankNumberFirstPart;
                verifyForm["cre_accountnumberp2"] = bankNumberSecondPart;
                verifyForm["cre_bankcode"] = bankCode;
                verifyForm["cre_siponumber"] = sipoNumber;

                if (customerLogicalName == "account")
                    verifyForm["cre_account"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };
                else if (customerLogicalName == "contact")
                    verifyForm["cre_contact"] = new EntityReference { LogicalName = customerLogicalName, Id = customerId };

                verifyForm["cre_supplypoint"] = new EntityReference { LogicalName = "cre_supplypoint", Id = supplyPointId };
                verifyForm["cre_opportunity"] = new EntityReference { LogicalName = "opportunity", Id = opportunityId };

                if (trustFirstId != Guid.Empty)
                    verifyForm["cre_responsibleperson"] = new EntityReference { LogicalName = "contact", Id = trustFirstId };

                if (trustSecondId != Guid.Empty)
                    verifyForm["cre_responsibleperson2"] = new EntityReference { LogicalName = "contact", Id = trustSecondId };

                if (lastTrustFirstId != Guid.Empty)
                    verifyForm["cre_lastresponsibleperson"] = new EntityReference { LogicalName = "contact", Id = lastTrustFirstId };

                if (lastTrustSecondId != Guid.Empty)
                    verifyForm["cre_lastresponsibleperson2"] = new EntityReference { LogicalName = "contact", Id = lastTrustSecondId };

                //Adding Signature Date on 19 Nov 2013
                if (signatureDate != string.Empty)
                {
                    DateTime dateofSignature;
                    if (DateTime.TryParse(signatureDate, out dateofSignature))
                        verifyForm["cre_dateofsignature"] = dateofSignature;
                }

                return Service.Create(verifyForm, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateVerifyForm in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }

        public static bool AddAnnotation(HttpPostedFile file, string objectLogicalName, Guid objectId)
        {

            try
            {

                BinaryReader binaryReader = new BinaryReader(file.InputStream);
                byte[] fileBytes = binaryReader.ReadBytes(file.ContentLength);

                Entity annotation = new Entity("annotation");
                annotation["subject"] = Path.GetFileName(file.FileName);
                annotation["filename"] = Path.GetFileName(file.FileName);
                annotation["isdocument"] = true;
                annotation["documentbody"] = Convert.ToBase64String(fileBytes);
                annotation["mimetype"] = file.ContentType;
                annotation["objectid"] = new EntityReference(objectLogicalName, objectId);
                Service.Create(annotation, ServiceControl.GetService());
                return true;

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: AddAnnotation in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return false;

            }

        }

        public static Guid CreateCustomerAddress(string name, string street, string cpco, string psc, string city, string parentLogicalName, Guid parentId)
        {

            try
            {

                Entity address = new Entity("customeraddress");
                address["parentid"] = new EntityReference { LogicalName = parentLogicalName, Id = parentId };
                address["name"] = name;
                address["addresstypecode"] = new OptionSetValue(1);
                address["line1"] = street + " " + cpco;
                address["postalcode"] = psc;
                address["city"] = city;
                return Service.Create(address, ServiceControl.GetService());

            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateCustomerAddress in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }


        public static Guid CreateUpdateContact(int titul, int titulLast, string firstName, string lastName, string email, string phone, DateTime? date,
            string userid, string password, Guid? entityid, Guid ParentAccountid, Guid RoleId, int accountRoleid)
        {

            try
            {
                Entity contact = null;
                if (entityid != null)
                {
                    contact = ServiceControl.GetService().Retrieve(Constants.Contact, entityid.Value, new ColumnSet(true));
                }
                else
                {
                    contact = new Entity(Constants.Contact);
                }

                if (titul > -1)
                    contact[Constants.ContactTitle] = new OptionSetValue(titul);

                if (titulLast > -1)
                    contact[Constants.ContactTitleLast] = new OptionSetValue(titulLast);

                contact[Constants.ContactFirstName] = firstName;
                contact[Constants.ContactLastName] = lastName;
                contact[Constants.ContactBirthDate] = date;
                contact[Constants.ContactEmail] = email;
                contact[Constants.ContactMobile] = phone;
                contact[Constants.ContactAccountRole] = new OptionSetValue(accountRoleid);
                var currentuser = LoginControl.LoggedUser();
                contact["cre_owner"] = new EntityReference(Constants.Contact, currentuser.Id);

                if (accountRoleid == Constants.AccountRoleId)
                {

                    contact[Constants.ContactLogin] = userid;
                    contact[Constants.ContactPassword] = password;

                    if (RoleId != Guid.Empty)
                    {
                        contact[Constants.PortalRole] = new EntityReference(Constants.PortalRole, RoleId);
                    }
                    if (ParentAccountid != Guid.Empty)
                    {
                        contact["parentcustomerid"] = new EntityReference(Constants.Account, ParentAccountid);
                    }
                }
                else
                {
                    //Adding vemex Account
                    contact["parentcustomerid"] = new EntityReference(Constants.Account, AccountControl.GetOrAddAccountByName("Vemex"));
                }

                if (entityid == null)
                {
                    Guid contactid = Service.Create(contact, ServiceControl.GetService());
                    if (contactid != Guid.Empty && ParentAccountid != null)
                    {
                        AccountControl.UpdateUserId(ParentAccountid);
                    }
                    return contactid;
                }
                else
                {
                    //     Service.Update(contact, ServiceControl.GetService());
                    ServiceControl.GetService().Update(contact);
                    return entityid.Value;
                }
            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: CreateContact in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return Guid.Empty;

            }

        }
    }
}