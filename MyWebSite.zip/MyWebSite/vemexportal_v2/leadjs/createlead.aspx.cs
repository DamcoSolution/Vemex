﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;

namespace VemexPortal_v2.leadjs
{
    public partial class createlead : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string firstName = Request.QueryString["firstName"];
            string lastName = Request.QueryString["lastName"];
            string email = Request.QueryString["email"];
            string phone = Request.QueryString["phone"];
            string message = Request.QueryString["message"];
            string contactDate = Request.QueryString["contactDate"];
            string country = Request.QueryString["country"];
            string consumptionElectricityNT = Request.QueryString["consumptionelectricitynt"];
            string consumptionElectricityVT = Request.QueryString["consumptionelectricityvt"];
            string consumptionGas = Request.QueryString["consumptiongas"];
            string callback = Request.QueryString["callback"];

            if (!String.IsNullOrEmpty(firstName) && !String.IsNullOrEmpty(lastName))
            {
                string description = "";
                if (!String.IsNullOrEmpty(consumptionGas))
                    description += "Plánovaná roční spotřeba plynu: " + consumptionGas + " MWh\n";
                if (!String.IsNullOrEmpty(consumptionElectricityVT))
                    description += "Plánovaná roční spotřeba elektřiny VT: " + consumptionElectricityVT + " MWh\n";
                if (!String.IsNullOrEmpty(consumptionElectricityNT))
                    description += "Plánovaná roční spotřeba elektřiny NT: " + consumptionElectricityNT + " MWh\n";
                if (!String.IsNullOrEmpty(message))
                    description += "Zpráva:\n" + message;
                if (!String.IsNullOrEmpty(contactDate))
                    description += "\nKontaktujte mě: " + contactDate;

                Guid _leadId = CustomerControl.CreateLead(
                    firstName,
                    lastName,
                    email,
                    phone,
                    "",
                    country,
                    "",
                    description, 
                    consumptionGas, 
                    consumptionElectricityVT, 
                    consumptionElectricityNT, 
                    contactDate
                    );

                if (_leadId != Guid.Empty)
                    Response.Write(callback + "({\"success\":1});");
                else
                    Response.Write(callback + "({\"success\":0});");
            }
            else
                Response.Write(callback + "({\"success\":0});");
        }
    }
}