﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class VerifyForm
    {
        public static Guid CreateVerifyForm(
            bool acccont,
            int titulpred,//171 140 000
            string firstname,
            string lastname,
            string birthdate,
            int titulza,//171 140 000
            string ico,
            string dic,
            string company_name,
            string company_ico,
            string company_dic,
            string jobtitle,
            string responsibleperson_firstname,
            string responsibleperson_lastname,
            string jobtitle2,
            string responsibleperson_firstname2,
            string responsibleperson_lastname2,
            string email,
            string phone,
            string city,
            string street,
            string housenumber,
            string orientationnumber,
            string psc,
            string commercialregisterrecord,
            string ship_street,
            string ship_housenumber,
            string ship_orientationnumber,
            string ship_city,
            string ship_psc,
            bool fixedtermcontract,
            string fromfixedtermcontract,
            string tofixedtermcontract,
            bool fixedtermcontract1,
            int fixedtermcontractyears, //171 140 001
            bool indefiniteperiodcontract,
            string fromindefiniteperiodcontract,
            string productname,
            string supplypoint_street,
            string supplypoint_housenumber,
            string supplypoint_orientationnumber,
            string supplypoint_city,
            string supplypoint_psc,
            string eanopm,
            string eic,
            int originaldistributor,//171 140 001
            int distributorelectricity,//171 140 001
            int distributorgas,//171 140 001
            string annualconsumptionnt,
            string annualconsumptionvt,
            string breakervalue,
            int distributionrate,//171 140 001
            int connectiontype,//171 140 001
            int advanceperiod,//171 140 001
            Money advancepayment,
            int paymentscheduledelivery,//171 140 001
            int informationdelivery,//171 140 001
            int paymenttypeadvances,//171 140 001
            int paymenttype,//171 140 001
            string siponumber,
            string accountnumberp1,
            string accountnumberp2,
            string bankcode,
            bool customer_resigned,
            int resignation_length,
            bool resignation_unit,
            int contractreason,
            string errorstring,
            string resignation,
            Money individualprice,
            string importnumber,
            string auctionnumber,

            string seller_id_auction,
            bool payment_of_commission, //bool 
            string reason_of_commission,
            string supplypoint_number,
            string capacity_for_day,
            string billingperiod,
            string real_consumption,

            Guid customerid,
            string customerLogicalName,

            Guid opportunity,
            string opportunityLogicalName,

            Guid supplyPoint,
            string supplyPointLogicalName,

            Guid p1,
            string p1LogicalName,

            Guid p2,
            string p2LogicalName,

            Guid contactID,
            string contactLogicalName,

            int contacttitle1person1,
            int contacttitle2person1,
            int genderscompany1,

            int contacttitle1person2,
            int contacttitle2person2,
            int genderscopmany2,

            int sexperson,

            int contacttitle1,
            int contacttitle2,
            string contactfirstname,
            string contactlastname,
            int contactgenders,

            Money individualpricent,
            Money stableprice,
            Guid seller_Guid,
            string dateofsignature,

            string auction_portal_name,
            string auction_date
        
            )
        {
            try
            {
                Entity verifyform = new Entity("cre_verifyform");

                if (dateofsignature != "") verifyform["cre_dateofsignature"] = DateTime.Parse(dateofsignature);
                if (auction_date != "") verifyform["cre_auction_date"] = DateTime.Parse(auction_date);
                verifyform["cre_auction_portal_name"] = auction_portal_name;

                if (acccont == true)
                {

                    if (eic != "" && lastname != "")
                    {
                        verifyform["cre_exemption_tax"] = true;
                    }

                    verifyform["cre_account"] = new EntityReference { LogicalName = customerLogicalName, Id = customerid };

                    if (supplypoint_orientationnumber == "") verifyform["cre_name"] = company_name + " - " + supplypoint_street + " " + supplypoint_housenumber + ", " + supplypoint_city;
                    else verifyform["cre_name"] = company_name + " - " + supplypoint_street + " " + supplypoint_housenumber + "/" + supplypoint_orientationnumber + ", " + supplypoint_city;
                    
                    verifyform["cre_company_name"] = company_name;
                    verifyform["cre_company_ico"] = company_ico;
                    verifyform["cre_company_dic"] = company_dic;

                    verifyform["cre_jobtitle"] = jobtitle;
                    verifyform["cre_responsibleperson_firstname"] = responsibleperson_firstname;
                    verifyform["cre_responsibleperson_lastname"] = responsibleperson_lastname;
                    verifyform["cre_jobtitle2"] = jobtitle2;
                    verifyform["cre_responsibleperson_firstname2"] = responsibleperson_firstname2;
                    verifyform["cre_responsibleperson_lastname2"] = responsibleperson_lastname2;
                    
                    verifyform["cre_contacttitle1person1"] = new OptionSetValue(contacttitle1person1);
                    verifyform["cre_contacttitle2person1"] = new OptionSetValue(contacttitle2person1);
                    verifyform["cre_genderscompany1"] = new OptionSetValue(genderscompany1);
                    
                    verifyform["cre_contacttitle1person2"] = new OptionSetValue(contacttitle1person2);
                    verifyform["cre_contacttitle2person2"] = new OptionSetValue(contacttitle2person2);
                    verifyform["cre_genderscopmany2_2"] = new OptionSetValue(genderscopmany2);
                    
                    verifyform["cre_contacttitle1"] = new OptionSetValue(contacttitle1);
                    verifyform["cre_contacttitle2"] = new OptionSetValue(contacttitle2);
                    
                    verifyform["cre_contactgenders"] = new OptionSetValue(contactgenders);

                    verifyform["cre_contactfirstname"] = contactfirstname;
                    verifyform["cre_contactlastname"] = contactlastname;

                    if (contactLogicalName != "")
                        verifyform["cre_contactperson"] = new EntityReference { LogicalName = contactLogicalName, Id = contactID };//navayat kontakt
                
                    if (p1LogicalName != "")
                        verifyform["cre_lastresponsibleperson"] = new EntityReference { LogicalName = p1LogicalName, Id = p1 };
                    if (p2LogicalName != "")
                        verifyform["cre_lastresponsibleperson2"] = new EntityReference { LogicalName = p2LogicalName, Id = p2 };
                }
                else
                {
                    verifyform["cre_contact"] = new EntityReference { LogicalName = customerLogicalName, Id = customerid };


                    if (supplypoint_orientationnumber == "") verifyform["cre_name"] = firstname + " " + lastname + " - " + supplypoint_street + " " + supplypoint_housenumber + ", " + supplypoint_city;
                    else verifyform["cre_name"] = firstname + " " + lastname + " - " + supplypoint_street + " " + supplypoint_housenumber + "/" + supplypoint_orientationnumber + ", " + supplypoint_city;
               
                    
                    verifyform["cre_firstname"] = firstname;
                    verifyform["cre_lastname"] = lastname;
                    if (birthdate != "") verifyform["cre_birthdate"] = DateTime.Parse(birthdate);
                    if (titulpred >= 171140000) verifyform["cre_titulpred"] = new OptionSetValue(titulpred);

                    if (titulza >= 171140000) verifyform["cre_titulza"] = new OptionSetValue(titulza);

                    verifyform["cre_gendersperson"] = new OptionSetValue(sexperson);
                    
                    verifyform["cre_ico"] = ico;
                    verifyform["cre_dic"] = dic;
                }
                verifyform["cre_opportunity"] = new EntityReference { LogicalName = opportunityLogicalName, Id = opportunity};
                verifyform["cre_supplypoint"] = new EntityReference { LogicalName = supplyPointLogicalName, Id = supplyPoint };





                verifyform["cre_email"] = email;
                verifyform["cre_phone"] = phone;
                verifyform["cre_commercialregisterrecord"] = commercialregisterrecord;

                verifyform["cre_city"] = city;
                verifyform["cre_street"] = street;
                verifyform["cre_housenumber"] = housenumber;
                verifyform["cre_orientationnumber"] = orientationnumber;
                verifyform["cre_psc"] = psc;

                if (city != ship_city || street != ship_street || housenumber != ship_housenumber || orientationnumber != ship_orientationnumber || psc != ship_psc)
                {
                    verifyform["cre_ship_street"] = ship_street;
                    verifyform["cre_ship_housenumber"] = ship_housenumber;
                    verifyform["cre_ship_orientationnumber"] = ship_orientationnumber;
                    verifyform["cre_ship_city"] = ship_city;
                    verifyform["cre_ship_psc"] = ship_psc;
                }

                verifyform["cre_fixedtermcontract"] = fixedtermcontract;
                if (fromfixedtermcontract != "") verifyform["cre_fromfixedtermcontract"] = DateTime.Parse(fromfixedtermcontract);
                if (tofixedtermcontract != "") verifyform["cre_tofixedtermcontract"] = DateTime.Parse(tofixedtermcontract);
                verifyform["cre_fixedtermcontract1"] = fixedtermcontract1;
                verifyform["cre_fixedtermcontractyears"] = new OptionSetValue(fixedtermcontractyears);
                verifyform["cre_indefiniteperiodcontract"] = indefiniteperiodcontract;
                if (fromindefiniteperiodcontract != "") verifyform["cre_fromindefiniteperiodcontract"] = DateTime.Parse(fromindefiniteperiodcontract);
                
                //if (productname=="")
                //    verifyform["cre_productname"] = "Individual";
                //else
                    verifyform["cre_productname"] = productname;

                verifyform["cre_supplypoint_street"] = supplypoint_street;
                verifyform["cre_supplypoint_housenumber"] = supplypoint_housenumber;
                verifyform["cre_supplypoint_orientationnumber"] = supplypoint_orientationnumber;
                verifyform["cre_supplypoint_city"] = supplypoint_city;
                verifyform["cre_supplypoint_psc"] = supplypoint_psc;
                verifyform["cre_eanopm"] = eanopm;
                verifyform["cre_eic"] = eic;
                verifyform["cre_originaldistributor"] = new OptionSetValue(originaldistributor);
                verifyform["cre_distributorelectricity"] = new OptionSetValue(distributorelectricity);
                verifyform["cre_distributorgas"] = new OptionSetValue(distributorgas);
                verifyform["cre_annualconsumptionnt"] = annualconsumptionnt;
                verifyform["cre_annualconsumptionvt"] = annualconsumptionvt;

                if (eic != "")
                    verifyform["cre_annualconsumption_gas"] = annualconsumptionvt;

                verifyform["cre_breakervalue"] = breakervalue;
                verifyform["cre_distributionrate"] = new OptionSetValue(distributionrate);
                verifyform["cre_connectiontype"] = new OptionSetValue(connectiontype);
                verifyform["cre_advanceperiod"] = new OptionSetValue(advanceperiod);
                verifyform["cre_advancepayment"] = advancepayment;
                verifyform["cre_paymentscheduledelivery"] = new OptionSetValue(paymentscheduledelivery);
                verifyform["cre_informationdelivery"] = new OptionSetValue(informationdelivery);
                verifyform["cre_paymenttypeadvances"] = new OptionSetValue(paymenttypeadvances);
                verifyform["cre_paymenttype"] = new OptionSetValue(paymenttype);
                verifyform["cre_siponumber"] = siponumber;
                verifyform["cre_accountnumberp1"] = accountnumberp1;
                verifyform["cre_accountnumberp2"] = accountnumberp2;
                verifyform["cre_bankcode"] = bankcode;
                verifyform["cre_customer_resigned"] = customer_resigned;
                verifyform["cre_resignation_length"] = resignation_length;
                verifyform["cre_resignation_unit"] = resignation_unit;
                verifyform["cre_afterverificationdesc"] = new OptionSetValue(contractreason);

                if (resignation != "") verifyform["cre_resignation"] = DateTime.Parse(resignation);
                else if (fromfixedtermcontract != "")
                {
                   
                    verifyform["cre_resignation"] = DateTime.Parse(fromfixedtermcontract).AddDays(-1);
                    DateTime.Today.AddDays(-1);

                }
                else if(fromindefiniteperiodcontract != "")
                {

                    verifyform["cre_resignation"] = DateTime.Parse(fromindefiniteperiodcontract).AddDays(-1);

                }


                verifyform["cre_stableprice"] = stableprice; //money

                if (eic != "")
                    verifyform["cre_individualprice_gas"] = individualprice;
                else
                {
                    verifyform["cre_individualpricemwh"] = individualprice;
                    verifyform["cre_individualpricent"] = individualpricent; //money
                }
                


                verifyform["cre_importnumber"] = importnumber; //string
                verifyform["cre_auctionnumber"] = auctionnumber; //string

                verifyform["cre_seller_id_auction"] = seller_id_auction;
                verifyform["cre_payment_of_commission"] = payment_of_commission; //bool               
                verifyform["cre_reason_of_commission"] = reason_of_commission;
                verifyform["cre_supplypoint_number"] = supplypoint_number;
                verifyform["cre_capacity_for_day"] = capacity_for_day;
                verifyform["cre_billingperiod"] = billingperiod;
                verifyform["cre_real_consumption"] = real_consumption;



                if (errorstring == "")
                {

                    verifyform["cre_import_status"] = new OptionSetValue(171140000);

                }

                else
                {

                    verifyform["cre_import_status"] = new OptionSetValue(171140001);
                    verifyform["cre_import_error_info"] = errorstring;

                }

                if (errorstring == "")
                {
                
                    verifyform["cre_contactver"] = new OptionSetValue(171140000);
                    verifyform["cre_accountver"] = new OptionSetValue(171140000);
                    verifyform["cre_responsiblever"] = new OptionSetValue(171140000);
                    verifyform["cre_contact_detailsver"] = new OptionSetValue(171140000);
                    verifyform["cre_permanent_addressver"] = new OptionSetValue(171140000);
                    verifyform["cre_mailing_adressver"] = new OptionSetValue(171140000);
                    verifyform["cre_contract_periodver"] = new OptionSetValue(171140000);
                    verifyform["cre_supplypoint_payment_termsver"] = new OptionSetValue(171140000);
                    verifyform["cre_status"] = new OptionSetValue(171140001);
                
                    verifyform["cre_afterverificationdesc"] = new OptionSetValue(contractreason);
                    verifyform["cre_aftervalidationdesc"] = new OptionSetValue(contractreason);
                    verifyform["cre_verificationcomplete"] = true;
                
                }
                else
                {
                
                    verifyform["cre_import_status"] = new OptionSetValue(171140001);
                    verifyform["cre_import_error_info"] = errorstring;
                
                }

                if (seller_Guid != Guid.Empty)
                    verifyform["cre_seller"] = new EntityReference { LogicalName = "contact", Id = seller_Guid };



                //validace primo nefunguje
                //if (false==true)
                //{
                //    verifyform["cre_contactver"] = new OptionSetValue(171140000);
                //    verifyform["cre_accountver"] = new OptionSetValue(171140000);
                //    verifyform["cre_responsiblever"] = new OptionSetValue(171140000);
                //    verifyform["cre_contact_detailsver"] = new OptionSetValue(171140000);
                //    verifyform["cre_permanent_addressver"] = new OptionSetValue(171140000);
                //    verifyform["cre_mailing_adressver"] = new OptionSetValue(171140000);
                //    verifyform["cre_contract_periodver"] = new OptionSetValue(171140000);
                //    verifyform["cre_supplypoint_payment_termsver"] = new OptionSetValue(171140000);
                //
                //    verifyform["cre_contactval"] = new OptionSetValue(171140000);
                //    verifyform["cre_accountval"] = new OptionSetValue(171140000);
                //    verifyform["cre_responsibleval"] = new OptionSetValue(171140000);
                //    verifyform["cre_contact_detailsval"] = new OptionSetValue(171140000);
                //    verifyform["cre_permanent_addressval"] = new OptionSetValue(171140000);
                //    verifyform["cre_mailing_adressval"] = new OptionSetValue(171140000);
                //    verifyform["cre_contract_periodval"] = new OptionSetValue(171140000);
                //    verifyform["cre_supplypoint_payment_termsval"] = new OptionSetValue(171140000);
                //
                //    verifyform["cre_status"] = new OptionSetValue(171140002);
                //
                //    verifyform["cre_afterverificationdesc"] = new OptionSetValue(contractreason);
                //    verifyform["cre_aftervalidationdesc"] = new OptionSetValue(contractreason);
                //
                //    verifyform["cre_verificationcomplete"] = true;
                //    verifyform["cre_validationcomplete"] = true;
                //
                //}

                

                return ServiceControl.Create(verifyform, ServiceControl.GetService());
            }
            catch (Exception ex)
            {
                Logger.WriteLine("VF Zaslání e-mailu s chybou: " + ex.Message);
                EmaiSender.SendError("consoleApp error VF", ex.Message);
                return Guid.Empty;
            }
        }
    }
}
