﻿function OnSave(context) {
    OnSaveValidation(context);
}

function OnLoad() {
    OnLoadValidation();
    CheckExistsEANEICCode();
    OnLoadCollapseSections();
}

function CustomerNotReachedClick() {
    var context = Xrm.Page.context;
    var entity = Xrm.Page.data.entity;
    var status = Xrm.Page.getAttribute("cre_status");
    status.setSubmitMode("always");
    switch (status.getValue()) {
        case 171140000:
            status.setValue(171140003);
            entity.save("saveandclose");
            break;
        case 171140003:
            status.setValue(171140004);
            entity.save("saveandclose");
            break;
        default:
            alert("Akci nelze použít.\nVerifikační formulář není ve vhodném stavu.");
            context.getEventArgs().preventDefault();
            break;
    }
}

function ContractFullVerifikation() {
    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();

    if (verificationComplete_value == false) {

        var entity = Xrm.Page.data.entity;
        var contactVer = Xrm.Page.getAttribute("cre_contactver");
        var accountVer = Xrm.Page.getAttribute("cre_accountver");
        var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
        var contactDetailsVer = Xrm.Page.getAttribute("cre_contact_detailsver");
        var permanentAddressVer = Xrm.Page.getAttribute("cre_permanent_addressver");
        var mailingAdressVer = Xrm.Page.getAttribute("cre_mailing_adressver");
        var contractPeriodVer = Xrm.Page.getAttribute("cre_contract_periodver");
        var supplyPointPaymentTermsVer = Xrm.Page.getAttribute("cre_supplypoint_payment_termsver");
        var status = Xrm.Page.getAttribute("cre_status");

        contactVer.setValue(171140000);
        accountVer.setValue(171140000);
        responsibleVer.setValue(171140000);
        contactDetailsVer.setValue(171140000);
        permanentAddressVer.setValue(171140000);
        mailingAdressVer.setValue(171140000);
        contractPeriodVer.setValue(171140000);
        supplyPointPaymentTermsVer.setValue(171140000);
        //alert("Záznam byl zverifikován");
        entity.save("save");
    }
    else {
        alert("Záznam je zverifikovaný");
    }

}

function ContractFullValidation() {

    var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
    var validationComplete_value = validationComplete.getValue();

    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();

    if (verificationComplete_value == false) {
        alert("Záznam není zverifikován");
    }
    else if (validationComplete_value == true) {
        alert("Záznam je zvalidován");
    }
    else {
        var entity = Xrm.Page.data.entity;
        var contactVal = Xrm.Page.getAttribute("cre_contactval");
        var accountVal = Xrm.Page.getAttribute("cre_accountval");
        var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
        var contactDetailVal = Xrm.Page.getAttribute("cre_contact_detailsval");
        var permanentAddressVal = Xrm.Page.getAttribute("cre_permanent_addressval");
        var mailingAdressVal = Xrm.Page.getAttribute("cre_mailing_adressval");
        var contractPeriodVal = Xrm.Page.getAttribute("cre_contract_periodval");
        var supplyPointPaymentTermsVal = Xrm.Page.getAttribute("cre_supplypoint_payment_termsval");

        contactVal.setValue(171140000);
        accountVal.setValue(171140000);
        responsibleVal.setValue(171140000);
        contactDetailVal.setValue(171140000);
        permanentAddressVal.setValue(171140000);
        mailingAdressVal.setValue(171140000);
        contractPeriodVal.setValue(171140000);
        supplyPointPaymentTermsVal.setValue(171140000);

        //alert("Záznam byl zvalidován");
        entity.save("save");
    }
}


function ContractCancelClick() {
    var entity = Xrm.Page.data.entity;
    var status = Xrm.Page.getAttribute("cre_status");
    status.setSubmitMode("always");
    status.setValue(171140006);
    entity.save("saveandclose");
}

function ContractVerifyClick() {
    var entity = Xrm.Page.data.entity;
    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
    var reVerification = Xrm.Page.getAttribute("cre_reverification");
    verificationComplete.setSubmitMode("always");
    validationComplete.setSubmitMode("always");
    reVerification.setSubmitMode("always");
    verificationComplete.setValue(false);
    validationComplete.setValue(false);
    reVerification.setValue(true);
    entity.save("save");
}

function ContractRejectClick() {
    var entity = Xrm.Page.data.entity;
    var status = Xrm.Page.getAttribute("cre_status");
    var verificationcomplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var validationcomplete = Xrm.Page.getAttribute("cre_validationcomplete");
    status.setSubmitMode("always");
    verificationcomplete.setSubmitMode("always");
    validationcomplete.setSubmitMode("always");
    status.setValue(171140000);
    verificationcomplete.setValue(false);
    validationcomplete.setValue(false);
    entity.save("save");
}

function ContractIncorrectClick() {
    var dateParts = [];
    var $cre_undefined_date = Xrm.Page.getAttribute("cre_undefined_date");
    do {
        var userInput = prompt("Zadejte správně datum: (format: dd.mm.rrrr)", userInput);
        if (userInput === null) {
            var task = new Object();
            task.Subject = "Kontaktovat zákazníka";
            task.RegardingObjectId = {
                Id: Xrm.Page.data.entity.getId(),
                LogicalName: Xrm.Page.data.entity.getEntityName()
            };
            REST.Create(task, "TaskSet", false);
            $cre_undefined_date.setValue(true);
            alert("Datum nevyplněno. Nyní byla vytvořena aktivita 'Kontaktovat zakazníka'.");
            Xrm.Page.data.entity.save("save");
            return;
        }
        dateParts = userInput.split(".");
    }
    while (!IsValidDate($.trim(userInput).replace(/\./g, "")));

    var date = new Date(dateParts[2], (dateParts[1] - 1), dateParts[0]);
    var $cre_date = Xrm.Page.getAttribute("cre_tofixedtermcontract");
    $cre_date.setValue(date);
    $cre_undefined_date.setValue(false);
    Xrm.Page.data.entity.save("save");
}

function IsValidDate(date) {
    if (date.length == 8) {
        var day = parseInt(date.substring(0, 2), 10);
        var month = parseInt(date.substring(2, 4), 10);
        var year = date.substring(4, 8);
        if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1900)
            return false;
        else
            return true;
    }
    else
        return false;
}

function CheckExistsEANEICCode() {
    var ean = Xrm.Page.getAttribute("cre_eanopm").getValue();
    var eic = Xrm.Page.getAttribute("cre_eic").getValue();
    if (ean)
        REST.RetrieveMultiple("cre_supplypointSet", "?$filter=cre_EANOPM eq '" + ean + "'&$top=2", true, function (result) {
            if (result)
                if (result.length > 1)
                    alert("Poznámka:\nEAN OPM kód odběrného místa již v systému existuje.");
        });
    else if (eic) {
        REST.RetrieveMultiple("cre_supplypointSet", "?$filter=cre_eic eq '" + eic + "'&$top=2", true, function (result) {
            if (result)
                if (result.length > 1)
                    alert("Poznámka:\nEIC kód odběrného místa již v systému existuje.");
        });
    }
}

function OnLoadCollapseSections() {
    var contactVer = Xrm.Page.getAttribute("cre_contactver");
    var contactVal = Xrm.Page.getAttribute("cre_contactval");
    var accountVer = Xrm.Page.getAttribute("cre_accountver");
    var accountVal = Xrm.Page.getAttribute("cre_accountval");
    var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
    var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
    var contact = Xrm.Page.getAttribute("cre_contact"),
        account = Xrm.Page.getAttribute("cre_account"),
        Tabs = Xrm.Page.ui.tabs;
    if (account.getValue() != null) {
        Tabs.get(2).setDisplayState("collapsed");
        contactVer.setValue(171140000);
        contactVal.setValue(171140000);
    }
    else if (contact.getValue() != null) {
        Tabs.get(3).setDisplayState("collapsed");
        Tabs.get(4).setDisplayState("collapsed");
        accountVer.setValue(171140000);
        accountVal.setValue(171140000);
        responsibleVer.setValue(171140000);
        responsibleVal.setValue(171140000);
    }
}

function OnChangeSectionState(index) {
    Xrm.Page.ui.tabs.get(index).setDisplayState("collapsed");
}

function OnLoadValidation() {
    ///////// POLE VALIDACE
    var contactVal = Xrm.Page.getControl("cre_contactval");
    var accountVal = Xrm.Page.getControl("cre_accountval");
    var responsibleVal = Xrm.Page.getControl("cre_responsibleval");
    var contactDetailVal = Xrm.Page.getControl("cre_contact_detailsval");
    var permanentAddressVal = Xrm.Page.getControl("cre_permanent_addressval");
    var mailingAdressVal = Xrm.Page.getControl("cre_mailing_adressval");
    var contractPeriodVal = Xrm.Page.getControl("cre_contract_periodval");
    var supplyPointPaymentTermsVal = Xrm.Page.getControl("cre_supplypoint_payment_termsval");

    var validationComplete = Xrm.Page.getControl("cre_validationcomplete");
    var validationComplete_value = Xrm.Page.getAttribute("cre_validationcomplete").getValue();
    var validationDesc = Xrm.Page.getControl("cre_aftervalidationdesc");
    var validationDate = Xrm.Page.getControl("cre_validationdate");
    var validationPerson = Xrm.Page.getControl("cre_validationperson");

    ///////// POLE VERIFIKACE
    var contactVer = Xrm.Page.getControl("cre_contactver");
    var accountVer = Xrm.Page.getControl("cre_accountver");
    var responsibleVer = Xrm.Page.getControl("cre_responsiblever");
    var contactDetailsVer = Xrm.Page.getControl("cre_contact_detailsver");
    var permanentAddressVer = Xrm.Page.getControl("cre_permanent_addressver");
    var mailingAdressVer = Xrm.Page.getControl("cre_mailing_adressver");
    var contractPeriodVer = Xrm.Page.getControl("cre_contract_periodver");
    var supplyPointPaymentTermsVer = Xrm.Page.getControl("cre_supplypoint_payment_termsver");

    var verificationComplete = Xrm.Page.getControl("cre_verificationcomplete");
    var verificationComplete_value = Xrm.Page.getAttribute("cre_verificationcomplete").getValue();
    var verificationDesc = Xrm.Page.getControl("cre_afterverificationdesc");
    var verificationDate = Xrm.Page.getControl("cre_verificationdate");
    var verificationPerson = Xrm.Page.getControl("cre_verificationperson");

    var status = Xrm.Page.getAttribute("cre_status");

    // rozdeleni plyn, ele--------------------------------------------------------------------------

    // cre_individualpricemwh kdyz plyn -> cre_individualprice_gas
    // cre_annualconsumptionvt kdyz plyn -> cre_annualconsumption_gas


    var individualpricemwh_control = Xrm.Page.getControl("cre_individualpricemwh");
    var individualpricent_control = Xrm.Page.getControl("cre_individualpricent");
    var stableprice_control = Xrm.Page.getControl("cre_stableprice");
    var individualprice_gas_control = Xrm.Page.getControl("cre_individualprice_gas");

    var annualconsumptionvt_control = Xrm.Page.getControl("cre_annualconsumptionvt");
    var annualconsumptionnt_control = Xrm.Page.getControl("cre_annualconsumptionnt");
    var annualconsumption_gas_control = Xrm.Page.getControl("cre_annualconsumption_gas");


    var individualpricemwh = Xrm.Page.getAttribute("cre_individualpricemwh");
    var individualprice_gas = Xrm.Page.getAttribute("cre_individualprice_gas");


    var annualconsumptionvt = Xrm.Page.getAttribute("cre_annualconsumptionvt");
    var annualconsumption_gas = Xrm.Page.getAttribute("cre_annualconsumption_gas");

    var exemption_tax_control = Xrm.Page.getControl("cre_exemption_tax");



    var eanopm_control = Xrm.Page.getControl("cre_eanopm");
    var eic_control = Xrm.Page.getControl("cre_eic");
    var distributorelectricity_control = Xrm.Page.getControl("cre_distributorelectricity");
    var distributorgas_control = Xrm.Page.getControl("cre_distributorgas");
    var annualconsumptionnt_control = Xrm.Page.getControl("cre_annualconsumptionnt");
    var breakervalue_control = Xrm.Page.getControl("cre_breakervalue");
    var distributionrate_control = Xrm.Page.getControl("cre_distributionrate");
    var connectiontype_control = Xrm.Page.getControl("cre_connectiontype");

    var eanopm = Xrm.Page.getAttribute("cre_eanopm");
    var eanopm_value = eanopm.getValue();

    var eic = Xrm.Page.getAttribute("cre_eic");
    var eic_value = eic.getValue();

    if (eanopm_value != null) {
        eanopm_control.setVisible(true);
        eic_control.setVisible(false);
        distributorelectricity_control.setVisible(true);
        distributorgas_control.setVisible(false);
        annualconsumptionnt_control.setVisible(true);
        breakervalue_control.setVisible(true);
        distributionrate_control.setVisible(true);
        connectiontype_control.setVisible(true);

        individualpricemwh_control.setVisible(true);
        individualpricent_control.setVisible(true);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(false);

        annualconsumptionvt_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        annualconsumption_gas_control.setVisible(false);

        exemption_tax_control.setVisible(false);

    }
    else if (eic_value != null) {
        eanopm_control.setVisible(false);
        eic_control.setVisible(true);
        distributorelectricity_control.setVisible(false);
        distributorgas_control.setVisible(true);
        annualconsumptionnt_control.setVisible(false);
        breakervalue_control.setVisible(false);
        distributionrate_control.setVisible(false);
        connectiontype_control.setVisible(false);

        individualpricemwh_control.setVisible(false);
        individualpricent_control.setVisible(false);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(true);

        annualconsumptionvt_control.setVisible(false);
        annualconsumptionnt_control.setVisible(false);
        annualconsumption_gas_control.setVisible(true);

        exemption_tax_control.setVisible(true);

        if (individualpricemwh.getValue() != null && individualprice_gas.getValue() == null) {
            individualprice_gas.setValue(individualpricemwh.getValue())
        }

        if (annualconsumptionvt.getValue() != null && annualconsumption_gas.getValue() == null) {
            annualconsumption_gas.setValue(annualconsumptionvt.getValue())
        }

    }
    else {
        alert("Není vyplněn kód EIC, nebo EAN");
        eanopm_control.setVisible(true);
        eic_control.setVisible(true);
        distributorelectricity_control.setVisible(true);
        distributorgas_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        breakervalue_control.setVisible(true);
        distributionrate_control.setVisible(true);
        connectiontype_control.setVisible(true);

        individualpricemwh_control.setVisible(true);
        individualpricent_control.setVisible(true);
        stableprice_control.setVisible(true);
        individualprice_gas_control.setVisible(true);

        annualconsumptionvt_control.setVisible(true);
        annualconsumptionnt_control.setVisible(true);
        annualconsumption_gas_control.setVisible(true);
        exemption_tax_control.setVisible(true);
    }
    // rozdeleni plyn, ele-----------------------------



    if (verificationComplete_value == false) {

        contactVal.setVisible(false);
        accountVal.setVisible(false);
        responsibleVal.setVisible(false);
        contactDetailVal.setVisible(false);
        permanentAddressVal.setVisible(false);
        mailingAdressVal.setVisible(false);
        contractPeriodVal.setVisible(false);
        supplyPointPaymentTermsVal.setVisible(false);
        validationDesc.setVisible(false);
        validationDate.setVisible(false);
        validationPerson.setVisible(false);
        validationComplete.setVisible(false);

    } else if (verificationComplete_value == true && validationComplete_value == false) {

        if (status.getValue() == 171140004)
            verificationPerson.setVisible(false);
        contactVer.setDisabled(true);
        accountVer.setDisabled(true);
        responsibleVer.setDisabled(true);
        contactDetailsVer.setDisabled(true);
        permanentAddressVer.setDisabled(true);
        mailingAdressVer.setDisabled(true);
        contractPeriodVer.setDisabled(true);
        supplyPointPaymentTermsVer.setDisabled(true);
        verificationDesc.setDisabled(true);
        Xrm.Page.getAttribute("cre_aftervalidationdesc").setValue(Xrm.Page.getAttribute("cre_afterverificationdesc").getValue());

    } else if (verificationComplete_value == true && validationComplete_value == true) {

        Xrm.Page.ui.controls.forEach(function (control, index) {

            control.setDisabled(true);

        });

    }

    verificationComplete.setDisabled(true);
    validationComplete.setDisabled(true);
    validationDate.setDisabled(true);
    verificationDate.setDisabled(true);
}

function OnSaveValidation(context) {
    ///////// POLE VALIDACE
    var contactVal = Xrm.Page.getAttribute("cre_contactval");
    var accountVal = Xrm.Page.getAttribute("cre_accountval");
    var responsibleVal = Xrm.Page.getAttribute("cre_responsibleval");
    var contactDetailVal = Xrm.Page.getAttribute("cre_contact_detailsval");
    var permanentAddressVal = Xrm.Page.getAttribute("cre_permanent_addressval");
    var mailingAdressVal = Xrm.Page.getAttribute("cre_mailing_adressval");
    var contractPeriodVal = Xrm.Page.getAttribute("cre_contract_periodval");
    var supplyPointPaymentTermsVal = Xrm.Page.getAttribute("cre_supplypoint_payment_termsval");

    var contactVal_value = contactVal.getValue();
    var accountVal_value = accountVal.getValue();
    var responsibleVal_value = responsibleVal.getValue();
    var contactDetailVal_value = contactDetailVal.getValue();
    var permanentAddressVal_value = permanentAddressVal.getValue();
    var mailingAdressVal_value = mailingAdressVal.getValue();
    var contractPeriodVal_value = contractPeriodVal.getValue();
    var supplyPointPaymentTermsVal_value = supplyPointPaymentTermsVal.getValue();

    var validationComplete = Xrm.Page.getAttribute("cre_validationcomplete");
    var validationComplete_value = validationComplete.getValue();
    var validationDesc = Xrm.Page.getAttribute("cre_aftervalidationdesc");
    var validationDesc_value = validationDesc.getValue();

    ///////// POLE VERIFIKACE
    var contactVer = Xrm.Page.getAttribute("cre_contactver");
    var accountVer = Xrm.Page.getAttribute("cre_accountver");
    var responsibleVer = Xrm.Page.getAttribute("cre_responsiblever");
    var contactDetailsVer = Xrm.Page.getAttribute("cre_contact_detailsver");
    var permanentAddressVer = Xrm.Page.getAttribute("cre_permanent_addressver");
    var mailingAdressVer = Xrm.Page.getAttribute("cre_mailing_adressver");
    var contractPeriodVer = Xrm.Page.getAttribute("cre_contract_periodver");
    var supplyPointPaymentTermsVer = Xrm.Page.getAttribute("cre_supplypoint_payment_termsver");
    var status = Xrm.Page.getAttribute("cre_status");

    var contactVer_value = contactVer.getValue();
    var accountVer_value = accountVer.getValue();
    var responsibleVer_value = responsibleVer.getValue();
    var contactDetailsVer_value = contactDetailsVer.getValue();
    var permanentAddressVer_value = permanentAddressVer.getValue();
    var mailingAdressVer_value = mailingAdressVer.getValue();
    var contractPeriodVer_value = contractPeriodVer.getValue();
    var supplyPointPaymentTermsVer_value = supplyPointPaymentTermsVer.getValue();
    var status_value = status.getValue();

    var verificationComplete = Xrm.Page.getAttribute("cre_verificationcomplete");
    var verificationComplete_value = verificationComplete.getValue();
    var verificationDesc = Xrm.Page.getAttribute("cre_afterverificationdesc");
    var verificationDesc_value = verificationDesc.getValue();

    //pridane kontroly ------------------------------------------------------------------

    var cre_aceptedon = Xrm.Page.getAttribute("cre_aceptedon"); // smlouva prijata dne OK
    var cre_aceptedon_value = cre_aceptedon.getValue();
    if (cre_aceptedon_value == null && status_value != 171140006) {

        alert("Smlouva přijata dne");
        context.getEventArgs().preventDefault();
        return false;

    }

    var cre_advancepayment = Xrm.Page.getAttribute("cre_advancepayment"); //výše zálohy, cre_advancepayment OK
    var cre_advancepayment_value = cre_advancepayment.getValue();
    if (cre_advancepayment_value == null && status_value != 171140006) {

        alert("Výše zálohy");
        context.getEventArgs().preventDefault();
        return false;

    }

    var cre_resignation = Xrm.Page.getAttribute("cre_resignation"); // výpověď k datu cre_resignation OK
    var cre_resignation_value = cre_resignation.getValue();
    if (cre_resignation_value == null && status_value != 171140006) {

        alert("Výpověď k datu");
        context.getEventArgs().preventDefault();
        return false;

    }

    var cre_originaldistributor = Xrm.Page.getAttribute("cre_originaldistributor"); //původního dodavatele cre_originaldistributor
    var cre_originaldistributor_value = cre_originaldistributor.getValue();
    if (cre_originaldistributor_value == null && status_value != 171140006) {

        alert("Původní dodavatel");
        context.getEventArgs().preventDefault();
        return false;

    }

    var cre_eanopm = Xrm.Page.getAttribute("cre_eanopm"); // cre_eanopm
    var cre_eanopm_value = cre_eanopm.getValue();

    var cre_eic = Xrm.Page.getAttribute("cre_eic"); // cre_eic
    var cre_eic_value = cre_eic.getValue();

    var cre_distributorelectricity = Xrm.Page.getAttribute("cre_distributorelectricity"); // cre_distributorelectricity EAN
    var cre_distributorelectricity_value = cre_distributorelectricity.getValue();

    var cre_distributorgas = Xrm.Page.getAttribute("cre_distributorgas"); // cre_distributorgas EIC
    var cre_distributorgas_value = cre_distributorgas.getValue();

    if (cre_eanopm_value != null && cre_distributorelectricity_value == null && status_value != 171140006) {

        alert("Distributor elektřiny");
        context.getEventArgs().preventDefault();
        return false;

    }
    if (cre_eic_value != null && cre_distributorgas_value == null && status_value != 171140006) {

        alert("Distributor plynu");
        context.getEventArgs().preventDefault();
        return false;

    }






    //pridane kontroly ---------------------------------------------------------------------

    var unvalidatedOptionValue = 171140001;
    var unverificatedOptionValue = 171140001;

    var firstTimeUnavalibleStatus = 171140003;
    var secondTimeUnavalibleStatus = 171140004;

    if (verificationComplete_value == false) {

        if (contactVer_value == unverificatedOptionValue || accountVer_value == unverificatedOptionValue || responsibleVer_value == unverificatedOptionValue || contactDetailsVer_value == unverificatedOptionValue || permanentAddressVer_value == unverificatedOptionValue || mailingAdressVer_value == unverificatedOptionValue || contractPeriodVer_value == unverificatedOptionValue || supplyPointPaymentTermsVer_value == unverificatedOptionValue) {

            if (status.getValue() != 171140005) {

                if (status_value != firstTimeUnavalibleStatus && status_value != secondTimeUnavalibleStatus) {

                    alert("Musíte zverifikovat celý formulář.");
                    context.getEventArgs().preventDefault();
                    return false;

                }

            }

        }

        if (verificationDesc_value == null) {

            alert("Musíte zvolit o jaký případ se jedná.");
            context.getEventArgs().preventDefault();
            return false;

        }

    } else if (validationComplete_value == false) {

        if (contactVal_value == unvalidatedOptionValue || accountVal_value == unvalidatedOptionValue || responsibleVal_value == unvalidatedOptionValue || contactDetailVal_value == unvalidatedOptionValue || permanentAddressVal_value == unvalidatedOptionValue || mailingAdressVal_value == unvalidatedOptionValue || contractPeriodVal_value == unvalidatedOptionValue || supplyPointPaymentTermsVal_value == unvalidatedOptionValue) {

            alert("Musíte zvalidovat celý formulář.");
            context.getEventArgs().preventDefault();
            return false;

        }

        if (validationDesc_value == null) {

            alert("Musíte zvolit o jaký případ se jedná.");
            context.getEventArgs().preventDefault();
            return false;

        }

    }
}