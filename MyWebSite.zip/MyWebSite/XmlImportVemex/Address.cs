﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class Address
    {
        static string LogicalName = "";
        static Guid id = Guid.Empty;

        public static Guid CreateCustomerAddress(string name, string street, string streetNumber1, string streetNumber2,
            string zipcode, string city, string parentLogicalName, Guid parentId)
        {
            try
            {
                Entity customerAddress = new Entity("customeraddress");
                customerAddress["name"] = name;
                customerAddress["line1"] = street;
                customerAddress["cre_housenumber"] = streetNumber1 + "/" + streetNumber2;
                customerAddress["postalcode"] = zipcode;
                customerAddress["city"] = city;
                customerAddress["parentid"] = new EntityReference { LogicalName = parentLogicalName, Id = parentId };
                return ServiceControl.Create(customerAddress, ServiceControl.GetService());
            }
            catch (Exception ex)
            {
                EmaiSender.SendError("consoleApp error", ex.Message);
                return Guid.Empty;
            }
        }
        public static string GetLogicalName()
        {
            return LogicalName;
        }
        public static Guid GetId()
        {
            return id;
        }
    }
}
