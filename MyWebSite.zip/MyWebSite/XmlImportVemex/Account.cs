﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class Account
    {
        static string logicalName = "";
        static Guid id = Guid.Empty;
        static string logicalNameP1 = "";
        static Guid idP1 = Guid.Empty;
        static string logicalNameP2 = "";
        static Guid idP2 = Guid.Empty;
        static string logicalNameC = "";
        static Guid idC = Guid.Empty;

        public static Guid CreateAccount(
                string companyName,
                string ico,
                string dic,               
                string p1_function,
                string p1_firstName,
                string p1_lastName,
                string p2_function,
                string p2_firstName,
                string p2_lastName,
                string email,
                string phoneNumber,
                string street,
                string streetNumber1,
                string streetNumber2,
                string zipcode,
                string city,
                string recordOR,
                string auctionnumber,
                string importnumber,
                int title1P1,
                int title2P1,
                int title1P2,
                int title2P2,
                int sexP1,
                int sexP2,
                string contact_firstName,
                string contact_lastName,
                int title1C,
                int title2C,
                int sexC
                
            )
        {
            try
            {
                logicalName = "";
                id = Guid.Empty;
                logicalNameP1 = "";
                idP1 = Guid.Empty;
                logicalNameP2 = "";
                idP2 = Guid.Empty;
                Entity account = new Entity("account");
                account["name"] = companyName;
                account["cre_ico"] = ico;
                account["cre_dic"] = dic;
                account["telephone1"] = phoneNumber;
                account["emailaddress1"] = email;
                account["cre_commercialregisterrecord"] = recordOR;
                account["address1_addresstypecode"] = new OptionSetValue(1);
                account["address1_name"] = companyName;
                account["address1_city"] = city;
                account["address1_line1"] = street;
                account["cre_housenumber"] = streetNumber1;
                account["cre_orientationnumber"] = streetNumber2;
                account["address1_postalcode"] = zipcode;
                account["cre_auctionnumber"] = auctionnumber;
                account["cre_importnumber"] = importnumber;
                Entity contact1 = new Entity("contact");
                Entity contact2 = new Entity("contact");
                Entity contact3 = new Entity("contact");



                if (p1_firstName != "" && p1_lastName != "")
                {
                    contact1["firstname"] = p1_firstName;
                    contact1["lastname"] = p1_lastName;
                    contact1["jobtitle"] = p1_function;
                    contact1["cre_genders"] = new OptionSetValue(sexP1);
                    contact1["cre_titulpred"] = new OptionSetValue(title1P1);
                    contact1["cre_titulza"] = new OptionSetValue(title2P1);
                    idP1 = ServiceControl.Create(contact1, ServiceControl.GetService());
                    logicalNameP1 = contact1.LogicalName;
                    account["cre_responsibleperson"] = new EntityReference { LogicalName = contact1.LogicalName, Id = idP1 };
                }
                else
                {
                    contact1["firstname"] = "DOPLNIT JMÉNO";
                    contact1["lastname"] = "DOPLNIT PŘÍJMENÍ";
                    contact1["jobtitle"] = p1_function;

                    idP1 = ServiceControl.Create(contact1, ServiceControl.GetService());
                    logicalNameP1 = contact1.LogicalName;
                    account["cre_responsibleperson"] = new EntityReference { LogicalName = contact1.LogicalName, Id = idP1 };

                }
                if (p2_firstName != "" && p2_lastName != "")
                {
                    contact2["firstname"] = p2_firstName;
                    contact2["lastname"] = p2_lastName;
                    contact2["jobtitle"] = p2_function;
                    contact2["cre_genders"] = new OptionSetValue(sexP2);
                    contact2["cre_titulpred"] = new OptionSetValue(title1P2);
                    contact2["cre_titulza"] = new OptionSetValue(title2P2);
                    idP2 = ServiceControl.Create(contact2, ServiceControl.GetService());
                    logicalNameP2 = contact2.LogicalName;
                    account["cre_responsibleperson2"] = new EntityReference { LogicalName = contact2.LogicalName, Id = idP2 };
                }
                
                if (contact_firstName != "" && contact_lastName != "")
                {
                    contact3["firstname"] = contact_firstName;
                    contact3["lastname"] = contact_lastName;
                    contact3["cre_genders"] = new OptionSetValue(sexC);
                    contact3["cre_titulpred"] = new OptionSetValue(title1C);
                    contact3["cre_titulza"] = new OptionSetValue(title2C);
                    idC = ServiceControl.Create(contact3, ServiceControl.GetService());
                    logicalNameC = contact3.LogicalName;
                    account["primarycontactid"] = new EntityReference { LogicalName = contact3.LogicalName, Id = idC };
                }
                
                logicalName = account.LogicalName;
                id = ServiceControl.Create(account, ServiceControl.GetService());
                return id;
            }
            catch (Exception ex)
            {
                EmaiSender.SendError("consoleApp error Acc", ex.Message);
                return Guid.Empty;
            }
        }
        public static string GetLogicalName()
        {
            return logicalName;
        }
        public static Guid GetId()
        {
            return id;
        }
        public static string GetLogicalNameP1()
        {
            return logicalNameP1;
        }
        public static Guid GetIdP1()
        {
            return idP1;
        }
        public static string GetLogicalNameP2()
        {
            return logicalNameP2;
        }
        public static Guid GetIdP2()
        {
            return idP2;
        }
        public static Guid GetIdC()
        {
            return idC; ;
        }
        public static string GetLogicalNameC()
        {
            return logicalNameC;
        }
    }
}
