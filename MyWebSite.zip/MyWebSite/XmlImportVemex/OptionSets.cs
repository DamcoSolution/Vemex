﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Web;

namespace XmlImportVemex
{
    public class OptionSets
    {
        //static Dictionary<string, GuidMap> guid_map = new Dictionary<string, GuidMap>();

        public static Dictionary<string, int> GetSelectOptions(string entityLogicalName, string fieldLogicalName)
        {
            try
            {
                int value_int;
                string value_string;
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityLogicalName, LogicalName = fieldLogicalName };
                RetrieveAttributeResponse response = (RetrieveAttributeResponse)ServiceControl.GetService().Execute(attributeRequest);

                PicklistAttributeMetadata quoteMetaData = (PicklistAttributeMetadata)response.AttributeMetadata;
                Dictionary<string, int> list = new Dictionary<string, int>();
                //Console.WriteLine(fieldLogicalName);
                foreach (OptionMetadata option in quoteMetaData.OptionSet.Options)
                {
                    try
                    {
                        value_string = option.Value.ToString();
                        value_int = System.Convert.ToInt32(value_string);

                        list.Add(option.Label.UserLocalizedLabel.Label, value_int);
                        //Console.WriteLine(option.Label.UserLocalizedLabel.Label);
                    }
                    catch (Exception)
                    {
                        
                    }
                    //list[option.Label.UserLocalizedLabel.Label] = value_int;

                }
                //Console.WriteLine("");
                //Console.WriteLine("");
                //Console.WriteLine("");
                //Console.WriteLine("");

                return list;
            }
            catch (Exception ex)
            {

                EmaiSender.SendError("consoleApp error Option sets", ex.Message);
                return null;

            }
            

        }

    }
}