﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace XmlImportVemex
{
    class Logger
    {

        static FileStream fs;

        static TextWriter w;
        static string path;
        public static bool WriteLine(string log)
        {
            try
            {
                w = File.AppendText(path);
                w.WriteLine(log);
                w.Close();
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }
            return true;
        }

        public static bool init(string log)
        {
            

            try
            {
                path = "Log " + DateTime.Now.ToString("yyyy MM dd HH_mm_ss") + ".txt";

                while (File.Exists(path))
                {
                    path = "Log " + DateTime.Now.ToString("yyyy MM dd HH_mm_ss") + ".txt";
                }
                //path = "co_ sdf .txt";
                fs = File.Create(path);

                fs.Close();

                w = File.AppendText(path);
                w.WriteLine(log);
                w.Close();
            }

            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }
            return true;
        }
            


    }
}
