﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    public class ContactSeller
    {
        /// <summary>
        /// Check contact lastname else create
        /// </summary>
        /// <param name="AuctionName"></param>
        /// <returns></returns>
        public static Guid AuctionCheckContact(string AuctionName)
        {
            //check contack, if lastName =auction Name, use that, if no, create that
            FilterExpression filter = new FilterExpression();
            filter.AddCondition("lastname", ConditionOperator.Equal, AuctionName);

            IOrganizationService service = ServiceControl.GetService();
            QueryExpression query = new QueryExpression()
            {
                EntityName = "contact",
                ColumnSet = new ColumnSet(new string[] 
                 {
                     "contactid", 
                     "firstname", 
                    "lastname",

                 }),
                Criteria = filter
            };

            EntityCollection ec = service.RetrieveMultiple(query);
            if (ec != null && ec.Entities.Count > 0)
            {
                return ec.Entities.FirstOrDefault().Id;
            }
            else
            {
                Entity contact = new Entity("contact");
                contact["firstname"] = AuctionName;
                contact["lastname"] = AuctionName;

                Guid ParentAccountid = GetOrAddAccountByName("Vemex");
                if (ParentAccountid != Guid.Empty)
                {
                    contact["parentcustomerid"] = new EntityReference("account", ParentAccountid);
                }

                return service.Create(contact);
            }
        }

        /// <summary>
        /// Check seller id(cre_login) contact entity
        /// </summary>
        /// <param name="sellerid"></param>
        /// <returns></returns>
        public static Guid CheckSeller(string sellerid)
        {
            //find Guid for contact seller with cre_login(contact)=sellerid, if we have not found contact, retur Guid.Empty

            FilterExpression filter = new FilterExpression();
            filter.AddCondition("cre_login", ConditionOperator.Equal, sellerid);
            IOrganizationService service = ServiceControl.GetService();
            QueryExpression query = new QueryExpression()
            {
                EntityName = "contact",
                ColumnSet = new ColumnSet(new string[] 
                 {
                     "contactid", 
                     "firstname", 
                    "lastname"
                 }),
                Criteria = filter
            };

            EntityCollection ec = service.RetrieveMultiple(query);
            if (ec != null && ec.Entities.Count > 0)
            {
                return ec.Entities.FirstOrDefault().Id;
            }
            else
            {
                return Guid.Empty;
            }

        }

        public static Guid GetOrAddAccountByName(string AccountName)
        {
            Guid AccountId = Guid.Empty;

            FilterExpression filter = new FilterExpression();
            filter.AddCondition("name", ConditionOperator.Equal, AccountName);

            IOrganizationService service = ServiceControl.GetService();
            QueryExpression query = new QueryExpression()
            {
                EntityName = "account",
                ColumnSet = new ColumnSet(new string[] 
                 {
                     "accountid", 
                     "name"
                 }),
                Criteria = filter
            };

            EntityCollection entitylist = service.RetrieveMultiple(query);

            if (entitylist != null && entitylist.Entities.Count > 0)
            {
                Entity entity = entitylist.Entities.FirstOrDefault();
                AccountId = entity.Id;
            }
            else
            {
                Entity contact = new Entity("account");
                contact["name"] = AccountName;
                AccountId = service.Create(contact);
            }
            return AccountId;
        }
    }
}
