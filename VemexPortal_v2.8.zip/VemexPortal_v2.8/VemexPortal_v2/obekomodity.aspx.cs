﻿using CRM.Helper;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using Web.Controls;

namespace VemexPortal
{
    public partial class obekomodity : PageControl
    {
        public List<SelectControl> distributionsList = new List<SelectControl>(),
                                   distributionsGasList = new List<SelectControl>(),
                                   titulList = new List<SelectControl>(),
                                   titulLastList = new List<SelectControl>(),
                                   distributionAmountsList = new List<SelectControl>(),
                                   suppliersList = new List<SelectControl>();
        public List<DuplicateControl> duplicateList = new List<DuplicateControl>();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!LoginControl.IsLogged())
                    Response.Redirect(UrlControl.GetPathUrl() + "/odhlaseni");

                if (Session["duplicate"] != null)
                {
                    // nacteni duplikovanych dat
                    duplicateList = (List<DuplicateControl>)Session["duplicate"];

                    #region Zobrazeni duplikovanych dat

                    //foreach (var duplicate in duplicateList)
                    //{
                    //    writtingORTxt.Text = duplicate.registryRecord;
                    //    companyNameTxt.Text = duplicate.companyName;
                    //    companyIcoTxt.Text = duplicate.companyIco;
                    //    companyDicTxt.Text = duplicate.companyDic;
                    //    titulTxt.Text = duplicate.titul;
                    //    titulLastTxt.Text = duplicate.titulLast;
                    //    firstNameTxt.Text = duplicate.firstName;
                    //    lastNameTxt.Text = duplicate.lastName;
                    //    birthdateTxt.Text = duplicate.birthday;
                    //    icoTxt.Text = duplicate.ico;
                    //    dicTxt.Text = duplicate.dic;
                    //    emailTxt.Text = duplicate.email;
                    //    phoneTxt.Text = duplicate.phone;
                    //    streetTxt.Text = duplicate.street;
                    //    houseNumberTxt.Text = duplicate.houseNumber;
                    //    orientationNumberTxt.Text = duplicate.orientationNumber;
                    //    postalCodeTxt.Text = duplicate.postalCode;
                    //    countryTxt.Text = duplicate.city;
                    //    postalStreetTxt.Text = duplicate.postalStreet;
                    //    postalHouseNumberTxt.Text = duplicate.postalHouseNumber;
                    //    postalOrientationNumberTxt.Text = duplicate.postalOrientationNumber;
                    //    postalPostalCodeTxt.Text = duplicate.postalPostalCode;
                    //    postalCountryTxt.Text = duplicate.postalCity;
                    //    contractTimeFirstCheck.Checked = duplicate.contractTimeFirstCheck;
                    //    timeToDayFirstTxt.Text = duplicate.contractTimeFirstTo;
                    //    timeFromDayFirstTxt.Text = duplicate.contractTimeFirstFrom;
                    //    contractTimeSecondCheck.Checked = duplicate.contractTimeSecondCheck;
                    //    contractTimeYearFirst.Checked = duplicate.contractTimeSecondOneYears;
                    //    contractTimeYearSecond.Checked = duplicate.contractTimeSecondTwoYears;
                    //    contractTimeYearThird.Checked = duplicate.contractTimeSecondThreeYears;
                    //    contractTimeThirdCheck.Checked = duplicate.contractTimeThirdCheck;
                    //    timeFromDayThirdTxt.Text = duplicate.contractTimeThirdFrom;
                    //    supplyPointDeliverEmailCheck.Checked = duplicate.invoiceDeliveryEmailCheck;
                    //    supplyPointDeliverPostCheck.Checked = duplicate.invoiceDeliveryPostCheck;
                    //    supplyPointChangesDeliverEmailCheck.Checked = duplicate.changesDeliveryEmailCheck;
                    //    supplyPointChangesDeliverPostCheck.Checked = duplicate.changesDeliveryPostCheck;
                    //    supplyPointChangesDeliverWebCheck.Checked = duplicate.changesDeliveryWebCheck;
                    //    supplyPointDepositPaymentTransferCheck.Checked = duplicate.advancesPaymentTransferCheck;
                    //    supplyPointDepositPaymentCollectionCheck.Checked = duplicate.advancesPaymentCollectionCheck;
                    //    supplyPointDepositPaymentSlipCheck.Checked = duplicate.advancesPaymentSlipCheck;
                    //    supplyPointDepositPaymentSIPOCheck.Checked = duplicate.advancesPaymentSIPOCheck;
                    //    supplyPointInvoicePaymentTransferCheck.Checked = duplicate.advancesInvoicesTransferCheck;
                    //    supplyPointInvoicePaymentCollectionCheck.Checked = duplicate.advancesInvoicesCollectionCheck;
                    //    supplyPointBankNumberFirstTxt.Text = duplicate.bankNumberFirst;
                    //    supplyPointBankNumberSecondTxt.Text = duplicate.bankNumberSecond;
                    //    supplyPointBankNumberCodeTxt.Text = duplicate.bankCode;
                    //    closedinspacesCheck.Checked = duplicate.contractClosedCheck;
                    //    signatureDateTxt.Text = duplicate.contractSignature;
                    //    supplyPointInvoicePaymentSIPOTxt.Text = duplicate.SIPONumber;
                    //    smallCheck.Checked = duplicate.smallCheck;
                    //    homeCheck.Checked = duplicate.homeCheck;
                    //    trustTitulTxt.Text = duplicate.trustJobTitle;
                    //    trustFirstNameTxt.Text = duplicate.trustFirstName;
                    //    trustLastNameTxt.Text = duplicate.trustLastName;
                    //    trustTitulSecondTxt.Text = duplicate.trustJobTitleSecond;
                    //    trustFirstNameSecondTxt.Text = duplicate.trustFirstNameSecond;
                    //    trustLastNameSecondTxt.Text = duplicate.trustLastNameSecond;
                    //}

                    #endregion
                }

                titulList = SelectControl.GetSelectOptions("contact", "cre_titulpred");
                titulLastList = SelectControl.GetSelectOptions("contact", "cre_titulza");
                distributionsGasList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_distributorgas");
                distributionsList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_distributorelectricity");
                distributionAmountsList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_distributionrate");
                suppliersList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_originaldistributor");

                sellerFirstNameTxt.Text = LoginControl.LoggedUser().FirstName;
                sellerLastNameTxt.Text = LoginControl.LoggedUser().LastName;
                sellerIdTxt.Text = LoginControl.LoggedUser().LoginNumber;
            }
        }

        protected void logoutSubmitBtn_Click(object sender, ImageClickEventArgs e)
        {
            LoginControl.Logout();
            Response.Redirect(UrlControl.GetPathUrl());
        }

        protected void gasSubmitBtn_Click(object sender, EventArgs e)
        {
            // comand name
            string command = ((Button)sender).CommandName;

            try
            {
                #region Promenne

                // cislo navrhu
                string proposedNumber = proposedNumberTxt.Text.Trim();
                bool generateIdCheck = generateCheck.Checked;

                // fyzicka osoba
                int titulInt = titulValue.Value != "" ? Convert.ToInt32(titulValue.Value.Trim()) : -1;

                // test 
                HelpControl.AddToLog("Hodnota titulInt: " + titulValue.Value);

                string titulString = titulTxt.Text.Trim();
                int titulLastInt = titulLastValue.Value != "" ? Convert.ToInt32(titulLastValue.Value.Trim()) : -1;

                // test 
                HelpControl.AddToLog("Hodnota titulLastInt: " + titulLastInt);

                string titulLastString = titulLastTxt.Text.Trim();
                string firstName = firstNameTxt.Text.Trim();
                string lastName = lastNameTxt.Text.Trim();
                string birthday = (birthdateTxt.Text.Trim() != "" && birthdateTxt.Text.Trim().Length == 8) ? birthdateTxt.Text.Trim().Substring(0, 2) + "/" + birthdateTxt.Text.Trim().Substring(2, 2) + "/" + birthdateTxt.Text.Trim().Substring(4, 4) : "";
                string ico = icoTxt.Text.Trim();
                string dic = dicTxt.Text.Trim();

                // pravnicka osoba
                string companyName = companyNameTxt.Text.Trim();
                string companyIco = companyIcoTxt.Text.Trim();
                string companyDic = companyDicTxt.Text.Trim();

                // osoba opravnena jednat
                string trustTitul = trustTitulTxt.Text.Trim();
                string trustFirstName = trustFirstNameTxt.Text.Trim();
                string trustLastName = trustLastNameTxt.Text.Trim();

                // kontaktni udaje
                string email = emailTxt.Text.Trim();
                string telephone = phoneTxt.Text.Trim();

                // silo trvale bydliste
                string street = streetTxt.Text.Trim();
                string houseNumber = houseNumberTxt.Text.Trim();
                string orientationNumber = orientationNumberTxt.Text.Trim();
                string postalCode = postalCodeTxt.Text.Trim();
                string country = countryTxt.Text.Trim();
                string writtingOR = writtingORTxt.Text.Trim();

                // korespondencni adresa
                string postalStreet = postalStreetTxt.Text.Trim();
                string postalHouseNumber = postalHouseNumberTxt.Text.Trim();
                string postalOrientationNumber = postalOrientationNumberTxt.Text.Trim();
                string postalPostalCode = postalPostalCodeTxt.Text.Trim();
                string postalCountry = postalCountryTxt.Text.Trim();

                // odberne misto
                string supplyPointStreet = supplyPointStreetTxt.Text.Trim();
                string supplyPointHouseNumber = supplyPointHouseNumberTxt.Text.Trim();
                string supplyPointOrientationNumber = supplyPointOrientationNumberTxt.Text.Trim();
                string supplyPointCity = supplyPointCountryTxt.Text.Trim();
                string supplyPointPostalCode = supplyPointPostalCodeTxt.Text.Trim();

                string supplyPointStreetGas = supplyPointStreetGasTxt.Text.Trim();
                string supplyPointHouseNumberGas = supplyPointHouseNumberGasTxt.Text.Trim();
                string supplyPointOrientationNumberGas = supplyPointOrientationNumberGasTxt.Text.Trim();
                string supplyPointCityGas = supplyPointCountryGasTxt.Text.Trim();
                string supplyPointPostalCodeGas = supplyPointPostalCodeGasTxt.Text.Trim();

                string supplyPointEIC = supplyPointEICTxt.Text.Trim();
                string supplyPointEAN = supplyPointEANTxt.Text.Trim();

                int supplyPointLastProvider = supplyPointLastProviderValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointLastProviderValue.Value.Trim()) : -1;
                int supplyPointLastProviderGas = supplyPointLastProviderGasValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointLastProviderGasValue.Value.Trim()) : -1;

                // test 
                HelpControl.AddToLog("Hodnota supplyPointLastProvider: " + supplyPointLastProviderValue.Value);
                HelpControl.AddToLog("Hodnota supplyPointLastProviderGas: " + supplyPointLastProviderGasValue.Value);

                int supplyPointNewDistribution = supplyPointNewDistributionValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointNewDistributionValue.Value.Trim()) : -1;
                int supplyPointNewDistributionGas = supplyPointNewDistributionGasValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointNewDistributionGasValue.Value.Trim()) : -1;

                // test 
                HelpControl.AddToLog("Hodnota supplyPointNewDistribution: " + supplyPointNewDistributionValue.Value);
                HelpControl.AddToLog("Hodnota supplyPointNewDistributionGas: " + supplyPointNewDistributionGasValue.Value);

                string supplyPointYearSubscriptionAmountNT = supplyPointYearSubscriptionAmountNTTxt.Text.Trim();
                string supplyPointYearSubscriptionAmountVT = supplyPointYearSubscriptionAmountVTTxt.Text.Trim();
                string supplyPointYearSubscriptionAmountGas = supplyPointYearSubscriptionAmountGasTxt.Text.Trim();

                int supplyPointDepositAmount = supplyPointDepositAmountTxt.Text.Trim() != "" ? Convert.ToInt32(supplyPointDepositAmountTxt.Text.Trim()) : 0;
                int supplyPointDepositAmountGas = supplyPointDepositAmountGasTxt.Text.Trim() != "" ? Convert.ToInt32(supplyPointDepositAmountGasTxt.Text.Trim()) : 0;

                // test 
                HelpControl.AddToLog("Hodnota supplyPointDepositAmount: " + supplyPointDepositAmountTxt.Text);
                HelpControl.AddToLog("Hodnota supplyPointDepositAmountGas: " + supplyPointDepositAmountGasTxt.Text);

                int supplyPointDistributionAmount = supplyPointDistributionAmountValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointDistributionAmountValue.Value.Trim()) : -1;

                // test 
                HelpControl.AddToLog("Hodnota supplyPointDistributionAmount: " + supplyPointDistributionAmountValue.Value);

                string supplyPointBreakerAmount = supplyPointBreakerAmountTxt.Text.Trim();

                string supplyPointInvoicePaymentSIPO = supplyPointInvoicePaymentSIPOTxt.Text.Trim();
                string supplyPointBankNumberFirst = supplyPointBankNumberFirstTxt.Text.Trim();
                string supplyPointBankNumberSecond = supplyPointBankNumberSecondTxt.Text.Trim();
                string supplyPointBankNumberCode = supplyPointBankNumberCodeTxt.Text.Trim();

                //int supplyPointChange = supplyPointChangeProviderCheck.Checked ? 171140000 : -1;
                //supplyPointChange = supplyPointChangeCustomerCheck.Checked ? 171140001 : supplyPointChange;
                //supplyPointChange = supplyPointChangeNewSubscriptionCheck.Checked ? 171140002 : supplyPointChange;
                //supplyPointChange = supplyPointChangeProviderPriceCheck.Checked ? 171140003 : supplyPointChange;
                //supplyPointChange = supplyPointOverwriteCheck.Checked ? 171140004 : supplyPointChange;

                int supplyPointDepositPeriod = supplyPointDepositMonthCheck.Checked ? 171140000 : -1;
                supplyPointDepositPeriod = supplyPointDepositQuarterCheck.Checked ? 171140001 : supplyPointDepositPeriod;

                //int supplyPointDeliverInvoice = supplyPointDeliverEmailCheck.Checked ? 171140000 : -1;
                //supplyPointDeliverInvoice = supplyPointDeliverPostCheck.Checked ? 171140001 : supplyPointDeliverInvoice;

                int supplyPointChangesDeliver = supplyPointChangesDeliverEmailCheck.Checked ? 171140002 : -1;
                supplyPointChangesDeliver = supplyPointChangesDeliverPostCheck.Checked ? 171140000 : supplyPointChangesDeliver;
                supplyPointChangesDeliver = supplyPointChangesDeliverWebCheck.Checked ? 171140001 : supplyPointChangesDeliver;

                int supplyPointDepositPayment = supplyPointDepositPaymentTransferCheck.Checked ? 171140000 : -1;
                supplyPointDepositPayment = supplyPointDepositPaymentCollectionCheck.Checked ? 171140001 : supplyPointDepositPayment;
                supplyPointDepositPayment = supplyPointDepositPaymentSlipCheck.Checked ? 171140002 : supplyPointDepositPayment;
                supplyPointDepositPayment = supplyPointDepositPaymentSIPOCheck.Checked ? 171140003 : supplyPointDepositPayment;

                int supplyPointInvoicePayment = supplyPointInvoicePaymentTransferCheck.Checked ? 171140000 : -1;
                supplyPointInvoicePayment = supplyPointInvoicePaymentCollectionCheck.Checked ? 171140001 : supplyPointInvoicePayment;
                supplyPointInvoicePayment = supplyPointInvoicePaymentSlipCheck.Checked ? 171140002 : supplyPointInvoicePayment;

                int supplyPointPhase = supplyPointPhaseOneCheck.Checked ? 171140000 : -1;
                supplyPointPhase = supplyPointPhaseThreeCheck.Checked ? 171140001 : supplyPointPhase;

                // info prodejce
                string signatureDate = (signatureDateTxt.Text.Trim() != "" && signatureDateTxt.Text.Trim().Length == 8) ? signatureDateTxt.Text.Trim().Substring(0, 2) + "/" + signatureDateTxt.Text.Trim().Substring(2, 2) + "/" + signatureDateTxt.Text.Trim().Substring(4, 4) : "";
                string sellerId = sellerIdTxt.Text.Trim();
                string sellerFirstName = sellerFirstNameTxt.Text.Trim();
                string sellerLastName = sellerLastNameTxt.Text.Trim();

                // smlouva na dobu
                string productName = productNameTxt.Text.Trim();
                string productNameGas = productNameGasTxt.Text.Trim();
                string dateTimeFromTxt = (timeFromDateTxt.Text.Trim() != "" && timeFromDateTxt.Text.Trim().Length == 8) ? timeFromDateTxt.Text.Trim().Substring(0, 2) + "/" + timeFromDateTxt.Text.Trim().Substring(2, 2) + "/" + timeFromDateTxt.Text.Trim().Substring(4, 4) : "";
                string dateTimeFromGasTxt = (timeFromDateGasTxt.Text.Trim() != "" && timeFromDateGasTxt.Text.Trim().Length == 8) ? timeFromDateGasTxt.Text.Trim().Substring(0, 2) + "/" + timeFromDateGasTxt.Text.Trim().Substring(2, 2) + "/" + timeFromDateGasTxt.Text.Trim().Substring(4, 4) : "";
                //string dateTimeToFirstTxt = (timeToDayFirstTxt.Text.Trim() != "" && timeToDayFirstTxt.Text.Trim().Length == 8) ? timeToDayFirstTxt.Text.Trim().Substring(0, 2) + "/" + timeToDayFirstTxt.Text.Trim().Substring(2, 2) + "/" + timeToDayFirstTxt.Text.Trim().Substring(4, 4) : "";
                //string dateTimeFromThirdTxt = (timeFromDayThirdTxt.Text.Trim() != "" && timeFromDayThirdTxt.Text.Trim().Length == 8) ? timeFromDayThirdTxt.Text.Trim().Substring(0, 2) + "/" + timeFromDayThirdTxt.Text.Trim().Substring(2, 2) + "/" + timeFromDayThirdTxt.Text.Trim().Substring(4, 4) : "";

                //int contractTimeYears = contractTimeYearFirst.Checked ? 171140000 : -1;
                //contractTimeYears = contractTimeYearSecond.Checked ? 171140001 : contractTimeYears;
                //contractTimeYears = contractTimeYearThird.Checked ? 171140002 : contractTimeYears;
                //contractTimeYears = contractTimeYearFive.Checked ? 171140003 : contractTimeYears;

                bool closedinspaces = closedinspacesCheck.Checked;
                bool customerResigned = customerResignedCheck.Checked;

                int noticePeriod = noticePeriodTxt.Text != "" ? Convert.ToInt32(noticePeriodTxt.Text.Trim()) : 0;

                // test
                HelpControl.AddToLog("Hodnota noticePeriod: " + noticePeriodTxt.Text);

                bool resignationUnit = resignationUnitMonthCheck.Checked ? false : true;

                int noticePeriodGas = noticePeriodGasTxt.Text != "" ? Convert.ToInt32(noticePeriodGasTxt.Text.Trim()) : 0;

                // test
                HelpControl.AddToLog("Hodnota noticePeriodGas: " + noticePeriodGasTxt.Text);

                bool resignationUnitGas = resignationUnitMonthGasCheck.Checked ? false : true;

                // neurcene promenne
                string opportunityCustomerLogicalName = string.Empty;
                string supplyPointName = string.Empty;
                //Guid _opportunityGasId = Guid.Empty;
                //Guid _opportunityElectricityId = Guid.Empty;
                Guid _opportunityObekomodityId = Guid.Empty;
                Guid _supplyPointGasId = Guid.Empty;
                Guid _supplyPointElectricityId = Guid.Empty;
                Guid _verifyFormGasId = Guid.Empty;
                Guid _verifyFormElectricityId = Guid.Empty;
                Guid _opportunityCustomerId = Guid.Empty;
                Guid _trustContactId = Guid.Empty;
                Guid _trustContactSecondId = Guid.Empty;
                Guid _lastTrustContactId = Guid.Empty;
                Guid _lastTrustContactSecondId = Guid.Empty;
                Guid _sellerId = Guid.Empty;
                bool isExistTrustPerson = false;
                #endregion

                #region Duplikace

                //if (command == "gas" || command == "electricity")
                //{
                //    duplicateList.Add(new DuplicateControl
                //    {
                //        companyName = companyName,
                //        companyIco = companyIco,
                //        companyDic = companyDic,
                //        titul = titulString,
                //        titulLast = titulLastString,
                //        firstName = firstName,
                //        lastName = lastName,
                //        birthday = birthdateTxt.Text.Trim(),
                //        ico = ico,
                //        dic = dic,
                //        email = email,
                //        phone = telephone,
                //        street = street,
                //        houseNumber = houseNumber,
                //        orientationNumber = orientationNumber,
                //        postalCode = postalCode,
                //        city = country,
                //        postalStreet = postalStreet,
                //        postalHouseNumber = postalHouseNumber,
                //        postalOrientationNumber = postalOrientationNumber,
                //        postalPostalCode = postalPostalCode,
                //        postalCity = postalCountry,
                //        smallCheck = smallCheck.Checked,
                //        homeCheck = homeCheck.Checked,
                //        registryRecord = writtingOR,
                //        contractTimeFirstCheck = contractTimeFirstCheck.Checked,
                //        contractTimeFirstTo = timeToDayFirstTxt.Text,
                //        contractTimeFirstFrom = timeFromDayFirstTxt.Text,
                //        contractTimeSecondCheck = contractTimeSecondCheck.Checked,
                //        contractTimeSecondOneYears = contractTimeYearFirst.Checked,
                //        contractTimeSecondTwoYears = contractTimeYearSecond.Checked,
                //        contractTimeSecondThreeYears = contractTimeYearThird.Checked,
                //        contractTimeThirdCheck = contractTimeThirdCheck.Checked,
                //        contractTimeThirdFrom = timeFromDayThirdTxt.Text,
                //        invoiceDeliveryEmailCheck = supplyPointDeliverEmailCheck.Checked,
                //        invoiceDeliveryPostCheck = supplyPointDeliverPostCheck.Checked,
                //        changesDeliveryEmailCheck = supplyPointChangesDeliverEmailCheck.Checked,
                //        changesDeliveryPostCheck = supplyPointChangesDeliverPostCheck.Checked,
                //        changesDeliveryWebCheck = supplyPointChangesDeliverWebCheck.Checked,
                //        advancesPaymentTransferCheck = supplyPointDepositPaymentTransferCheck.Checked,
                //        advancesPaymentCollectionCheck = supplyPointDepositPaymentCollectionCheck.Checked,
                //        advancesPaymentSlipCheck = supplyPointDepositPaymentSlipCheck.Checked,
                //        advancesPaymentSIPOCheck = supplyPointDepositPaymentSIPOCheck.Checked,
                //        advancesInvoicesTransferCheck = supplyPointInvoicePaymentTransferCheck.Checked,
                //        advancesInvoicesCollectionCheck = supplyPointInvoicePaymentCollectionCheck.Checked,
                //        bankNumberFirst = supplyPointBankNumberFirstTxt.Text,
                //        bankNumberSecond = supplyPointBankNumberSecondTxt.Text,
                //        bankCode = supplyPointBankNumberCodeTxt.Text,
                //        contractClosedCheck = closedinspacesCheck.Checked,
                //        contractSignature = signatureDateTxt.Text,
                //        SIPONumber = supplyPointInvoicePaymentSIPOTxt.Text,
                //        trustJobTitle = trustTitul,
                //        trustFirstName = trustFirstName,
                //        trustLastName = trustLastName,
                //        trustJobTitleSecond = trustTitulSecond,
                //        trustFirstNameSecond = trustFirstNameSecond,
                //        trustLastNameSecond = trustLastNameSecond
                //    });
                //    Session["duplicate"] = duplicateList;
                //}
                //else
                //    Session["duplicate"] = null;

                #endregion

                // ziskání Guid obchodníka
                _sellerId = LoginControl.LoggedUser().Id;

                if (smallCheck.Checked) // maloodber checkbox
                {
                    #region Pokud je zaskrtnuty Maloodber
                    // add message to log file
                    HelpControl.AddToLog("--> Začátek Maloodběr - Plyn - Obchodník: " + sellerFirstName + " " + sellerLastName + " s ID: " + _sellerId);

                    // nastavime hodnotu na account
                    opportunityCustomerLogicalName = "account";
                    supplyPointName = companyName + " - " + supplyPointStreet + " " + supplyPointHouseNumber + (supplyPointOrientationNumber != "" ? "/" + supplyPointOrientationNumber : "") + ", " + supplyPointCity;

                    // vytvoreni prvni opravnene osoby
                    if (trustFirstName != string.Empty && trustLastName != string.Empty)
                    {
                        Entity trustContact = CustomerControl.ExistsTrustContact(trustFirstName, trustLastName, ServiceControl.GetService());

                        if (trustContact != null)
                            isExistTrustPerson = true;

                        _trustContactId = CustomerControl.CreateTrustContact(
                            trustTitul,
                            trustFirstName,
                            trustLastName
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření první zodpovědné osoby: " + _trustContactId);
                    }

                    // vytvoreni druhe opravnene osoby
                    //if (trustFirstNameSecond != string.Empty && trustLastNameSecond != string.Empty)
                    //{
                    //    Entity trustContactSecond = CustomerControl.ExistsTrustContact(trustFirstNameSecond, trustLastNameSecond, ServiceControl.GetService());

                    //    if (trustContactSecond != null)
                    //        isExistTrustPerson = true;

                    //    _trustContactSecondId = CustomerControl.CreateTrustContact(
                    //        trustTitulSecond,
                    //        trustFirstNameSecond,
                    //        trustLastNameSecond
                    //        );

                    //    // add message to log file
                    //    HelpControl.AddToLog("Vytvoření druhé zodpovědné osoby: " + _trustContactSecondId);
                    //}

                    // maloodber - vytvoreni pravnicke osoby
                    Entity existsAccount = CustomerControl.ExistsAccount(companyName, companyIco, email, ServiceControl.GetService());

                    if (existsAccount != null)
                    {
                        _opportunityCustomerId = existsAccount.Id;
                        _lastTrustContactId = existsAccount.Contains("cre_responsibleperson") ? ((EntityReference)existsAccount["cre_responsibleperson"]).Id : Guid.Empty;
                        _lastTrustContactSecondId = existsAccount.Contains("cre_responsibleperson2") ? ((EntityReference)existsAccount["cre_responsibleperson2"]).Id : Guid.Empty;
                        CustomerControl.UpdateAccountTrustContacts(existsAccount, _trustContactId, _trustContactSecondId);

                        // add message to log file
                        HelpControl.AddToLog("Obchodní vztah \"" + companyName + "\" nalezen: " + _opportunityCustomerId);
                    }
                    else
                    {
                        _opportunityCustomerId = CustomerControl.CreateAccount(
                            companyName,
                            companyIco,
                            companyDic,
                            email,
                            telephone,
                            street,
                            houseNumber,
                            orientationNumber,
                            postalCode,
                            country,
                            writtingOR,
                            _trustContactId,
                            _trustContactSecondId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Obchodní vztah \"" + companyName + "\" nenalezen. Vytvořen nový: " + _opportunityCustomerId);
                    }

                    // prirazeni accountu k odpovednym osobam
                    bool assignToAccount = CustomerControl.AssignToAccountTrustContacts(_trustContactId, _trustContactSecondId, _opportunityCustomerId);

                    // add message to log file
                    HelpControl.AddToLog("Přiřazení právnických osob k obchodnímu vztahu: " + assignToAccount);

                    // vytvoreni korespondencni adresy
                    if (postalStreet != string.Empty && postalHouseNumber != string.Empty && postalOrientationNumber != string.Empty && postalPostalCode != string.Empty && postalCountry != string.Empty)
                    {
                        CustomerControl.CreateCustomerAddress(
                            companyName,
                            postalStreet,
                            postalHouseNumber + (postalOrientationNumber != "" ? "/" + postalOrientationNumber : ""),
                            postalPostalCode,
                            postalCountry,
                            opportunityCustomerLogicalName,
                            _opportunityCustomerId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření korespondenční adresy k obchodnímu vztahu: " + companyName);
                    }
                    #endregion
                }
                else if (homeCheck.Checked) // domacnost checkbox
                {
                    #region Pokud je zaskrkla Domacnost
                    // add message to log file
                    HelpControl.AddToLog("--> Začátek Domácnost - Plyn - Obchodník: " + sellerFirstName + " " + sellerLastName + " s ID: " + _sellerId);

                    // nastavime hodnotu na account
                    opportunityCustomerLogicalName = "contact";
                    supplyPointName = firstName + " " + lastName + " - " + supplyPointStreet + " " + supplyPointHouseNumber + (supplyPointOrientationNumber != "" ? "/" + supplyPointOrientationNumber : "") + ", " + supplyPointCity;


                    // domacnost - vytvoreni kontaktu
                    Entity existsContact = CustomerControl.ExistsContact(ico, street, houseNumber, orientationNumber, postalCode, country, firstName, lastName, birthday, email, ServiceControl.GetService());

                    if (existsContact != null)
                    {
                        _opportunityCustomerId = existsContact.Id;

                        // add message to log file
                        HelpControl.AddToLog("Kontakt \"" + firstName + " " + lastName + "\" nalezen: " + _opportunityCustomerId);
                    }
                    else
                    {
                        _opportunityCustomerId = CustomerControl.CreateContact(
                            titulInt,
                            titulLastInt,
                            firstName,
                            lastName,
                            email,
                            telephone,
                            street,
                            houseNumber,
                            orientationNumber,
                            postalCode,
                            country,
                            birthday,
                            ico,
                            dic
                            );

                        // add message to log file
                        HelpControl.AddToLog("Kontakt \"" + firstName + " " + lastName + "\" nenalezen. Vytvořen nový: " + _opportunityCustomerId);
                    }

                    // vytvoreni korespondencni adresy
                    if (postalStreet != string.Empty && postalHouseNumber != string.Empty && postalOrientationNumber != string.Empty && postalPostalCode != string.Empty && postalCountry != string.Empty)
                    {
                        CustomerControl.CreateCustomerAddress(
                            firstName + " " + lastName,
                            postalStreet,
                            postalHouseNumber + (postalOrientationNumber != "" ? "/" + postalOrientationNumber : ""),
                            postalPostalCode,
                            postalCountry,
                            opportunityCustomerLogicalName,
                            _opportunityCustomerId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření korespondenční adresy ke kontaktu: " + firstName + " " + lastName);
                    }
                    #endregion
                }

                #region Kontrola prilezitosti, Vytvoreni Smlouvy, Odberneho mista a Nahrani souboru

                //// try to find exists opportunity
                //EntityCollection existOpportunities = CustomerControl.ExistsOpportunities(171140000, _opportunityCustomerId, ServiceControl.GetService());
                //Entity existOpportunity = null;

                //if (existOpportunities != null)
                //{
                //    existOpportunity = existOpportunities.Entities.FirstOrDefault();

                //    // add message to log file
                //    HelpControl.AddToLog("Příležitosti nalezeny " + existOpportunities.Entities.Count + ": " + _opportunityCustomerId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Příležitosti nenalezeny: " + _opportunityCustomerId);
                //}

                // add message to log file
                HelpControl.AddToLog("Vytváření příležitosti, odberného místa, verifikačního formuláře a nahrání souborů.");

                // vytvoreni prilezitosti pro plyn
                //Contracttype - 171140002=Obě komodity
                _opportunityObekomodityId = CustomerControl.CreateContract(
                    171140002,
                    proposedNumber,
                    sellerId,
                    sellerFirstName,
                    sellerLastName,
                    signatureDate,
                    false,
                    //false, now always be 5 years changed by prem on 31 oct 2013
                    true,
                    false,
                    dateTimeFromGasTxt,
                    "",
                    productNameGas,
                    //-1, now always be 5 years changed by prem on 31 oct 2013
                    171140003,
                    closedinspaces,
                    "",
                    customerResigned,
                    generateIdCheck,
                    _sellerId,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořena příležitost pro plyn: " + _opportunityObekomodityId);

                // vytvoreni prilezitosti pro elektrinu
                /*
                _opportunityElectricityId = CustomerControl.CreateContract(
                    171140000,
                    proposedNumber,
                    sellerId,
                    sellerFirstName,
                    sellerLastName,
                    signatureDate,
                    false,
                    false,
                    false,
                    dateTimeFromTxt,
                    "",
                    productName,
                    -1,
                    closedinspaces,
                    "",
                    customerResigned,
                    generateIdCheck,
                    _sellerId,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořena příležitost pro elektrinu: " + _opportunityElectricityId);
                */

                // vytvoreni odberneho mista pro plyn
                _supplyPointGasId = CustomerControl.CreateSupplyPoint(
                    supplyPointName,
                    supplyPointStreetGas,
                    supplyPointCityGas,
                    supplyPointPostalCodeGas,
                    supplyPointHouseNumberGas,
                    supplyPointOrientationNumberGas,
                    "",
                    supplyPointEIC,
                    -1,
                    supplyPointLastProviderGas,
                    supplyPointNewDistributionGas,
                    -1,
                    supplyPointYearSubscriptionAmountGas,
                    "",
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    -1,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    -1,
                    -1,
                    "",
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId,
                    //_opportunityGasId
                    _opportunityObekomodityId,
                    171140001
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořeno odběrné místo pro plyn: " + _supplyPointGasId);

                // vytvoreni odberneho mista pro elektrinu
                _supplyPointElectricityId = CustomerControl.CreateSupplyPoint(
                    supplyPointName,
                    supplyPointStreet,
                    supplyPointCity,
                    supplyPointPostalCode,
                    supplyPointHouseNumber,
                    supplyPointOrientationNumber,
                    supplyPointEAN,
                    "",
                    -1,
                    supplyPointLastProvider,
                    -1,
                    supplyPointNewDistribution,
                    supplyPointYearSubscriptionAmountVT,
                    supplyPointYearSubscriptionAmountNT,
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    -1,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    supplyPointPhase,
                    supplyPointDistributionAmount,
                    supplyPointBreakerAmount,
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId,
                    // _opportunityElectricityId
                   _opportunityObekomodityId,
                    171140000
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořeno odběrné místo pro elektrinu: " + _supplyPointElectricityId);

                // vytvoreni verify form pro plyn
                _verifyFormGasId = CustomerControl.CreateVerifyForm(
                    trustTitul,
                    trustFirstName,
                    trustLastName,
                    "",
                    "",
                    "",
                    companyDic,
                    companyIco,
                    companyName,
                    dic,
                    ico,
                    email,
                    titulInt,
                    firstName,
                    lastName,
                    titulLastInt,
                    birthday,
                    telephone,
                    writtingOR,
                    street,
                    country,
                    postalCode,
                    postalStreet,
                    postalCountry,
                    postalPostalCode,
                    postalHouseNumber,
                    postalOrientationNumber,
                    supplyPointStreetGas,
                    supplyPointCityGas,
                    supplyPointPostalCodeGas,
                    supplyPointHouseNumberGas,
                    supplyPointOrientationNumberGas,
                    houseNumber,
                    orientationNumber,
                    supplyPointName,
                    "",
                    supplyPointEIC,
                    false,

                    //false, now always be 5 years changed by prem on 31 oct 2013
                    true,
                    false,
                    dateTimeFromGasTxt,
                    "", "",
                    productNameGas,

                    //-1 , now always be 5 years changed by prem on 31 oct 2013
                    171140003,
                    -1,
                    supplyPointLastProviderGas,
                    supplyPointNewDistributionGas,
                    -1,
                    supplyPointYearSubscriptionAmountGas,
                    "",
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    -1,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    -1,
                    -1,
                    "",
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    noticePeriodGas,
                    resignationUnitGas,
                    customerResigned,
                    isExistTrustPerson,
                    opportunityCustomerLogicalName,
                    proposedNumber,
                    _opportunityCustomerId,
                    // _opportunityGasId,
                   _opportunityObekomodityId,
                    _supplyPointGasId,
                    _trustContactId,
                    _trustContactSecondId,
                    _lastTrustContactId,
                    _lastTrustContactSecondId,
                    _sellerId,
                    171140001,
                    signatureDate, closedinspaces
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořen verifikační formulář pro plyn: " + _verifyFormGasId);

                // vytvoreni verify form pro elektrinu
                _verifyFormElectricityId = CustomerControl.CreateVerifyForm(
                    trustTitul,
                    trustFirstName,
                    trustLastName,
                    "",
                    "",
                    "",
                    companyDic,
                    companyIco,
                    companyName,
                    dic,
                    ico,
                    email,
                    titulInt,
                    firstName,
                    lastName,
                    titulLastInt,
                    birthday,
                    telephone,
                    writtingOR,
                    street,
                    country,
                    postalCode,
                    postalStreet,
                    postalCountry,
                    postalPostalCode,
                    postalHouseNumber,
                    postalOrientationNumber,
                    supplyPointStreet,
                    supplyPointCity,
                    supplyPointPostalCode,
                    supplyPointHouseNumber,
                    supplyPointOrientationNumber,
                    houseNumber,
                    orientationNumber,
                    supplyPointName,
                    supplyPointEAN,
                    "",
                    false,
                    //false, now always be 5 years changed by prem on 31 oct 2013
                    true,
                    false,
                    dateTimeFromTxt,
                    "",
                    "",
                    productName,
                    //-1,now always be 5 years changed by prem on 31 oct 2013
                     171140003,
                    -1,
                    supplyPointLastProvider,
                    supplyPointNewDistribution,
                    -1,
                    supplyPointYearSubscriptionAmountVT,
                    supplyPointYearSubscriptionAmountNT,
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    -1,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    -1,
                    supplyPointDistributionAmount,
                    supplyPointBreakerAmount,
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    noticePeriod,
                    resignationUnit,
                    customerResigned,
                    isExistTrustPerson,
                    opportunityCustomerLogicalName,
                    proposedNumber,
                    _opportunityCustomerId,
                    // _opportunityElectricityId,
                   _opportunityObekomodityId,
                    _supplyPointElectricityId,
                    _trustContactId,
                    _trustContactSecondId,
                    _lastTrustContactId,
                    _lastTrustContactSecondId,
                    _sellerId,
                    171140000,
                    signatureDate, closedinspaces
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořen verifikační formulář pro elektřinu: " + _verifyFormElectricityId);

                #region AddMarketingList Member
                //_opportunityCustomerId
                Guid ListId;
                if (!string.IsNullOrEmpty(hdnMarketingList.Value) && Guid.TryParse(hdnMarketingList.Value, out ListId))
                {
                    Guid memeberId = CustomerControl.AddListMemeber(ListId, _opportunityCustomerId);

                    if (memeberId != Guid.Empty)
                        // add message to log file
                        HelpControl.AddToLog("Memeber Added into MarketingList. list memeber id :  " + memeberId);
                }
                #endregion


                // nahrane soubory
                HttpFileCollection files = Request.Files;

                // pokud soubor existuje, nahraje se
                for (var i = 0; i < files.Count; i++)
                {
                    if (files[i].ContentLength > 0)
                    {
                        bool uploadedGas = CustomerControl.AddAnnotation(files[i], "cre_verifyform", _verifyFormGasId);
                        bool uploadedElectricity = CustomerControl.AddAnnotation(files[i], "cre_verifyform", _verifyFormElectricityId);

                        if (uploadedGas)
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" byl uložen na plyn. " + (i + 1) + " z " + files.Count);
                        else
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" nebyl uložen na plyn. " + (i + 1) + " z " + files.Count);

                        if (uploadedElectricity)
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" byl uložen na elektřinu. " + (i + 1) + " z " + files.Count);
                        else
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" nebyl uložen na elektřinu. " + (i + 1) + " z " + files.Count);
                    }
                }
                #endregion

                #region Aktivace prilezitosti a nabidek
                //// aktivovani nabidky jako ziskane
                //bool isOrdersActivated = CustomerControl.ActivateQuotesByOpportunity(_opportunityId);

                //if (isOrdersActivated)
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Nabidky oznaceny jako ziskany pro prilezistost: " + _opportunityId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Nabidky se nepodarily oznacit jako ziskane pro prilezistost: " + _opportunityId);
                //}

                //// aktivovani prilezistosti jako ziskana
                //bool isActivated = CustomerControl.ActivateOpportunity(_opportunityId);

                //if (isActivated)
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Prilezitost oznacena jako ziskana: " + _opportunityId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Prilezitost se nepodarilo oznacit jako ziskana: " + _opportunityId);
                //}
                #endregion

                new ErrorControl("Formulář byl uložen.");
            }
            catch (Exception ex)
            {
                Email.SendError("VemexPortal error", "Error: gasSubmitBtn_Click in obekomodity.aspx code-behind was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));

                // add message to log file
                HelpControl.AddToLog("Nepodařilo se vytvořit smlouvy pro komodity.");

                // throw message
                new ErrorControl("Formulář se nepodařilo uložit.");
            }

            Response.Redirect(UrlControl.GetPathUrl() + "/obekomodity");
        }
    }
}