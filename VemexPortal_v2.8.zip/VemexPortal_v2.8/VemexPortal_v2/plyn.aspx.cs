﻿using CRM.Helper;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using Web.Controls;
using Microsoft.Xrm.Sdk.Query;

namespace VemexPortal
{
    public partial class plyn : PageControl
    {
        public List<SelectControl> distributionsList = new List<SelectControl>(),
                                   titulList = new List<SelectControl>(),
                                   titulLastList = new List<SelectControl>(),
                                   suppliersList = new List<SelectControl>();
        public List<DuplicateControl> duplicateList = new List<DuplicateControl>();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!LoginControl.IsLogged())
                    Response.Redirect(UrlControl.GetPathUrl() + "/odhlaseni");

                if (Session["duplicate"] != null)
                {
                    // nacteni duplikovanych dat
                    duplicateList = (List<DuplicateControl>)Session["duplicate"];

                    #region Zobrazeni duplikovanych dat

                    foreach (var duplicate in duplicateList)
                    {
                        writtingORTxt.Text = duplicate.registryRecord;
                        companyNameTxt.Text = duplicate.companyName;
                        companyIcoTxt.Text = duplicate.companyIco;
                        companyDicTxt.Text = duplicate.companyDic;
                        titulTxt.Text = duplicate.titul;
                        titulLastTxt.Text = duplicate.titulLast;
                        firstNameTxt.Text = duplicate.firstName;
                        lastNameTxt.Text = duplicate.lastName;
                        birthdateTxt.Text = duplicate.birthday;
                        icoTxt.Text = duplicate.ico;
                        dicTxt.Text = duplicate.dic;
                        emailTxt.Text = duplicate.email;
                        phoneTxt.Text = duplicate.phone;
                        streetTxt.Text = duplicate.street;
                        houseNumberTxt.Text = duplicate.houseNumber;
                        orientationNumberTxt.Text = duplicate.orientationNumber;
                        postalCodeTxt.Text = duplicate.postalCode;
                        countryTxt.Text = duplicate.city;
                        postalStreetTxt.Text = duplicate.postalStreet;
                        postalHouseNumberTxt.Text = duplicate.postalHouseNumber;
                        postalOrientationNumberTxt.Text = duplicate.postalOrientationNumber;
                        postalPostalCodeTxt.Text = duplicate.postalPostalCode;
                        postalCountryTxt.Text = duplicate.postalCity;
                        contractTimeFirstCheck.Checked = duplicate.contractTimeFirstCheck;
                        timeToDayFirstTxt.Text = duplicate.contractTimeFirstTo;
                        timeFromDayFirstTxt.Text = duplicate.contractTimeFirstFrom;
                        contractTimeSecondCheck.Checked = duplicate.contractTimeSecondCheck;
                        contractTimeYearFirst.Checked = duplicate.contractTimeSecondOneYears;
                        contractTimeYearSecond.Checked = duplicate.contractTimeSecondTwoYears;
                        contractTimeYearThird.Checked = duplicate.contractTimeSecondThreeYears;
                        contractTimeThirdCheck.Checked = duplicate.contractTimeThirdCheck;
                        timeFromDayThirdTxt.Text = duplicate.contractTimeThirdFrom;
                        supplyPointDeliverEmailCheck.Checked = duplicate.invoiceDeliveryEmailCheck;
                        supplyPointDeliverPostCheck.Checked = duplicate.invoiceDeliveryPostCheck;
                        supplyPointChangesDeliverEmailCheck.Checked = duplicate.changesDeliveryEmailCheck;
                        supplyPointChangesDeliverPostCheck.Checked = duplicate.changesDeliveryPostCheck;
                        supplyPointChangesDeliverWebCheck.Checked = duplicate.changesDeliveryWebCheck;
                        supplyPointDepositPaymentTransferCheck.Checked = duplicate.advancesPaymentTransferCheck;
                        supplyPointDepositPaymentCollectionCheck.Checked = duplicate.advancesPaymentCollectionCheck;
                        supplyPointDepositPaymentSlipCheck.Checked = duplicate.advancesPaymentSlipCheck;
                        supplyPointDepositPaymentSIPOCheck.Checked = duplicate.advancesPaymentSIPOCheck;
                        supplyPointInvoicePaymentTransferCheck.Checked = duplicate.advancesInvoicesTransferCheck;
                        supplyPointInvoicePaymentCollectionCheck.Checked = duplicate.advancesInvoicesCollectionCheck;
                        supplyPointBankNumberFirstTxt.Text = duplicate.bankNumberFirst;
                        supplyPointBankNumberSecondTxt.Text = duplicate.bankNumberSecond;
                        supplyPointBankNumberCodeTxt.Text = duplicate.bankCode;
                        closedinspacesCheck.Checked = duplicate.contractClosedCheck;
                        signatureDateTxt.Text = duplicate.contractSignature;
                        supplyPointInvoicePaymentSIPOTxt.Text = duplicate.SIPONumber;
                        smallCheck.Checked = duplicate.smallCheck;
                        homeCheck.Checked = duplicate.homeCheck;
                        trustTitulTxt.Text = duplicate.trustJobTitle;
                        trustFirstNameTxt.Text = duplicate.trustFirstName;
                        trustLastNameTxt.Text = duplicate.trustLastName;
                        trustTitulSecondTxt.Text = duplicate.trustJobTitleSecond;
                        trustFirstNameSecondTxt.Text = duplicate.trustFirstNameSecond;
                        trustLastNameSecondTxt.Text = duplicate.trustLastNameSecond;
                    }

                    #endregion
                }

                titulList = SelectControl.GetSelectOptions("contact", "cre_titulpred");
                titulLastList = SelectControl.GetSelectOptions("contact", "cre_titulza");
                distributionsList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_distributorgas");
                suppliersList = SelectControl.GetSelectOptions("cre_supplypoint", "cre_originaldistributor");

                sellerFirstNameTxt.Text = LoginControl.LoggedUser().FirstName;
                sellerLastNameTxt.Text = LoginControl.LoggedUser().LastName;
                sellerIdTxt.Text = LoginControl.LoggedUser().LoginNumber;



                #region MarketingList
/*
                FilterExpression filter = new FilterExpression();
                filter.AddCondition("cre_uselikesource", ConditionOperator.Equal, true);
                //Account
                filter.AddCondition("createdfromcode", ConditionOperator.Equal, 1);
                filter.FilterOperator = LogicalOperator.And;
                QueryExpression query = new QueryExpression()
                {
                    EntityName = "list",
                    ColumnSet = new ColumnSet(new string[] 
                 {
                     "listid", 
                     "listname"
                 }),
                    Criteria = filter
                };
                marketingList = SelectControl.GetSelectOptions(query, "listname", "listid");
*/
                #endregion
 

            }
        }

        protected void logoutSubmitBtn_Click(object sender, ImageClickEventArgs e)
        {
            LoginControl.Logout();
            Response.Redirect(UrlControl.GetPathUrl());
        }

        [WebMethod]
        public static bool IsEICExists(string eic)
        {
            return CustomerControl.IsExistsEIC(eic, ServiceControl.GetService());
        }

        protected void gasSubmitBtn_Click(object sender, EventArgs e)
        {
            // comand name
            string command = ((Button)sender).CommandName;

            try
            {
                #region Promenne

                // cislo navrhu
                string proposedNumber = proposedNumberTxt.Text.Trim();
                bool generateIdCheck = generateCheck.Checked;

                // fyzicka osoba
                int titulInt = titulValue.Value != "" ? Convert.ToInt32(titulValue.Value.Trim()) : -1;
                string titulString = titulTxt.Text.Trim();
                int titulLastInt = titulLastValue.Value != "" ? Convert.ToInt32(titulLastValue.Value.Trim()) : -1;
                string titulLastString = titulLastTxt.Text.Trim();
                string firstName = firstNameTxt.Text.Trim();
                string lastName = lastNameTxt.Text.Trim();
                string birthday = (birthdateTxt.Text.Trim() != "" && birthdateTxt.Text.Trim().Length == 8) ? birthdateTxt.Text.Trim().Substring(0, 2) + "/" + birthdateTxt.Text.Trim().Substring(2, 2) + "/" + birthdateTxt.Text.Trim().Substring(4, 4) : "";
                string ico = icoTxt.Text.Trim();
                string dic = dicTxt.Text.Trim();

                // pravnicka osoba
                string companyName = companyNameTxt.Text.Trim();
                string companyIco = companyIcoTxt.Text.Trim();
                string companyDic = companyDicTxt.Text.Trim();

                // osoba opravnena jednat
                string trustTitul = trustTitulTxt.Text.Trim();
                string trustFirstName = trustFirstNameTxt.Text.Trim();
                string trustLastName = trustLastNameTxt.Text.Trim();
                string trustTitulSecond = trustTitulSecondTxt.Text.Trim();
                string trustFirstNameSecond = trustFirstNameSecondTxt.Text.Trim();
                string trustLastNameSecond = trustLastNameSecondTxt.Text.Trim();

                // kontaktni udaje
                string email = emailTxt.Text.Trim();
                string telephone = phoneTxt.Text.Trim();

                // silo trvale bydliste
                string street = streetTxt.Text.Trim();
                string houseNumber = houseNumberTxt.Text.Trim();
                string orientationNumber = orientationNumberTxt.Text.Trim();
                string postalCode = postalCodeTxt.Text.Trim();
                string country = countryTxt.Text.Trim();
                string writtingOR = writtingORTxt.Text.Trim();

                // korespondencni adresa
                string postalStreet = postalStreetTxt.Text.Trim();
                string postalHouseNumber = postalHouseNumberTxt.Text.Trim();
                string postalOrientationNumber = postalOrientationNumberTxt.Text.Trim();
                string postalPostalCode = postalPostalCodeTxt.Text.Trim();
                string postalCountry = postalCountryTxt.Text.Trim();

                // odberne misto
                string supplyPointStreet = supplyPointStreetTxt.Text.Trim();
                string supplyPointHouseNumber = supplyPointHouseNumberTxt.Text.Trim();
                string supplyPointOrientationNumber = supplyPointOrientationNumberTxt.Text.Trim();
                string supplyPointCity = supplyPointCountryTxt.Text.Trim();
                string supplyPointPostalCode = supplyPointPostalCodeTxt.Text.Trim();
                string supplyPointEIC = supplyPointEICTxt.Text.Trim();
                int supplyPointLastProvider = supplyPointLastProviderValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointLastProviderValue.Value.Trim()) : -1;
                int supplyPointNewDistribution = supplyPointNewDistributionValue.Value.Trim() != "" ? Convert.ToInt32(supplyPointNewDistributionValue.Value.Trim()) : -1;
                string supplyPointYearSubscriptionAmount = supplyPointYearSubscriptionAmountTxt.Text.Trim();
                int supplyPointDepositAmount = supplyPointDepositAmountTxt.Text.Trim() != "" ? Convert.ToInt32(supplyPointDepositAmountTxt.Text.Trim()) : 0;
                string supplyPointInvoicePaymentSIPO = supplyPointInvoicePaymentSIPOTxt.Text.Trim();
                string supplyPointBankNumberFirst = supplyPointBankNumberFirstTxt.Text.Trim();
                string supplyPointBankNumberSecond = supplyPointBankNumberSecondTxt.Text.Trim();
                string supplyPointBankNumberCode = supplyPointBankNumberCodeTxt.Text.Trim();

                int supplyPointChange = supplyPointChangeProviderCheck.Checked ? 171140000 : -1;
                supplyPointChange = supplyPointChangeCustomerCheck.Checked ? 171140001 : supplyPointChange;
                supplyPointChange = supplyPointChangeNewSubscriptionCheck.Checked ? 171140002 : supplyPointChange;
                supplyPointChange = supplyPointChangeProviderPriceCheck.Checked ? 171140003 : supplyPointChange;
                supplyPointChange = supplyPointOverwriteCheck.Checked ? 171140004 : supplyPointChange;

                int supplyPointDepositPeriod = supplyPointDepositMonthCheck.Checked ? 171140000 : -1;
                supplyPointDepositPeriod = supplyPointDepositQuarterCheck.Checked ? 171140001 : supplyPointDepositPeriod;

                int supplyPointDeliverInvoice = supplyPointDeliverEmailCheck.Checked ? 171140000 : -1;
                supplyPointDeliverInvoice = supplyPointDeliverPostCheck.Checked ? 171140001 : supplyPointDeliverInvoice;

                int supplyPointChangesDeliver = supplyPointChangesDeliverEmailCheck.Checked ? 171140002 : -1;
                supplyPointChangesDeliver = supplyPointChangesDeliverPostCheck.Checked ? 171140000 : supplyPointChangesDeliver;
                supplyPointChangesDeliver = supplyPointChangesDeliverWebCheck.Checked ? 171140001 : supplyPointChangesDeliver;

                int supplyPointDepositPayment = supplyPointDepositPaymentTransferCheck.Checked ? 171140000 : -1;
                supplyPointDepositPayment = supplyPointDepositPaymentCollectionCheck.Checked ? 171140001 : supplyPointDepositPayment;
                supplyPointDepositPayment = supplyPointDepositPaymentSlipCheck.Checked ? 171140002 : supplyPointDepositPayment;
                supplyPointDepositPayment = supplyPointDepositPaymentSIPOCheck.Checked ? 171140003 : supplyPointDepositPayment;

                int supplyPointInvoicePayment = supplyPointInvoicePaymentTransferCheck.Checked ? 171140000 : -1;
                supplyPointInvoicePayment = supplyPointInvoicePaymentCollectionCheck.Checked ? 171140001 : supplyPointInvoicePayment;
                supplyPointInvoicePayment = supplyPointInvoicePaymentSlipCheck.Checked ? 171140002 : supplyPointInvoicePayment;

                // odberne misto 2
                string supplyPointStreet2 = supplyPointStreetTxt2.Text.Trim();
                string supplyPointHouseNumber2 = supplyPointHouseNumberTxt2.Text.Trim();
                string supplyPointOrientationNumber2 = supplyPointOrientationNumberTxt2.Text.Trim();
                string supplyPointCity2 = supplyPointCountryTxt2.Text.Trim();
                string supplyPointPostalCode2 = supplyPointPostalCodeTxt2.Text.Trim();
                string supplyPointEIC2 = supplyPointEICTxt2.Text.Trim();
                int supplyPointLastProvider2 = supplyPointLastProviderValue2.Value.Trim() != "" ? Convert.ToInt32(supplyPointLastProviderValue2.Value.Trim()) : -1;
                int supplyPointNewDistribution2 = supplyPointNewDistributionValue2.Value.Trim() != "" ? Convert.ToInt32(supplyPointNewDistributionValue2.Value.Trim()) : -1;
                string supplyPointYearSubscriptionAmount2 = supplyPointYearSubscriptionAmountTxt2.Text.Trim();
                int supplyPointDepositAmount2 = supplyPointDepositAmountTxt2.Text.Trim() != "" ? Convert.ToInt32(supplyPointDepositAmountTxt2.Text.Trim()) : 0;
                string supplyPointInvoicePaymentSIPO2 = supplyPointInvoicePaymentSIPOTxt2.Text.Trim();
                string supplyPointBankNumberFirst2 = supplyPointBankNumberFirstTxt2.Text.Trim();
                string supplyPointBankNumberSecond2 = supplyPointBankNumberSecondTxt2.Text.Trim();
                string supplyPointBankNumberCode2 = supplyPointBankNumberCodeTxt2.Text.Trim();

                int supplyPointChange2 = supplyPointChangeProviderCheck2.Checked ? 171140000 : -1;
                supplyPointChange2 = supplyPointChangeCustomerCheck2.Checked ? 171140001 : supplyPointChange2;
                supplyPointChange2 = supplyPointChangeNewSubscriptionCheck2.Checked ? 171140002 : supplyPointChange2;
                supplyPointChange2 = supplyPointChangeProviderPriceCheck2.Checked ? 171140003 : supplyPointChange2;
                supplyPointChange2 = supplyPointOverwriteCheck2.Checked ? 171140004 : supplyPointChange2;

                int supplyPointDepositPeriod2 = supplyPointDepositMonthCheck2.Checked ? 171140000 : -1;
                supplyPointDepositPeriod2 = supplyPointDepositQuarterCheck2.Checked ? 171140001 : supplyPointDepositPeriod2;

                int supplyPointDeliverInvoice2 = supplyPointDeliverEmailCheck2.Checked ? 171140000 : -1;
                supplyPointDeliverInvoice2 = supplyPointDeliverPostCheck2.Checked ? 171140001 : supplyPointDeliverInvoice2;

                int supplyPointChangesDeliver2 = supplyPointChangesDeliverEmailCheck2.Checked ? 171140002 : -1;
                supplyPointChangesDeliver2 = supplyPointChangesDeliverPostCheck2.Checked ? 171140000 : supplyPointChangesDeliver2;
                supplyPointChangesDeliver2 = supplyPointChangesDeliverWebCheck2.Checked ? 171140001 : supplyPointChangesDeliver2;

                int supplyPointDepositPayment2 = supplyPointDepositPaymentTransferCheck2.Checked ? 171140000 : -1;
                supplyPointDepositPayment2 = supplyPointDepositPaymentCollectionCheck2.Checked ? 171140001 : supplyPointDepositPayment2;
                supplyPointDepositPayment2 = supplyPointDepositPaymentSlipCheck2.Checked ? 171140002 : supplyPointDepositPayment2;
                supplyPointDepositPayment2 = supplyPointDepositPaymentSIPOCheck2.Checked ? 171140003 : supplyPointDepositPayment2;

                int supplyPointInvoicePayment2 = supplyPointInvoicePaymentTransferCheck2.Checked ? 171140000 : -1;
                supplyPointInvoicePayment2 = supplyPointInvoicePaymentCollectionCheck2.Checked ? 171140001 : supplyPointInvoicePayment2;
                supplyPointInvoicePayment2 = supplyPointInvoicePaymentSlipCheck2.Checked ? 171140002 : supplyPointInvoicePayment2;

                // info prodejce
                string signatureDate = (signatureDateTxt.Text.Trim() != "" && signatureDateTxt.Text.Trim().Length == 8) ? signatureDateTxt.Text.Trim().Substring(0, 2) + "/" + signatureDateTxt.Text.Trim().Substring(2, 2) + "/" + signatureDateTxt.Text.Trim().Substring(4, 4) : "";
                string sellerId = sellerIdTxt.Text.Trim();
                string sellerFirstName = sellerFirstNameTxt.Text.Trim();
                string sellerLastName = sellerLastNameTxt.Text.Trim();

                // smlouva na dobu
                string productName = productNameTxt.Text.Trim();
                string dateTimeFromFirstTxt = (timeFromDayFirstTxt.Text.Trim() != "" && timeFromDayFirstTxt.Text.Trim().Length == 8) ? timeFromDayFirstTxt.Text.Trim().Substring(0, 2) + "/" + timeFromDayFirstTxt.Text.Trim().Substring(2, 2) + "/" + timeFromDayFirstTxt.Text.Trim().Substring(4, 4) : "";
                string dateTimeToFirstTxt = (timeToDayFirstTxt.Text.Trim() != "" && timeToDayFirstTxt.Text.Trim().Length == 8) ? timeToDayFirstTxt.Text.Trim().Substring(0, 2) + "/" + timeToDayFirstTxt.Text.Trim().Substring(2, 2) + "/" + timeToDayFirstTxt.Text.Trim().Substring(4, 4) : "";
                string dateTimeFromThirdTxt = (timeFromDayThirdTxt.Text.Trim() != "" && timeFromDayThirdTxt.Text.Trim().Length == 8) ? timeFromDayThirdTxt.Text.Trim().Substring(0, 2) + "/" + timeFromDayThirdTxt.Text.Trim().Substring(2, 2) + "/" + timeFromDayThirdTxt.Text.Trim().Substring(4, 4) : "";

                int contractTimeYears = contractTimeYearFirst.Checked ? 171140000 : -1;
                contractTimeYears = contractTimeYearSecond.Checked ? 171140001 : contractTimeYears;
                contractTimeYears = contractTimeYearThird.Checked ? 171140002 : contractTimeYears;
                contractTimeYears = contractTimeYearFive.Checked ? 171140003 : contractTimeYears;

                bool closedinspaces = closedinspacesCheck.Checked;
                bool customerResigned = customerResignedCheck.Checked;
                int noticePeriod = noticePeriodTxt.Text != "" ? Convert.ToInt32(noticePeriodTxt.Text.Trim()) : 0;
                bool resignationUnit = resignationUnitMonthCheck.Checked ? false : true;

                // neurcene promenne
                string opportunityCustomerLogicalName = string.Empty;
                string supplyPointName = string.Empty;
                Guid _opportunityId = Guid.Empty;
                Guid _supplyPointId = Guid.Empty;
                Guid _verifyFormId = Guid.Empty;
                Guid _opportunityCustomerId = Guid.Empty;
                Guid _trustContactId = Guid.Empty;
                Guid _trustContactSecondId = Guid.Empty;
                Guid _lastTrustContactId = Guid.Empty;
                Guid _lastTrustContactSecondId = Guid.Empty;
                Guid _sellerId = Guid.Empty;
                bool isExistTrustPerson = false;
                #endregion

                #region Duplikace

                if (command == "gas" || command == "electricity")
                {
                    duplicateList.Add(new DuplicateControl
                    {
                        companyName = companyName,
                        companyIco = companyIco,
                        companyDic = companyDic,
                        titul = titulString,
                        titulLast = titulLastString,
                        firstName = firstName,
                        lastName = lastName,
                        birthday = birthdateTxt.Text.Trim(),
                        ico = ico,
                        dic = dic,
                        email = email,
                        phone = telephone,
                        street = street,
                        houseNumber = houseNumber,
                        orientationNumber = orientationNumber,
                        postalCode = postalCode,
                        city = country,
                        postalStreet = postalStreet,
                        postalHouseNumber = postalHouseNumber,
                        postalOrientationNumber = postalOrientationNumber,
                        postalPostalCode = postalPostalCode,
                        postalCity = postalCountry,
                        smallCheck = smallCheck.Checked,
                        homeCheck = homeCheck.Checked,
                        registryRecord = writtingOR,
                        contractTimeFirstCheck = contractTimeFirstCheck.Checked,
                        contractTimeFirstTo = timeToDayFirstTxt.Text,
                        contractTimeFirstFrom = timeFromDayFirstTxt.Text,
                        contractTimeSecondCheck = contractTimeSecondCheck.Checked,
                        contractTimeSecondOneYears = contractTimeYearFirst.Checked,
                        contractTimeSecondTwoYears = contractTimeYearSecond.Checked,
                        contractTimeSecondThreeYears = contractTimeYearThird.Checked,
                        contractTimeThirdCheck = contractTimeThirdCheck.Checked,
                        contractTimeThirdFrom = timeFromDayThirdTxt.Text,
                        invoiceDeliveryEmailCheck = supplyPointDeliverEmailCheck.Checked,
                        invoiceDeliveryPostCheck = supplyPointDeliverPostCheck.Checked,
                        changesDeliveryEmailCheck = supplyPointChangesDeliverEmailCheck.Checked,
                        changesDeliveryPostCheck = supplyPointChangesDeliverPostCheck.Checked,
                        changesDeliveryWebCheck = supplyPointChangesDeliverWebCheck.Checked,
                        advancesPaymentTransferCheck = supplyPointDepositPaymentTransferCheck.Checked,
                        advancesPaymentCollectionCheck = supplyPointDepositPaymentCollectionCheck.Checked,
                        advancesPaymentSlipCheck = supplyPointDepositPaymentSlipCheck.Checked,
                        advancesPaymentSIPOCheck = supplyPointDepositPaymentSIPOCheck.Checked,
                        advancesInvoicesTransferCheck = supplyPointInvoicePaymentTransferCheck.Checked,
                        advancesInvoicesCollectionCheck = supplyPointInvoicePaymentCollectionCheck.Checked,
                        bankNumberFirst = supplyPointBankNumberFirstTxt.Text,
                        bankNumberSecond = supplyPointBankNumberSecondTxt.Text,
                        bankCode = supplyPointBankNumberCodeTxt.Text,
                        contractClosedCheck = closedinspacesCheck.Checked,
                        contractSignature = signatureDateTxt.Text,
                        SIPONumber = supplyPointInvoicePaymentSIPOTxt.Text,
                        trustJobTitle = trustTitul,
                        trustFirstName = trustFirstName,
                        trustLastName = trustLastName,
                        trustJobTitleSecond = trustTitulSecond,
                        trustFirstNameSecond = trustFirstNameSecond,
                        trustLastNameSecond = trustLastNameSecond
                    });
                    Session["duplicate"] = duplicateList;
                }
                else
                    Session["duplicate"] = null;

                #endregion

                // ziskání Guid obchodníka
                _sellerId = LoginControl.LoggedUser().Id;

                #region SmallScale Company
                if (smallCheck.Checked) // maloodber checkbox
                {
                    #region Pokud je zaskrtnuty Maloodber
                    // add message to log file
                    HelpControl.AddToLog("--> Začátek Maloodběr - Plyn - Obchodník: " + sellerFirstName + " " + sellerLastName + " s ID: " + _sellerId);

                    // nastavime hodnotu na account
                    opportunityCustomerLogicalName = "account";
                    supplyPointName = companyName + " - " + supplyPointStreet + " " + supplyPointHouseNumber + (supplyPointOrientationNumber != "" ? "/" + supplyPointOrientationNumber : "") + ", " + supplyPointCity;

                    // vytvoreni prvni opravnene osoby
                    if (trustFirstName != string.Empty && trustLastName != string.Empty)
                    {
                        Entity trustContact = CustomerControl.ExistsTrustContact(trustFirstName, trustLastName, ServiceControl.GetService());

                        if (trustContact != null)
                            isExistTrustPerson = true;

                        _trustContactId = CustomerControl.CreateTrustContact(
                            trustTitul,
                            trustFirstName,
                            trustLastName
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření první zodpovědné osoby: " + _trustContactId);
                    }

                    // vytvoreni druhe opravnene osoby
                    if (trustFirstNameSecond != string.Empty && trustLastNameSecond != string.Empty)
                    {
                        Entity trustContactSecond = CustomerControl.ExistsTrustContact(trustFirstNameSecond, trustLastNameSecond, ServiceControl.GetService());

                        if (trustContactSecond != null)
                            isExistTrustPerson = true;

                        _trustContactSecondId = CustomerControl.CreateTrustContact(
                            trustTitulSecond,
                            trustFirstNameSecond,
                            trustLastNameSecond
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření druhé zodpovědné osoby: " + _trustContactSecondId);
                    }

                    // maloodber - vytvoreni pravnicke osoby
                    Entity existsAccount = CustomerControl.ExistsAccount(companyName, companyIco, email, ServiceControl.GetService());

                    if (existsAccount != null)
                    {
                        _opportunityCustomerId = existsAccount.Id;
                        _lastTrustContactId = existsAccount.Contains("cre_responsibleperson") ? ((EntityReference)existsAccount["cre_responsibleperson"]).Id : Guid.Empty;
                        _lastTrustContactSecondId = existsAccount.Contains("cre_responsibleperson2") ? ((EntityReference)existsAccount["cre_responsibleperson2"]).Id : Guid.Empty;
                        CustomerControl.UpdateAccountTrustContacts(existsAccount, _trustContactId, _trustContactSecondId);

                        // add message to log file
                        HelpControl.AddToLog("Obchodní vztah \"" + companyName + "\" nalezen: " + _opportunityCustomerId);
                    }
                    else
                    {
                        _opportunityCustomerId = CustomerControl.CreateAccount(
                            companyName,
                            companyIco,
                            companyDic,
                            email,
                            telephone,
                            street,
                            houseNumber,
                            orientationNumber,
                            postalCode,
                            country,
                            writtingOR,
                            _trustContactId,
                            _trustContactSecondId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Obchodní vztah \"" + companyName + "\" nenalezen. Vytvořen nový: " + _opportunityCustomerId);
                    }

                    // prirazeni accountu k odpovednym osobam
                    bool assignToAccount = CustomerControl.AssignToAccountTrustContacts(_trustContactId, _trustContactSecondId, _opportunityCustomerId);

                    // add message to log file
                    HelpControl.AddToLog("Přiřazení právnických osob k obchodnímu vztahu: " + assignToAccount);

                    // vytvoreni korespondencni adresy
                    if (postalStreet != string.Empty && postalHouseNumber != string.Empty && postalOrientationNumber != string.Empty && postalPostalCode != string.Empty && postalCountry != string.Empty)
                    {
                        CustomerControl.CreateCustomerAddress(
                            companyName,
                            postalStreet,
                            postalHouseNumber + (postalOrientationNumber != "" ? "/" + postalOrientationNumber : ""),
                            postalPostalCode,
                            postalCountry,
                            opportunityCustomerLogicalName,
                            _opportunityCustomerId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření korespondenční adresy k obchodnímu vztahu: " + companyName);
                    }
                    #endregion
                }
                #endregion

                #region Person
                else if (homeCheck.Checked) // domacnost checkbox
                {
                    #region Pokud je zaskrkla Domacnost
                    // add message to log file
                    HelpControl.AddToLog("--> Začátek Domácnost - Plyn - Obchodník: " + sellerFirstName + " " + sellerLastName + " s ID: " + _sellerId);

                    // nastavime hodnotu na account
                    opportunityCustomerLogicalName = "contact";
                    supplyPointName = firstName + " " + lastName + " - " + supplyPointStreet + " " + supplyPointHouseNumber + (supplyPointOrientationNumber != "" ? "/" + supplyPointOrientationNumber : "") + ", " + supplyPointCity;


                    // domacnost - vytvoreni kontaktu
                    Entity existsContact = CustomerControl.ExistsContact(ico, street, houseNumber, orientationNumber, postalCode, country, firstName, lastName, birthday, email, ServiceControl.GetService());

                    if (existsContact != null)
                    {
                        _opportunityCustomerId = existsContact.Id;

                        // add message to log file
                        HelpControl.AddToLog("Kontakt \"" + firstName + " " + lastName + "\" nalezen: " + _opportunityCustomerId);
                    }
                    else
                    {
                        _opportunityCustomerId = CustomerControl.CreateContact(
                            titulInt,
                            titulLastInt,
                            firstName,
                            lastName,
                            email,
                            telephone,
                            street,
                            houseNumber,
                            orientationNumber,
                            postalCode,
                            country,
                            birthday,
                            ico,
                            dic
                            );

                        // add message to log file
                        HelpControl.AddToLog("Kontakt \"" + firstName + " " + lastName + "\" nenalezen. Vytvořen nový: " + _opportunityCustomerId);
                    }

                    // vytvoreni korespondencni adresy
                    if (postalStreet != string.Empty && postalHouseNumber != string.Empty && postalOrientationNumber != string.Empty && postalPostalCode != string.Empty && postalCountry != string.Empty)
                    {
                        CustomerControl.CreateCustomerAddress(
                            firstName + " " + lastName,
                            postalStreet,
                            postalHouseNumber + (postalOrientationNumber != "" ? "/" + postalOrientationNumber : ""),
                            postalPostalCode,
                            postalCountry,
                            opportunityCustomerLogicalName,
                            _opportunityCustomerId
                            );

                        // add message to log file
                        HelpControl.AddToLog("Vytvoření korespondenční adresy ke kontaktu: " + firstName + " " + lastName);
                    }
                    #endregion
                }
                #endregion

                #region Kontrola prilezitosti, Vytvoreni Smlouvy, Odberneho mista a Nahrani souboru

                //// try to find exists opportunity
                //EntityCollection existOpportunities = CustomerControl.ExistsOpportunities(171140000, _opportunityCustomerId, ServiceControl.GetService());
                //Entity existOpportunity = null;

                //if (existOpportunities != null)
                //{
                //    existOpportunity = existOpportunities.Entities.FirstOrDefault();

                //    // add message to log file
                //    HelpControl.AddToLog("Příležitosti nalezeny " + existOpportunities.Entities.Count + ": " + _opportunityCustomerId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Příležitosti nenalezeny: " + _opportunityCustomerId);
                //}

                // add message to log file
                HelpControl.AddToLog("Vytváření příležitosti, odberného místa, verifikačního formuláře a nahrání souborů.");

                // vytvoreni prilezitosti
                _opportunityId = CustomerControl.CreateContract(
                    171140001,
                    proposedNumber,
                    sellerId,
                    sellerFirstName,
                    sellerLastName,
                    signatureDate,
                    contractTimeFirstCheck.Checked,
                    contractTimeSecondCheck.Checked,
                    contractTimeThirdCheck.Checked,
                    dateTimeFromFirstTxt,
                    dateTimeToFirstTxt,
                    productName,
                    contractTimeYears,
                    closedinspaces,
                    dateTimeFromThirdTxt,
                    customerResigned,
                    generateIdCheck,
                    _sellerId,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořena příležitost: " + _opportunityId);

                // vytvoreni odberneho mista
                _supplyPointId = CustomerControl.CreateSupplyPoint(
                    supplyPointName,
                    supplyPointStreet,
                    supplyPointCity,
                    supplyPointPostalCode,
                    supplyPointHouseNumber,
                    supplyPointOrientationNumber,
                    "",
                    supplyPointEIC,
                    supplyPointChange,
                    supplyPointLastProvider,
                    supplyPointNewDistribution,
                    -1,
                    supplyPointYearSubscriptionAmount,
                    "",
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    supplyPointDeliverInvoice,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    -1,
                    -1,
                    "",
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    opportunityCustomerLogicalName,
                    _opportunityCustomerId,
                    _opportunityId,
                    171140001
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořeno odběrné místo: " + _supplyPointId);

                _verifyFormId = CustomerControl.CreateVerifyForm(
                    trustTitul,
                    trustFirstName,
                    trustLastName,
                    trustTitulSecond,
                    trustFirstNameSecond,
                    trustLastNameSecond,
                    companyDic,
                    companyIco,
                    companyName,
                    dic,
                    ico,
                    email,
                    titulInt,
                    firstName,
                    lastName,
                    titulLastInt,
                    birthday,
                    telephone,
                    writtingOR,
                    street,
                    country,
                    postalCode,
                    postalStreet,
                    postalCountry,
                    postalPostalCode,
                    postalHouseNumber,
                    postalOrientationNumber,
                    supplyPointStreet,
                    supplyPointCity,
                    supplyPointPostalCode,
                    supplyPointHouseNumber,
                    supplyPointOrientationNumber,
                    houseNumber,
                    orientationNumber,
                    supplyPointName,
                    "",
                    supplyPointEIC,
                    contractTimeFirstCheck.Checked,
                    contractTimeSecondCheck.Checked,
                    contractTimeThirdCheck.Checked,
                    dateTimeFromFirstTxt,
                    dateTimeFromThirdTxt,
                    dateTimeToFirstTxt,
                    productName,
                    contractTimeYears,
                    supplyPointChange,
                    supplyPointLastProvider,
                    supplyPointNewDistribution,
                    -1,
                    supplyPointYearSubscriptionAmount,
                    "",
                    supplyPointDepositPeriod,
                    supplyPointDepositAmount,
                    supplyPointDeliverInvoice,
                    supplyPointChangesDeliver,
                    supplyPointDepositPayment,
                    supplyPointInvoicePayment,
                    -1,
                    -1,
                    "",
                    supplyPointBankNumberFirst,
                    supplyPointBankNumberSecond,
                    supplyPointBankNumberCode,
                    supplyPointInvoicePaymentSIPO,
                    noticePeriod,
                    resignationUnit,
                    customerResigned,
                    isExistTrustPerson,
                    opportunityCustomerLogicalName,
                    proposedNumber,
                    _opportunityCustomerId,
                    _opportunityId,
                    _supplyPointId,
                    _trustContactId,
                    _trustContactSecondId,
                    _lastTrustContactId,
                    _lastTrustContactSecondId,
                    _sellerId,
                    171140001,
                    signatureDate, closedinspaces
                    );

                // add message to log file
                HelpControl.AddToLog("Vytvořen verifikační formulář: " + _verifyFormId);

                // create second supply point and second verify form
                if (supplyPointStreet2 != "" && supplyPointCity2 != "" && supplyPointPostalCode2 != "" && supplyPointHouseNumber2 != "" && supplyPointEIC2 != "")
                {
                    supplyPointName = firstName + " " + lastName + " - " + supplyPointStreet2 + " " + supplyPointHouseNumber2 + (supplyPointOrientationNumber2 != "" ? (supplyPointOrientationNumber2 != "" ? "/" + supplyPointOrientationNumber2 : "") : "") + ", " + supplyPointCity2;

                    // vytvoreni odberneho mista
                    _supplyPointId = CustomerControl.CreateSupplyPoint(
                        supplyPointName,
                        supplyPointStreet2,
                        supplyPointCity2,
                        supplyPointPostalCode2,
                        supplyPointHouseNumber2,
                        supplyPointOrientationNumber2,
                        "",
                        supplyPointEIC2,
                        supplyPointChange2,
                        supplyPointLastProvider2,
                        supplyPointNewDistribution2,
                        -1,
                        supplyPointYearSubscriptionAmount2,
                        "",
                        supplyPointDepositPeriod2,
                        supplyPointDepositAmount2,
                        supplyPointDeliverInvoice2,
                        supplyPointChangesDeliver2,
                        supplyPointDepositPayment2,
                        supplyPointInvoicePayment2,
                        -1,
                        -1,
                        "",
                        supplyPointBankNumberFirst2,
                        supplyPointBankNumberSecond2,
                        supplyPointBankNumberCode2,
                        supplyPointInvoicePaymentSIPO2,
                        opportunityCustomerLogicalName,
                        _opportunityCustomerId,
                        _opportunityId,
                        171140001
                        );

                    // add message to log file 
                    HelpControl.AddToLog("Vytvořeno druhé odběrné místo: " + _supplyPointId);

                    _verifyFormId = CustomerControl.CreateVerifyForm(
                        trustTitul,
                        trustFirstName,
                        trustLastName,
                        trustTitulSecond,
                        trustFirstNameSecond,
                        trustLastNameSecond,
                        companyDic,
                        companyIco,
                        companyName,
                        dic,
                        ico,
                        email,
                        titulInt,
                        firstName,
                        lastName,
                        titulLastInt,
                        birthday,
                        telephone,
                        writtingOR,
                        street,
                        country,
                        postalCode,
                        postalStreet,
                        postalCountry,
                        postalPostalCode,
                        postalHouseNumber,
                        postalOrientationNumber,
                        supplyPointStreet2,
                        supplyPointCity2,
                        supplyPointPostalCode2,
                        supplyPointHouseNumber2,
                        supplyPointOrientationNumber2,
                        houseNumber,
                        orientationNumber,
                        supplyPointName,
                        "",
                        supplyPointEIC2,
                        contractTimeFirstCheck.Checked,
                        contractTimeSecondCheck.Checked,
                        contractTimeThirdCheck.Checked,
                        dateTimeFromFirstTxt,
                        dateTimeFromThirdTxt,
                        dateTimeToFirstTxt,
                        productName,
                        contractTimeYears,
                        supplyPointChange2,
                        supplyPointLastProvider2,
                        supplyPointNewDistribution2,
                        -1,
                        supplyPointYearSubscriptionAmount2,
                        "",
                        supplyPointDepositPeriod2,
                        supplyPointDepositAmount2,
                        supplyPointDeliverInvoice2,
                        supplyPointChangesDeliver2,
                        supplyPointDepositPayment2,
                        supplyPointInvoicePayment2,
                        -1,
                        -1,
                        "",
                        supplyPointBankNumberFirst2,
                        supplyPointBankNumberSecond2,
                        supplyPointBankNumberCode2,
                        supplyPointInvoicePaymentSIPO2,
                        noticePeriod,
                        resignationUnit,
                        customerResigned,
                        isExistTrustPerson,
                        opportunityCustomerLogicalName,
                        proposedNumber,
                        _opportunityCustomerId,
                        _opportunityId,
                        _supplyPointId,
                        _trustContactId,
                        _trustContactSecondId,
                        _lastTrustContactId,
                        _lastTrustContactSecondId,
                        _sellerId,
                        171140001,
                        signatureDate, closedinspaces
                        );

                    // add message to log file
                    HelpControl.AddToLog("Vytvořen druhý verifikační formulář: " + _verifyFormId);
                }

                #region AddMarketingList Member
                
                Guid ListId;
                if (!string.IsNullOrEmpty(hdnMarketingList.Value) && Guid.TryParse(hdnMarketingList.Value, out ListId))
                {
                   Guid memeberId= CustomerControl.AddListMemeber(ListId, _opportunityCustomerId);

                    if(memeberId != Guid.Empty)
                   // add message to log file
                        HelpControl.AddToLog("Memeber Added into MarketingList. list memeber id :  " + memeberId);
                }
                #endregion


                // nahrane soubory
                HttpFileCollection files = Request.Files;

                // pokud soubor existuje, nahraje se
                for (var i = 0; i < files.Count; i++)
                {
                    if (files[i].ContentLength > 0)
                    {
                        bool uploaded = CustomerControl.AddAnnotation(files[i], "cre_verifyform", _verifyFormId);

                        if (uploaded)
                        {
                            // add message to log file
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" byl uložen. " + (i + 1) + " z " + files.Count);
                        }
                        else
                        {
                            // add message to log file
                            HelpControl.AddToLog("Soubor \"" + files[i].FileName + "\" nebyl uložen. " + (i + 1) + " z " + files.Count);
                        }
                    }
                }

                #endregion

                #region Aktivace prilezitosti a nabidek
                //// aktivovani nabidky jako ziskane
                //bool isOrdersActivated = CustomerControl.ActivateQuotesByOpportunity(_opportunityId);

                //if (isOrdersActivated)
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Nabidky oznaceny jako ziskany pro prilezistost: " + _opportunityId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Nabidky se nepodarily oznacit jako ziskane pro prilezistost: " + _opportunityId);
                //}

                //// aktivovani prilezistosti jako ziskana
                //bool isActivated = CustomerControl.ActivateOpportunity(_opportunityId);

                //if (isActivated)
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Prilezitost oznacena jako ziskana: " + _opportunityId);
                //}
                //else
                //{
                //    // add message to log file
                //    HelpControl.AddToLog("Prilezitost se nepodarilo oznacit jako ziskana: " + _opportunityId);
                //}
                #endregion

                new ErrorControl("Smlouva byla uložena.");
            }
            catch (Exception ex)
            {
                Email.SendError("VemexPortal error", "Error: gasSubmitBtn_Click in plyn.aspx code-behind was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));

                // add message to log file
                HelpControl.AddToLog("Nepodařilo se vytvořit smlouvu pro plyn.");

                // throw message
                new ErrorControl("Smlouva se nepodařila uložit.");
            }

            if (command != "electricity")
                Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
            else
                Response.Redirect(UrlControl.GetPathUrl() + "/elektrina");
        }
    }
}