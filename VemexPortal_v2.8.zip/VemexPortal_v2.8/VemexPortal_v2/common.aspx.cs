﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm.Sdk.Query;
using VemexPortal.Controls;

namespace VemexPortal_v2
{
    public partial class common : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static string GetMarketingList(int listtype)
        {
            FilterExpression filter = new FilterExpression();
            filter.AddCondition("cre_uselikesource", ConditionOperator.Equal, true);
            filter.AddCondition("createdfromcode", ConditionOperator.Equal, listtype);
            filter.FilterOperator = LogicalOperator.And;

            QueryExpression query = new QueryExpression()
            {
                EntityName = "list",
                ColumnSet = new ColumnSet(new string[] 
                 {
                     "listid", 
                     "listname"
                 }),
                Criteria = filter
            };
            
            // Return JSON data
            JavaScriptSerializer js = new JavaScriptSerializer();

            List<SelectControl> list = SelectControl.GetSelectOptions(query, "listname", "listid");

            string retJSON = js.Serialize(list);
            return retJSON;
        }
    }
}