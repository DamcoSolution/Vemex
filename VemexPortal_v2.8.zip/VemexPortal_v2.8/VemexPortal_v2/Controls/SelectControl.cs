﻿using CRM.Helper;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace VemexPortal.Controls
{
    public class SelectControl
    {
        public string text { get; set; }
        public string value { get; set; }


        public static List<SelectControl> GetSelectOptions(string entityLogicalName, string fieldLogicalName)
        {
            try
            {
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityLogicalName, LogicalName = fieldLogicalName };
                RetrieveAttributeResponse response = (RetrieveAttributeResponse)ServiceControl.GetService().Execute(attributeRequest);

                PicklistAttributeMetadata quoteMetaData = (PicklistAttributeMetadata)response.AttributeMetadata;
                List<SelectControl> list = new List<SelectControl>();

                foreach (OptionMetadata option in quoteMetaData.OptionSet.Options)
                {
                    list.Add(new SelectControl
                    {
                        text = option.Label.UserLocalizedLabel.Label,
                        value = option.Value.ToString()
                    });
                }

                return list;
            }
            catch (Exception ex)
            {

                Email.SendError("VemexPortal error", "Error: GetSelectOptions in VemexPortal.Controls was unsuccessful.<br /><br />" +
                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));
                return null;

            }
            

        }
        
        public static List<SelectControl> GetSelectOptions(QueryExpression query, string textField, string valueField)
        {
            List<SelectControl> list = new List<SelectControl>();

            EntityCollection entityList = ServiceControl.GetService().RetrieveMultiple(query);

            foreach (Entity entity in entityList.Entities)
            {
                SelectControl sel = new SelectControl();
                sel.text = entity.Attributes.Contains(textField) ? Convert.ToString(entity[textField]) : string.Empty;
                sel.value = entity.Attributes.Contains(valueField) ? Convert.ToString(entity[valueField]) : string.Empty;
                list.Add(sel);
            }
            return list;
        }
    }
}