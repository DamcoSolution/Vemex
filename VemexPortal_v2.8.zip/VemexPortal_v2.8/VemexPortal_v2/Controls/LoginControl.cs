﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VemexPortal.Controls
{
    public class LoginControl
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LoginNumber { get; set; }


        public static LoginControl LoggedUser()
        {
            LoginControl user = new LoginControl();

            if (HttpContext.Current.Session["userID"] != null)
            {
                Entity contact = ((Entity)HttpContext.Current.Session["userID"]);
                user.Id = contact.Id;
                user.FirstName = contact.Attributes.Contains("firstname") ? contact["firstname"].ToString() : string.Empty;
                user.LastName = contact.Attributes.Contains("lastname") ? contact["lastname"].ToString() : string.Empty;
                user.LoginNumber = contact.Attributes.Contains("cre_login") ? contact["cre_login"].ToString() : string.Empty;
            }

            return user;
        }

        public static bool IsLogged()
        {
            return (HttpContext.Current.Session["userID"] != null);
        }

        public static bool Login(string loginName, string loginPassword)
        {

            FilterExpression filter = new FilterExpression();
            filter.AddCondition("cre_login", ConditionOperator.Equal, loginName);
            filter.AddCondition("cre_password", ConditionOperator.Equal, loginPassword);
            filter.FilterOperator = LogicalOperator.And;

            EntityCollection contacts = Service.RetrieveMultiple("contact", filter, new ColumnSet(new string[] { "firstname", "lastname", "cre_lastlogin", "cre_login" }), ServiceControl.GetService());

            if (contacts.Entities.Count() == 1)
            {
                Entity contact = contacts.Entities.FirstOrDefault();
                contact["cre_lastlogin"] = DateTime.Now;
                Service.Update(contact, ServiceControl.GetService());
                HttpContext.Current.Session["userID"] = contact;

                return true;
            }
            else
                return false;

        }

        public static void Logout()
        {

            HttpContext.Current.Session["userID"] = null;

        }
    }
}