﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using VemexPortal.Controls;
using Web.Controls;

namespace VemexPortal.Controls
{
    public class PageControl : System.Web.UI.Page
    {
        public string title { get; set; }
        public string description { get; set; }


        protected void Page_Init()
        {
            if (!IsPostBack)
            {
                string fileName = Path.GetFileName(Request.PhysicalPath).Replace(".aspx", "");
                    
                XmlControl xml = new XmlControl("pageinfo.xml");
                PageControl page = xml.GetXmlList("page[@name='" + fileName + "']").FirstOrDefault();

                if (page != null)
                {
                    Master.Page.Title = page.title;
                    Master.Page.MetaDescription = page.description;
                }
            }
        }
    }
}