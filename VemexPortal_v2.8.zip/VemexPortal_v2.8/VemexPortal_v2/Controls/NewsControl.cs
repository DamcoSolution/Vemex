﻿using CRM;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VemexPortal.Controls
{
    public class NewsControl
    {
        public string name { get; set; }
        public string createdon { get; set; }
        public string content { get; set; }


        public static List<NewsControl> GetNews()
        {
            List<NewsControl> newsList = new List<NewsControl>();

            EntityCollection newsCollection = Service.RetrieveMultiple("cre_news", null, new ColumnSet(new string[] { "cre_name", "cre_content", "createdon" }), ServiceControl.GetService());

            foreach (Entity news in newsCollection.Entities.OrderByDescending(e => e["createdon"]))
            {
                if (news.Attributes.Contains("cre_name") && news.Attributes.Contains("cre_content"))
                    newsList.Add(new NewsControl
                    { 
                        name = news["cre_name"].ToString(),
                        content = news["cre_content"].ToString(),
                        createdon = DateTime.Parse(news["createdon"].ToString()).ToLocalTime().ToString("dd/MM/yyyy")
                    });
            }

            return newsList;
        }
    }
}