﻿var JSONP = {

    Get: function (url, dataType, successCallback, errorCallback) {

        $.ajax({
            dataType: dataType,
            jsonpCallback: "callback",
            url: url + "&callback=callback",
            timeout: 15000,
            success: function (result) {
                if (typeof (successCallback) == "function")
                    successCallback(result);
            },
            error: function (result) {
                if (typeof (errorCallback) == "function")
                    errorCallback(result);
            }
        });

    }

};