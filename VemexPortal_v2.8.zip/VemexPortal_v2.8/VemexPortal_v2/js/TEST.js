﻿cre_fixedtermcontractyears

171 140 000  1. Rok
171 140 001  2. Roky
171 140 002  3. Roky
171 140 003  5. Let 
171 140 004  Doba neurcita


cre_commision_is_create true





Date of signature

20.10


Reports


1.10.2013 - 29.10.2013  - 20.10.2013 +100  -100
1.11.2013 - 29.11.2013




20.10 - date of signature
1.11 - date of validation
1.10.2013 - 29.10.2013  20.10   
1.11.2013 - 29.11.2013  
1.12.2013 - 29.12.2013    


OTE 




False
1 commision

20.10 - date of signature
1.11 - date of validation
20.11 - cre_ote_date_approved 
20.12  - date_of_deni (storning)
1.10.2013 - 29.10.2013    
1.11.2013 - 29.11.2013 
1.12.2013 - 29.12.2013 










cre_runningcommission  (on cre_commission entity) (Průběžná provize)

cre_dateofsignature (Datum podpisu) (opportunity)
cre_ote_date_approved (Datum schválení na OTE)(verifi form)
cre_canceled_date (Datum stornování smlouvy) (verifi form)
cre_aceptedon (Smlouva přijata dne)(verifi form)
cre_guaranteelength (Délka garance ve dnech) (on entity cre_commissionsettings)
condision fromDate - toDate (1.10.2013 - 29.10.2013)(only one month max)
Price



--------------------algoritm -------------------

if (cre_runningcommission == true)
{
    if (cre_canceled_date == null)
    {
        if (cre_ote_date_approved < toDate)
            show Price/12;

    else
    {
         if (cre_ote_date_approved < toDate && cre_canceled_date > fromDate)
            show Price/12;
    }
}
else
{
    if (cre_canceled_date == null)
    {
        if(fromDate < cre_aceptedon && toDate > cre_aceptedon)
            show Price; 
    
    }
    else
    {
        var real_guaranteelength =  cre_canceled_date - cre_dateofsignature;
    
        if (real_guaranteelength > cre_guaranteelength)
        {
            if(fromDate < cre_aceptedon && toDate > cre_aceptedon)
                show Price; 
        }
        else
        {
            if(fromDate < cre_canceled_date && toDate > cre_canceled_date
                && fromDate < cre_aceptedon && toDate > cre_aceptedon)
            {
                show Price = 0;
            }
            else if(fromDate < cre_canceled_date && toDate > cre_canceled_date
                && fromDate > cre_aceptedon && toDate > cre_aceptedon)      
            {
                show Price = -Price;        
            }  
            else if (fromDate < cre_canceled_date && toDate < cre_canceled_date
                  && fromDate < cre_aceptedon && toDate > cre_aceptedon)
            {
                show Price
            }       
        }   
    }
}