﻿var ARES = {

    Retrieve: function (ico, successCallback, errorCallback) {
            
        if (!ico) {
            alert("Parameter ico is required.");
            return;
        }

        JSONP.Get("http://cobyne.cz/ares/a.php?ic=" + ico, "jsonp", function (result) {
            if (successCallback)
                successCallback(result);
        }, function () {
            if(errorCallback)
                errorCallback();
        });

    }

};