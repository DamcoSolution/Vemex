﻿// variables
var errorCount = 0,
    lineCount = 0,
    $bottomError = $("<div class=\"bottomerror\">" +
                        "<div class=\"holder\">" +
                            "<div class=\"bottomerrortop\">" +
                                "<div class=\"bottomerrortopalert\"></div>" +
                                "<div class=\"bottomerrortopcontent\">Formulář nelze odeslat!</div>" +
                                "<div class=\"bottomerrortoparrow\"><span>Zobrazit chyby:</span> <strong>28</strong></div>" +
                            "</div>" +
                            "<div class=\"bottomerrormiddle\"></div>" +
                        "</div>" +
                        "</div>"),
    $bottomErrorTop = $bottomError.find(".bottomerrortop"),
    $bottomErrorTopCount = $bottomErrorTop.find(".bottomerrortoparrow strong"),
    $bottomErrorTopText = $bottomErrorTop.find(".bottomerrortoparrow span"),
    $bottomErrorTopArrow = $bottomErrorTop.find(".bottomerrortoparrow"),
    $bottomErrorMiddle = $bottomError.find(".bottomerrormiddle");

// events
$bottomErrorTop.click(ErrorTopClick);


// functions
function ValidateForm(clientType, formType) {

    if (!clientType) {
        alert("Parameter clientType is required.");
        return;
    }

    if (!formType) {
        alert("Parameter formType is required.");
        return;
    }

    var $inputs = $("input"),
        $labels = $(".label"),
        $proposedNumberTxt = $("#proposedNumberTxt"),
        $titul = $("#titulTxt"),
        $titulLast = $("#titulLastTxt"),
        $firstName = $("#firstNameTxt"),
        $lastName = $("#lastNameTxt"),
        $birthdate = $("#birthdateTxt"),
        $ico = $("#icoTxt"),
        $dic = $("#dicTxt"),
        $companyName = $("#companyNameTxt"),
        $companyIco = $("#companyIcoTxt"),
        $companyDic = $("#companyDicTxt"),
        $trustFirstName = $("#trustFirstNameTxt"),
        $trustLastName = $("#trustLastNameTxt"),
        $email = $("#emailTxt"),
        $phone = $("#phoneTxt"),
        $street = $("#streetTxt"),
        $houseNumber = $("#houseNumberTxt"),
        $orientationNumber = $("#orientationNumberTxt"),
        $postalCode = $("#postalCodeTxt"),
        $country = $("#countryTxt"),
        $contractTimeFirstCheck = $("#contractTimeFirstCheck"),
        $contractTimeSecondCheck = $("#contractTimeSecondCheck"),
        $contractTimeYearFirst = $("#contractTimeYearFirst"),
        $contractTimeYearSecond = $("#contractTimeYearSecond"),
        $contractTimeYearThird = $("#contractTimeYearThird"),
        $contractTimeThirdCheck = $("#contractTimeThirdCheck"),
        $contractTimeYearFive = $("#contractTimeYearFive"),
        $timeFromDayThirdTxt = $("#timeFromDayThirdTxt"),
        $timeFromDayFirstTxt = $("#timeFromDayFirstTxt"),
        $timeToDayFirstTxt = $("#timeToDayFirstTxt"),
        $supplyPointStreetTxt = $("#supplyPointStreetTxt"),
        $supplyPointHouseNumberTxt = $("#supplyPointHouseNumberTxt"),
        $supplyPointOrientationNumberTxt = $("#supplyPointOrientationNumberTxt"),
        $supplyPointCountryTxt = $("#supplyPointCountryTxt"),
        $supplyPointPostalCodeTxt = $("#supplyPointPostalCodeTxt"),
        $supplyPointEICTxt = $("#supplyPointEICTxt"),
        $supplyPointChangeProviderCheck = $("#supplyPointChangeProviderCheck"),
        $supplyPointChangeCustomerCheck = $("#supplyPointChangeCustomerCheck"),
        $supplyPointChangeNewSubscriptionCheck = $("#supplyPointChangeNewSubscriptionCheck"),
        $supplyPointChangeProviderPriceCheck = $("#supplyPointChangeProviderPriceCheck"),
        $supplyPointOverwriteCheck = $("#supplyPointOverwriteCheck"),
        $supplyPointLastProviderTxt = $("#supplyPointLastProviderTxt"),
        $supplyPointNewDistributionTxt = $("#supplyPointNewDistributionTxt"),
        $supplyPointYearSubscriptionAmountTxt = $("#supplyPointYearSubscriptionAmountTxt"),
        $supplyPointDepositMonthCheck = $("#supplyPointDepositMonthCheck"),
        $supplyPointDepositQuarterCheck = $("#supplyPointDepositQuarterCheck"),
        $supplyPointDepositAmountTxt = $("#supplyPointDepositAmountTxt"),
        $supplyPointDeliverEmailCheck = $("#supplyPointDeliverEmailCheck"),
        $supplyPointDeliverPostCheck = $("#supplyPointDeliverPostCheck"),
        $supplyPointChangesDeliverEmailCheck = $("#supplyPointChangesDeliverEmailCheck"),
        $supplyPointChangesDeliverPostCheck = $("#supplyPointChangesDeliverPostCheck"),
        $supplyPointChangesDeliverWebCheck = $("#supplyPointChangesDeliverWebCheck"),
        $supplyPointDepositPaymentTransferCheck = $("#supplyPointDepositPaymentTransferCheck"),
        $supplyPointDepositPaymentCollectionCheck = $("#supplyPointDepositPaymentCollectionCheck"),
        $supplyPointDepositPaymentSlipCheck = $("#supplyPointDepositPaymentSlipCheck"),
        $supplyPointDepositPaymentSIPOCheck = $("#supplyPointDepositPaymentSIPOCheck"),
        $supplyPointInvoicePaymentTransferCheck = $("#supplyPointInvoicePaymentTransferCheck"),
        $supplyPointInvoicePaymentCollectionCheck = $("#supplyPointInvoicePaymentCollectionCheck"),
        $supplyPointInvoicePaymentSlipCheck = $("#supplyPointInvoicePaymentSlipCheck"),
        $supplyPointInvoicePaymentSIPOTxt = $("#supplyPointInvoicePaymentSIPOTxt"),
        $supplyPointBankNumberFirstTxt = $("#supplyPointBankNumberFirstTxt"),
        $supplyPointBankNumberSecondTxt = $("#supplyPointBankNumberSecondTxt"),
        $supplyPointBankNumberCodeTxt = $("#supplyPointBankNumberCodeTxt"),

        $supplyPointStreetTxt2 = $("#supplyPointStreetTxt2"),
        $supplyPointHouseNumberTxt2 = $("#supplyPointHouseNumberTxt2"),
        $supplyPointOrientationNumberTxt2 = $("#supplyPointOrientationNumberTxt2"),
        $supplyPointCountryTxt2 = $("#supplyPointCountryTxt2"),
        $supplyPointPostalCodeTxt2 = $("#supplyPointPostalCodeTxt2"),
        $supplyPointEICTxt2 = $("#supplyPointEICTxt2"),
        $supplyPointChangeProviderCheck2 = $("#supplyPointChangeProviderCheck2"),
        $supplyPointChangeCustomerCheck2 = $("#supplyPointChangeCustomerCheck2"),
        $supplyPointChangeNewSubscriptionCheck2 = $("#supplyPointChangeNewSubscriptionCheck2"),
        $supplyPointChangeProviderPriceCheck2 = $("#supplyPointChangeProviderPriceCheck2"),
        $supplyPointOverwriteCheck2 = $("#supplyPointOverwriteCheck2"),
        $supplyPointLastProviderTxt2 = $("#supplyPointLastProviderTxt2"),
        $supplyPointNewDistributionTxt2 = $("#supplyPointNewDistributionTxt2"),
        $supplyPointYearSubscriptionAmountTxt2 = $("#supplyPointYearSubscriptionAmountTxt2"),
        $supplyPointDepositMonthCheck2 = $("#supplyPointDepositMonthCheck2"),
        $supplyPointDepositQuarterCheck2 = $("#supplyPointDepositQuarterCheck2"),
        $supplyPointDepositAmountTxt2 = $("#supplyPointDepositAmountTxt2"),
        $supplyPointDeliverEmailCheck2 = $("#supplyPointDeliverEmailCheck2"),
        $supplyPointDeliverPostCheck2 = $("#supplyPointDeliverPostCheck2"),
        $supplyPointChangesDeliverEmailCheck2 = $("#supplyPointChangesDeliverEmailCheck2"),
        $supplyPointChangesDeliverPostCheck2 = $("#supplyPointChangesDeliverPostCheck2"),
        $supplyPointChangesDeliverWebCheck2 = $("#supplyPointChangesDeliverWebCheck2"),
        $supplyPointDepositPaymentTransferCheck2 = $("#supplyPointDepositPaymentTransferCheck2"),
        $supplyPointDepositPaymentCollectionCheck2 = $("#supplyPointDepositPaymentCollectionCheck2"),
        $supplyPointDepositPaymentSlipCheck2 = $("#supplyPointDepositPaymentSlipCheck2"),
        $supplyPointDepositPaymentSIPOCheck2 = $("#supplyPointDepositPaymentSIPOCheck2"),
        $supplyPointInvoicePaymentTransferCheck2 = $("#supplyPointInvoicePaymentTransferCheck2"),
        $supplyPointInvoicePaymentCollectionCheck2 = $("#supplyPointInvoicePaymentCollectionCheck2"),
        $supplyPointInvoicePaymentSlipCheck2 = $("#supplyPointInvoicePaymentSlipCheck2"),
        $supplyPointInvoicePaymentSIPOTxt2 = $("#supplyPointInvoicePaymentSIPOTxt2"),
        $supplyPointBankNumberFirstTxt2 = $("#supplyPointBankNumberFirstTxt2"),
        $supplyPointBankNumberSecondTxt2 = $("#supplyPointBankNumberSecondTxt2"),
        $supplyPointBankNumberCodeTxt2 = $("#supplyPointBankNumberCodeTxt2"),

        $resignationUnitMonthCheck = $("#resignationUnitMonthCheck"),
        $resignationUnitDayCheck = $("#resignationUnitDayCheck"),
        $resignationPeriodTxt = $("#noticePeriodTxt"),
        $signatureDateTxt = $("#signatureDateTxt"),
        $sellerIdTxt = $("#sellerIdTxt"),
        $sellerFirstNameTxt = $("#sellerFirstNameTxt"),
        $sellerLastNameTxt = $("#sellerLastNameTxt"),
        $contractPolicyCheck = $("#contractPolicyCheck"),
        $supplyPointEANTxt = $("#supplyPointEANTxt"),
        $supplyPointYearSubscriptionAmountVTTxt = $("#supplyPointYearSubscriptionAmountVTTxt"),
        $supplyPointYearSubscriptionAmountNTTxt = $("#supplyPointYearSubscriptionAmountNTTxt"),
        $supplyPointBreakerAmountTxt = $("#supplyPointBreakerAmountTxt"),
        $supplyPointDistributionAmountTxt = $("#supplyPointDistributionAmountTxt"),
        $supplyPointPhaseOneCheck = $("#supplyPointPhaseOneCheck"),
        $supplyPointPhaseThreeCheck = $("#supplyPointPhaseThreeCheck"),

        $supplyPointEANTxt2 = $("#supplyPointEANTxt"),
        $supplyPointYearSubscriptionAmountVTTxt2 = $("#supplyPointYearSubscriptionAmountVTTxt2"),
        $supplyPointYearSubscriptionAmountNTTxt2 = $("#supplyPointYearSubscriptionAmountNTTxt2"),
        $supplyPointBreakerAmountTxt2 = $("#supplyPointBreakerAmountTxt2"),
        $supplyPointDistributionAmountTxt2 = $("#supplyPointDistributionAmountTxt2"),
        $supplyPointPhaseOneCheck2 = $("#supplyPointPhaseOneCheck2"),
        $supplyPointPhaseThreeCheck2 = $("#supplyPointPhaseThreeCheck2"),

        $contractTimeLabelFirst = $("#contractTimeLabelFirst"),
        $contractTimeLabelSecond = $("#contractTimeLabelSecond"),
        $contractTimeLabelThird = $("#contractTimeLabelThird"),
        $contractReasonLabel = $("#contractReasonLabel"),
        $advancesTimeLabel = $("#advancesTimeLabel"),
        $deliverLabel = $("#deliverLabel"),
        $changesLabel = $("#changesLabel"),
        $depositPaymentLabel = $("#depositPaymentLabel"),
        $invoicePaymentLabel = $("#invoicePaymentLabel"),
        $connectionTypeLabel = $("#connectionTypeLabel"),
        $resignationUnitLabel = $("#resignationUnitLabel"),

        $contractReasonLabel2 = $("#contractReasonLabel2"),
        $advancesTimeLabel2 = $("#advancesTimeLabel2"),
        $deliverLabel2 = $("#deliverLabel2"),
        $changesLabel2 = $("#changesLabel2"),
        $depositPaymentLabel2 = $("#depositPaymentLabel2"),
        $invoicePaymentLabel2 = $("#invoicePaymentLabel2"),
        $connectionTypeLabel2 = $("#connectionTypeLabel2"),
        $resignationUnitLabel2 = $("#resignationUnitLabel2"),

        $generateCheck = $("#generateCheck"),
        $nextSupplyPoint = $("#nextSupplyPoint");

    // remove errors and set default values
    $inputs.removeClass("error");
    $labels.removeClass("error");
    $bottomErrorMiddle.empty();
    errorCount = lineCount = 0;

    // validation
    if (!$generateCheck.is(":checked"))
        if ($.trim($proposedNumberTxt.val()) == "")
            AddErrorLine($proposedNumberTxt, "Musíte vyplnit Číslo návrhu.");

    // home
    if (clientType == "home") {

        if ($.trim($titul.val()) != "")
            if (!IsValidOption($titul))
                AddErrorLine($titul, "Musíte zadat správnou hodnotu pro Titul.");

        if ($.trim($titulLast.val()) != "")
            if (!IsValidOption($titulLast))
                AddErrorLine($titulLast, "Musíte zadat správnou hodnotu pro Titul za jménem.");

        if ($.trim($firstName.val()) == "")
            AddErrorLine($firstName, "Musíte vyplnit Jméno fyzické osoby.");

        if ($.trim($lastName.val()) == "")
            AddErrorLine($lastName, "Musíte vyplnit Příjmení fyzické osoby.");

        if ($.trim($birthdate.val()) == "" && $.trim($ico.val()) == "") {
            AddErrorLine($birthdate, "Musíte vyplnit Datum narození nebo IČO fyzické osoby.");
            AddErrorClass($ico);
        }

        if ($.trim($ico.val()) != "") {
            if (!IsValidLength($.trim($ico.val()), 8))
                AddErrorLine($ico, "Musíte správně vyplnit IČO.");
        }

        if ($.trim($birthdate.val()) != "") {
            if (!IsValidDate($.trim($birthdate.val())))
                AddErrorLine($birthdate, "Musíte vyplnit správně Datum narození fyzické osoby.");
            else if (!Is18YearsOld($.trim($birthdate.val())))
                AddErrorLine($birthdate, "Fyzická osoba musí být starší 18-ti let.");
        }

        if ($.trim($email.val()) == "" && $.trim($phone.val()) == "") {
            AddErrorLine($email, "Musíte vyplnit kontaktní údaj Email nebo Telefon.");
            AddErrorClass($phone);
        }

        if ($supplyPointChangesDeliverEmailCheck.is(":checked") || $supplyPointDeliverEmailCheck.is(":checked"))
            if ($.trim($email.val()) == "")
                AddErrorLine($email, "Musíte vyplnit kontaktní údaj Email.");

        if ($.trim($email.val()) != "")
            if (!IsValidEmail($.trim($email.val())))
                AddErrorLine($email, "Musíte vyplnit správný kontaktní údaj Email.");

        if ($.trim($phone.val()) != "")
            if (!IsValidLength($.trim($phone.val()), 9))
                AddErrorLine($phone, "Musíte vyplnit správně Telefon.");
    }

    if (clientType == "small") { // maloodber

        if ($.trim($companyName.val()) == "")
            AddErrorLine($companyName, "Musíte vyplnit Název společnosti.");

        if ($.trim($companyIco.val()) != "") {
            if (!IsValidLength($.trim($companyIco.val()), 8))
                AddErrorLine($companyIco, "Musíte správně vyplnit IČO společnosti.");
        }
        else
            AddErrorLine($companyIco, "Musíte vyplnit IČO společnosti.");

        if ($.trim($trustFirstName.val()) == "")
            AddErrorLine($trustFirstName, "Musíte vyplnit Jméno oprávněné osoby.");

        if ($.trim($trustLastName.val()) == "")
            AddErrorLine($trustLastName, "Musíte vyplnit Příjmení oprávněné osoby.");

        if ($.trim($email.val()) == "")
            AddErrorLine($email, "Musíte vyplnit kontaktní údaj Email.");

        if ($.trim($phone.val()) == "")
            AddErrorLine($phone, "Musíte vyplnit kontaktní údaj Telefon.");

        if ($.trim($email.val()) != "")
            if (!IsValidEmail($.trim($email.val())))
                AddErrorLine($email, "Musíte správně vyplnit kontaktní údaj Email.");

        if ($.trim($phone.val()) != "")
            if (!IsValidLength($.trim($phone.val()), 9))
                AddErrorLine($phone, "Musíte správně vyplnit kontaktní údaj Telefon.");
    }

    if ($.trim($street.val()) == "")
        AddErrorLine($street, "Musíte vyplnit Ulici.");

    if ($.trim($houseNumber.val()) == "")
        AddErrorLine($houseNumber, "Musíte vyplnit Číslo popisné.");

    if ($.trim($postalCode.val()) == "")
        AddErrorLine($postalCode, "Musíte vyplnit PSČ.");
    else if (!IsValidLength($.trim($postalCode.val()), 5))
        AddErrorLine($postalCode, "Musíte správně vyplnit PSČ.");

    if ($.trim($country.val()) == "")
        AddErrorLine($country, "Musíte vyplnit Obec.");

    if (!$contractTimeFirstCheck.is(":checked") && !$contractTimeSecondCheck.is(":checked") && !$contractTimeThirdCheck.is(":checked")) {
        AddErrorLine($contractTimeFirstCheck, "Musíte vybrat jednu z možností Smlouva na dobu.");
        AddErrorClass($contractTimeLabelFirst);
        AddErrorClass($contractTimeLabelSecond);
        AddErrorClass($contractTimeLabelThird);
    }

    if ($contractTimeFirstCheck.is(":checked")) {
        if ($.trim($timeFromDayFirstTxt.val()) == "")
            AddErrorLine($timeFromDayFirstTxt, "Musíte vyplnit časové období Od.");
        else if (!IsValidDate($.trim($timeFromDayFirstTxt.val())))
            AddErrorLine($timeFromDayFirstTxt, "Musíte správně vyplnit časové období Od.");

        if ($.trim($timeToDayFirstTxt.val()) == "")
            AddErrorLine($timeToDayFirstTxt, "Musíte vyplnit časové období Do.");
        else if (!IsValidDate($.trim($timeToDayFirstTxt.val())))
            AddErrorLine($timeToDayFirstTxt, "Musíte správně vyplnit časové období Do.");

        if (IsValidDate($.trim($timeFromDayFirstTxt.val())) && IsValidDate($.trim($timeToDayFirstTxt.val())))
            if (!ValidTwoDates($.trim($timeFromDayFirstTxt.val()), $.trim($timeToDayFirstTxt.val()))) {
                AddErrorLine($timeFromDayFirstTxt, "Časové rozmezí musí být minimálně jeden měsíc a zároveň nesmí být starší než dnešní datum.");
                AddErrorClass($timeToDayFirstTxt);
            }
    }

    if ($contractTimeSecondCheck.is(":checked"))
        if (!$contractTimeYearFirst.is(":checked") && !$contractTimeYearSecond.is(":checked") && !$contractTimeYearThird.is(":checked") && !$contractTimeYearFive.is(":checked")) {
            AddErrorLine($contractTimeYearFirst, "Musíte vybrat časové období 1, 2, 3 nebo 5 roků.");
            AddErrorClass($contractTimeLabelSecond);
        }

    if ($contractTimeThirdCheck.is(":checked")) {
        if ($.trim($timeFromDayThirdTxt.val()) == "")
            AddErrorLine($timeFromDayThirdTxt, "Musíte vyplnit časové období Od.");
        else if (!IsValidDate($.trim($timeFromDayThirdTxt.val())))
            AddErrorLine($timeFromDayThirdTxt, "Musíte správně vyplnit časové období Od.");
    }

    if ($.trim($supplyPointStreetTxt.val()) == "")
        AddErrorLine($supplyPointStreetTxt, "Musíte vyplnit Ulici odběrného místa.");

    if ($.trim($supplyPointHouseNumberTxt.val()) == "")
        AddErrorLine($supplyPointHouseNumberTxt, "Musíte vyplnit Číslo popisné odběrného místa.");

    if ($.trim($supplyPointCountryTxt.val()) == "")
        AddErrorLine($supplyPointCountryTxt, "Musíte vyplnit Obec odběrného místa.");

    if ($.trim($supplyPointPostalCodeTxt.val()) == "")
        AddErrorLine($supplyPointPostalCodeTxt, "Musíte vyplnit PSČ odběrného místa.");
    else if (!IsValidLength($.trim($supplyPointPostalCodeTxt.val()), 5))
        AddErrorLine($supplyPointPostalCodeTxt, "Musíte správně vyplnit PSČ odběrného místa.");

    if (formType == "gas") {
        if ($.trim($supplyPointEICTxt.val()) == "")
            AddErrorLine($supplyPointEICTxt, "Musíte vyplnit EIC kód.");
           
        else if (!IsValidEIC($.trim($supplyPointEICTxt.val())))
            AddErrorLine($supplyPointEICTxt, "Musíte vyplnit EIC kód ve správném tvaru.");
    }

    if (formType == "electricity") {
        if ($.trim($supplyPointEANTxt.val()) == "")
            AddErrorLine($supplyPointEANTxt, "Musíte vyplnit EAN OPM kód.");
        else if (!IsValidEAN($.trim($supplyPointEANTxt.val())))
            AddErrorLine($supplyPointEANTxt, "Musíte vyplnit EAN OPM kód ve správném tvaru.");
    }

    if (!$supplyPointChangeProviderCheck.is(":checked") && !$supplyPointChangeCustomerCheck.is(":checked") && !$supplyPointChangeNewSubscriptionCheck.is(":checked") && !$supplyPointChangeProviderPriceCheck.is(":checked") && !$supplyPointOverwriteCheck.is(":checked")) {
        AddErrorLine($supplyPointChangeProviderCheck, "Musíte vybrat Důvod uzavření smlouvy odběrného místa.");
        AddErrorClass($contractReasonLabel);
    }

    if ($.trim($supplyPointLastProviderTxt.val()) == "")
        AddErrorLine($supplyPointLastProviderTxt, "Musíte vyplnit Původního dodavatele odběrného místa.");

    if ($.trim($supplyPointNewDistributionTxt.val()) == "")
        AddErrorLine($supplyPointNewDistributionTxt, "Musíte vyplnit Distributora odběrného místa.");

    if ($.trim($supplyPointNewDistributionTxt.val()) != "")
        if (!IsValidOption($supplyPointNewDistributionTxt))
            AddErrorLine($supplyPointNewDistributionTxt, "Musíte zadat správnou hodnotu pro Distributora odběrného místa.");

    if (formType == "gas") {
        if ($.trim($supplyPointYearSubscriptionAmountTxt.val()) == "")
            AddErrorLine($supplyPointYearSubscriptionAmountTxt, "Musíte vyplnit Plánovanou roční spotřebu odběrného místa.");
        else if ($.trim($supplyPointYearSubscriptionAmountTxt.val()) > 630)
            AddErrorLine($supplyPointYearSubscriptionAmountTxt, "Plánovaná roční spotřeba odběrného místa nesmí být větší než 630 MWh/rok.");
    }

    if (formType == "electricity") {
        if ($.trim($supplyPointYearSubscriptionAmountVTTxt.val()) == "")
            AddErrorLine($supplyPointYearSubscriptionAmountVTTxt, "Musíte vyplnit Plánovanou roční spotřebu VT odběrného místa.");
    }

    if (formType == "electricity") {
        if ($.trim($supplyPointBreakerAmountTxt.val()) == "")
            AddErrorLine($supplyPointBreakerAmountTxt, "Musíte vyplnit Hodnotu jističe před elektroměrem odběrného místa.");

        if ($.trim($supplyPointDistributionAmountTxt.val()) == "")
            AddErrorLine($supplyPointDistributionAmountTxt, "Musíte vyplnit Distribuční sazbu odběrného místa.");

        if ($.trim($supplyPointDistributionAmountTxt.val()) != "")
            if (!IsValidOption($supplyPointDistributionAmountTxt))
                AddErrorLine($supplyPointDistributionAmountTxt, "Musíte zadat správnou hodnotu pro Distribuční sazbu odběrného místa.");

        if (!$supplyPointPhaseOneCheck.is(":checked") && !$supplyPointPhaseThreeCheck.is(":checked")) {
            AddErrorLine($supplyPointPhaseOneCheck, "Musíte vybrat Způsob připojení odběrného místa.");
            AddErrorClass($connectionTypeLabel);
        }
    }

    if (!$supplyPointDepositMonthCheck.is(":checked") && !$supplyPointDepositQuarterCheck.is(":checked")) {
        AddErrorLine($supplyPointDepositMonthCheck, "Musíte vybrat Zálohové období odběrného místa.");
        AddErrorClass($depositPaymentLabel);
    }

    if ($.trim($supplyPointDepositAmountTxt.val()) == "")
        AddErrorLine($supplyPointDepositAmountTxt, "Musíte vyplnit Výši zálohy odběrného místa.");

    if (!$supplyPointDeliverEmailCheck.is(":checked") && !$supplyPointDeliverPostCheck.is(":checked")) {
        AddErrorLine($supplyPointDeliverEmailCheck, "Musíte vybrat Doručení platebního kalendáře, faktury odběrného místa.");
        AddErrorClass($deliverLabel);
    }

    if (!$supplyPointChangesDeliverEmailCheck.is(":checked") && !$supplyPointChangesDeliverPostCheck.is(":checked") && !$supplyPointChangesDeliverWebCheck.is(":checked")) {
        AddErrorLine($supplyPointChangesDeliverEmailCheck, "Musíte vybrat Doručení informace o změně ceníku a OP odběrného místa.");
        AddErrorClass($changesLabel);
    }

    if (!$supplyPointDepositPaymentTransferCheck.is(":checked") && !$supplyPointDepositPaymentCollectionCheck.is(":checked") && !$supplyPointDepositPaymentSlipCheck.is(":checked") && !$supplyPointDepositPaymentSIPOCheck.is(":checked")) {
        AddErrorLine($supplyPointDepositPaymentTransferCheck, "Musíte vybrat Způsob platby záloh odběrného místa.");
        AddErrorClass($depositPaymentLabel);
    }

    if (!$supplyPointInvoicePaymentTransferCheck.is(":checked") && !$supplyPointInvoicePaymentCollectionCheck.is(":checked") && !$supplyPointInvoicePaymentSlipCheck.is(":checked")) {
        AddErrorLine($supplyPointInvoicePaymentTransferCheck, "Musíte vybrat Způsob platby faktur odběrného místa.");
        AddErrorClass($invoicePaymentLabel);
    }

    if ($supplyPointDepositPaymentSIPOCheck.is(":checked"))
        if ($.trim($supplyPointInvoicePaymentSIPOTxt.val()) != "") {
            if (!IsValidLength($.trim($supplyPointInvoicePaymentSIPOTxt.val()), 10))
                AddErrorLine($supplyPointInvoicePaymentSIPOTxt, "Spojovací číslo SIPO musí být ve správném tvaru.");
            else if(!IsValidSIPO($.trim($supplyPointInvoicePaymentSIPOTxt.val())))
                AddErrorLine($supplyPointInvoicePaymentSIPOTxt, "Musíte zadat validní Spojovací číslo SIPO.");
        }
        else
            AddErrorLine($supplyPointInvoicePaymentSIPOTxt, "Musíte vyplnit Spojovací číslo SIPO.");

    if ($supplyPointDepositPaymentCollectionCheck.is(":checked") || $supplyPointInvoicePaymentCollectionCheck.is(":checked")) {

        if ($.trim($supplyPointBankNumberFirstTxt.val()) != "")
            if (!IsValidPrefix($.trim($supplyPointBankNumberFirstTxt.val())))
                AddErrorLine($supplyPointBankNumberFirstTxt, "Musíte vyplnit správně předčíslí bankovního účtu.");

        if ($.trim($supplyPointBankNumberSecondTxt.val()) == "")
            AddErrorLine($supplyPointBankNumberSecondTxt, "Musíte vyplnit Číslo účtu.");
        else if (!IsValidBasic($.trim($supplyPointBankNumberSecondTxt.val())))
            AddErrorLine($supplyPointBankNumberSecondTxt, "Musíte správně vyplnit Číslo účtu.");

        if ($.trim($supplyPointBankNumberCodeTxt.val()) == "")
            AddErrorLine($supplyPointBankNumberCodeTxt, "Musíte vyplnit Kód banky.");

    }

    if ($nextSupplyPoint.is(":visible")) {

        if ($.trim($supplyPointStreetTxt2.val()) == "")
            AddErrorLine($supplyPointStreetTxt2, "Musíte vyplnit Ulici odběrného místa.");

        if ($.trim($supplyPointHouseNumberTxt2.val()) == "")
            AddErrorLine($supplyPointHouseNumberTxt2, "Musíte vyplnit Číslo popisné odběrného místa.");

        if ($.trim($supplyPointCountryTxt2.val()) == "")
            AddErrorLine($supplyPointCountryTxt2, "Musíte vyplnit Obec odběrného místa.");

        if ($.trim($supplyPointPostalCodeTxt2.val()) == "")
            AddErrorLine($supplyPointPostalCodeTxt2, "Musíte vyplnit PSČ odběrného místa.");
        else if (!IsValidLength($.trim($supplyPointPostalCodeTxt2.val()), 5))
            AddErrorLine($supplyPointPostalCodeTxt2, "Musíte správně vyplnit PSČ odběrného místa.");

        if (formType == "gas") {
            if ($.trim($supplyPointEICTxt2.val()) == "")
                AddErrorLine($supplyPointEICTxt2, "Musíte vyplnit EIC kód.");
            else if (!IsValidEIC($.trim($supplyPointEICTxt2.val())))
                AddErrorLine($supplyPointEICTxt2, "Musíte vyplnit EIC kód ve správném tvaru.");
        }

        if (formType == "electricity") {
            if ($.trim($supplyPointEANTxt2.val()) == "")
                AddErrorLine($supplyPointEANTxt2, "Musíte vyplnit EAN OPM kód.");
            else if (!IsValidEAN($.trim($supplyPointEANTxt2.val())))
                AddErrorLine($supplyPointEANTxt2, "Musíte vyplnit EAN OPM kód ve správném tvaru.");
        }

        if (!$supplyPointChangeProviderCheck2.is(":checked") && !$supplyPointChangeCustomerCheck2.is(":checked") && !$supplyPointChangeNewSubscriptionCheck2.is(":checked") && !$supplyPointChangeProviderPriceCheck2.is(":checked") && !$supplyPointOverwriteCheck2.is(":checked")) {
            AddErrorLine($supplyPointChangeProviderCheck2, "Musíte vybrat Důvod uzavření smlouvy odběrného místa.");
            AddErrorClass($contractReasonLabel2);
        }

        if ($.trim($supplyPointLastProviderTxt2.val()) == "")
            AddErrorLine($supplyPointLastProviderTxt2, "Musíte vyplnit Původního dodavatele odběrného místa.");

        if ($.trim($supplyPointNewDistributionTxt2.val()) == "")
            AddErrorLine($supplyPointNewDistributionTxt2, "Musíte vyplnit Distributora odběrného místa.");

        if ($.trim($supplyPointNewDistributionTxt2.val()) != "")
            if (!IsValidOption($supplyPointNewDistributionTxt2))
                AddErrorLine($supplyPointNewDistributionTxt2, "Musíte zadat správnou hodnotu pro Distributora odběrného místa.");

        if (formType == "gas") {
            if ($.trim($supplyPointYearSubscriptionAmountTxt2.val()) == "")
                AddErrorLine($supplyPointYearSubscriptionAmountTxt2, "Musíte vyplnit Plánovanou roční spotřebu odběrného místa.");
            else if ($.trim($supplyPointYearSubscriptionAmountTxt2.val()) > 630)
                AddErrorLine($supplyPointYearSubscriptionAmountTxt2, "Plánovaná roční spotřeba odběrného místa nesmí být větší než 630 MWh/rok.");
        }

        if (formType == "electricity") {
            if ($.trim($supplyPointYearSubscriptionAmountVTTxt2.val()) == "")
                AddErrorLine($supplyPointYearSubscriptionAmountVTTxt2, "Musíte vyplnit Plánovanou roční spotřebu VT odběrného místa.");
        }

        if (formType == "electricity") {
            if ($.trim($supplyPointBreakerAmountTxt2.val()) == "")
                AddErrorLine($supplyPointBreakerAmountTxt2, "Musíte vyplnit Hodnotu jističe před elektroměrem odběrného místa.");

            if ($.trim($supplyPointDistributionAmountTxt2.val()) == "")
                AddErrorLine($supplyPointDistributionAmountTxt2, "Musíte vyplnit Distribuční sazbu odběrného místa.");

            if ($.trim($supplyPointDistributionAmountTxt2.val()) != "")
                if (!IsValidOption($supplyPointDistributionAmountTxt2))
                    AddErrorLine($supplyPointDistributionAmountTxt2, "Musíte zadat správnou hodnotu pro Distribuční sazbu odběrného místa.");

            if (!$supplyPointPhaseOneCheck2.is(":checked") && !$supplyPointPhaseThreeCheck2.is(":checked")) {
                AddErrorLine($supplyPointPhaseOneCheck2, "Musíte vybrat Způsob připojení odběrného místa.");
                AddErrorClass($connectionTypeLabel2);
            }
        }

        if (!$supplyPointDepositMonthCheck2.is(":checked") && !$supplyPointDepositQuarterCheck2.is(":checked")) {
            AddErrorLine($supplyPointDepositMonthCheck2, "Musíte vybrat Zálohové období odběrného místa.");
            AddErrorClass($depositPaymentLabel2);
        }

        if ($.trim($supplyPointDepositAmountTxt2.val()) == "")
            AddErrorLine($supplyPointDepositAmountTxt2, "Musíte vyplnit Výši zálohy odběrného místa.");

        if (!$supplyPointDeliverEmailCheck2.is(":checked") && !$supplyPointDeliverPostCheck2.is(":checked")) {
            AddErrorLine($supplyPointDeliverEmailCheck2, "Musíte vybrat Doručení platebního kalendáře, faktury odběrného místa.");
            AddErrorClass($deliverLabel2);
        }

        if (!$supplyPointChangesDeliverEmailCheck2.is(":checked") && !$supplyPointChangesDeliverPostCheck2.is(":checked") && !$supplyPointChangesDeliverWebCheck2.is(":checked")) {
            AddErrorLine($supplyPointChangesDeliverEmailCheck2, "Musíte vybrat Doručení informace o změně ceníku a OP odběrného místa.");
            AddErrorClass($changesLabel2);
        }

        if (!$supplyPointDepositPaymentTransferCheck2.is(":checked") && !$supplyPointDepositPaymentCollectionCheck2.is(":checked") && !$supplyPointDepositPaymentSlipCheck2.is(":checked") && !$supplyPointDepositPaymentSIPOCheck2.is(":checked")) {
            AddErrorLine($supplyPointDepositPaymentTransferCheck2, "Musíte vybrat Způsob platby záloh odběrného místa.");
            AddErrorClass($depositPaymentLabel2);
        }

        if (!$supplyPointInvoicePaymentTransferCheck2.is(":checked") && !$supplyPointInvoicePaymentCollectionCheck2.is(":checked") && !$supplyPointInvoicePaymentSlipCheck2.is(":checked")) {
            AddErrorLine($supplyPointInvoicePaymentTransferCheck2, "Musíte vybrat Způsob platby faktur odběrného místa.");
            AddErrorClass($invoicePaymentLabel2);
        }

        if ($supplyPointDepositPaymentSIPOCheck2.is(":checked"))
            if ($.trim($supplyPointInvoicePaymentSIPOTxt2.val()) != "") {
                if (!IsValidLength($.trim($supplyPointInvoicePaymentSIPOTxt2.val()), 10))
                    AddErrorLine($supplyPointInvoicePaymentSIPOTxt2, "Spojovací číslo SIPO musí být ve správném tvaru.");
                else if (!IsValidSIPO($.trim($supplyPointInvoicePaymentSIPOTxt2.val())))
                    AddErrorLine($supplyPointInvoicePaymentSIPOTxt2, "Musíte zadat validní Spojovací číslo SIPO.");
            }
            else
                AddErrorLine($supplyPointInvoicePaymentSIPOTxt2, "Musíte vyplnit Spojovací číslo SIPO.");

        if ($supplyPointDepositPaymentCollectionCheck2.is(":checked") || $supplyPointInvoicePaymentCollectionCheck2.is(":checked")) {

            if ($.trim($supplyPointBankNumberFirstTxt2.val()) != "")
                if (!IsValidPrefix($.trim($supplyPointBankNumberFirstTxt2.val())))
                    AddErrorLine($supplyPointBankNumberFirstTxt2, "Musíte vyplnit správně předčíslí bankovního účtu.");

            if ($.trim($supplyPointBankNumberSecondTxt2.val()) == "")
                AddErrorLine($supplyPointBankNumberSecondTxt2, "Musíte vyplnit Číslo účtu.");
            else if (!IsValidBasic($.trim($supplyPointBankNumberSecondTxt2.val())))
                AddErrorLine($supplyPointBankNumberSecondTxt2, "Musíte správně vyplnit Číslo účtu.");

            if ($.trim($supplyPointBankNumberCodeTxt2.val()) == "")
                AddErrorLine($supplyPointBankNumberCodeTxt2, "Musíte vyplnit Kód banky.");

        }

    }

    if ($.trim($resignationPeriodTxt.val()) == "" || $.trim($resignationPeriodTxt.val()) == "0")
        AddErrorLine($resignationPeriodTxt, "Musíte vyplnit délku výpovědní lhůty.");

    if (!$resignationUnitMonthCheck.is(":checked") && !$resignationUnitDayCheck.is(":checked")) {
        AddErrorLine($resignationUnitMonthCheck, "Musíte vybrat Jednotku výpovědní lhůty.");
        AddErrorClass($resignationUnitLabel);
    }

    if ($.trim($signatureDateTxt.val()) == "")
        AddErrorLine($signatureDateTxt, "Musíte vyplnit Datum podpisu smlouvy.");
    else if (!IsValidDate($.trim($signatureDateTxt.val())))
        AddErrorLine($signatureDateTxt, "Musíte správně vyplnit Datum podpisu smlouvy.");

    if ($.trim($sellerIdTxt.val()) == "")
        AddErrorLine($sellerIdTxt, "Musíte vyplnit ID prodejce.");

    if ($.trim($sellerFirstNameTxt.val()) == "")
        AddErrorLine($sellerFirstNameTxt, "Musíte vyplnit Jméno prodejce.");

    if ($.trim($sellerLastNameTxt.val()) == "")
        AddErrorLine($sellerLastNameTxt, "Musíte vyplnit Příjmení prodejce.");

    if (!$contractPolicyCheck.is(":checked"))
        AddErrorLine($contractPolicyCheck, "Musíte souhlasit s obchodními podmínkami.");

    ShowHideError();
    return (errorCount == 0);
}

function AddErrorLine($field, message) {
    lineCount += 1;
    var elementId = $field.attr("id").split(" ")[0],
        $element = $("<a href=\"#\" class=\"bottomerrormiddleline\" data-id=\"" + elementId + "\">" + "<span>" + lineCount + "</span>" + message + "</a>");
    $element.click(ErrorLineClick);
    $bottomErrorMiddle.append($element);
    $field.addClass("error");
    errorCount = lineCount;
}

function AddErrorClass($field) {
    $field.addClass("error");
}

function ShowHideError() {
    var $body = $("body");
    if (errorCount > 0) {
        $bottomErrorTopCount.text(errorCount);
        $body.append($bottomError);
        $bottomError.show();
    } else
        $bottomError.hide();
}

function ErrorLineClick() {
    var elId = $(this).attr("data-id");
    var $element = $("#" + elId);
    var scrollTop = $element.offset().top - 15;
    $("html, body").stop().animate({ scrollTop: scrollTop }, 400, function () {
        $element.focus();
    });
    return false;
}

function ErrorTopClick() {
    $bottomErrorMiddle.toggle();
    $bottomErrorTopArrow.toggleClass("active");
    if ($bottomErrorTopText.text() == "Zobrazit chyby:")
        $bottomErrorTopText.text("Skrýt chyby:");
    else
        $bottomErrorTopText.text("Zobrazit chyby:");
    return false;
}

function IsValidEmail(email) {
    var emailRegex = /\S+@\S+\.\S+/;
    return (emailRegex.test(email));
}

function IsValidDate(date) {
    if (date.length == 8) {
        var day = parseInt(date.substring(0, 2), 10);
        var month = parseInt(date.substring(2, 4), 10);
        var year = date.substring(4, 8);
        if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1900)
            return false;
        else
            return true;
    }
    else
        return false;
}

function ValidTwoDates(fromDate, toDate) {
    if (fromDate.length == 8 && toDate.length == 8) {
        var fromDay = parseInt(fromDate.substring(0, 2), 10);
        var fromMonth = parseInt(fromDate.substring(2, 4), 10);
        var fromYear = fromDate.substring(4, 8);
        var toDay = parseInt(toDate.substring(0, 2), 10);
        var toMonth = parseInt(toDate.substring(2, 4), 10);
        var toYear = toDate.substring(4, 8);
        if (fromDay <= toDay && fromMonth <= toMonth && fromYear < toYear && fromYear >= new Date().getFullYear() && toYear >= new Date().getFullYear())
            return true;
        else if (fromDay <= toDay && fromMonth < toMonth && fromYear <= toYear && fromYear >= new Date().getFullYear() && toYear >= new Date().getFullYear())
            return true;
        else if (fromYear < toYear && fromYear >= new Date().getFullYear() && toYear >= new Date().getFullYear())
            return true;
        else
            return false;
    }
    else
        return false;
}

function Is18YearsOld(date) {
    var day = parseInt(date.substring(0, 2), 10);
    var month = parseInt(date.substring(2, 4), 10);
    var year = date.substring(4, 8);
    var today = new Date();
    var todayYear = today.getFullYear();
    var todayMonth = today.getMonth() + 1;
    var todayDay = today.getDate();
    var age = todayYear - year;
    var m = todayMonth - month;
    var d = todayDay - day;
    if (m < 0 || d < 0) 
        age -= 1;
    return (age >= 18);
}

function IsValidLength(value, length) {
    return (value.length == length);
}

function IsValidBasic(basic) {
    var basicArray = [6, 3, 7, 9, 10, 5, 8, 4, 2, 1];
    var sum = 0;
    for (var i = 1; i <= basic.length; i++)
        sum += (parseInt(basic.charAt(basic.length - i)) * basicArray[basicArray.length - i]);
    return (sum % 11 == 0);
}

function IsValidPrefix(prefix) {
    var prefixArray = [10, 5, 8, 4, 2, 1];
    var sum = 0;
    for (var i = 1; i <= prefix.length; i++)
        sum += (parseInt(prefix.chartAt(prefix.length - i)) * prefixArray[prefixArray.length - i]);
    return (sum % 11 == 0);
}

function IsValidSIPO(sipo) {
    var sipoArray = [3, 7, 3, 1, 7, 3, 1, 7, 3, 1];
    var sum = 0;
    for (var i = 0; i < sipoArray.length; i++) 
        sum += parseInt(sipo.charAt(i)) * sipoArray[i];
    var result = sum % 10;
    if (result == 0)
        return true;
    else if (result.toString().substring(0, 1) == sipo.charAt(sipo.length - 1))
        return true;
    else
        return false;
}

function IsValidOption($input) {
    return ($input.parent().find(".options").find("div:contains(" + $input.val() + ")").length > 0);
}

/*
function IsValidEAN(ean) {
    var eanRegex = /^\d+$/;
    return (eanRegex.test(ean) && ean.length == 18);
}

function IsValidEIC(eic) {
    var prefix = eic.substring(0, 4);
    return (prefix == "27ZG" && eic.length == 16);
}*/

function convertor(value) {
    if (value == 0) return 0;
    if (value == 1) return 1;
    if (value == 2) return 2;
    if (value == 3) return 3;
    if (value == 4) return 4;
    if (value == 5) return 5;
    if (value == 6) return 6;
    if (value == 7) return 7;
    if (value == 8) return 8;
    if (value == 9) return 9;
    if (value == "A") return 10;
    if (value == "B") return 11;
    if (value == "C") return 12;
    if (value == "D") return 13;
    if (value == "E") return 14;
    if (value == "F") return 15;
    if (value == "G") return 16;
    if (value == "H") return 17;
    if (value == "I") return 18;
    if (value == "J") return 19;
    if (value == "K") return 20;
    if (value == "L") return 21;
    if (value == "M") return 22;
    if (value == "N") return 23;
    if (value == "O") return 24;
    if (value == "P") return 25;
    if (value == "Q") return 26;
    if (value == "R") return 27;
    if (value == "S") return 28;
    if (value == "T") return 29;
    if (value == "U") return 30;
    if (value == "V") return 31;
    if (value == "W") return 32;
    if (value == "X") return 33;
    if (value == "Y") return 34;
    if (value == "Z") return 35;
    if (value == "-") return 36;
}

function IsValidEIC(EIC) {

    var isValidEIC = true;
    if (EIC.length != 16)
        return false;
    else {
        var v1 = 16 * convertor(EIC.substring(0, 1));
        var v2 = 15 * convertor(EIC.substring(1, 2));
        var v3 = 14 * convertor(EIC.substring(2, 3));
        var v4 = 13 * convertor(EIC.substring(3, 4));
        var v5 = 12 * convertor(EIC.substring(4, 5));
        var v6 = 11 * convertor(EIC.substring(5, 6));
        var v7 = 10 * convertor(EIC.substring(6, 7));
        var v8 = 9 * convertor(EIC.substring(7, 8));
        var v9 = 8 * convertor(EIC.substring(8, 9));
        var v10 = 7 * convertor(EIC.substring(9, 10));
        var v11 = 6 * convertor(EIC.substring(10, 11));
        var v12 = 5 * convertor(EIC.substring(11, 12));
        var v13 = 4 * convertor(EIC.substring(12, 13));
        var v14 = 3 * convertor(EIC.substring(13, 14));
        var v15 = 2 * convertor(EIC.substring(14, 15));
        var v16_control = convertor(EIC.substring(15, 16));
        var controlAdd = v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9 + v10 + v11 + v12 + v13 + v14 + v15;
        var modulo = 37 - (controlAdd % 37);
        if (modulo == 37) modulo = 0;
        if (v16_control != modulo) isValidEIC = false;
        if (EIC.substring(0, 4) != "27ZG") isValidEIC = false;
    }
    return isValidEIC;
}

function IsValidEAN(EAN) {
    var isValidEAN = true;

    if (EAN.length != 18) {
        isValidEAN = false;
    }
    else {
        var ean1 = 3 * EAN.substring(0, 1);
        var ean2 = 1 * EAN.substring(1, 2);
        var ean3 = 3 * EAN.substring(2, 3);
        var ean4 = 1 * EAN.substring(3, 4);
        var ean5 = 3 * EAN.substring(4, 5);
        var ean6 = 1 * EAN.substring(5, 6);
        var ean7 = 3 * EAN.substring(6, 7);
        var ean8 = 1 * EAN.substring(7, 8);
        var ean9 = 3 * EAN.substring(8, 9);
        var ean10 = 1 * EAN.substring(9, 10);
        var ean11 = 3 * EAN.substring(10, 11);
        var ean12 = 1 * EAN.substring(11, 12);
        var ean13 = 3 * EAN.substring(12, 13);
        var ean14 = 1 * EAN.substring(13, 14);
        var ean15 = 3 * EAN.substring(14, 15);
        var ean16 = 1 * EAN.substring(15, 16);
        var ean17 = 3 * EAN.substring(16, 17);
        var ean18_control = EAN.substring(17, 18);

        var eanmod = ean1 + ean2 + ean3 + ean4 + ean5 + ean6 + ean7 + ean8 + ean9 + ean10 + ean11 + ean12 + ean13 + ean14 + ean15 + ean16 + ean17;

        var eanmod1 = 10 - (eanmod % 10);
        if (eanmod1 == 10) eanmod1 = 0;
        if (ean18_control != eanmod1) isValidEAN = false;
        if (EAN.substring(0, 9) != "859182400") isValidEAN = false;
    }
    return isValidEAN;
}