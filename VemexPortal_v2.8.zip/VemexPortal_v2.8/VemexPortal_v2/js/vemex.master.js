﻿$(function () {

    // Get a reference to the embedded SCRIPT tag.
    // SCRIPT tags are loaded and parsed serially.
    // So the last script loaded is the current script being parsed. 
    
    //var path = "";
    
    //var all_script_tags = document.getElementsByTagName('script');
   
    //for (var i = 0; i < all_script_tags.length; i++) {
    //    var current = all_script_tags[i];

    //    if (current.attributes["src"].value.indexOf("vemex.master.js") != -1)
    //    {
    
    //        // Get the query string from the embedded SCRIPT tag's src attribute
    //        var query = current.attributes["src"].value.replace(/^[^\?]+\??/, '');
    //        // Parse query string into arguments/parameter

    //        var vars = query.split("&");
    //        var args = {};
            
    //        for (var j = 0; j < vars.length; j++) {
    //            path = vars[j];
    //            i = all_script_tags.length;
    //            break;
    //        }
    //    }
    //}

    
    
});

function GetListMemberData(containerId, listtype) {

    var webmethod = "common.aspx/GetMarketingList";
    var $container = $(containerId);
    var $input = $container.find("input[type=text]");
    var $hiddenInput = $container.find("input[type=hidden]");

    $input.val("");
    $hiddenInput.val("");

    var object, tags = [];

    Ajax.CallWebMethod(
       webmethod,
        { listtype: listtype },
        function (data) {            
            var obj = $.parseJSON(data);
            $.each(obj, function (i, item) {

                object = new Object();
                object.label = item.text;
                object.index = item.value;
                tags.push(object);
            });            
            $input.autocomplete({
                delay: 0,
                minLength: 0,
                source: tags,
                select: function (event, ui) {                 
                    $hiddenInput.val(ui.item.index);
                }
            });

        });

}
