﻿/*
                                //result = excelReader2007.AsDataSet();

                                    if (Path.GetExtension(FilePath) == ".xls")
                                    {
                                        oledbConn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"");
                                    }
                                    else if (Path.GetExtension(path) == ".xlsx")
                                    {
                                        oledbConn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");
                                    }

                                    //oledbConn =   new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';")) ;
                               // {

                                    oledbConn.Open();

                                    Logger.WriteLine("reading sheets");
                                    // Get the data table containg the schema guid.
                                    DataTable dt = oledbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                                    if (dt == null)
                                    {
                                        return;
                                    }

                                    String[] excelSheets = new String[dt.Rows.Count];
                                    int i = 0;

                                    // Add the sheet name to the string array.
                                    foreach (DataRow row in dt.Rows)
                                    {
                                        excelSheets[i] = row["TABLE_NAME"].ToString();
                                        i++;
                                    }


                                    OleDbCommand cmd = new OleDbCommand();
                                    OleDbDataAdapter oleda = new OleDbDataAdapter();
                                    DataSet ds = new DataSet();

                                    cmd.Connection = oledbConn;
                                    cmd.CommandType = CommandType.Text;
                                    cmd.CommandText = "SELECT * FROM [" + excelSheets[0] + "]";
                                    oleda = new OleDbDataAdapter(cmd);
                                    oleda.Fill(result);
                                    
                                    if (result.Tables.Count > 0) result.Tables[0].TableName = excelSheets[0].Replace("$", "");
*/