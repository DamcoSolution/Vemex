﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class SupplyPoint
    {

        static string logicalName = "";
        static Guid id = Guid.Empty;

        public static Guid CreateSupplyPoint(
            string name,

            bool acccont,//true acc false cont
            Guid customerGuid,
            string customerLogicalName,

            Guid opportunity,
            string opportunityLogicalName,
            string street,
            string streetNumber1,
            string streetNumber2,
            string zipcode,
            string city,
            string eanopm,
            string eic,
            int contractreason, //171 140 000
            int distributorelectricity,//171 140 000
            int distributorgas, //171 140 000
            int originaldistributor,//171 140 000
            string annualconsumptionnt,
            string annualconsumptionvt,
            int distributionrate,//171 140 000
            string breakervalue,
            Money advancepayment,
            int advanceperiod,//171 140 000
            int connectiontype,//171 140 000
            int informationdelivery,//171 140 000
            int paymentscheduledelivery,//171 140 000
            int paymenttype,//171 140 000
            string siponumber,
            int paymenttypeadvances,//171 140 000
            string accountnumberp2,
            string accountnumberp1,
            string bankcode,
            string auctionnumber,
            string importnumber
            )
        {
            try
            {
                Entity supplyPoint = new Entity("cre_supplypoint");
                if (streetNumber2=="") supplyPoint["cre_name"] = name + " - " + street + " " + streetNumber1 + ", " + city;
                else supplyPoint["cre_name"] = name + " - " + street + " " + streetNumber1 + "/" + streetNumber2 + ", " + city;


                if (acccont == true) supplyPoint["cre_account"] = new EntityReference { LogicalName = customerLogicalName, Id = customerGuid };
                supplyPoint["cre_opportunity"] = new EntityReference { LogicalName = opportunityLogicalName, Id = opportunity };
                if (acccont == false) supplyPoint["cre_contact"] = new EntityReference { LogicalName = customerLogicalName, Id = customerGuid };
                supplyPoint["cre_street"] = street;
                supplyPoint["cre_housenumber"] = streetNumber1;
                supplyPoint["cre_orientationnumber"] = streetNumber2;
                supplyPoint["cre_city"] = city;
                supplyPoint["cre_postalcode"] = zipcode;
                supplyPoint["cre_eanopm"] = eanopm;
                supplyPoint["cre_eic"] = eic;
                supplyPoint["cre_contractreason"] = new OptionSetValue(contractreason);
                supplyPoint["cre_distributorelectricity"] = new OptionSetValue(distributorelectricity);
                supplyPoint["cre_distributorgas"] = new OptionSetValue(distributorgas);
                supplyPoint["cre_originaldistributor"] = new OptionSetValue(originaldistributor);
                supplyPoint["cre_annualconsumptionnt"] = annualconsumptionnt;
                supplyPoint["cre_annualconsumptionvt"] = annualconsumptionvt;

                if (eic != "")
                    supplyPoint["cre_annualconsumption_gas"] = annualconsumptionvt;

                supplyPoint["cre_distributionrate"] = new OptionSetValue(distributionrate);
                supplyPoint["cre_breakervalue"] = breakervalue;
                supplyPoint["cre_advancepayment"] = advancepayment;
                supplyPoint["cre_advanceperiod"] = new OptionSetValue(advanceperiod);
                supplyPoint["cre_connectiontype"] = new OptionSetValue(connectiontype);
                supplyPoint["cre_informationdelivery"] = new OptionSetValue(informationdelivery);
                supplyPoint["cre_paymentscheduledelivery"] = new OptionSetValue(paymentscheduledelivery);
                supplyPoint["cre_paymenttype"] = new OptionSetValue(paymenttype);
                supplyPoint["cre_siponumber"] = siponumber;
                supplyPoint["cre_paymenttypeadvances"] = new OptionSetValue(paymenttypeadvances);
                supplyPoint["cre_accountnumberp2"] = accountnumberp2;
                supplyPoint["cre_accountnumberp1"] = accountnumberp1;
                supplyPoint["cre_bankcode"] = bankcode;
                supplyPoint["cre_auctionnumber"] = auctionnumber;
                supplyPoint["cre_importnumber"] = importnumber;
                logicalName = supplyPoint.LogicalName;
                id = ServiceControl.Create(supplyPoint, ServiceControl.GetService());
                return id;
            }
            catch (Exception ex)
            {
                Logger.WriteLine("SP Zaslání e-mailu s chybou: " + ex.Message);
                EmaiSender.SendError("consoleApp error SP", ex.Message);
                return Guid.Empty;
            }
        }

        public static string GetLogicalName()
        {
            return logicalName;
        }

        public static Guid GetId()
        {
            return id;
        }

    }

}
