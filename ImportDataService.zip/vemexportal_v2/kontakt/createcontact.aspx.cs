﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using VemexPortal;
using VemexPortal_v2.App_Code;
using System.Web.Services;
using VemexPortal_v2.Controls;
using VemexPortal_v2.EntityObjects;
using CRM.Helper;

namespace VemexPortal_v2.contact
{
    public partial class createcontact : PageControl
    {
        public List<SelectControl> titulList = new List<SelectControl>(),
                                  titulLastList = new List<SelectControl>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                ApplyRights();
                titulList = SelectControl.GetSelectOptions(Constants.Contact, "cre_titulpred");
                titulLastList = SelectControl.GetSelectOptions(Constants.Contact, "cre_titulza");
            }
        }

        /// <summary>
        /// Authorization check
        /// </summary>
        private void ApplyRights()
        {

            LoginControl currentuser = LoginControl.LoggedUser();

            bool canCreate = VemexPortal_v2.Controls.PortalRole.CanCreate(Entity_Name.kontakt.ToString());
            if (!canCreate)
            {
                new ErrorControl("You don't have right to create contact ");
                //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }

            PortalRights rights = PortalRole.GetRights(Entity_Name.kontakt).FirstOrDefault();


            List<PortalRole> Roles = PortalRole.GetAllRoles();

            List<Account> AccountList = new AccountControl().GetAllAccount();
            ddlAccount.DataSource = AccountList;
            ddlAccount.DataBind();

            ListItem item = ddlAccount.Items.FindByValue(Convert.ToString(currentuser.ParentCustomer.Id));
            if (item != null) item.Selected = true;


            Roles = Roles.Where(lst => lst.Rights.Where(ls => (int)ls.AccessLevel <= (int)rights.AccessLevel).FirstOrDefault() != null).ToList();

            ddlRole.DataSource = Roles;
            ddlRole.DataBind();

            if (rights.AccessLevel == AccessLevel.account || rights.AccessLevel == AccessLevel.kontakt)
            {
                ddlAccount.Enabled = false;
            }
            UserIdTxt.Text = GetNextUserIdByAccountId(Convert.ToString(currentuser.ParentCustomer.Id));
        }

        /// <summary>
        /// Create Contact event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CreateContactBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // fyzicka osoba
                int titulInt = titulValue.Value.Trim() != "" ? Convert.ToInt32(titulValue.Value.Trim()) : -1;

                int titulLastInt = titulLastValue.Value.Trim() != "" ? Convert.ToInt32(titulLastValue.Value.Trim()) : -1;
                DateTime? date = null;
                if (birthdateTxt.Text.Trim() != "" && birthdateTxt.Text.Trim().Length == 8)
                {
                    int day = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(0, 2));
                    int month = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(2, 2));
                    int year = Convert.ToInt32(birthdateTxt.Text.Trim().Substring(4, 4));
                    date = new DateTime(year, month, day);
                }
                Guid ParentAccountId = new Guid(ddlAccount.SelectedValue);
                Guid RoleId = new Guid(ddlRole.SelectedValue);
                int accountRoleid = Convert.ToInt32(ddlContactType.SelectedValue);
                
                Guid contactid = CustomerControl.CreateUpdateContact(titulInt, titulLastInt, firstNameTxt.Text.Trim(), lastNameTxt.Text.Trim(), txtEmail.Text.Trim(),
                    txtPhone.Text.Trim(), date, UserIdTxt.Text.Trim(), passwordTxt.Text.Trim(), null, ParentAccountId, RoleId, accountRoleid);

                // add message to log file
                HelpControl.AddToLog("Kontakt \"" + firstNameTxt.Text + " " + lastNameTxt.Text + "\" Added successfully: " + contactid);

                new ErrorControl("Contact Created successfully with ID : " + UserIdTxt.Text);

                Response.Redirect(UrlControl.GetPathUrl() + "/viewcontact",false);
            }
            catch (Exception ex)
            {
                Email.SendError("VemexPortal error", "Error: CreateContactBtn_Click in createcontaxt.aspx code-behind was unsuccessful.<br /><br />" +
                                "Message:<br />" + ex.Message + "<br /><br />StackTrace:<br />" + (ex.StackTrace != null ? ex.StackTrace : "None"));

                // add message to log file
                HelpControl.AddToLog("Errror occured while creating contact records");

                // throw message
                new ErrorControl("Smlouva se nepodařila uložit.");
            }
        }

        [WebMethod]
        public static bool IsUserExists(string user)
        {
            return ContactControl.IsUserExists(user, ServiceControl.GetService(), null);
        }

        [WebMethod]
        public static string GetNextUserIdByAccountId(string AccountId)
        {
            Guid Accountid = new Guid(AccountId);
            return AccountControl.GetNextUserId(Accountid);
        }
    }
}