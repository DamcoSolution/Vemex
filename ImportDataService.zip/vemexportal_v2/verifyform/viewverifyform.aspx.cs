﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;
using VemexPortal_v2.Controls;
using VemexPortal_v2.EntityObjects;

namespace VemexPortal_v2.verifyform
{
    public partial class ViewVerifyForm : PageControl
    {
        int pageSize = 20;
        protected int TotalRecordCount { get; set; }

        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpContext.Current.Session["Exported"] = false;

                if (!PortalRole.CanView(Entity_Name.cre_verifyform))
                {
                    new ErrorControl("You don't have right to view verify form ");
                    //Response.Redirect(UrlControl.GetPathUrl() + "/plyn");
                    Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
                }
                else
                {
                    BindGrid(0, pageSize);

                }
            }
        }

        private void BindGrid(int pageNumber, int pageSize)
        {
            var rights = LoginControl.Role.Rights.Where(lst => lst.Entity == Entity_Name.cre_verifyform).FirstOrDefault();
            LoginControl user = LoginControl.LoggedUser();
            VerifyFormControl verifyFormControl = new VerifyFormControl();
            var list = verifyFormControl.GetVerifyFormList(rights, user, pageNumber, pageSize);
            grdVeryForm.DataSource = list;
            TotalRecordCount = verifyFormControl.TotalRecords;
            grdVeryForm.VirtualItemCount = TotalRecordCount;
            grdVeryForm.DataBind();
        }
   
        protected void grdVeryForm_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdVeryForm.PageIndex = e.NewPageIndex;
            BindGrid(e.NewPageIndex, pageSize);
        }

        protected void grdVeryForm_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Pager)
            {
                var row = e.Row;
                //Create one Cell for adding in my current paging strip
                TableCell infocell = new TableCell();
                infocell.Text = "   [ " + ((grdVeryForm.PageIndex) * 20).ToString() + " - " + Convert.ToString((TotalRecordCount > grdVeryForm.PageIndex * 20 + 20) ? grdVeryForm.PageIndex * 20 + 20 : TotalRecordCount) + " : " + Convert.ToString(TotalRecordCount) + " ]";

                //Getting table which shows PagingStrip
                Table tbl = (Table)row.Cells[0].Controls[0];

                //Will Find  table
                tbl.Rows[0].Cells.Add(infocell);
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            HttpContext.Current.Session["Exported"] = false;
            grdVeryForm.AllowPaging = false;
            grdVeryForm.AllowCustomPaging = false;
            BindGrid(0, 200);

            ExportToExcel(grdVeryForm);
           // Response.Redirect(Request.RawUrl);
        

        }

     
        private void ExportToExcel(GridView grid)
        {

            //FileName
            string path_suffix = DateTime.Now.Day.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".xls";
            
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename="+path_suffix);
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";


            StringWriter sw = new StringWriter();
            HtmlTextWriter htmlWrite = new HtmlTextWriter(sw);
            
            ////string path = HttpContext.Current.Server.MapPath("~") + "ExportedFiles\\" + path_suffix;
            //FileInfo FI = new FileInfo(path);

            grid.RenderControl(htmlWrite);

            //style to format numbers to string
            HttpContext.Current.Session["Exported"] = true;

            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

            //string directory = path.Substring(0, path.LastIndexOf("\\"));// GetDirectory(Path);
            //if (!Directory.Exists(directory))
            //{
            //    Directory.CreateDirectory(directory);
            //}
            //System.IO.StreamWriter vw = new System.IO.StreamWriter(path, true);
            //stringWriter.ToString().Normalize();
            //vw.Write(stringWriter.ToString());
            //vw.Write("");
            //vw.Flush();
            //vw.Close();
            //WriteAttachment("ExportedFiles_" + FI.Name, "application/vnd.ms-excel", stringWriter.ToString());
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
               server control at run time. */
        }


        [WebMethod]
        public static bool IsExported(string user)
        {
            return Convert.ToBoolean(HttpContext.Current.Session["Exported"]);
            
        }


    }
}