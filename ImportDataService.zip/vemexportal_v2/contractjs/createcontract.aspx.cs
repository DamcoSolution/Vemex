﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;

namespace VemexPortal_v2.contractjs
{
    public partial class createcontract : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // callback
            string callback = Request.QueryString["callback"];

            // cislo navrhu
            string customerType = Request.QueryString["customerType"];

            // fyzicka osoba
            string firstName = Request.QueryString["firstName"];
            string lastName = Request.QueryString["lastName"];
            string birthday = Request.QueryString["birthdate"] != null ? Request.QueryString["birthdate"] : "";
            string ico = Request.QueryString["ico"];
            string dic = Request.QueryString["dic"];

            // pravnicka osoba
            string companyName = Request.QueryString["companyName"];
            string companyIco = Request.QueryString["companyIco"];
            string companyDic = Request.QueryString["companyDic"];

            // osoba opravnena jednat
            string trustTitul = Request.QueryString["trustJobTitle"];
            string trustFirstName = Request.QueryString["trustFirstName"];
            string trustLastName = Request.QueryString["trustLastName"];
            string trustTitulSecond = Request.QueryString["trustJobTitleSecond"];
            string trustFirstNameSecond = Request.QueryString["trustFirstNameSecond"];
            string trustLastNameSecond = Request.QueryString["trustLastNameSecond"];

            // kontaktni udaje
            string email = Request.QueryString["email"];
            string telephone = Request.QueryString["phone"];

            // silo trvale bydliste
            string street = Request.QueryString["street"];
            string houseNumber = Request.QueryString["houseNumber"];
            string orientationNumber = Request.QueryString["orientationNumber"];
            string postalCode = Request.QueryString["postalCode"];
            string city = Request.QueryString["city"];

            // korespondencni adresa
            string postalStreet = Request.QueryString["postalStreet"];
            string postalHouseNumber = Request.QueryString["postalHouseNumber"];
            string postalOrientationNumber = Request.QueryString["postalOrientationNumber"];
            string postalPostalCode = Request.QueryString["postalPostalCode"];
            string postalCountry = Request.QueryString["postalCity"];

            // odberne misto
            string supplyPointStreet = Request.QueryString["supplyPointStreet"];
            string supplyPointHouseNumber = Request.QueryString["supplyPointHouseNumber"];
            string supplyPointOrientationNumber = Request.QueryString["supplyPointOrientationNumber"];
            string supplyPointCity = Request.QueryString["supplyPointCity"];
            string supplyPointPostalCode = Request.QueryString["supplyPointPostalCode"];
            string supplyPointEAN = Request.QueryString["ean"];
            string supplyPointEIC = Request.QueryString["eic"];
            string supplyPointLastProvider = Request.QueryString["supplyPointLastProvider"];
            string supplyPointNewDistributionGas = Request.QueryString["supplyPointNewDistributionGas"];
            string supplyPointNewDistributionElectricity = Request.QueryString["supplyPointNewDistributionElectricity"];
            string supplyPointYearSubscriptionAmount = Request.QueryString["supplyPointConsumption"];
            string supplyPointYearSubscriptionAmountVT = Request.QueryString["supplyPointConsumptionVT"];
            string supplyPointYearSubscriptionAmountNT = Request.QueryString["supplyPointConsumptionNT"];
            string supplyPointDistributionAmount = Request.QueryString["supplyPointDistributionAmount"];
            string supplyPointBreakerValue = Request.QueryString["supplyPointBreakerValue"];
            string supplyPointDepositAmount = Request.QueryString["supplyPointDepositAmount"];
            string supplyPointInvoicePaymentSIPO = Request.QueryString["supplyPointSIPO"];
            string supplyPointBankNumberFirst = Request.QueryString["supplyPointBankNumberFirst"];
            string supplyPointBankNumberSecond = Request.QueryString["supplyPointBankNumberSecond"];
            string supplyPointBankNumberCode = Request.QueryString["supplyPointBankCode"];

            string supplyPointChange = Request.QueryString["supplyPointContractReason"];
            string supplyPointPhase = Request.QueryString["supplyPointConnectionType"];
            string supplyPointDepositPeriod = Request.QueryString["supplyPointDepositTimeType"];
            string supplyPointDeliverInvoice = Request.QueryString["supplyPointDeliveryType"];
            string supplyPointChangesDeliver = Request.QueryString["supplyPointChangesType"];
            string supplyPointDepositPayment = Request.QueryString["supplyPointDepositPaymentType"];
            string supplyPointInvoicePayment = Request.QueryString["supplyPointInvoicePaymentType"];

            string contractTime = Request.QueryString["contractTime"];

            string description = "";
            if (!String.IsNullOrEmpty(customerType))
                description += "Typ zákazníka: " + customerType + "\n";
            if (!String.IsNullOrEmpty(birthday))
                description += "Datum narození: " + birthday + "\n";
            if (!String.IsNullOrEmpty(ico))
                description += "IČO: " + ico + "\n";
            if (!String.IsNullOrEmpty(dic))
                description += "DIČ: " + dic + "\n";
            if (!String.IsNullOrEmpty(companyName))
                description += "Název společnosti: " + companyName + "\n";
            if (!String.IsNullOrEmpty(companyIco))
                description += "IČO společnosti: " + companyIco + "\n";
            if (!String.IsNullOrEmpty(companyDic))
                description += "DIČ společnosti: " + companyDic + "\n";
            if (!String.IsNullOrEmpty(trustTitul))
                description += "Titul odpovědné osoby: " + trustTitul + "\n";
            if (!String.IsNullOrEmpty(trustFirstName))
                description += "Jméno odpovědné osoby: " + trustFirstName + "\n";
            if (!String.IsNullOrEmpty(trustLastName))
                description += "Příjmení odpovědné osoby: " + trustLastName + "\n";
            if (!String.IsNullOrEmpty(trustTitulSecond))
                description += "Titul odpovědné osoby 2: " + trustTitulSecond + "\n";
            if (!String.IsNullOrEmpty(trustFirstNameSecond))
                description += "Jméno odpovědné osoby 2: " + trustFirstNameSecond + "\n";
            if (!String.IsNullOrEmpty(trustLastNameSecond))
                description += "Příjmení odpovědné osoby 2: " + trustLastNameSecond + "\n";

            if (!String.IsNullOrEmpty(street))
                description += "Ulice: " + street + "\n";
            if (!String.IsNullOrEmpty(houseNumber))
                description += "Číslo popisné: " + houseNumber + "\n";
            if (!String.IsNullOrEmpty(orientationNumber))
                description += "Číslo orientační: " + orientationNumber + "\n";
            if (!String.IsNullOrEmpty(postalCode))
                description += "PSČ: " + postalCode + "\n";

            if (!String.IsNullOrEmpty(postalStreet))
                description += "Korespondenční adresa: Ulice: " + postalStreet + "\n";
            if (!String.IsNullOrEmpty(postalHouseNumber))
                description += "Korespondenční adresa: Číslo popisné: " + postalHouseNumber + "\n";
            if (!String.IsNullOrEmpty(postalOrientationNumber))
                description += "Korespondenční adresa: Číslo orientační: " + postalOrientationNumber + "\n";
            if (!String.IsNullOrEmpty(postalPostalCode))
                description += "Korespondenční adresa: PSČ: " + postalPostalCode + "\n";
            if (!String.IsNullOrEmpty(postalCountry))
                description += "Korespondenční adresa: Město: " + postalCountry + "\n";


            if (!String.IsNullOrEmpty(supplyPointStreet))
                description += "Odběrné místo: Ulice: " + supplyPointStreet + "\n";
            if (!String.IsNullOrEmpty(supplyPointHouseNumber))
                description += "Odběrné místo: Číslo popisné: " + supplyPointHouseNumber + "\n";
            if (!String.IsNullOrEmpty(supplyPointOrientationNumber))
                description += "Odběrné místo: Číslo orientační: " + supplyPointOrientationNumber + "\n";
            if (!String.IsNullOrEmpty(supplyPointCity))
                description += "Odběrné místo: Město: " + supplyPointCity + "\n";
            if (!String.IsNullOrEmpty(supplyPointPostalCode))
                description += "Odběrné místo: PSČ: " + supplyPointPostalCode + "\n";
            if (!String.IsNullOrEmpty(supplyPointEAN))
                description += "Odběrné místo: EAN kód: " + supplyPointEAN + "\n";
            if (!String.IsNullOrEmpty(supplyPointEIC))
                description += "Odběrné místo: EIC kód: " + supplyPointEIC + "\n";
            if (!String.IsNullOrEmpty(supplyPointLastProvider))
                description += "Odběrné místo: Původní dodavatel: " + supplyPointLastProvider + "\n";
            if (!String.IsNullOrEmpty(supplyPointNewDistributionGas))
                description += "Odběrné místo: Distributor plyn: " + supplyPointNewDistributionGas + "\n";
            if (!String.IsNullOrEmpty(supplyPointNewDistributionElectricity))
                description += "Odběrné místo: Distributor elektřina: " + supplyPointNewDistributionElectricity + "\n";
            if (!String.IsNullOrEmpty(supplyPointYearSubscriptionAmount))
                description += "Odběrné místo: Roční spotřeba plyn: " + supplyPointYearSubscriptionAmount + "\n";
            if (!String.IsNullOrEmpty(supplyPointYearSubscriptionAmountVT))
                description += "Odběrné místo: Roční spotřeba elektřina VT: " + supplyPointYearSubscriptionAmountVT + "\n";
            if (!String.IsNullOrEmpty(supplyPointYearSubscriptionAmountNT))
                description += "Odběrné místo: Roční spotřeba elektřina NT: " + supplyPointYearSubscriptionAmountNT + "\n";
            if (!String.IsNullOrEmpty(supplyPointDistributionAmount))
                description += "Odběrné místo: Distribuční sazba: " + supplyPointDistributionAmount + "\n";
            if (!String.IsNullOrEmpty(supplyPointBreakerValue))
                description += "Odběrné místo: Hodnota jističe před elektroměrem: " + supplyPointBreakerValue + "\n";
            if (!String.IsNullOrEmpty(supplyPointDepositAmount))
                description += "Odběrné místo: Výše zálohy: " + supplyPointDepositAmount + "\n";
            if (!String.IsNullOrEmpty(supplyPointInvoicePaymentSIPO))
                description += "Odběrné místo: SIPO: " + supplyPointInvoicePaymentSIPO + "\n";
            if (!String.IsNullOrEmpty(supplyPointBankNumberFirst))
                description += "Odběrné místo: Předčíslí bankovního účtu: " + supplyPointBankNumberFirst + "\n";
            if (!String.IsNullOrEmpty(supplyPointBankNumberSecond))
                description += "Odběrné místo: Číslo bankovního účtu: " + supplyPointBankNumberSecond + "\n";
            if (!String.IsNullOrEmpty(supplyPointBankNumberCode))
                description += "Odběrné místo: Kód banky: " + supplyPointBankNumberCode + "\n";
            if (!String.IsNullOrEmpty(supplyPointChange))
                description += "Důvod uzavření smlouvy: " + supplyPointChange + "\n";
            if (!String.IsNullOrEmpty(supplyPointPhase))
                description += "Způsob zapojení: " + supplyPointPhase + "\n";
            if (!String.IsNullOrEmpty(supplyPointDepositPeriod))
                description += "Zálohové období: " + supplyPointDepositPeriod + "\n";
            if (!String.IsNullOrEmpty(supplyPointDeliverInvoice))
                description += "Doručení platebního kalendáře, faktury: " + supplyPointDeliverInvoice + "\n";
            if (!String.IsNullOrEmpty(supplyPointChangesDeliver))
                description += "Doručení informace o změně ceníku a OP: " + supplyPointChangesDeliver + "\n";
            if (!String.IsNullOrEmpty(supplyPointDepositPayment))
                description += "Způsob platby záloh: " + supplyPointDepositPayment + "\n";
            if (!String.IsNullOrEmpty(supplyPointInvoicePayment))
                description += "Způsob platby faktur: " + supplyPointInvoicePayment + "\n";

            Guid _leadId = CustomerControl.CreateLead(
                firstName,
                lastName,
                email,
                telephone,
                street,
                city,
                postalCode,
                description,"","","",""
                );

            if (_leadId != Guid.Empty)
                Response.Write(callback + "({\"success\":1});");
            else
                Response.Write(callback + "({\"success\":0});");
        }
    }
}