﻿// variables

var errorCount = 0,
    lineCount = 0,
    $bottomError = $("<div class=\"bottomerror\">" +
                        "<div class=\"holder\">" +
                            "<div class=\"bottomerrortop\">" +
                                "<div class=\"bottomerrortopalert\"></div>" +
                                "<div class=\"bottomerrortopcontent\">Formulář nelze odeslat!</div>" +
                                "<div class=\"bottomerrortoparrow\"><span>Zobrazit chyby:</span> <strong>28</strong></div>" +
                            "</div>" +
                            "<div class=\"bottomerrormiddle\"></div>" +
                        "</div>" +
                        "</div>"),
    $bottomErrorTop = $bottomError.find(".bottomerrortop"),
    $bottomErrorTopCount = $bottomErrorTop.find(".bottomerrortoparrow strong"),
    $bottomErrorTopText = $bottomErrorTop.find(".bottomerrortoparrow span"),
    $bottomErrorTopArrow = $bottomErrorTop.find(".bottomerrortoparrow"),
    $bottomErrorMiddle = $bottomError.find(".bottomerrormiddle");

// events
$bottomErrorTop.click(ErrorTopClick);


// functions
function ValidateForm() {
    debugger;
    var  $hdnContactId = $("#hdnContactId"),
        $checkedItems = $('#detailsCheckBoxList'),
    $txtContactId = $("#txtContactId");

    var $ControlContainer = $("div[data-id=Controls]");

    var $rows = $ControlContainer.find(".row");

    $rows.each(function () {

        var $hdnIsRequired = $(this).find("input[id = 'hdnIsRequired']");
        
        var $hdncontroltype = $(this).find("input[id = 'hdnControlType']");

        if ($hdnIsRequired != null && $hdnIsRequired.val() == "true")
        {
            var $control = $(this).find("input[type != 'hidden']");

            var controltype = $hdncontroltype.val();
            switch (controltype) {
                //Checkbox
                case '171140000':
                    alert('jQuery sucks!');
                    break;
                //Option Set
                case '171140001':
                    alert('prototype sucks!');
                //Single line of text
                case '171140002':
                    alert('mootools sucks!');
                //Decimal Number
                case '171140003':
                    alert('dojo sucks!');
                    break;
                //Multiple line of text
                case '171140004':
                    alert('dojo sucks!');
                    break;
                //Radio Button
                case '171140005':
                    alert('dojo sucks!');
                    break;
                    
                default:
                    alert('Nobody sucks!');
            }
        }
    });
    
    ////var checkedItems = 
    //if ($.trim($hdnContactId.val()) == "" || $.trim($txtContactId.val()) == "") {
    //    AddErrorLine($txtContactId, "Please Select User.");
    //}
    //if ($checkedItems.find('input:checked').length == 0){
    //    AddErrorLine($checkedItems, "Please Select Product.");
    //}

    ShowHideError();
    return (errorCount == 0);
};

function AddErrorLine($field, message) {
    lineCount += 1;
    var elementId = $field.attr("id").split(" ")[0],
    $element = $("<a href=\"#\" class=\"bottomerrormiddleline\" data-id=\"" + elementId + "\">" + "<span>" + lineCount + "</span>" + message + "</a>");
    $element.click(ErrorLineClick);
    $bottomErrorMiddle.append($element);
    $field.addClass("error");
    errorCount = lineCount;
}

function AddErrorClass($field) {
    $field.addClass("error");
}

function ShowHideError() {

    var $body = $("body");
    if (errorCount > 0) {
        $bottomErrorTopCount.text(errorCount);
        $body.append($bottomError);
        $bottomError.show();
    } else
        $bottomError.hide();
}

function ErrorLineClick() {
    var elId = $(this).attr("data-id");
    var $element = $("#" + elId);
    var scrollTop = $element.offset().top - 15;
    $("html, body").stop().animate({ scrollTop: scrollTop }, 400, function () {
        $element.focus();
    });
    return false;
}

function ErrorTopClick() {
    $bottomErrorMiddle.toggle();
    $bottomErrorTopArrow.toggleClass("active");
    return false;
}

function IsValidEmail(email) {

    var emailRegex = /\S+@\S+\.\S+/;
    return (emailRegex.test(email));
}

function IsValidDate(date) {
    if (date.length == 8) {
        var day = parseInt(date.substring(0, 2), 10);
        var month = parseInt(date.substring(2, 4), 10);
        var year = date.substring(4, 8);
        if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1900)
            return false;
        else
            return true;
    }
    else
        return false;
}