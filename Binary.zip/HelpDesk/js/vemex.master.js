﻿$(function () {

    // Get a reference to the embedded SCRIPT tag.
    // SCRIPT tags are loaded and parsed serially.
    // So the last script loaded is the current script being parsed. 

    var path = "";

    var all_script_tags = document.getElementsByTagName('script');
   
    for (var i = 0; i < all_script_tags.length; i++) {
        var current = all_script_tags[i];

        if (current.attributes["src"].value.indexOf("vemex.master.js") != -1)
        {          
            // Get the query string from the embedded SCRIPT tag's src attribute
            var query = current.attributes["src"].value.replace(/^[^\?]+\??/, '');
            // Parse query string into arguments/parameter

            var vars = query.split("&");
            var args = {};

            for (var j = 0; j < vars.length; j++) {
                path = vars[j];
                i = all_script_tags.length;
                break;
            }
        }
    }


    $(".menulink").click(function () {

        var $hiddenInput = $(this).find("input[id='hdnId']");

        var $hiddenInputUrl = $(this).find("input[id='hdnurl']");

        var $a = $(this).find("a");
        var webmethod = path + "/common.aspx/SetMenuClick";
        var rightid = $hiddenInput.val();
        if (rightid.length > 0) {
                
            Ajax.CallWebMethod(
               webmethod,
                { rightId: rightid },
                function (response) {
                    if (response) {
        
                        location.href = $hiddenInputUrl.val();
                    }
                });
        }
    });

    
    // to apply field level security.
    $(document).ready(function () {
       
        var rightid = "hello";
        var webmethod = path + "/common.aspx/GetPageFieldRights";

            Ajax.CallWebMethod(
               webmethod,
                { rightId: rightid },
                function (data) {                    
                    var obj = $.parseJSON(data);
                    $.each(obj, function (i, item) {                       
                        if (item.IsGridField == false) {
                            var $var = $("#" + item.Name);
                            var $otherfield = $("#" + item.OtherField);
                            if ($var != undefined) {
                                if (item.Show == false) {
                                    $var.hide();
                                    $otherfield.hide();
                                }
                                else {
                                    $var.show();
                                    $otherfield.show();
                                }
                            }
                        }
                        else {
                            var index = 0;
                            $("#" + item.Name).find("tr").each(function () {
                                if ($(this).find("#" + item.OtherField) != null)
                                    index = $(this).find("#" + item.OtherField).closest("td").index();
                            });
                            if (index > 0)
                                index = index + 1;
                            $("#" + item.Name + " td:nth-child(" + index + "),th:nth-child(" + index + ")").fadeOut(250);
                        }
                        
                    });

                });
    });
    
});