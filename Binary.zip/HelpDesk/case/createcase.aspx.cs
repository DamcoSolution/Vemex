﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CreativeMages.Xrm;
using HelpDesk.Controls;
using HelpDesk.EntityObjects;

namespace HelpDesk.ServiceCase
{
	public partial class createcase : PageControl
	{
        public List<SelectControl> CategoryList = new List<SelectControl>(),
                                   SubCategoryList = new List<SelectControl>();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ApplyRights();

                CategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_category");
                SubCategoryList = SelectControl.GetSelectOptions("cre_helpdeskissue", "cre_subcategory");
            }
        }


        /// <summary>
        /// Authorization check
        /// </summary>
        private void ApplyRights()
        {
            var currentuser = LoginControl.GetUser();

            bool canCreate = HelpDesk.Controls.PortalRole.CanCreate(Entity_Name.Case.ToString());
            if (!canCreate)
            {             
                Response.Redirect(UrlControl.GetSiteRootUrl() + "/home");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            using(XrmContext context = new XrmContext(ServiceControl.GetService()))
            {
                var conf = context.cre_helpdeskconfigurationSet.ToList();

                rptControls.DataSource = conf;
                rptControls.DataBind();
                
            }
        }

        protected void rptControls_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var entity = e.Item.DataItem as cre_helpdeskconfiguration;
                if (entity != null)
                {

                    cre_helpdeskconfigurationcre_controltype ControlType = (cre_helpdeskconfigurationcre_controltype)entity.cre_controltype.Value;
                    var hdnControlType = e.Item.FindControl("hdnControlType") as HiddenField;
                    if(hdnControlType != null)
                        hdnControlType.Value = entity.cre_controltype.Value.ToString();

                    var hdnControlName = e.Item.FindControl("hdnControlName") as HiddenField;
                    if (hdnControlName != null)
                        hdnControlName.Value = entity.cre_controlname;

                    //cre_helpdeskissuecre_priority.
                    switch (ControlType)
                    { 
                        case cre_helpdeskconfigurationcre_controltype.CheckBox:
                            var chkControl = e.Item.FindControl("chkControl") as CheckBox;
                            chkControl.Visible = true;
                            chkControl.Text = entity.cre_name;
                           
                            break;
                        case cre_helpdeskconfigurationcre_controltype.DecimalNumber:
                            var txtControl = e.Item.FindControl("txtControl") as TextBox;
                            if (txtControl != null)
                            {
                                txtControl.Visible = true;
                                
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.MultipleLinesofText:
                            var txtMulControl = e.Item.FindControl("txtMulControl") as TextBox;
                            txtMulControl.Visible = true;
                            
                            break;
                        case cre_helpdeskconfigurationcre_controltype.OptionSet:

                            var ddlControl = e.Item.FindControl("ddlControl") as DropDownList;
                            if (ddlControl != null)
                            {
                                ddlControl.Visible = true;

                                Type type = Type.GetType("CreativeMages.Xrm.cre_helpdeskissue" + entity.cre_controlname + ", CreativeMages.Xrm");
                                ddlControl.DataSource = GetEnumForBind(type);
                                ddlControl.DataTextField = "Value";
                                ddlControl.DataValueField = "Key";
                                ddlControl.DataBind();
                            }
                            break;
                        case cre_helpdeskconfigurationcre_controltype.RadioButton:
                            break;
                        case cre_helpdeskconfigurationcre_controltype.SingleLineofText:
                            break;
                        default:
                            break;

                    }

                }

                
            }
        }

        public Dictionary<int,string> GetEnumForBind(Type enumeration)
        {

            string[] names = Enum.GetNames(enumeration);
            Array values = Enum.GetValues(enumeration);
            Dictionary<int, string> lstValues = new Dictionary<int, string>();
            for (int i = 0; i < names.Length; i++)
            {
                lstValues.Add(Convert.ToInt32(values.GetValue(i)), names[i]);
            }
            return lstValues;
        }

	}
}