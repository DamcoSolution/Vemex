﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VemexPortal.Controls;

namespace VemexPortal
{
    public partial class odhlaseni : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoginControl.Logout();
            Response.Redirect(UrlControl.GetPathUrl());
        }
    }
}