﻿var Lead = {

    isBusy: false,

    Create: function (firstName, lastName, phone, email, message, contactDate, country, consumptionGas, consumptionElectricityVT, consumptionElectricityNT, successCallback, errorCallback) {

        if (!firstName) {
            alert("Parameter \"firstName\" is required.");
            return;
        }

        if (!lastName) {
            alert("Parameter \"lastName\" is required.");
            return;
        }

        if (!phone || !email) {
            alert("Parameter \"phone or email\" is required.");
            return;
        }

        if (this.isBusy)
            return;

        var domain = "http://www.creativemages.com/vemex/leadjs/createlead.aspx",
            params = "?firstName=" + firstName + "&lastName=" + lastName + "&phone=" + phone + "&email=" + email + "&message=" + message + "&contactDate=" + contactDate + "&country=" + country + "&consumptiongas=" + consumptionGas + "&consumptionelectricityvt=" + consumptionElectricityVT + "&consumptionelectricitynt=" + consumptionElectricityNT,
            url = domain + params;

        this.isBusy = true;

        $.ajax({
            dataType: "jsonp",
            jsonpCallback: "callback",
            url: url + "&callback=callback",
            timeout: 10000,
            cache: false,
            success: function (result) {
                this.isBusy = false;
                if (typeof (successCallback) == "function")
                    successCallback(result);
            },
            error: function (result) {
                this.isBusy = false;
                if (typeof (errorCallback) == "function")
                    errorCallback(result);
            }
        });

    }

};