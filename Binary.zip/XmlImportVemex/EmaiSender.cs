﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace XmlImportVemex
{
    public class EmaiSender
    {
        public static bool SendError(string subject, string body)
        {

            CreativeMagesAudit.AddErrorToMessage(subject);
            CreativeMagesAudit.AddErrorToMessage(body);

            return true;

            //try
            //{
            //string date = "<br /><br />Sent: " + DateTime.Now.ToLocalTime().ToString();
            //
            //MailMessage mail = new MailMessage();
            //mail.Subject = subject;
            //mail.Body = body + date;
            //
            //mail.To.Add("petr.vavrousek@creativemages.com");
            //mail.From = new MailAddress("petr.vavrousek@creativemages.com");
            //mail.IsBodyHtml = true;
            //
            //SmtpClient smtp = new SmtpClient();
            //smtp.Host = "pod51014.outlook.com";
            //smtp.Port = 25;
            //smtp.UseDefaultCredentials = true;
            //                                                                                                                                                                                                                smtp.Credentials = new System.Net.NetworkCredential("petr.vavrousek@creativemages.com", "");
            //smtp.EnableSsl = true;
            //
            //
            //    smtp.Send(mail);
            //    return true;
            //}
            //catch
            //{
            //    Logger.WriteLine("E-mail se nepovedlo odeslat, kontaktujte prosím administrátora");
            //    Console.WriteLine("E-mail s chybou se nepovedlo odeslat, kontaktujte prosím administrátora");
            //    return false;
            //}

        }

        //public static bool SendMail(string toEmail, string fromEmail, string fromPassword, string subject, string body)
        //{
        //    try
        //    {
        //    MailMessage mail = new MailMessage();
        //    mail.Subject = subject;
        //    mail.Body = body;
        //
        //    mail.To.Add(toEmail);
        //    mail.From = new MailAddress(fromEmail);
        //    mail.IsBodyHtml = true;
        //
        //    SmtpClient smtp = new SmtpClient();
        //    smtp.Host = "pod51014.outlook.com";
        //    smtp.Port = 25;
        //    smtp.UseDefaultCredentials = true;
        //    smtp.Credentials = new System.Net.NetworkCredential(fromEmail, fromPassword);
        //    smtp.EnableSsl = true;
        //
        //    
        //        smtp.Send(mail);
        //        return true;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //
        //}
    }
}