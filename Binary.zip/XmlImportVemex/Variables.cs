﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
    class Variables
    {
        public static string eanopm = ""; //EAN OPM kod
        public static string eic = ""; // EIC kod 
        public static string contractId = "ExcelImport test";    //cislo navrhu   
        public static string firstName = "";
        public static string lastName = "";
        public static string postalstreet = "";
        public static string street = "";
        public static string takestreet = "";
        public static string companyName = "";

        public static int title1 = enums.titulpred.Default.GetHashCode();      //titul pred jmenem

        public static int title2 = enums.titulza.Default.GetHashCode();    //titul za jmenem
        public static string born = "";         //narozen
        public static string ico = "";
        public static string dic = "";
        
        public static string p1_function = "";
        public static string p1_firstName = "";
        public static string p1_lastName = "";
        
        public static string p2_function = "";
        public static string p2_firstName = "";
        public static string p2_lastName = "";
        
        public static string email = "";
        public static string phoneNumber = "";

        public static string streetNumber1 = "";
        public static string streetNumber2 = "";
        public static string zipcode = "";
        public static string city = "";
        public static string recordOR = "";

        //korespondencni adresa
        public static string postalstreetNumber1 = "";
        public static string postalstreetNumber2 = "";
        public static string postalzipcode = "";
        public static string postalcity = "";

        public static bool fixedtermcontract = false; //smlouva na dobu urcitou
        public static string fromfixedtermcontract = ""; //od 
        public static string tofixedtermcontract = ""; //do
        public static bool fixedtermcontract1 = false;//smlouva na dobu urcitou
        public static int fixedtermcontractyears = enums.fixedtermcontractyears.Default.GetHashCode(); //171 140 000 1.rok 02 - 3.rok 
        public static string fromindefiniteperiodcontract = "";
        public static bool indefiniteperiodcontract = false; //smlouva na dobu neurcitou
        public static string productname = ""; //nazev produktu

        // adresa specifikace odberneho mista
        public static string takestreetNumber1 = "";
        public static string takestreetNumber2 = "";
        public static string takezipcode = "";
        public static string takecity = "";

        public static int contractreason = enums.contractreason.Default.GetHashCode();// duvod uzavreni smlouvy
        public static int distributorelectricity = enums.distributorelectricity.Default.GetHashCode();// distributor elektriny
        public static int distributorgas = enums.distributorgas.Default.GetHashCode();//  distributor plynu

        public static int originaldistributor = -1;//  puvodni dodavatel
        public static string annualconsumptionnt = ""; //Plánovaná roční spotřeba MWh/rok VT
        public static string annualconsumptionvt = ""; //Plánovaná roční spotřeba MWh/rok NT
        public static int distributionrate = enums.distributionrate.Default.GetHashCode();//  //Distribuční sazba
        public static string breakervalue = ""; //Hodnota jističe před elektroměrem
        public static decimal advancepayment = 0m; //Výše zálohy 
        public static int advanceperiod = enums.advanceperiod.Default.GetHashCode();//  //Zálohové období
        public static int connectiontype = enums.connectiontype.Default.GetHashCode();//  //zpusob pripojeni
        public static int informationdelivery = enums.informationdelivery.Default.GetHashCode();//  //Doručení informace o změně ceníku a OP
        public static int paymentscheduledelivery = enums.paymentscheduledelivery.Default.GetHashCode();//  //Doručení platebního kalendáře, faktury
        public static int paymenttype = enums.paymenttype.Default.GetHashCode();//  //Způsob platby faktur
        public static string siponumber = ""; //Spojovací číslo SIPO
        public static int paymenttypeadvances = enums.paymenttypeadvances.Default.GetHashCode();//  //Způsob platby záloh
        public static string accountnumberp1 = ""; //Číslo účtu pro vracení přeplatku část 1.
        public static string accountnumberp2 = ""; //Číslo účtu pro vracení přeplatku část 2.
        public static string bankcode = ""; //Kód banky

        public static bool closedinspaces = false; //ne 0 ano 1 uzavreno mimo prostory obvykle k podnikani

        public static bool customer_resigned = false;//zakaznik podal vypoved sam neni v CRM?
        public static int resignation_length = 0;//vypovedni lhuta
        public static bool resignation_unit = false;//Jednotky vypovedni lhuty
        
        public static string sellerfirstname = "";
        public static string sellerlastname = "";
        public static string sellerid = "";
        public static string resignation = "";
        public static decimal individualprice = 0;
        public static string importnumber = "";
        public static string auctionnumber = "";
        public static string seller_id_auction = "";
        public static bool payment_of_commission = false; //bool 
        public static string reason_of_commission = "";
        public static string supplypoint_number = "";
        public static string capacity_for_day = "";
        public static string billingperiod = "";
        public static string real_consumption = "";

        public static int sex = enums.sex.Default.GetHashCode();
        public static decimal individualpriceNT = 0;//podivat se co se s tim dela u individualpriceVT
        public static decimal stableprice = 0;
        public static int title1P1 = enums.titulpred.Default.GetHashCode();
        public static int title2P1 = enums.titulza.Default.GetHashCode();
        public static int title1P2 = enums.titulpred.Default.GetHashCode();
        public static int title2P2 = enums.titulza.Default.GetHashCode();
        public static int sexP1 = enums.sex.Default.GetHashCode();
        public static int sexP2 = enums.sex.Default.GetHashCode();
        public static string contact_firstName = "";
        public static string contact_lastName = "";
        public static int title1C = enums.titulpred.Default.GetHashCode();
        public static int title2C = enums.titulza.Default.GetHashCode();
        public static int sexC = enums.sex.Default.GetHashCode();
        public static string dateofsignature = "";
        public static string auction_date = "";
        public static string auction_portal_name = "";

        public static string marketing_list = "";

        public static string mefakborn = "";

        public static bool Reset()
        {
                        
            eanopm = ""; //EAN OPM kod
            eic = ""; // EIC kod 
            contractId = "";  //cislo navrhu   
            firstName = "";
            lastName = "";
            postalstreet = "";
            street = "";
            takestreet = "";
            companyName = "";
            title1 = enums.titulpred.Default.GetHashCode();      //titul pred jmenem
            title2 = enums.titulza.Default.GetHashCode();    //titul za jmenem
            born = "";         //narozen
            ico = "";
            dic = "";
            p1_function = "";
            p1_firstName = "";
            p1_lastName = "";
            p2_function = "";
            p2_firstName = "";
            p2_lastName = "";
            email = "";
            phoneNumber = "";
            streetNumber1 = "";
            streetNumber2 = "";
            zipcode = "";
            city = "";
            recordOR = "";
            postalstreetNumber1 = "";
            postalstreetNumber2 = "";
            postalzipcode = "";
            postalcity = "";
            fixedtermcontract = false; //smlouva na dobu urcitou
            fromfixedtermcontract = ""; //od 
            tofixedtermcontract = ""; //do
            fixedtermcontract1 = false;//smlouva na dobu urcitou
            fixedtermcontractyears = enums.fixedtermcontractyears.Default.GetHashCode(); //171 140 000 1.rok 02 - 3.rok 
            fromindefiniteperiodcontract = "";
            indefiniteperiodcontract = false; //smlouva na dobu neurcitou
            productname = ""; //nazev produktu
            takestreetNumber1 = "";
            takestreetNumber2 = "";
            takezipcode = "";
            takecity = "";
            contractreason = enums.contractreason.Default.GetHashCode();// duvod uzavreni smlouvy
            distributorelectricity = enums.distributorelectricity.Default.GetHashCode();// distributor elektriny
            distributorgas = enums.distributorgas.Default.GetHashCode();//  distributor plynu
            originaldistributor = -1;//  puvodni dodavatel
            annualconsumptionnt = "43"; //Plánovaná roční spotřeba MWh/rok VT
            annualconsumptionvt = "66"; //Plánovaná roční spotřeba MWh/rok NT
            distributionrate = enums.distributionrate.Default.GetHashCode();//  //Distribuční sazba
            breakervalue = ""; //Hodnota jističe před elektroměrem
            advancepayment = 0m; //Výše zálohy 
            advanceperiod = enums.advanceperiod.Default.GetHashCode();//  //Zálohové období
            connectiontype = enums.connectiontype.Default.GetHashCode();//  //zpusob pripojeni
            informationdelivery = enums.informationdelivery.Default.GetHashCode();//  //Doručení informace o změně ceníku a OP
            paymentscheduledelivery = enums.paymentscheduledelivery.Default.GetHashCode();//  //Doručení platebního kalendáře, faktury
            paymenttype = enums.paymenttype.Default.GetHashCode();//  //Způsob platby faktur
            siponumber = ""; //Spojovací číslo SIPO
            paymenttypeadvances = enums.paymenttypeadvances.Default.GetHashCode();//  //Způsob platby záloh
            accountnumberp1 = ""; //Číslo účtu pro vracení přeplatku část 1.
            accountnumberp2 = ""; //Číslo účtu pro vracení přeplatku část 2.
            bankcode = ""; //Kód banky
            closedinspaces = false; //ne 0 ano 1 uzavreno mimo prostory obvykle k podnikani
            customer_resigned = false;//zakaznik podal vypoved sam neni v CRM?
            resignation_length = 0;//vypovedni lhuta
            resignation_unit = false;//Jednotky vypovedni lhuty
            sellerfirstname = "";
            sellerlastname = "";
            sellerid = "";
            resignation = "";
            individualprice=0;
            importnumber="";
            auctionnumber="";
            seller_id_auction="";
            payment_of_commission = false; //bool 
            reason_of_commission="";
            supplypoint_number="";
            capacity_for_day="";
            billingperiod="";
            real_consumption="";
            sex = enums.sex.Default.GetHashCode();
            individualpriceNT = 0;//podivat se co se s tim dela u individualpriceVT
            stableprice = 0;
            title1P1 = enums.titulpred.Default.GetHashCode();
            title2P1 = enums.titulza.Default.GetHashCode();
            title1P2 = enums.titulpred.Default.GetHashCode();
            title2P2 = enums.titulza.Default.GetHashCode();
            sexP1 = enums.sex.Default.GetHashCode();
            sexP2 = enums.sex.Default.GetHashCode();
            contact_firstName = "";
            contact_lastName = "";
            title1C = enums.titulpred.Default.GetHashCode();
            title2C = enums.titulza.Default.GetHashCode();
            sexC = enums.sex.Default.GetHashCode();
            dateofsignature = "";
            auction_date = "";
            auction_portal_name = "";
            marketing_list = "";
            mefakborn = "";

            return true;

        }
        public static bool ReduceLenght()
        {
            try
            {

                if (contractId.Length > 49) contractId = contractId.Substring(0, 48);
                if (firstName.Length > 49) firstName = firstName.Substring(0, 48);
                if (lastName.Length > 49) lastName = lastName.Substring(0, 48);
                if (phoneNumber.Length > 49) phoneNumber = phoneNumber.Substring(0, 48);
                if (companyName.Length > 49) companyName = companyName.Substring(0, 48);
                if (p1_firstName.Length > 49) p1_firstName = p1_firstName.Substring(0, 48);
                if (p1_lastName.Length > 49) p1_lastName = p1_lastName.Substring(0, 48);
                if (p1_function.Length > 49) p1_function = p1_function.Substring(0, 48);
                if (p2_firstName.Length > 49) p2_firstName = p2_firstName.Substring(0, 48);
                if (p2_lastName.Length > 49) p2_lastName = p2_lastName.Substring(0, 48);
                if (p2_function.Length > 49) p2_function = p2_function.Substring(0, 48);
                if (email.Length > 49) email = email.Substring(0, 48);
                if (street.Length > 49) street = street.Substring(0, 48);
                if (streetNumber1.Length > 49) streetNumber1 = streetNumber1.Substring(0, 48);
                if (streetNumber2.Length > 49) streetNumber2 = streetNumber2.Substring(0, 48);
                if (zipcode.Length > 49) zipcode = zipcode.Substring(0, 48);
                if (city.Length > 49) city = city.Substring(0, 48);
                if (postalstreet.Length > 49) postalstreet = postalstreet.Substring(0, 48);
                if (postalstreetNumber1.Length > 49) postalstreetNumber1 = postalstreetNumber1.Substring(0, 48);
                if (postalstreetNumber2.Length > 49) postalstreetNumber2 = postalstreetNumber2.Substring(0, 48);
                if (postalzipcode.Length > 49) postalzipcode = postalzipcode.Substring(0, 48);
                if (postalcity.Length > 49) postalcity = postalcity.Substring(0, 48);
                if (productname.Length > 49) productname = productname.Substring(0, 48);
                if (takestreet.Length > 49) takestreet = takestreet.Substring(0, 48);
                if (takestreetNumber1.Length > 49) takestreetNumber1 = takestreetNumber1.Substring(0, 48);
                if (takestreetNumber2.Length > 49) takestreetNumber2 = takestreetNumber2.Substring(0, 48);
                if (takezipcode.Length > 49) takezipcode = takezipcode.Substring(0, 48);
                if (takecity.Length > 49) takecity = takecity.Substring(0, 48);
                if (annualconsumptionvt.Length > 49) annualconsumptionvt = annualconsumptionvt.Substring(0, 48);
                if (annualconsumptionnt.Length > 49) annualconsumptionnt = annualconsumptionnt.Substring(0, 48);
                if (breakervalue.Length > 49) breakervalue = breakervalue.Substring(0, 48);
                if (sellerfirstname.Length > 49) sellerfirstname = sellerfirstname.Substring(0, 48);
                if (sellerlastname.Length > 49) sellerlastname = sellerlastname.Substring(0, 48);
                if (sellerid.Length > 49) sellerid = sellerid.Substring(0, 48);
                if (contact_firstName.Length > 49) contact_firstName = contact_firstName.Substring(0, 48);
                if (contact_lastName.Length > 49) contact_lastName = contact_lastName.Substring(0, 48);
                if (auction_portal_name.Length > 49) auction_portal_name = auction_portal_name.Substring(0, 48);
                if (marketing_list.Length > 49) marketing_list = marketing_list.Substring(0, 48);
                if (mefakborn.Length > 49) mefakborn = mefakborn.Substring(0, 48);

            }
            catch(Exception)
            {
                return false;
            }

            return true;
        }
        public static bool cleanspace()
        {
            contractId = contractId.Trim();
            firstName = firstName.Trim();
            lastName = lastName.Trim();
            phoneNumber = phoneNumber.Trim();
            companyName = companyName.Trim();
            p1_firstName = p1_firstName.Trim();
            p1_lastName = p1_lastName.Trim();
            p1_function = p1_function.Trim();
            p2_firstName = p2_firstName.Trim();
            p2_lastName = p2_lastName.Trim();
            p2_function = p2_function.Trim();
            email = email.Trim();
            street = street.Trim();
            streetNumber1 = streetNumber1.Trim();
            streetNumber2 = streetNumber2.Trim();
            zipcode = zipcode.Trim();
            city = city.Trim();
            postalstreet = postalstreet.Trim();
            postalstreetNumber1 = postalstreetNumber1.Trim();
            postalstreetNumber2 = postalstreetNumber2.Trim();
            postalzipcode = postalzipcode.Trim();
            postalcity = postalcity.Trim();
            productname = productname.Trim();
            takestreet = takestreet.Trim();
            takestreetNumber1 = takestreetNumber1.Trim();
            takestreetNumber2 = takestreetNumber2.Trim();
            takezipcode = takezipcode.Trim();
            takecity = takecity.Trim();
            annualconsumptionvt = annualconsumptionvt.Trim();
            annualconsumptionnt = annualconsumptionnt.Trim();
            breakervalue = breakervalue.Trim();
            sellerfirstname = sellerfirstname.Trim();
            sellerlastname = sellerlastname.Trim();
            sellerid = sellerid.Trim();
            contact_firstName = contact_firstName.Trim();
            contact_lastName = contact_lastName.Trim();
            auction_portal_name = auction_portal_name.Trim();
            marketing_list = marketing_list.Trim();

            mefakborn = mefakborn.Trim();

            return true;
        }
        //string dsd = " fd    fd  fd   ";
        //
        //string dsd1 = dsd.TrimEnd();
        //string dsd2 = dsd.TrimStart();
        //string dsd4 = dsd.Trim();
        //string myString = dsd.Replace(@"\s+", " ");
        //string dsd5 = dsd.Replace("  ", " ");
        //string dsd6 = dsd.Replace("   ", " ");




    }
}
