﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlImportVemex
{
   public  class Convertor
    {

       public  Dictionary<string, int> Dictionar_titulpred;
       public Dictionary<string, int> Dictionar_titulza;
       public Dictionary<string, int> Dictionar_informationdelivery;
       public Dictionary<string, int> Dictionar_sex;
       public Dictionary<string, int> Dictionar_distributorelectricity;
       public Dictionary<string, int> Dictionar_originaldistributor;
       public Dictionary<string, int> Dictionar_paymenttype;
       public Dictionary<string, int> Dictionar_paymenttypeadvances;
       public Dictionary<string, int> Dictionar_connectiontype;
       public Dictionary<string, int> Dictionar_paymentscheduledelivery;
       public Dictionary<string, int> Dictionar_advanceperiod;
       public Dictionary<string, int> Dictionar_distributorgas;
       public Dictionary<string, int> Dictionar_fixedtermcontractyears;
       public Dictionary<string, int> Dictionar_distributionrate;
       public Dictionary<string, int> Dictionar_contractreason;

       public bool InitiliazationSuccess;

       bool UpdateOptionSets()
        {

           this.Dictionar_titulpred = OptionSets.GetSelectOptions("cre_verifyform", "cre_titulpred");

           this.Dictionar_titulza = OptionSets.GetSelectOptions("cre_verifyform", "cre_titulza");
           this.Dictionar_informationdelivery = OptionSets.GetSelectOptions("cre_supplypoint", "cre_informationdelivery");
           this.Dictionar_sex = OptionSets.GetSelectOptions("cre_verifyform", "cre_gendersperson");
           this.Dictionar_distributorelectricity = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributorelectricity");
           this.Dictionar_originaldistributor = OptionSets.GetSelectOptions("cre_supplypoint", "cre_originaldistributor");
           this.Dictionar_paymenttype = OptionSets.GetSelectOptions("cre_supplypoint", "cre_paymenttype");
           this.Dictionar_paymenttypeadvances = OptionSets.GetSelectOptions("cre_supplypoint", "cre_paymenttypeadvances");
           this.Dictionar_connectiontype = OptionSets.GetSelectOptions("cre_supplypoint", "cre_connectiontype");
           this.Dictionar_paymentscheduledelivery = OptionSets.GetSelectOptions("cre_verifyform", "cre_paymentscheduledelivery");
           this.Dictionar_advanceperiod = OptionSets.GetSelectOptions("cre_supplypoint", "cre_advanceperiod");
           this.Dictionar_distributorgas = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributorgas");
           this.Dictionar_fixedtermcontractyears = OptionSets.GetSelectOptions("opportunity", "cre_fixedtermcontractyears");
           this.Dictionar_distributionrate = OptionSets.GetSelectOptions("cre_supplypoint", "cre_distributionrate");
           this.Dictionar_contractreason = OptionSets.GetSelectOptions("cre_supplypoint", "cre_contractreason");

           if (null == this.Dictionar_titulpred) return false;
           if (null == this.Dictionar_titulza) return false;
           if (null == this.Dictionar_informationdelivery) return false;
           if (null == this.Dictionar_sex) return false;
           if (null == this.Dictionar_distributorelectricity) return false;
           if (null == this.Dictionar_originaldistributor) return false;
           if (null == this.Dictionar_paymenttype) return false;
           if (null == this.Dictionar_paymenttypeadvances) return false;
           if (null == this.Dictionar_connectiontype) return false;
           if (null == this.Dictionar_paymentscheduledelivery) return false;
           if (null == this.Dictionar_advanceperiod) return false;
           if (null == this.Dictionar_distributorgas) return false;
           if (null == this.Dictionar_fixedtermcontractyears) return false;
           if (null == this.Dictionar_distributionrate) return false;
           if (null == this.Dictionar_contractreason) return false;
            
            return true;
        }

        public Convertor()
        {
           this.InitiliazationSuccess = UpdateOptionSets();
        }

        //public static int contractoptions(string value)
        //{
        //
        //         if (value == "Určitou") return enums.contractoptions.Urcitou.GetHashCode();
        //    else if (value == "Určitou roky") return enums.contractoptions.Urcitou_roky.GetHashCode();
        //    else if (value == "Neurčitou") return enums.contractoptions.Neurcitou.GetHashCode();
        //    else return enums.contractoptions.Default.GetHashCode();
        //}

        public int titulpred(string title1)
        {
            
            if (title1 == "ak.") return enums.titulpred.ak.GetHashCode();
            else if (title1 == "ak.arch.") return enums.titulpred.akArch.GetHashCode();
            else if (title1 == "ak.mal.") return enums.titulpred.akMal.GetHashCode();
            else if (title1 == "ak.soch.") return enums.titulpred.akSoch.GetHashCode();
            else if (title1 == "arch.") return enums.titulpred.arch.GetHashCode();
            else if (title1 == "Bc.") return enums.titulpred.Bc.GetHashCode();
            else if (title1 == "BcA.") return enums.titulpred.BcA.GetHashCode();
            else if (title1 == "Doc.") return enums.titulpred.Doc.GetHashCode();
            else if (title1 == "Doc.Mgr.et Mgr.") return enums.titulpred.DocMgrEtMgr.GetHashCode();
            else if (title1 == "Doc.Ing.") return enums.titulpred.DocIng.GetHashCode();
            else if (title1 == "Doc.Ing.Dr.") return enums.titulpred.DocIngDr.GetHashCode();
            else if (title1 == "Doc.MUDr.") return enums.titulpred.DocMUDr.GetHashCode();
            else if (title1 == "Doc.PhDr.") return enums.titulpred.DocPhDr.GetHashCode();
            else if (title1 == "Doc.RNDr.") return enums.titulpred.DocRNDr.GetHashCode();
            else if (title1 == "Dr.") return enums.titulpred.Dr.GetHashCode();
            else if (title1 == "Dr.Doc.") return enums.titulpred.DrDoc.GetHashCode();
            else if (title1 == "Dr.Ing.") return enums.titulpred.DrIng.GetHashCode();
            else if (title1 == "Dr.prof.") return enums.titulpred.DrProf.GetHashCode();
            else if (title1 == "ICDr.") return enums.titulpred.ICDr.GetHashCode();
            else if (title1 == "Ing.") return enums.titulpred.Ing.GetHashCode();
            else if (title1 == "Ing.arch.") return enums.titulpred.IngArch.GetHashCode();
            else if (title1 == "Ing.Bc.") return enums.titulpred.IngBc.GetHashCode();
            else if (title1 == "Ing.Mgr.") return enums.titulpred.IngMgr.GetHashCode();
            else if (title1 == "Ing.PhDr.") return enums.titulpred.IngPhDr.GetHashCode();
            else if (title1 == "JUDr.") return enums.titulpred.JUDr.GetHashCode();
            else if (title1 == "JUDr.Mgr.") return enums.titulpred.JUDrMgr.GetHashCode();
            else if (title1 == "JUDr.Ing.") return enums.titulpred.JUDrIng.GetHashCode();
            else if (title1 == "Mag.") return enums.titulpred.Mag.GetHashCode();
            else if (title1 == "MDDr.") return enums.titulpred.MDDr.GetHashCode();
            else if (title1 == "MgA.") return enums.titulpred.MgA.GetHashCode();
            else if (title1 == "Mgr.") return enums.titulpred.Mgr.GetHashCode();
            else if (title1 == "Mgr.Bc.") return enums.titulpred.MgrBc.GetHashCode();
            else if (title1 == "Mgr.et Mgr.Ing.") return enums.titulpred.MgrEtMgrIng.GetHashCode();
            else if (title1 == "MSDr.") return enums.titulpred.MSDr.GetHashCode();
            else if (title1 == "MUC.") return enums.titulpred.MUC.GetHashCode();
            else if (title1 == "MUDr.") return enums.titulpred.MUDr.GetHashCode();
            else if (title1 == "MVDr.") return enums.titulpred.MVDr.GetHashCode();
            else if (title1 == "Nenalezen titul") return enums.titulpred.NenalezenTitul.GetHashCode();
            else if (title1 == "PaedDr.") return enums.titulpred.PaedDr.GetHashCode();
            else if (title1 == "PharmDr.") return enums.titulpred.PharmDr.GetHashCode();
            else if (title1 == "PhDr.") return enums.titulpred.PhDr.GetHashCode();
            else if (title1 == "PhDr.Mgr.") return enums.titulpred.PhDrMgr.GetHashCode();
            else if (title1 == "PhMr.") return enums.titulpred.PhMr.GetHashCode();
            else if (title1 == "pplk.Ing.") return enums.titulpred.pplkIng.GetHashCode();
            else if (title1 == "Prof.") return enums.titulpred.Prof.GetHashCode();
            else if (title1 == "Prof.Dr.") return enums.titulpred.ProfDr.GetHashCode();
            else if (title1 == "Prof.Ing.") return enums.titulpred.ProfIng.GetHashCode();
            else if (title1 == "Prof.MUDr.") return enums.titulpred.ProfMUDr.GetHashCode();
            else if (title1 == "Prof.MUDr.PhMr.Dr.") return enums.titulpred.ProfMUDrPhMrDr.GetHashCode();
            else if (title1 == "Prof.RNDr.") return enums.titulpred.ProfRNDr.GetHashCode();
            else if (title1 == "RCDr.") return enums.titulpred.RCDr.GetHashCode();
            else if (title1 == "RNDr.") return enums.titulpred.RNDr.GetHashCode();
            else if (title1 == "RSDr.") return enums.titulpred.RSDr.GetHashCode();
            else if (title1 == "Th.D.") return enums.titulpred.ThD.GetHashCode();
            else if (title1 == "ThDr.") return enums.titulpred.ThDr.GetHashCode();
            else if (title1 == "ThLic.") return enums.titulpred.ThLic.GetHashCode();
            else if (title1 == "ThMgr.") return enums.titulpred.ThMgr.GetHashCode();
            //else return enums.titulpred.Default.GetHashCode();

            else if (title1 == "ak. arch.") return enums.titulpred.akArch.GetHashCode();
            else if (title1 == "ak. mal.") return enums.titulpred.akMal.GetHashCode();
            else if (title1 == "ak. soch.") return enums.titulpred.akSoch.GetHashCode();
            else if (title1 == "arch.") return enums.titulpred.arch.GetHashCode();
            else if (title1 == "Bc.") return enums.titulpred.Bc.GetHashCode();
            else if (title1 == "BcA.") return enums.titulpred.BcA.GetHashCode();
            else if (title1 == "Doc.") return enums.titulpred.Doc.GetHashCode();
            else if (title1 == "Doc. Mgr. et Mgr.") return enums.titulpred.DocMgrEtMgr.GetHashCode();
            else if (title1 == "Doc. Ing.") return enums.titulpred.DocIng.GetHashCode();
            else if (title1 == "Doc. Ing. Dr.") return enums.titulpred.DocIngDr.GetHashCode();
            else if (title1 == "Doc. MUDr.") return enums.titulpred.DocMUDr.GetHashCode();
            else if (title1 == "Doc. PhDr.") return enums.titulpred.DocPhDr.GetHashCode();
            else if (title1 == "Doc. RNDr.") return enums.titulpred.DocRNDr.GetHashCode();
            else if (title1 == "Dr.") return enums.titulpred.Dr.GetHashCode();
            else if (title1 == "Dr. Doc.") return enums.titulpred.DrDoc.GetHashCode();
            else if (title1 == "Dr. Ing.") return enums.titulpred.DrIng.GetHashCode();
            else if (title1 == "Dr. prof.") return enums.titulpred.DrProf.GetHashCode();
            else if (title1 == "ICDr.") return enums.titulpred.ICDr.GetHashCode();
            else if (title1 == "Ing.") return enums.titulpred.Ing.GetHashCode();
            else if (title1 == "Ing. arch.") return enums.titulpred.IngArch.GetHashCode();
            else if (title1 == "Ing. Bc.") return enums.titulpred.IngBc.GetHashCode();
            else if (title1 == "Ing. Mgr.") return enums.titulpred.IngMgr.GetHashCode();
            else if (title1 == "Ing. PhDr.") return enums.titulpred.IngPhDr.GetHashCode();
            else if (title1 == "JUDr.") return enums.titulpred.JUDr.GetHashCode();
            else if (title1 == "JUDr. Mgr.") return enums.titulpred.JUDrMgr.GetHashCode();
            else if (title1 == "JUDr. Ing.") return enums.titulpred.JUDrIng.GetHashCode();
            else if (title1 == "Mag.") return enums.titulpred.Mag.GetHashCode();
            else if (title1 == "MDDr.") return enums.titulpred.MDDr.GetHashCode();
            else if (title1 == "MgA.") return enums.titulpred.MgA.GetHashCode();
            else if (title1 == "Mgr.") return enums.titulpred.Mgr.GetHashCode();
            else if (title1 == "Mgr. Bc.") return enums.titulpred.MgrBc.GetHashCode();
            else if (title1 == "Mgr. et Mgr. Ing.") return enums.titulpred.MgrEtMgrIng.GetHashCode();
            else if (title1 == "MSDr.") return enums.titulpred.MSDr.GetHashCode();
            else if (title1 == "MUC.") return enums.titulpred.MUC.GetHashCode();
            else if (title1 == "MUDr.") return enums.titulpred.MUDr.GetHashCode();
            else if (title1 == "MVDr.") return enums.titulpred.MVDr.GetHashCode();
            else if (title1 == "Nenalezen titul") return enums.titulpred.NenalezenTitul.GetHashCode();
            else if (title1 == "PaedDr.") return enums.titulpred.PaedDr.GetHashCode();
            else if (title1 == "PharmDr.") return enums.titulpred.PharmDr.GetHashCode();
            else if (title1 == "PhDr.") return enums.titulpred.PhDr.GetHashCode();
            else if (title1 == "PhDr. Mgr.") return enums.titulpred.PhDrMgr.GetHashCode();
            else if (title1 == "PhMr.") return enums.titulpred.PhMr.GetHashCode();
            else if (title1 == "pplk. Ing.") return enums.titulpred.pplkIng.GetHashCode();
            else if (title1 == "Prof.") return enums.titulpred.Prof.GetHashCode();
            else if (title1 == "Prof. Dr.") return enums.titulpred.ProfDr.GetHashCode();
            else if (title1 == "Prof. Ing.") return enums.titulpred.ProfIng.GetHashCode();
            else if (title1 == "Prof. MUDr.") return enums.titulpred.ProfMUDr.GetHashCode();
            else if (title1 == "Prof. MUDr. PhMr. Dr.") return enums.titulpred.ProfMUDrPhMrDr.GetHashCode();
            else if (title1 == "Prof. RNDr.") return enums.titulpred.ProfRNDr.GetHashCode();
            else if (title1 == "RCDr.") return enums.titulpred.RCDr.GetHashCode();
            else if (title1 == "RNDr.") return enums.titulpred.RNDr.GetHashCode();
            else if (title1 == "RSDr.") return enums.titulpred.RSDr.GetHashCode();
            else if (title1 == "Th.D.") return enums.titulpred.ThD.GetHashCode();
            else if (title1 == "ThDr.") return enums.titulpred.ThDr.GetHashCode();
            else if (title1 == "ThLic.") return enums.titulpred.ThLic.GetHashCode();
            else if (title1 == "ThMgr.") return enums.titulpred.ThMgr.GetHashCode();
            
            else if (title1 == "MVDr. Ing.") return enums.titulpred.MVDrIng.GetHashCode();
            else if (title1 == "MVDr.Ing.") return enums.titulpred.MVDrIng.GetHashCode();

            title1 = title1.Replace(". ", ".");
            if (Dictionar_titulpred.ContainsKey(title1)) return Dictionar_titulpred[title1];

            title1 = title1.Replace(".", ". ");
            if (title1.Length>0) if (title1[title1.Length - 1] == ' ') title1 = title1.Remove(title1.Length - 1);

            if (Dictionar_titulpred.ContainsKey(title1)) return Dictionar_titulpred[title1];

            if (title1.Length > 0)
            {
                return enums.titulpred.NenalezenTitul.GetHashCode();
            }

            else return enums.titulpred.Default.GetHashCode();

        }

        public int titulza(string value)
        {

                 if (value == "CSc.") return enums.titulza.CSc.GetHashCode();
            else if (value == "Dipl. arch.") return enums.titulza.DiplArch.GetHashCode();
            else if (value == "Dipl. ekon.") return enums.titulza.DiplEkon.GetHashCode();
            else if (value == "Dipl. geol.") return enums.titulza.DiplGeol.GetHashCode();
            else if (value == "Dipl. ing.") return enums.titulza.DiplIng.GetHashCode();
            else if (value == "Dipl. tech.") return enums.titulza.DiplTech.GetHashCode();
            else if (value == "Dipl. theol.") return enums.titulza.DiplTheol.GetHashCode();
            else if (value == "DiS.") return enums.titulza.DiS.GetHashCode();
            else if (value == "DrSc.") return enums.titulza.DrSc.GetHashCode();
            else if (value == "LL. M") return enums.titulza.LLM.GetHashCode();
            else if (value == "M. A.") return enums.titulza.MA.GetHashCode();
            else if (value == "M. D.") return enums.titulza.MD.GetHashCode();
            else if (value == "M. S.") return enums.titulza.MS.GetHashCode();
            else if (value == "MBA") return enums.titulza.MBA.GetHashCode();
            else if (value == "MSc") return enums.titulza.MSc.GetHashCode();
            else if (value == "Ph. D.") return enums.titulza.PhD.GetHashCode();


            else if (value == "Dipl.arch.") return enums.titulza.DiplArch.GetHashCode();
            else if (value == "Dipl.ekon.") return enums.titulza.DiplEkon.GetHashCode();
            else if (value == "Dipl.geol.") return enums.titulza.DiplGeol.GetHashCode();
            else if (value == "Dipl.ing.") return enums.titulza.DiplIng.GetHashCode();
            else if (value == "Dipl.tech.") return enums.titulza.DiplTech.GetHashCode();
            else if (value == "Dipl.theol.") return enums.titulza.DiplTheol.GetHashCode();
            else if (value == "DiS.") return enums.titulza.DiS.GetHashCode();
            else if (value == "DrSc.") return enums.titulza.DrSc.GetHashCode();
            else if (value == "LL.M") return enums.titulza.LLM.GetHashCode();
            else if (value == "M.A.") return enums.titulza.MA.GetHashCode();
            else if (value == "M.D.") return enums.titulza.MD.GetHashCode();
            else if (value == "M.S.") return enums.titulza.MS.GetHashCode();
            else if (value == "MBA") return enums.titulza.MBA.GetHashCode();
            else if (value == "MSc") return enums.titulza.MSc.GetHashCode();
            else if (value == "Ph.D.") return enums.titulza.PhD.GetHashCode();

            else if (value == "Titul není obsažen v databázi") return enums.titulza.TitulNenalezen.GetHashCode();
            else if (Dictionar_titulza.ContainsKey(value)) return Dictionar_titulza[value];

            value = value.Replace(". ", ".");
            if (Dictionar_titulza.ContainsKey(value)) return Dictionar_titulza[value];

            value = value.Replace(".", ". ");
            if (value.Length > 0) if (value[value.Length - 1] == ' ') value = value.Remove(value.Length - 1);

            if (Dictionar_titulza.ContainsKey(value)) return Dictionar_titulza[value];

            
            if (value.Length>0) return enums.titulza.TitulNenalezen.GetHashCode();
            else return enums.titulza.Default.GetHashCode();

        }

        public int informationdelivery(string value)
        {

                 if (value == "e-mailem") return enums.informationdelivery.emailem.GetHashCode();
            else if (value == "poštou") return enums.informationdelivery.postou.GetHashCode(); 
            else if (value == "web") return enums.informationdelivery.web.GetHashCode();

            else return enums.informationdelivery.Default.GetHashCode();

        }

        public int sex(string value)
        {

            if (value == "muž") return enums.sex.muz.GetHashCode();
            else if (value == "žena") return enums.sex.zena.GetHashCode();
            else return enums.sex.Default.GetHashCode();

        }

        public int distributorelectricity(string value)
        {   

                 if (value == "ČEZ Distribuce") return enums.distributorelectricity.CEZ_Distribuce.GetHashCode();
            else if (value == "EON Distribuce") return enums.distributorelectricity.EON_Distribuce.GetHashCode();
            else if (value == "PRE Distribuce") return enums.distributorelectricity.PRE_Distribuce.GetHashCode();
            else if (value == "SV servisní") return enums.distributorelectricity.SV_servisni.GetHashCode();

            else if (value == "ČEZ Distribuce a.s.") return enums.distributorelectricity.CEZ_Distribuce.GetHashCode();
            else if (value == "EON Distribuce a.s.") return enums.distributorelectricity.EON_Distribuce.GetHashCode();
            else if (value == "PRE Distribuce a.s.") return enums.distributorelectricity.PRE_Distribuce.GetHashCode();
            else if (value == "SV servisní s.r.o.") return enums.distributorelectricity.SV_servisni.GetHashCode();

            else if (value == "Energy Ústí nad Labem, a.s.") return enums.distributorelectricity.Energy_Usti_nad_Labem.GetHashCode();
            else if (value == "Petr Hurta licence č. 220102855") return enums.distributorelectricity.Petr_Hurta.GetHashCode();
            else if (value == "QUANTUM, a.s.") return enums.distributorelectricity.QUANTUM.GetHashCode();
            else if (value == "VLČEK Josef – elektro s.r.o.") return enums.distributorelectricity.VLCEK_Josef.GetHashCode();

            else if (value == "Energy Ústí nad Labem") return enums.distributorelectricity.Energy_Usti_nad_Labem.GetHashCode();
            else if (value == "Petr Hurta licence č. 220102855") return enums.distributorelectricity.Petr_Hurta.GetHashCode();
            else if (value == "QUANTUM") return enums.distributorelectricity.QUANTUM.GetHashCode();
            else if (value == "VLČEK Josef – elektro") return enums.distributorelectricity.VLCEK_Josef.GetHashCode();

            else if (Dictionar_distributorelectricity.ContainsKey(value)) return Dictionar_distributorelectricity[value];
            else return enums.distributorelectricity.Default.GetHashCode();

         }

        public int originaldistributor(string value)
         {   
    
            if (value == "AKCENTA ENERGIE") return enums.originaldistributor.AKCENTA_ENERGIE.GetHashCode();
            else if (value == "ALPIQ ENERGY SE") return enums.originaldistributor.ALPIQ_ENERGY_SE.GetHashCode();
            else if (value == "Amper Market") return enums.originaldistributor.Amper_Market.GetHashCode();
            else if (value == "AKCENTA ENERGIE a.s.") return enums.originaldistributor.AKCENTA_ENERGIE.GetHashCode();
            else if (value == "Amper Market, a.s.") return enums.originaldistributor.Amper_Market.GetHashCode();
            else if (value == "Armex Energy") return enums.originaldistributor.ArmexEnergy.GetHashCode();
            else if (value == "ARMEX ENERGY, a.s.") return enums.originaldistributor.ArmexEnergy.GetHashCode();
            else if (value == "Bicorn") return enums.originaldistributor.Bicorn.GetHashCode();
            else if (value == "BICORN s.r.o.") return enums.originaldistributor.Bicorn.GetHashCode();
            else if (value == "Bohemia Energy Entity") return enums.originaldistributor.BohemiaEnergy.GetHashCode();
            else if (value == "BOHEMIA ENERGY entity s.r.o.") return enums.originaldistributor.BohemiaEnergy.GetHashCode();
            else if (value == "Central Energy") return enums.originaldistributor.Central_Energy.GetHashCode();
            else if (value == "Centropol") return enums.originaldistributor.Centropol.GetHashCode();
            else if (value == "CENTROPOL ENERGY, a.s.") return enums.originaldistributor.Centropol.GetHashCode();
            else if (value == "COMFORT ENERGY") return enums.originaldistributor.COMFORT_ENERGY.GetHashCode();
            else if (value == "COMFORT ENERGY s.r.o.") return enums.originaldistributor.COMFORT_ENERGY.GetHashCode();
            else if (value == "CORASTA") return enums.originaldistributor.CORASTA.GetHashCode();
            else if (value == "CORASTA s.r.o.") return enums.originaldistributor.CORASTA.GetHashCode();
            else if (value == "Czech Coal ") return enums.originaldistributor.Czech_Coal.GetHashCode();
            else if (value == "Czech Coal a.s.") return enums.originaldistributor.Czech_Coal.GetHashCode();
            else if (value == "Česká energie") return enums.originaldistributor.Ceska_energie.GetHashCode();
            else if (value == "Česká energie, a.s.") return enums.originaldistributor.Ceska_energie.GetHashCode();
            else if (value == "České energetické centrum") return enums.originaldistributor.CeskeEnergetickeCentrum.GetHashCode();
            else if (value == "České Energetické Centrum a.s.") return enums.originaldistributor.CeskeEnergetickeCentrum.GetHashCode();
            else if (value == "České Energetické Centrum Jih") return enums.originaldistributor.Ceske_Energeticke_Centrum_Jih.GetHashCode();
            else if (value == "České Energetické Centrum Jih s.r.o.") return enums.originaldistributor.Ceske_Energeticke_Centrum_Jih.GetHashCode();
            else if (value == "ČEZ") return enums.originaldistributor.CEZ.GetHashCode();
            else if (value == "ČEZ Prodej, s.r.o.") return enums.originaldistributor.CEZ.GetHashCode();
            else if (value == "ČEZ, a.s.") return enums.originaldistributor.CEZ.GetHashCode();
            else if (value == "Dalkia Commodities CZ") return enums.originaldistributor.Dalkia_Commodities_CZ.GetHashCode();
            else if (value == "Dalkia Commodities CZ, s.r.o.") return enums.originaldistributor.Dalkia_Commodities_CZ.GetHashCode();
            else if (value == "Dalkia Česká republika") return enums.originaldistributor.Dalkia_Ceska_republika.GetHashCode();
            else if (value == "Dalkia Česká republika, a.s.") return enums.originaldistributor.Dalkia_Ceska_republika.GetHashCode();
            else if (value == "E.ON") return enums.originaldistributor.EON.GetHashCode();
            else if (value == "E.ON Energie, a.s.") return enums.originaldistributor.EON.GetHashCode();
            else if (value == "Elimon") return enums.originaldistributor.Elimon.GetHashCode();
            else if (value == "ELIMON a.s.") return enums.originaldistributor.Elimon.GetHashCode();
            else if (value == "Eneka") return enums.originaldistributor.Eneka.GetHashCode();
            else if (value == "Eneka s.r.o.") return enums.originaldistributor.Eneka.GetHashCode();
            else if (value == "Energie 2") return enums.originaldistributor.Energie_2.GetHashCode();
            else if (value == "Energie2, a.s.") return enums.originaldistributor.Energie_2.GetHashCode();
            else if (value == "ENERGO LaR") return enums.originaldistributor.ENERGO_LaR.GetHashCode();
            else if (value == "ENERGO LaR s.r.o.") return enums.originaldistributor.ENERGO_LaR.GetHashCode();
            else if (value == "ENRA SERVICES") return enums.originaldistributor.ENRA_SERVICES.GetHashCode();
            else if (value == "EP Energy Traiding") return enums.originaldistributor.EP_Energy_Traiding.GetHashCode();
            else if (value == "Europe Easy Energy") return enums.originaldistributor.EuropeEasyEnergy.GetHashCode();
            else if (value == "Europe Easy Energy a.s.") return enums.originaldistributor.EuropeEasyEnergy.GetHashCode();
            else if (value == "Gas International") return enums.originaldistributor.GasInternational.GetHashCode();
            else if (value == "Global Energy") return enums.originaldistributor.GlobalEnergy.GetHashCode();
            else if (value == "GLOBAL ENERGY, a.s.") return enums.originaldistributor.GlobalEnergy.GetHashCode();
            else if (value == "HALIMEDES") return enums.originaldistributor.HALIMEDES.GetHashCode();
            else if (value == "Jihomoravská plynárenská, a.s.") return enums.originaldistributor.RWEJMP.GetHashCode();
            else if (value == "KORLEA INVEST") return enums.originaldistributor.KORLEA_INVEST.GetHashCode();
            else if (value == "KORLEA INVEST, a.s., organizační složka") return enums.originaldistributor.KORLEA_INVEST.GetHashCode();
            else if (value == "Lama Energy") return enums.originaldistributor.LamaEnergy.GetHashCode();
            else if (value == "LAMA energy a.s.") return enums.originaldistributor.LamaEnergy.GetHashCode();
            else if (value == "Lumen") return enums.originaldistributor.Lumen.GetHashCode();
            else if (value == "Lumen Energy a.s.") return enums.originaldistributor.Lumen.GetHashCode();
            else if (value == "Lumius") return enums.originaldistributor.Lumius.GetHashCode();
            else if (value == "Lumius, spol. s r.o.") return enums.originaldistributor.Lumius.GetHashCode();
            else if (value == "Nano Energies") return enums.originaldistributor.NanoEnergies.GetHashCode();
            else if (value == "Nano Energies Trade s.r.o.") return enums.originaldistributor.NanoEnergies.GetHashCode();
            else if (value == "Optim Trade") return enums.originaldistributor.Optim_Trade.GetHashCode();
            else if (value == "Optim Trade s.r.o.") return enums.originaldistributor.Optim_Trade.GetHashCode();
            else if (value == "Optimum Energy") return enums.originaldistributor.OptimumEnergy.GetHashCode();
            else if (value == "Optimum Energy, s.r.o.") return enums.originaldistributor.OptimumEnergy.GetHashCode();
            else if (value == "Pragoplyn") return enums.originaldistributor.Pragoplyn.GetHashCode();
            else if (value == "Pragoplyn, a.s.") return enums.originaldistributor.Pragoplyn.GetHashCode();
            else if (value == "Pražská Energetika") return enums.originaldistributor.PrazskaEnergetika.GetHashCode();
            else if (value == "Pražská energetika, a.s.") return enums.originaldistributor.PrazskaEnergetika.GetHashCode();
            else if (value == "Pražská plynárenská") return enums.originaldistributor.PrazskaPlynarenska.GetHashCode();
            else if (value == "Pražská plynárenská, a.s.") return enums.originaldistributor.PrazskaPlynarenska.GetHashCode();
            else if (value == "Quantum") return enums.originaldistributor.Quantum.GetHashCode();
            else if (value == "RWE") return enums.originaldistributor.RWE.GetHashCode();
            else if (value == "RWE Energie, a.s.") return enums.originaldistributor.RWE.GetHashCode();
            else if (value == "RWE JMP") return enums.originaldistributor.RWEJMP.GetHashCode();
            else if (value == "RWE Key Account CZ") return enums.originaldistributor.RWE_Key_Account_CZ.GetHashCode();
            else if (value == "RWE Key Account CZ, s.r.o.") return enums.originaldistributor.RWE_Key_Account_CZ.GetHashCode();
            else if (value == "RWE SMP") return enums.originaldistributor.RWESMP.GetHashCode();
            else if (value == "RWE VČP") return enums.originaldistributor.RWEVCP.GetHashCode();
            else if (value == "Severomoravská plynárenská, a.s.") return enums.originaldistributor.RWESMP.GetHashCode();
            else if (value == "Slovenské elektrárne") return enums.originaldistributor.Slovenske_elektrarne.GetHashCode();
            else if (value == "Slovenské elektrárne, a.s., organizační složka") return enums.originaldistributor.Slovenske_elektrarne.GetHashCode();
            else if (value == "SPP CZ") return enums.originaldistributor.SPPCZ.GetHashCode();
            else if (value == "St. Energy") return enums.originaldistributor.StEnergy.GetHashCode();
            else if (value == "SVT Group") return enums.originaldistributor.SVT_Group.GetHashCode();
            else if (value == "SVT Group, a.s.") return enums.originaldistributor.SVT_Group.GetHashCode();
            else if (value == "United Energy Trading") return enums.originaldistributor.United_Energy_Trading.GetHashCode();
            else if (value == "United Energy Trading, a.s.") return enums.originaldistributor.United_Energy_Trading.GetHashCode();
            else if (value == "V-Elektra") return enums.originaldistributor.V_Elektra.GetHashCode();
            else if (value == "V-Elektra, s.r.o.") return enums.originaldistributor.V_Elektra.GetHashCode();
            else if (value == "VEMEX Energie") return enums.originaldistributor.VEMEX_Energie.GetHashCode();
            else if (value == "VEMEX Energie a.s.") return enums.originaldistributor.VEMEX_Energie.GetHashCode();
            else if (value == "Východočeská plynárenská, a.s.") return enums.originaldistributor.RWEVCP.GetHashCode();
            else if (value == "X Energie, s.r.o.") return enums.originaldistributor.XEnergie.GetHashCode();
            else if (value == "X-Energie") return enums.originaldistributor.XEnergie.GetHashCode();
            else if (value == "Západomoravská energetická s.r.o.") return enums.originaldistributor.Zapadomoravska_energeticka.GetHashCode();            
            else if (value == "Západomoravská energetická") return enums.originaldistributor.Zapadomoravska_energeticka.GetHashCode();

            else if (value == "FONERGY") return enums.originaldistributor.FONERGY.GetHashCode();
            else if (value == "FONERGY s.r.o.") return enums.originaldistributor.FONERGY.GetHashCode();

            else if (Dictionar_originaldistributor.ContainsKey(value)) return Dictionar_originaldistributor[value];
            else return enums.originaldistributor.Default.GetHashCode();

         }

        public int paymenttype(string value)
         {

                  if (value == "Bankovní převod") return enums.paymenttype.Prevodem_z_uctu.GetHashCode();
             else if (value == "Inkaso") return enums.paymenttype.Inkasem.GetHashCode();
             else if (value == "Složenkou") return enums.paymenttype.Slozenkou.GetHashCode();
            //Mefak format
             else if (value == "PlatebniPrikaz") return enums.paymenttype.Prevodem_z_uctu.GetHashCode();
             else if (value == "Slozenka") return enums.paymenttype.Slozenkou.GetHashCode();
             else if (Dictionar_paymenttype.ContainsKey(value)) return Dictionar_paymenttype[value];
             
                      
             //else return (int)enums.paymenttype.Default;
             else return enums.paymenttype.Default.GetHashCode();

         }

        public int paymenttypeadvances(string value)
        {

                if (value == "Bankovní převod") return enums.paymenttypeadvances.PrevodemZUctu.GetHashCode();
                else if (value == "Inkaso") return enums.paymenttypeadvances.Inkasem.GetHashCode();
                else if (value == "Složenkou") return enums.paymenttypeadvances.Slozenkou.GetHashCode();
                else if (value == "SIPO") return enums.paymenttypeadvances.SIPO.GetHashCode();
                    //Mefak
                else if (value == "PlatebniPrikaz") return enums.paymenttypeadvances.PrevodemZUctu.GetHashCode();
                else if (value == "Inkaso") return enums.paymenttypeadvances.Inkasem.GetHashCode();
                else if (value == "Slozenka") return enums.paymenttypeadvances.Slozenkou.GetHashCode();
                else if (Dictionar_paymenttypeadvances.ContainsKey(value)) return Dictionar_paymenttypeadvances[value];
            else return enums.paymenttypeadvances.Default.GetHashCode();

        }

        public int connectiontype(string value)
        {   
    
                 if (value == "Jednofázově") return enums.connectiontype.Jednofazove.GetHashCode();
            else if (value == "Třífázově") return enums.connectiontype.Trifazove.GetHashCode();
            else if (value == "1x") return enums.connectiontype.Jednofazove.GetHashCode();
            else if (value == "3x") return enums.connectiontype.Trifazove.GetHashCode();
            else if (value == "1") return enums.connectiontype.Jednofazove.GetHashCode();
            else if (value == "3") return enums.connectiontype.Trifazove.GetHashCode();
                     //Mefak
                 else if (value == "jednofázové") return enums.connectiontype.Jednofazove.GetHashCode();
                 else if (value == "třífázové") return enums.connectiontype.Trifazove.GetHashCode();
            else return enums.connectiontype.Default.GetHashCode();

        }

        public int paymentscheduledelivery(string value)
        {   
    
            if (value == "e-mailem") return enums.paymentscheduledelivery.emailem.GetHashCode();
            else if (value == "poštou") return enums.paymentscheduledelivery.postou.GetHashCode();
            else return enums.paymentscheduledelivery.Default.GetHashCode();

         }

        public int advanceperiod(string value)
         {

                  if (value == "Měsíční") return enums.advanceperiod.Mesicne.GetHashCode();
            else if (value == "Čtvrtletní") return enums.advanceperiod.Ctvrtletne.GetHashCode();
            else if (value == "Měsíčně") return enums.advanceperiod.Mesicne.GetHashCode();
            else if (value == "Čtvrtletně") return enums.advanceperiod.Ctvrtletne.GetHashCode();
            else if (value == "Žádné") return enums.advanceperiod.Zadne.GetHashCode();//žadné
            else if (Dictionar_advanceperiod.ContainsKey(value)) return Dictionar_advanceperiod[value];
            else return enums.advanceperiod.Default.GetHashCode();

         }

        //public static enums.afterverificationdesc afterverificationdesc(string value)
         //{   
         //
         //        if (value == "Změna dodavatele") return enums.afterverificationdesc.ZmenaDodavatele.GetHashCode();
         //   else if (value == "Přepis se ZD") return enums.afterverificationdesc.PrepisSeZD.GetHashCode();
         //   else if (value == "Nový odběr") return enums.afterverificationdesc.NovyOdber.GetHashCode();
         //   else if (value == "Změna dodavatele (změna ceny)") return enums.afterverificationdesc.ZmenaDodavateleZmenaCeny.GetHashCode();
         //   else if (value == "Přepis v rámci VEMEX Energie") return enums.afterverificationdesc.PrepisVRamciVEMEXEnergie.GetHashCode();
         //   else if (value == "Změna produktu") return enums.afterverificationdesc.ZmenaProduktu.GetHashCode();
         //   else return enums.afterverificationdesc.Default.GetHashCode();
         //
         //}

        public int distributorgas(string value)
         {   
    
            if (value == "RWE GasNet") return enums.distributorgas.RWEGasNet.GetHashCode();
            else if (value == "E.ON Distribuce") return enums.distributorgas.EONDistribuce.GetHashCode();
            else if (value == "JMP Net") return enums.distributorgas.JMPNet.GetHashCode();
            else if (value == "SMP Net") return enums.distributorgas.SMPNet.GetHashCode();
            else if (value == "VČP Net") return enums.distributorgas.VČPNet.GetHashCode();
            else if (value == "Pražská plynárenská Distribuce") return enums.distributorgas.PrazskaPlynarenskaDistribuce.GetHashCode();

            else if (value == "RWE GasNet s.r.o.") return enums.distributorgas.RWEGasNet.GetHashCode();
            else if (value == "E.ON Distribuce a.s.") return enums.distributorgas.EONDistribuce.GetHashCode();
            else if (value == "JMP Net s.r.o.") return enums.distributorgas.JMPNet.GetHashCode();
            else if (value == "SMP Net s.r.o.") return enums.distributorgas.SMPNet.GetHashCode();
            else if (value == "VČP Net s.r.o.") return enums.distributorgas.VČPNet.GetHashCode();
            else if (value == "Pražská plynárenská Distribuce a.s.") return enums.distributorgas.PrazskaPlynarenskaDistribuce.GetHashCode();
            //else if (value == "Energy Ústí nad Labem, a.s.") return enums.distributorgas.EnergyUstiNadLabemAS.GetHashCode();
            //else if (value == "Petr Hurta licence č. 220102855") return enums.distributorgas.PetrHurtaLicenceC220102855.GetHashCode();
            //else if (value == "QUANTUM, a.s.") return enums.distributorgas.QUANTUMAS.GetHashCode();
            //else if (value == "VLČEK Josef – elektro s.r.o.") return enums.distributorgas.VLCEKJosefElektroSRO.GetHashCode();
            else if (Dictionar_distributorgas.ContainsKey(value)) return Dictionar_distributorgas[value];
            else return enums.distributorgas.Default.GetHashCode();

        }

        //public static enums.aftervalidationdesc aftervalidationdesc(string value)
        //{   
        //
        //    if (value == "Změna dodavatele") return enums.aftervalidationdesc.ZmenaDodavatele.GetHashCode();
        //    else if (value == "Přepis se ZD") return enums.aftervalidationdesc.PrepisSeZD.GetHashCode();
        //    else if (value == "Nový odběr") return enums.aftervalidationdesc.NovyOdber.GetHashCode();
        //    else if (value == "Změna dodavatele (změna ceny)") return enums.aftervalidationdesc.ZmenaDodavateleZmenaCeny.GetHashCode();
        //    else if (value == "Přepis v rámci VEMEX Energie") return enums.aftervalidationdesc.PrepisVramciVEMEXEnergie.GetHashCode();
        //    else return enums.aftervalidationdesc.Default.GetHashCode();
        //
        //}

        public int fixedtermcontractyears(string value)
        {

                 if (value == "1. Rok") return enums.fixedtermcontractyears.Rok1.GetHashCode();
            else if (value == "2. Roky") return enums.fixedtermcontractyears.Roky2.GetHashCode();
            else if (value == "3. Roky") return enums.fixedtermcontractyears.Roky3.GetHashCode();
            else if (value == "5. Let") return enums.fixedtermcontractyears.Roky5.GetHashCode();
            else if (value == "1") return enums.fixedtermcontractyears.Rok1.GetHashCode();
            else if (value == "2") return enums.fixedtermcontractyears.Roky2.GetHashCode();
            else if (value == "3") return enums.fixedtermcontractyears.Roky3.GetHashCode();
            else if (value == "5") return enums.fixedtermcontractyears.Roky5.GetHashCode();
            else return enums.fixedtermcontractyears.Default.GetHashCode();

        }

        public int distributionrate(string value)
        {   
    
                 if (value == "C01d") return enums.distributionrate.C01d.GetHashCode();
            else if (value == "C02d") return enums.distributionrate.C02d.GetHashCode();
            else if (value == "C03d") return enums.distributionrate.C03d.GetHashCode();
            else if (value == "C25d") return enums.distributionrate.C25d.GetHashCode();
            else if (value == "C26d") return enums.distributionrate.C26d.GetHashCode();
            else if (value == "C35d") return enums.distributionrate.C35d.GetHashCode();
            else if (value == "C45d") return enums.distributionrate.C45d.GetHashCode();
            else if (value == "C55d") return enums.distributionrate.C55d.GetHashCode();
            else if (value == "C56d") return enums.distributionrate.C56d.GetHashCode();
            else if (value == "C62d") return enums.distributionrate.C62d.GetHashCode();
            else if (value == "D01d") return enums.distributionrate.D01d.GetHashCode();
            else if (value == "D02d") return enums.distributionrate.D02d.GetHashCode();
            else if (value == "D25d") return enums.distributionrate.D25d.GetHashCode();
            else if (value == "D26d") return enums.distributionrate.D26d.GetHashCode();
            else if (value == "D35d") return enums.distributionrate.D35d.GetHashCode();
            else if (value == "D45d") return enums.distributionrate.D45d.GetHashCode();
            else if (value == "D55d") return enums.distributionrate.D55d.GetHashCode();
            else if (value == "D56d") return enums.distributionrate.D56d.GetHashCode();
            else if (Dictionar_distributionrate.ContainsKey(value)) return Dictionar_distributionrate[value];
            return enums.distributionrate.Default.GetHashCode();

        }

        public int contractreason(string value)
        {

            if (value == "Změna dodavatele") return enums.contractreason.ZmenaDodavatele.GetHashCode();
            else if (value == "Přepis se ZD") return enums.contractreason.PrepisSeZD.GetHashCode();
            else if (value == "Nový odběr") return enums.contractreason.NovyOdber.GetHashCode();
            else if (value == "Změna dodavatele (změna ceny)") return enums.contractreason.ZmenaDodavateleZmenaCeny.GetHashCode();
            else if (value == "Přepis v rámci VEMEX Energie") return enums.contractreason.PrepisVRamciVEMEXEnergie.GetHashCode();
            else if (value == "Změna produktu") return enums.contractreason.ZmenaProduktu.GetHashCode();
            else if (Dictionar_contractreason.ContainsKey(value)) return Dictionar_contractreason[value];
            else return enums.contractreason.Default.GetHashCode();

        }

    }
}



