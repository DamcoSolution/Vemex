﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace XmlImportVemex
{
    class Opportunity
    {
       
        static string logicalName = "";
        static Guid contactId = Guid.Empty;
        public static Guid CreateOpportunity(
            int contractType,
            string contractId,
            string dateofsignature,
            string sellerfirstname,
            string sellerlastname,
            string sellerid,
            bool closedinspaces,
            bool fixedtermcontract,
            string fromfixedtermcontract,
            string tofixedtermcontract,
            bool fixedtermcontract1,
            int fixedtermcontractyears,
            string fromindefiniteperiodcontract,
            bool indefiniteperiodcontract,
            string productname,
            Guid customerid,
            string customerLogicalName,
            string auctionnumber,
            string importnumber,
            Money individualpriceVT,
            Money individualpriceNT,
            Money stableprice,
            Guid seller_Guid

            )
        {
            try
            {

                //171 140 000 ele 171 140 001 plyn cre_contracttypecode
                Entity opportunity = new Entity("opportunity");
                //opportunity["name"] = "Smlouva č." + contractId;
                if (contractType == 171140000) contractType = 171140001;//plyn
                else if (contractType == 171140001) contractType = 171140000;//ele
                opportunity["cre_auctionnumber"] = auctionnumber;
                opportunity["cre_importnumber"] = importnumber;



                opportunity["cre_stableprice"] = stableprice;


                if (contractType == 171140001)
                    opportunity["cre_individualprice_gas"] = individualpriceVT;
                else
                {
                    opportunity["cre_individualpricemwh"] = individualpriceVT;
                    opportunity["cre_individualpricent"] = individualpriceNT;
                }

                opportunity["cre_contracttypecode"] = new OptionSetValue(contractType);
                opportunity["cre_contractid"] = contractId;
                if (dateofsignature != "") opportunity["cre_dateofsignature"] = DateTime.Parse(dateofsignature);
                //opportunity["cre_seller"] = seller;
                opportunity["cre_sellerfirstname"] = sellerfirstname;
                opportunity["cre_sellerlastname"] = sellerlastname;
                opportunity["cre_sellerid"] = sellerid;
                opportunity["cre_closedinspaces"] = closedinspaces; //uzavreno mimo prostory obvykle k podnikani
                opportunity["cre_fixedtermcontract"] = fixedtermcontract;
                if (fromfixedtermcontract != "") opportunity["cre_fromfixedtermcontract"] = DateTime.Parse(fromfixedtermcontract);
                if (tofixedtermcontract != "") opportunity["cre_tofixedtermcontract"] = DateTime.Parse(tofixedtermcontract);
                opportunity["cre_fixedtermcontract1"] = fixedtermcontract1;
                opportunity["cre_fixedtermcontractyears"] = new OptionSetValue(fixedtermcontractyears);
                if (fromindefiniteperiodcontract != "") opportunity["cre_fromindefiniteperiodcontract"] = DateTime.Parse(fromindefiniteperiodcontract);
                opportunity["cre_indefiniteperiodcontract"] = indefiniteperiodcontract;
                opportunity["cre_productname"] = productname;
                opportunity["customerid"] = new EntityReference { LogicalName = customerLogicalName, Id = customerid };

                if (seller_Guid != Guid.Empty)
                    opportunity["cre_seller"] = new EntityReference { LogicalName = "contact", Id = seller_Guid };

                contactId = ServiceControl.Create(opportunity, ServiceControl.GetService());
                logicalName = opportunity.LogicalName;



                return contactId;
            }
            catch (Exception ex)
            {
                Logger.WriteLine("Opp Zaslání e-mailu s chybou: " + ex.Message);
                EmaiSender.SendError("consoleApp error Opp", ex.Message);
                return Guid.Empty;
            }
        }
        public static string GetLogicalName()
        {
            return logicalName;
        }
        public static Guid GetId()
        {
            return contactId;
        }
    }
}
