﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
   
    public enum ContractType
    { 
        gas,
        electric,
        both,
    }

    public enum ContractMode
    { 
        person,
        company
    }

    public enum AccountRoleCode
    {
        AccountContact = 171140003,
        VerifyContact = 171140002,
    }

}
