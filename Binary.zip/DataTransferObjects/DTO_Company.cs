﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTransferObjects
{
  public  class DTO_Company
    {

    }
}
